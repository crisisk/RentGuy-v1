# VPS Infrastructure Integration Plan

**Target Environment:** dakslopers.nl VPS  
**Current Services:** PSRA Tool + Monitoring Stack  
**Integration Goal:** Multi-tenant architecture with RentGuy + WP Control Suite  

---

## 🏗️ **Current Infrastructure Analysis**

### Active Services (from dockerstatus.txt)

| Service | Technology | Port | Status | Notes |
|---------|------------|------|--------|-------|
| **PSRA Frontend** | Next.js | 3000 | ⚠️ CONFLICT | Conflicts with Grafana |
| **PSRA Backend** | API | 8001, 4203 | ✅ ACTIVE | Multiple ports |
| **PSRA Database** | PostgreSQL | 5432 | ✅ ACTIVE | Shared resource |
| **PSRA Redis** | Redis | 6379 | ✅ ACTIVE | Caching layer |
| **Keycloak** | Auth Service | 8080 | ✅ ACTIVE | SSO provider |
| **NGINX** | Reverse Proxy | 80, 443 | ✅ ACTIVE | Entry point |
| **Prometheus** | Monitoring | 9090 | ✅ ACTIVE | Metrics collection |
| **Grafana** | Monitoring UI | 3000 | ⚠️ CONFLICT | Conflicts with PSRA |

### Critical Issues Identified

1. **Port 3000 Conflict:** PSRA Frontend vs Grafana
2. **Resource Sharing:** Single PostgreSQL for multiple apps
3. **NGINX Routing:** No multi-tenant configuration
4. **Service Isolation:** All services in single network

---

## 🎯 **Target Multi-Tenant Architecture**

### Port Reassignment Strategy

```
Current → Target
PSRA Frontend:    3000 → 3001
RentGuy Frontend: ---- → 3002  
WP Suite Frontend: --- → 3003
Grafana:          3000 → 3004

Backend Services:
PSRA Backend:     8001, 4203 (unchanged)
RentGuy Backend:  ---- → 8002
WP Suite Backend: ---- → 8003
```

### Service Topology

```
┌─────────────────────────────────────────────────────────┐
│                    NGINX (80/443)                      │
│  ┌─────────────────────────────────────────────────┐   │
│  │              SSL Termination                    │   │
│  │              Load Balancing                     │   │
│  │              Path-based Routing                 │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────┬───────────────────────────────────────┘
                  │
    ┌─────────────┼─────────────┬─────────────┐
    │             │             │             │
┌───▼───┐    ┌────▼────┐   ┌────▼────┐   ┌───▼───┐
│ PSRA  │    │RentGuy  │   │WP Suite │   │Monitor│
│(3001) │    │ (3002)  │   │ (3003)  │   │(3004) │
└───┬───┘    └────┬────┘   └────┬────┘   └───────┘
    │             │             │
┌───▼───┐    ┌────▼────┐   ┌────▼────┐
│Backend│    │Backend  │   │Backend  │
│(8001) │    │ (8002)  │   │ (8003)  │
└───┬───┘    └────┬────┘   └────┬────┘
    │             │             │
    └─────────────┼─────────────┘
                  │
        ┌─────────▼─────────┐
        │   Shared Services │
        │ PostgreSQL (5432) │
        │   Redis (6379)    │
        │  Keycloak (8080)  │
        └───────────────────┘
```

---

## 🔧 **Implementation Steps**

### Phase 1: Port Conflict Resolution (30 minutes)

**1.1 Update PSRA Frontend Port**
```bash
# Update docker-compose.yml for PSRA
services:
  psra-frontend:
    ports:
      - "3001:3000"  # Changed from 3000:3000
```

**1.2 Update Grafana Port**
```bash
# Update monitoring docker-compose.yml
services:
  grafana:
    ports:
      - "3004:3000"  # Changed from 3000:3000
```

**1.3 Restart Affected Services**
```bash
docker-compose down psra-frontend grafana
docker-compose up -d psra-frontend grafana
```

### Phase 2: NGINX Multi-Tenant Configuration (45 minutes)

**2.1 Create Multi-Tenant NGINX Config**
```nginx
# /etc/nginx/sites-available/multi-tenant
server {
    listen 80;
    listen 443 ssl http2;
    server_name dakslopers.nl;
    
    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/dakslopers.nl/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/dakslopers.nl/privkey.pem;
    
    # PSRA Tool (Main Application)
    location / {
        proxy_pass http://localhost:3001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # RentGuy Application
    location /rentguy/ {
        proxy_pass http://localhost:3002/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # WP Control Suite
    location /wp-suite/ {
        proxy_pass http://localhost:3003/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Monitoring (Grafana)
    location /monitoring/ {
        proxy_pass http://localhost:3004/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # API Endpoints
    location /api/psra/ {
        proxy_pass http://localhost:8001/;
    }
    
    location /api/rentguy/ {
        proxy_pass http://localhost:8002/;
    }
    
    location /api/wp-suite/ {
        proxy_pass http://localhost:8003/;
    }
}
```

**2.2 Enable and Test Configuration**
```bash
sudo ln -sf /etc/nginx/sites-available/multi-tenant /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Phase 3: RentGuy Deployment (60 minutes)

**3.1 Create RentGuy Docker Compose**
```yaml
# /opt/rentguy/docker-compose.yml
version: "3.9"

services:
  rentguy-frontend:
    build: 
      context: ./apps/web
      dockerfile: Dockerfile
    ports:
      - "3002:3000"
    environment:
      - REACT_APP_API_URL=https://dakslopers.nl/api/rentguy
    depends_on:
      - rentguy-backend
    networks:
      - rentguy_network

  rentguy-backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    ports:
      - "8002:8000"
    environment:
      - DATABASE_URL=postgresql+psycopg://rentguy:${RENTGUY_DB_PASSWORD}@postgres:5432/rentguy
      - JWT_SECRET=${RENTGUY_JWT_SECRET}
    depends_on:
      postgres:
        condition: service_healthy
    networks:
      - rentguy_network
      - shared_network

  postgres:
    image: postgres:16
    environment:
      POSTGRES_DB: rentguy
      POSTGRES_USER: rentguy
      POSTGRES_PASSWORD: ${RENTGUY_DB_PASSWORD}
    volumes:
      - rentguy_db_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U rentguy -d rentguy"]
      interval: 10s
      timeout: 5s
      retries: 5
    networks:
      - rentguy_network

volumes:
  rentguy_db_data:

networks:
  rentguy_network:
    driver: bridge
  shared_network:
    external: true
```

**3.2 Environment Configuration**
```bash
# /opt/rentguy/.env
RENTGUY_DB_PASSWORD=secure_rentguy_password_2025
RENTGUY_JWT_SECRET=rentguy_jwt_secret_key_production_2025
RENTGUY_SMTP_HOST=smtp.gmail.com
RENTGUY_SMTP_PORT=587
RENTGUY_SMTP_USER=noreply@dakslopers.nl
RENTGUY_SMTP_PASSWORD=smtp_app_password
```

**3.3 Deploy RentGuy**
```bash
cd /opt/rentguy
docker-compose up -d
docker-compose logs -f
```

### Phase 4: Monitoring Integration (30 minutes)

**4.1 Update Prometheus Configuration**
```yaml
# Add to prometheus.yml
- job_name: 'rentguy-backend'
  static_configs:
    - targets: ['localhost:8002']
  metrics_path: '/metrics'
  scrape_interval: 30s

- job_name: 'wp-control-suite'
  static_configs:
    - targets: ['localhost:8003']
  metrics_path: '/health'
  scrape_interval: 30s
```

**4.2 Create Grafana Dashboards**
```json
{
  "dashboard": {
    "title": "Multi-Tenant Application Monitoring",
    "panels": [
      {
        "title": "PSRA Health",
        "targets": [{"expr": "up{job=\"psra-backend\"}"}]
      },
      {
        "title": "RentGuy Health", 
        "targets": [{"expr": "up{job=\"rentguy-backend\"}"}]
      },
      {
        "title": "WP Suite Health",
        "targets": [{"expr": "up{job=\"wp-control-suite\"}"}]
      }
    ]
  }
}
```

---

## 🔐 **Security Configuration**

### SSL/TLS Setup

**Current SSL Status:** ✅ Active for dakslopers.nl  
**Required Updates:** None (existing certificates work for all paths)

### Authentication Integration

**Strategy:** Unified Keycloak SSO

```javascript
// Frontend authentication configuration
const keycloakConfig = {
  url: 'https://dakslopers.nl/auth/',
  realm: 'dakslopers',
  clientId: 'multi-tenant-app'
}

// Service-specific clients
const clients = {
  psra: 'psra-frontend',
  rentguy: 'rentguy-frontend', 
  wpSuite: 'wp-suite-frontend'
}
```

### Environment Security

```bash
# Secure environment variables
KEYCLOAK_ADMIN_PASSWORD=secure_keycloak_admin_2025
POSTGRES_MASTER_PASSWORD=secure_postgres_master_2025
REDIS_PASSWORD=secure_redis_password_2025

# Application-specific secrets
PSRA_DB_PASSWORD=secure_psra_db_2025
RENTGUY_DB_PASSWORD=secure_rentguy_db_2025
WP_SUITE_DB_PASSWORD=secure_wp_suite_db_2025
```

---

## 📊 **Resource Management**

### Current Resource Usage

```bash
# Check current usage
docker stats --no-stream
free -h
df -h
```

### Resource Allocation Plan

| Service | CPU Limit | Memory Limit | Storage |
|---------|-----------|--------------|---------|
| PSRA Frontend | 0.5 CPU | 512MB | - |
| PSRA Backend | 1.0 CPU | 1GB | - |
| RentGuy Frontend | 0.5 CPU | 512MB | - |
| RentGuy Backend | 1.0 CPU | 1GB | - |
| WP Suite Frontend | 0.5 CPU | 512MB | - |
| WP Suite Backend | 1.0 CPU | 1GB | - |
| PostgreSQL | 2.0 CPU | 2GB | 20GB |
| Redis | 0.5 CPU | 256MB | 1GB |
| NGINX | 0.5 CPU | 256MB | - |

### Scaling Considerations

**Horizontal Scaling:**
- Load balancer for multiple frontend instances
- Database read replicas for scaling
- Redis cluster for session management

**Vertical Scaling:**
- Monitor resource usage patterns
- Adjust limits based on actual usage
- Plan for peak load scenarios

---

## 🚨 **Risk Mitigation**

### Deployment Risks

| Risk | Impact | Probability | Mitigation |
|------|--------|-------------|------------|
| Port conflicts | High | Medium | Systematic port reassignment |
| Service downtime | High | Low | Rolling deployment strategy |
| Database conflicts | Medium | Low | Separate databases per app |
| SSL certificate issues | Medium | Low | Test certificate renewal |
| Resource exhaustion | High | Medium | Resource monitoring & limits |

### Rollback Procedures

**Emergency Rollback (< 5 minutes):**
```bash
# Revert NGINX configuration
sudo cp /etc/nginx/sites-available/psra-only /etc/nginx/sites-enabled/default
sudo systemctl reload nginx

# Stop new services
docker-compose -f /opt/rentguy/docker-compose.yml down
docker-compose -f /opt/wp-suite/docker-compose.yml down

# Restore original ports
docker-compose -f /opt/psra/docker-compose.yml down
# Edit ports back to original
docker-compose -f /opt/psra/docker-compose.yml up -d
```

**Planned Rollback (30 minutes):**
```bash
# Graceful service shutdown
# Data backup and preservation
# Clean environment restoration
# Service validation
```

---

## 📈 **Performance Optimization**

### Database Optimization

```sql
-- RentGuy database tuning
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
ALTER SYSTEM SET checkpoint_completion_target = 0.9;
ALTER SYSTEM SET wal_buffers = '16MB';
```

### Caching Strategy

```yaml
# Redis configuration for multi-tenant caching
redis:
  databases:
    0: psra_cache
    1: rentguy_cache
    2: wp_suite_cache
    3: shared_sessions
```

### CDN Integration

```nginx
# Static asset optimization
location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
    add_header Vary Accept-Encoding;
    gzip_static on;
}
```

---

## 🔍 **Health Monitoring**

### Service Health Checks

```bash
#!/bin/bash
# /opt/scripts/health-check.sh

services=("psra:3001" "rentguy:3002" "wp-suite:3003" "grafana:3004")

for service in "${services[@]}"; do
    name=${service%:*}
    port=${service#*:}
    
    if curl -f -s "http://localhost:$port/health" > /dev/null; then
        echo "✅ $name is healthy"
    else
        echo "❌ $name is unhealthy"
        # Send alert
        curl -X POST "https://hooks.slack.com/..." \
             -d "{\"text\":\"🚨 $name service is down\"}"
    fi
done
```

### Automated Monitoring

```yaml
# Prometheus alerting rules
groups:
  - name: multi-tenant-alerts
    rules:
      - alert: ServiceDown
        expr: up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Service {{ $labels.job }} is down"
          
      - alert: HighMemoryUsage
        expr: container_memory_usage_bytes / container_spec_memory_limit_bytes > 0.9
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High memory usage on {{ $labels.name }}"
```

---

## 📋 **Deployment Checklist**

### Pre-Deployment
- [ ] Backup current PSRA configuration
- [ ] Verify resource availability
- [ ] Test port assignments
- [ ] Prepare rollback procedures
- [ ] Schedule maintenance window

### Deployment Execution
- [ ] Phase 1: Resolve port conflicts (30 min)
- [ ] Phase 2: Update NGINX configuration (45 min)
- [ ] Phase 3: Deploy RentGuy services (60 min)
- [ ] Phase 4: Configure monitoring (30 min)
- [ ] Phase 5: End-to-end testing (30 min)

### Post-Deployment Validation
- [ ] All services responding on correct ports
- [ ] NGINX routing working correctly
- [ ] SSL certificates valid for all paths
- [ ] Authentication flow functional
- [ ] Monitoring dashboards updated
- [ ] Performance metrics within limits
- [ ] Backup systems operational

### Success Criteria
- [ ] PSRA tool accessible at https://dakslopers.nl/
- [ ] RentGuy accessible at https://dakslopers.nl/rentguy/
- [ ] All services healthy in monitoring
- [ ] No port conflicts remaining
- [ ] Response times < 2 seconds
- [ ] Zero downtime during deployment

---

**This integration plan provides a complete roadmap for adding RentGuy and WP Control Suite to the existing PSRA infrastructure while maintaining service availability and performance.**
