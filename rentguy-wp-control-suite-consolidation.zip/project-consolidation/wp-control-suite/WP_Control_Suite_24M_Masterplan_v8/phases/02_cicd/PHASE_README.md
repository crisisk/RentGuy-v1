# CI/CD & Integratie — (02_cicd)
**Doel:** Matrix deploy, GHCR images, SSL jobs, Slack notify

**Tijdlijn:** Maand 4–6  
**Branch:** `feat/02_cicd`

## Deliverables (kern)
- Zie `TASKS.csv` en `CHECKLIST.md` (gate: port-lint, nginx -t, tests)
- KPI's in `KPIS.yaml`
- Workflow: `n8n/` + `ci/`
- ManusAI Superprompt: `ManusAI_SUPERPROMPT.txt`
- Integratie met v6 baseline (compose overlay, NGINX, Prometheus)
