# AI SEO & Reviews — (04_ai_seo_reviews)
**Doel:** SEO Fixer 2.0, AI replies, topic hubs

**Tijdlijn:** Maand 10–12  
**Branch:** `feat/04_ai_seo_reviews`

## Deliverables (kern)
- Zie `TASKS.csv` en `CHECKLIST.md` (gate: port-lint, nginx -t, tests)
- KPI's in `KPIS.yaml`
- Workflow: `n8n/` + `ci/`
- ManusAI Superprompt: `ManusAI_SUPERPROMPT.txt`
- Integratie met v6 baseline (compose overlay, NGINX, Prometheus)
