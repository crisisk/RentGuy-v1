# Automation Scaling — (08_automation_scaling)
**Doel:** Queues, event bus, async pipelines

**Tijdlijn:** Maand 22–24  
**Branch:** `feat/08_automation_scaling`

## Deliverables (kern)
- Zie `TASKS.csv` en `CHECKLIST.md` (gate: port-lint, nginx -t, tests)
- KPI's in `KPIS.yaml`
- Workflow: `n8n/` + `ci/`
- ManusAI Superprompt: `ManusAI_SUPERPROMPT.txt`
- Integratie met v6 baseline (compose overlay, NGINX, Prometheus)
