# Data Warehouse & API — (09_data_warehouse_api)
**Doel:** Clickhouse/ELK, public API, quotas

**Tijdlijn:** Maand 25–26  
**Branch:** `feat/09_data_warehouse_api`

## Deliverables (kern)
- Zie `TASKS.csv` en `CHECKLIST.md` (gate: port-lint, nginx -t, tests)
- KPI's in `KPIS.yaml`
- Workflow: `n8n/` + `ci/`
- ManusAI Superprompt: `ManusAI_SUPERPROMPT.txt`
- Integratie met v6 baseline (compose overlay, NGINX, Prometheus)
