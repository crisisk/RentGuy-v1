# Stabilisatie & PSRA MVP — (01_stabilization)
**Doel:** PSRA health, backups, monitoring, WP Control draft pipelines

**Tijdlijn:** Maand 1–3  
**Branch:** `feat/01_stabilization`

## Deliverables (kern)
- Zie `TASKS.csv` en `CHECKLIST.md` (gate: port-lint, nginx -t, tests)
- KPI's in `KPIS.yaml`
- Workflow: `n8n/` + `ci/`
- ManusAI Superprompt: `ManusAI_SUPERPROMPT.txt`
- Integratie met v6 baseline (compose overlay, NGINX, Prometheus)
