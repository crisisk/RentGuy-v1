Voeg specifieke CI-jobs toe voor deze fase (lint/tests/deploy gates).
