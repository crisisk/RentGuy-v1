# AI Orchestrator — (10_ai_orchestrator)
**Doel:** ManusAI Ops Copilot, approvals

**Tijdlijn:** Maand 27–28  
**Branch:** `feat/10_ai_orchestrator`

## Deliverables (kern)
- Zie `TASKS.csv` en `CHECKLIST.md` (gate: port-lint, nginx -t, tests)
- KPI's in `KPIS.yaml`
- Workflow: `n8n/` + `ci/`
- ManusAI Superprompt: `ManusAI_SUPERPROMPT.txt`
- Integratie met v6 baseline (compose overlay, NGINX, Prometheus)
