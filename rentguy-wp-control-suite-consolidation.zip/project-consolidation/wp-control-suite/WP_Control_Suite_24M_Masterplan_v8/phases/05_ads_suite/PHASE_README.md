# Ads Suite — (05_ads_suite)
**Doel:** Google/Meta connectors, budgets, ROAS

**Tijdlijn:** Maand 13–15  
**Branch:** `feat/05_ads_suite`

## Deliverables (kern)
- Zie `TASKS.csv` en `CHECKLIST.md` (gate: port-lint, nginx -t, tests)
- KPI's in `KPIS.yaml`
- Workflow: `n8n/` + `ci/`
- ManusAI Superprompt: `ManusAI_SUPERPROMPT.txt`
- Integratie met v6 baseline (compose overlay, NGINX, Prometheus)
