# Social Suite — (06_social_suite)
**Doel:** Scheduler, listening, sentiment

**Tijdlijn:** Maand 16–18  
**Branch:** `feat/06_social_suite`

## Deliverables (kern)
- Zie `TASKS.csv` en `CHECKLIST.md` (gate: port-lint, nginx -t, tests)
- KPI's in `KPIS.yaml`
- Workflow: `n8n/` + `ci/`
- ManusAI Superprompt: `ManusAI_SUPERPROMPT.txt`
- Integratie met v6 baseline (compose overlay, NGINX, Prometheus)
