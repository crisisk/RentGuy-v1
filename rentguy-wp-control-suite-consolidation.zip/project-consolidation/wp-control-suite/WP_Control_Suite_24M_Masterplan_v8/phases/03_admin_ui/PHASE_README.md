# Admin UI — (03_admin_ui)
**Doel:** React dashboard, RBAC, audit-trail

**Tijdlijn:** Maand 7–9  
**Branch:** `feat/03_admin_ui`

## Deliverables (kern)
- Zie `TASKS.csv` en `CHECKLIST.md` (gate: port-lint, nginx -t, tests)
- KPI's in `KPIS.yaml`
- Workflow: `n8n/` + `ci/`
- ManusAI Superprompt: `ManusAI_SUPERPROMPT.txt`
- Integratie met v6 baseline (compose overlay, NGINX, Prometheus)
