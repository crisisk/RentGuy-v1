## Context
- Phase:
- Service(s):
- Related PR(s):

## Acceptance Criteria
- [ ] Tests added/passing
- [ ] Port-lint / nginx -t OK
- [ ] Security reviewed
- [ ] Rollback plan documented
