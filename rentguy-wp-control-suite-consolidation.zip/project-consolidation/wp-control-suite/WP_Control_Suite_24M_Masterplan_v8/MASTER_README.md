# WP Control Suite — 24M Masterplan (v8)
_Generated: 2025-09-29_

Dit pakket integreert **alle 10 fasen** uit de 24-maanden roadmap in één uitvoerbare structuur.
Elke fase bevat: taken, checklists, KPI's, ManusAI-superprompt, en n8n-workflow stubs.
Koppel dit masterplan aan je **v6 baseline** (compose overlay + NGINX + CI/CD).

## Navigatie
- `phases/01_stabilization/` … `phases/10_ai_orchestrator/`
- `global/` — gedeelde sjablonen (issue/PR/risk), OKR matrix, owners
- `ROADMAP_SUMMARY.md` en `ROADMAP_GANTT.html`

## Start
1) Lees `phases/01_stabilization/PHASE_README.md`
2) Maak een feature branch `feat/fase-1-stabilisatie`
3) Volg `CHECKLIST.md` en draai de n8n/ManusAI stappen
4) PR met CI-checks → merge → deploy naar **staging**, daarna **prod**
