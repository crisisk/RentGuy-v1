# Roadmap — Samenvatting (10 fasen)
1) Stabilisatie (0–3m) — PSRA MVP, monitoring, backups
2) CI/CD (3–6m) — matrix deploy, GHCR, SSL-jobs, Slack notify
3) Admin UI (6–9m) — React dashboard, RBAC, audit-trail
4) AI SEO & Reviews (9–12m) — detect→fix→approve
5) Ads Suite (12–15m) — Google/Meta, budget rules, ROAS
6) Social Suite (15–18m) — planner, listening, sentiment
7) Multi-tenant SaaS (18–21m) — tenants, billing
8) Automation Scaling (21–24m) — queues, event bus, Traefik
9) Data Warehouse & API (24m+) — DW + public API
10) AI Orchestrator (24m+) — ManusAI Ops Copilot
