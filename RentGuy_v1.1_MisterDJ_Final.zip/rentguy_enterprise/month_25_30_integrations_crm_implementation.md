# Month 25-30 Implementation: Integrations & CRM for RentGuy AV Rental Platform

## Overview
This document provides comprehensive implementations for the Month 25-30 roadmap tasks focusing on Integrations & CRM features specifically designed for the RentGuy AV rental platform. These implementations enable native CRM capabilities, Invoice Ninja integration, multi-tenant support, and GDPR compliance for AV rental operations.

## 1. Native RentGuy CRM System (Replacing HubSpot)

### Core CRM Service Implementation

```python
# services/rentguy_crm_service.py
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import json
import uuid
from abc import ABC, abstractmethod

class LeadStatus(Enum):
    NEW = "new"
    CONTACTED = "contacted"
    QUALIFIED = "qualified"
    PROPOSAL_SENT = "proposal_sent"
    NEGOTIATING = "negotiating"
    WON = "won"
    LOST = "lost"
    NURTURING = "nurturing"

class CustomerType(Enum):
    INDIVIDUAL = "individual"
    CORPORATE = "corporate"
    EVENT_PLANNER = "event_planner"
    PRODUCTION_COMPANY = "production_company"
    VENUE = "venue"
    RENTAL_PARTNER = "rental_partner"

class ContactMethod(Enum):
    EMAIL = "email"
    PHONE = "phone"
    SMS = "sms"
    WHATSAPP = "whatsapp"
    IN_PERSON = "in_person"
    WEBSITE_FORM = "website_form"

class EventType(Enum):
    WEDDING = "wedding"
    CORPORATE_EVENT = "corporate_event"
    CONFERENCE = "conference"
    CONCERT = "concert"
    FESTIVAL = "festival"
    PRIVATE_PARTY = "private_party"
    TRADE_SHOW = "trade_show"
    THEATER_PRODUCTION = "theater_production"
    FILM_PRODUCTION = "film_production"
    OTHER = "other"

@dataclass
class Lead:
    lead_id: str
    first_name: str
    last_name: str
    email: str
    phone: Optional[str]
    company: Optional[str]
    status: LeadStatus
    source: str
    created_at: datetime
    updated_at: datetime
    assigned_to: Optional[str] = None
    expected_event_date: Optional[datetime] = None
    event_type: Optional[EventType] = None
    estimated_budget: Optional[float] = None
    equipment_interests: List[str] = None
    notes: List[str] = None
    tags: List[str] = None
    custom_fields: Dict[str, Any] = None
    last_contact_date: Optional[datetime] = None
    next_follow_up: Optional[datetime] = None
    conversion_probability: float = 0.0

@dataclass
class Customer:
    customer_id: str
    first_name: str
    last_name: str
    email: str
    phone: Optional[str]
    company: Optional[str]
    customer_type: CustomerType
    created_at: datetime
    updated_at: datetime
    billing_address: Dict[str, str]
    delivery_address: Dict[str, str]
    payment_terms: str = "net_30"
    credit_limit: float = 0.0
    tax_id: Optional[str] = None
    preferred_contact_method: ContactMethod = ContactMethod.EMAIL
    rental_history: List[str] = None
    total_spent: float = 0.0
    average_order_value: float = 0.0
    last_rental_date: Optional[datetime] = None
    customer_lifetime_value: float = 0.0
    risk_score: float = 0.0
    preferences: Dict[str, Any] = None
    notes: List[str] = None
    tags: List[str] = None

@dataclass
class Opportunity:
    opportunity_id: str
    customer_id: str
    lead_id: Optional[str]
    name: str
    description: str
    event_date: datetime
    event_type: EventType
    venue: str
    estimated_value: float
    probability: float
    stage: str
    created_at: datetime
    updated_at: datetime
    assigned_to: str
    equipment_requirements: List[Dict[str, Any]]
    competitors: List[str] = None
    decision_makers: List[str] = None
    timeline: Dict[str, datetime] = None
    budget_constraints: Dict[str, Any] = None
    special_requirements: List[str] = None
    proposal_sent_date: Optional[datetime] = None
    expected_close_date: Optional[datetime] = None
    actual_close_date: Optional[datetime] = None
    won_reason: Optional[str] = None
    lost_reason: Optional[str] = None

@dataclass
class Activity:
    activity_id: str
    related_to_type: str  # lead, customer, opportunity
    related_to_id: str
    activity_type: str
    subject: str
    description: str
    created_by: str
    created_at: datetime
    scheduled_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    status: str = "pending"
    priority: str = "medium"
    duration_minutes: Optional[int] = None
    location: Optional[str] = None
    attendees: List[str] = None
    outcome: Optional[str] = None
    follow_up_required: bool = False
    next_action: Optional[str] = None

class RentGuyCRMService:
    def __init__(self, invoice_ninja_service=None):
        self.leads = {}
        self.customers = {}
        self.opportunities = {}
        self.activities = []
        self.sales_pipeline = SalesPipeline()
        self.lead_scoring = LeadScoringEngine()
        self.automation_engine = CRMAutomationEngine()
        self.invoice_ninja_service = invoice_ninja_service
        self.analytics = CRMAnalytics()
    
    # Lead Management
    async def create_lead(self, lead_data: Dict[str, Any]) -> Lead:
        """Create a new lead"""
        try:
            lead = Lead(
                lead_id=str(uuid.uuid4()),
                first_name=lead_data["first_name"],
                last_name=lead_data["last_name"],
                email=lead_data["email"],
                phone=lead_data.get("phone"),
                company=lead_data.get("company"),
                status=LeadStatus.NEW,
                source=lead_data.get("source", "unknown"),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                assigned_to=lead_data.get("assigned_to"),
                expected_event_date=lead_data.get("expected_event_date"),
                event_type=EventType(lead_data["event_type"]) if lead_data.get("event_type") else None,
                estimated_budget=lead_data.get("estimated_budget"),
                equipment_interests=lead_data.get("equipment_interests", []),
                notes=lead_data.get("notes", []),
                tags=lead_data.get("tags", []),
                custom_fields=lead_data.get("custom_fields", {})
            )
            
            # Calculate initial lead score
            lead.conversion_probability = await self.lead_scoring.calculate_score(lead)
            
            # Store lead
            self.leads[lead.lead_id] = lead
            
            # Trigger automation
            await self.automation_engine.trigger_lead_created(lead)
            
            print(f"Lead created: {lead.first_name} {lead.last_name} ({lead.email})")
            return lead
            
        except Exception as e:
            print(f"Failed to create lead: {e}")
            raise
    
    async def update_lead(self, lead_id: str, updates: Dict[str, Any]) -> Optional[Lead]:
        """Update an existing lead"""
        try:
            if lead_id not in self.leads:
                return None
            
            lead = self.leads[lead_id]
            old_status = lead.status
            
            # Update fields
            for key, value in updates.items():
                if hasattr(lead, key):
                    if key == "status":
                        lead.status = LeadStatus(value)
                    elif key == "event_type":
                        lead.event_type = EventType(value) if value else None
                    else:
                        setattr(lead, key, value)
            
            lead.updated_at = datetime.utcnow()
            
            # Recalculate lead score
            lead.conversion_probability = await self.lead_scoring.calculate_score(lead)
            
            # Trigger automation if status changed
            if old_status != lead.status:
                await self.automation_engine.trigger_lead_status_changed(lead, old_status)
            
            print(f"Lead updated: {lead.lead_id}")
            return lead
            
        except Exception as e:
            print(f"Failed to update lead {lead_id}: {e}")
            return None
    
    async def convert_lead_to_customer(self, lead_id: str, customer_data: Dict[str, Any]) -> Optional[Customer]:
        """Convert a lead to a customer"""
        try:
            if lead_id not in self.leads:
                return None
            
            lead = self.leads[lead_id]
            
            # Create customer from lead
            customer = Customer(
                customer_id=str(uuid.uuid4()),
                first_name=lead.first_name,
                last_name=lead.last_name,
                email=lead.email,
                phone=lead.phone,
                company=lead.company,
                customer_type=CustomerType(customer_data.get("customer_type", "individual")),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                billing_address=customer_data.get("billing_address", {}),
                delivery_address=customer_data.get("delivery_address", {}),
                payment_terms=customer_data.get("payment_terms", "net_30"),
                credit_limit=customer_data.get("credit_limit", 0.0),
                tax_id=customer_data.get("tax_id"),
                preferred_contact_method=ContactMethod(customer_data.get("preferred_contact_method", "email")),
                rental_history=[],
                total_spent=0.0,
                average_order_value=0.0,
                customer_lifetime_value=0.0,
                risk_score=0.0,
                preferences=customer_data.get("preferences", {}),
                notes=lead.notes or [],
                tags=lead.tags or []
            )
            
            # Store customer
            self.customers[customer.customer_id] = customer
            
            # Update lead status
            await self.update_lead(lead_id, {"status": "won"})
            
            # Create customer in Invoice Ninja if integrated
            if self.invoice_ninja_service:
                await self.invoice_ninja_service.create_customer(customer)
            
            # Trigger automation
            await self.automation_engine.trigger_lead_converted(lead, customer)
            
            print(f"Lead converted to customer: {customer.customer_id}")
            return customer
            
        except Exception as e:
            print(f"Failed to convert lead {lead_id}: {e}")
            return None
    
    # Customer Management
    async def create_customer(self, customer_data: Dict[str, Any]) -> Customer:
        """Create a new customer directly"""
        try:
            customer = Customer(
                customer_id=str(uuid.uuid4()),
                first_name=customer_data["first_name"],
                last_name=customer_data["last_name"],
                email=customer_data["email"],
                phone=customer_data.get("phone"),
                company=customer_data.get("company"),
                customer_type=CustomerType(customer_data.get("customer_type", "individual")),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                billing_address=customer_data.get("billing_address", {}),
                delivery_address=customer_data.get("delivery_address", {}),
                payment_terms=customer_data.get("payment_terms", "net_30"),
                credit_limit=customer_data.get("credit_limit", 0.0),
                tax_id=customer_data.get("tax_id"),
                preferred_contact_method=ContactMethod(customer_data.get("preferred_contact_method", "email")),
                rental_history=[],
                total_spent=0.0,
                average_order_value=0.0,
                customer_lifetime_value=0.0,
                risk_score=0.0,
                preferences=customer_data.get("preferences", {}),
                notes=customer_data.get("notes", []),
                tags=customer_data.get("tags", [])
            )
            
            # Store customer
            self.customers[customer.customer_id] = customer
            
            # Create customer in Invoice Ninja if integrated
            if self.invoice_ninja_service:
                await self.invoice_ninja_service.create_customer(customer)
            
            # Trigger automation
            await self.automation_engine.trigger_customer_created(customer)
            
            print(f"Customer created: {customer.first_name} {customer.last_name} ({customer.email})")
            return customer
            
        except Exception as e:
            print(f"Failed to create customer: {e}")
            raise
    
    async def update_customer(self, customer_id: str, updates: Dict[str, Any]) -> Optional[Customer]:
        """Update an existing customer"""
        try:
            if customer_id not in self.customers:
                return None
            
            customer = self.customers[customer_id]
            
            # Update fields
            for key, value in updates.items():
                if hasattr(customer, key):
                    if key == "customer_type":
                        customer.customer_type = CustomerType(value)
                    elif key == "preferred_contact_method":
                        customer.preferred_contact_method = ContactMethod(value)
                    else:
                        setattr(customer, key, value)
            
            customer.updated_at = datetime.utcnow()
            
            # Update customer in Invoice Ninja if integrated
            if self.invoice_ninja_service:
                await self.invoice_ninja_service.update_customer(customer)
            
            print(f"Customer updated: {customer.customer_id}")
            return customer
            
        except Exception as e:
            print(f"Failed to update customer {customer_id}: {e}")
            return None
    
    # Opportunity Management
    async def create_opportunity(self, opportunity_data: Dict[str, Any]) -> Opportunity:
        """Create a new sales opportunity"""
        try:
            opportunity = Opportunity(
                opportunity_id=str(uuid.uuid4()),
                customer_id=opportunity_data["customer_id"],
                lead_id=opportunity_data.get("lead_id"),
                name=opportunity_data["name"],
                description=opportunity_data["description"],
                event_date=opportunity_data["event_date"],
                event_type=EventType(opportunity_data["event_type"]),
                venue=opportunity_data["venue"],
                estimated_value=opportunity_data["estimated_value"],
                probability=opportunity_data.get("probability", 0.5),
                stage=opportunity_data.get("stage", "qualification"),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                assigned_to=opportunity_data["assigned_to"],
                equipment_requirements=opportunity_data.get("equipment_requirements", []),
                competitors=opportunity_data.get("competitors", []),
                decision_makers=opportunity_data.get("decision_makers", []),
                timeline=opportunity_data.get("timeline", {}),
                budget_constraints=opportunity_data.get("budget_constraints", {}),
                special_requirements=opportunity_data.get("special_requirements", []),
                expected_close_date=opportunity_data.get("expected_close_date")
            )
            
            # Store opportunity
            self.opportunities[opportunity.opportunity_id] = opportunity
            
            # Add to sales pipeline
            await self.sales_pipeline.add_opportunity(opportunity)
            
            # Trigger automation
            await self.automation_engine.trigger_opportunity_created(opportunity)
            
            print(f"Opportunity created: {opportunity.name} (€{opportunity.estimated_value})")
            return opportunity
            
        except Exception as e:
            print(f"Failed to create opportunity: {e}")
            raise
    
    async def update_opportunity(self, opportunity_id: str, updates: Dict[str, Any]) -> Optional[Opportunity]:
        """Update an existing opportunity"""
        try:
            if opportunity_id not in self.opportunities:
                return None
            
            opportunity = self.opportunities[opportunity_id]
            old_stage = opportunity.stage
            
            # Update fields
            for key, value in updates.items():
                if hasattr(opportunity, key):
                    if key == "event_type":
                        opportunity.event_type = EventType(value)
                    else:
                        setattr(opportunity, key, value)
            
            opportunity.updated_at = datetime.utcnow()
            
            # Update in sales pipeline
            await self.sales_pipeline.update_opportunity(opportunity)
            
            # Trigger automation if stage changed
            if old_stage != opportunity.stage:
                await self.automation_engine.trigger_opportunity_stage_changed(opportunity, old_stage)
            
            print(f"Opportunity updated: {opportunity.opportunity_id}")
            return opportunity
            
        except Exception as e:
            print(f"Failed to update opportunity {opportunity_id}: {e}")
            return None
    
    # Activity Management
    async def create_activity(self, activity_data: Dict[str, Any]) -> Activity:
        """Create a new activity"""
        try:
            activity = Activity(
                activity_id=str(uuid.uuid4()),
                related_to_type=activity_data["related_to_type"],
                related_to_id=activity_data["related_to_id"],
                activity_type=activity_data["activity_type"],
                subject=activity_data["subject"],
                description=activity_data["description"],
                created_by=activity_data["created_by"],
                created_at=datetime.utcnow(),
                scheduled_at=activity_data.get("scheduled_at"),
                status=activity_data.get("status", "pending"),
                priority=activity_data.get("priority", "medium"),
                duration_minutes=activity_data.get("duration_minutes"),
                location=activity_data.get("location"),
                attendees=activity_data.get("attendees", []),
                follow_up_required=activity_data.get("follow_up_required", False),
                next_action=activity_data.get("next_action")
            )
            
            # Store activity
            self.activities.append(activity)
            
            # Trigger automation
            await self.automation_engine.trigger_activity_created(activity)
            
            print(f"Activity created: {activity.subject}")
            return activity
            
        except Exception as e:
            print(f"Failed to create activity: {e}")
            raise
    
    async def complete_activity(self, activity_id: str, outcome: str, follow_up_action: Optional[str] = None) -> Optional[Activity]:
        """Mark an activity as completed"""
        try:
            activity = next((a for a in self.activities if a.activity_id == activity_id), None)
            
            if not activity:
                return None
            
            activity.status = "completed"
            activity.completed_at = datetime.utcnow()
            activity.outcome = outcome
            
            if follow_up_action:
                activity.next_action = follow_up_action
                activity.follow_up_required = True
            
            # Trigger automation
            await self.automation_engine.trigger_activity_completed(activity)
            
            print(f"Activity completed: {activity.activity_id}")
            return activity
            
        except Exception as e:
            print(f"Failed to complete activity {activity_id}: {e}")
            return None
    
    # Search and Filtering
    async def search_leads(self, criteria: Dict[str, Any]) -> List[Lead]:
        """Search leads based on criteria"""
        results = []
        
        for lead in self.leads.values():
            match = True
            
            # Apply filters
            if "status" in criteria and lead.status != LeadStatus(criteria["status"]):
                match = False
            
            if "source" in criteria and lead.source != criteria["source"]:
                match = False
            
            if "assigned_to" in criteria and lead.assigned_to != criteria["assigned_to"]:
                match = False
            
            if "event_type" in criteria and lead.event_type != EventType(criteria["event_type"]):
                match = False
            
            if "min_budget" in criteria and (not lead.estimated_budget or lead.estimated_budget < criteria["min_budget"]):
                match = False
            
            if "max_budget" in criteria and (not lead.estimated_budget or lead.estimated_budget > criteria["max_budget"]):
                match = False
            
            if "tags" in criteria:
                required_tags = set(criteria["tags"])
                lead_tags = set(lead.tags or [])
                if not required_tags.issubset(lead_tags):
                    match = False
            
            if "text_search" in criteria:
                search_text = criteria["text_search"].lower()
                searchable_text = f"{lead.first_name} {lead.last_name} {lead.email} {lead.company or ''} {' '.join(lead.notes or [])}".lower()
                if search_text not in searchable_text:
                    match = False
            
            if match:
                results.append(lead)
        
        # Sort by conversion probability (highest first)
        results.sort(key=lambda x: x.conversion_probability, reverse=True)
        
        return results
    
    async def search_customers(self, criteria: Dict[str, Any]) -> List[Customer]:
        """Search customers based on criteria"""
        results = []
        
        for customer in self.customers.values():
            match = True
            
            # Apply filters
            if "customer_type" in criteria and customer.customer_type != CustomerType(criteria["customer_type"]):
                match = False
            
            if "min_total_spent" in criteria and customer.total_spent < criteria["min_total_spent"]:
                match = False
            
            if "max_total_spent" in criteria and customer.total_spent > criteria["max_total_spent"]:
                match = False
            
            if "tags" in criteria:
                required_tags = set(criteria["tags"])
                customer_tags = set(customer.tags or [])
                if not required_tags.issubset(customer_tags):
                    match = False
            
            if "text_search" in criteria:
                search_text = criteria["text_search"].lower()
                searchable_text = f"{customer.first_name} {customer.last_name} {customer.email} {customer.company or ''}".lower()
                if search_text not in searchable_text:
                    match = False
            
            if match:
                results.append(customer)
        
        # Sort by customer lifetime value (highest first)
        results.sort(key=lambda x: x.customer_lifetime_value, reverse=True)
        
        return results
    
    # Analytics and Reporting
    async def get_crm_dashboard(self) -> Dict[str, Any]:
        """Get CRM dashboard data"""
        return await self.analytics.generate_dashboard_data(
            self.leads, self.customers, self.opportunities, self.activities
        )
    
    async def get_sales_pipeline_report(self) -> Dict[str, Any]:
        """Get sales pipeline report"""
        return await self.sales_pipeline.generate_report()
    
    async def get_lead_conversion_report(self, period_days: int = 30) -> Dict[str, Any]:
        """Get lead conversion report"""
        return await self.analytics.generate_lead_conversion_report(
            self.leads, self.customers, period_days
        )

class SalesPipeline:
    def __init__(self):
        self.stages = [
            "qualification",
            "needs_analysis",
            "proposal",
            "negotiation",
            "closed_won",
            "closed_lost"
        ]
        self.opportunities_by_stage = {stage: [] for stage in self.stages}
    
    async def add_opportunity(self, opportunity: Opportunity):
        """Add opportunity to pipeline"""
        if opportunity.stage in self.opportunities_by_stage:
            self.opportunities_by_stage[opportunity.stage].append(opportunity)
    
    async def update_opportunity(self, opportunity: Opportunity):
        """Update opportunity in pipeline"""
        # Remove from all stages
        for stage_opportunities in self.opportunities_by_stage.values():
            stage_opportunities[:] = [opp for opp in stage_opportunities if opp.opportunity_id != opportunity.opportunity_id]
        
        # Add to correct stage
        if opportunity.stage in self.opportunities_by_stage:
            self.opportunities_by_stage[opportunity.stage].append(opportunity)
    
    async def generate_report(self) -> Dict[str, Any]:
        """Generate sales pipeline report"""
        report = {
            "pipeline_summary": {},
            "stage_details": {},
            "total_pipeline_value": 0.0,
            "weighted_pipeline_value": 0.0,
            "average_deal_size": 0.0,
            "conversion_rates": {}
        }
        
        total_opportunities = 0
        total_value = 0.0
        weighted_value = 0.0
        
        for stage, opportunities in self.opportunities_by_stage.items():
            stage_count = len(opportunities)
            stage_value = sum(opp.estimated_value for opp in opportunities)
            stage_weighted_value = sum(opp.estimated_value * opp.probability for opp in opportunities)
            
            report["stage_details"][stage] = {
                "count": stage_count,
                "total_value": stage_value,
                "weighted_value": stage_weighted_value,
                "average_deal_size": stage_value / stage_count if stage_count > 0 else 0,
                "opportunities": [
                    {
                        "id": opp.opportunity_id,
                        "name": opp.name,
                        "value": opp.estimated_value,
                        "probability": opp.probability,
                        "event_date": opp.event_date.isoformat(),
                        "assigned_to": opp.assigned_to
                    }
                    for opp in opportunities
                ]
            }
            
            total_opportunities += stage_count
            total_value += stage_value
            weighted_value += stage_weighted_value
        
        report["pipeline_summary"] = {
            "total_opportunities": total_opportunities,
            "total_pipeline_value": total_value,
            "weighted_pipeline_value": weighted_value,
            "average_deal_size": total_value / total_opportunities if total_opportunities > 0 else 0
        }
        
        return report

class LeadScoringEngine:
    def __init__(self):
        self.scoring_rules = {
            "budget_score": {
                "weight": 0.25,
                "rules": {
                    "high_budget": {"min": 10000, "score": 100},
                    "medium_budget": {"min": 5000, "score": 70},
                    "low_budget": {"min": 1000, "score": 40},
                    "no_budget": {"min": 0, "score": 10}
                }
            },
            "event_type_score": {
                "weight": 0.20,
                "rules": {
                    EventType.WEDDING: 90,
                    EventType.CORPORATE_EVENT: 85,
                    EventType.CONFERENCE: 80,
                    EventType.CONCERT: 75,
                    EventType.FESTIVAL: 70,
                    EventType.PRIVATE_PARTY: 60,
                    EventType.TRADE_SHOW: 85,
                    EventType.THEATER_PRODUCTION: 65,
                    EventType.FILM_PRODUCTION: 80,
                    EventType.OTHER: 50
                }
            },
            "timing_score": {
                "weight": 0.15,
                "rules": {
                    "immediate": {"days": 30, "score": 100},
                    "near_term": {"days": 90, "score": 80},
                    "medium_term": {"days": 180, "score": 60},
                    "long_term": {"days": 365, "score": 40},
                    "no_date": {"days": 9999, "score": 20}
                }
            },
            "engagement_score": {
                "weight": 0.20,
                "rules": {
                    "high_engagement": {"contacts": 5, "score": 100},
                    "medium_engagement": {"contacts": 3, "score": 70},
                    "low_engagement": {"contacts": 1, "score": 40},
                    "no_engagement": {"contacts": 0, "score": 10}
                }
            },
            "company_score": {
                "weight": 0.10,
                "rules": {
                    "has_company": 80,
                    "no_company": 40
                }
            },
            "source_score": {
                "weight": 0.10,
                "rules": {
                    "referral": 100,
                    "website": 80,
                    "social_media": 70,
                    "advertising": 60,
                    "cold_outreach": 30,
                    "unknown": 20
                }
            }
        }
    
    async def calculate_score(self, lead: Lead) -> float:
        """Calculate lead score based on scoring rules"""
        total_score = 0.0
        
        # Budget score
        budget_score = self._calculate_budget_score(lead.estimated_budget)
        total_score += budget_score * self.scoring_rules["budget_score"]["weight"]
        
        # Event type score
        event_type_score = self._calculate_event_type_score(lead.event_type)
        total_score += event_type_score * self.scoring_rules["event_type_score"]["weight"]
        
        # Timing score
        timing_score = self._calculate_timing_score(lead.expected_event_date)
        total_score += timing_score * self.scoring_rules["timing_score"]["weight"]
        
        # Engagement score (mock - in real implementation, count actual interactions)
        engagement_score = 70  # Default medium engagement
        total_score += engagement_score * self.scoring_rules["engagement_score"]["weight"]
        
        # Company score
        company_score = 80 if lead.company else 40
        total_score += company_score * self.scoring_rules["company_score"]["weight"]
        
        # Source score
        source_score = self.scoring_rules["source_score"]["rules"].get(lead.source, 20)
        total_score += source_score * self.scoring_rules["source_score"]["weight"]
        
        return min(100.0, max(0.0, total_score))
    
    def _calculate_budget_score(self, budget: Optional[float]) -> float:
        """Calculate score based on budget"""
        if not budget:
            return 10
        
        rules = self.scoring_rules["budget_score"]["rules"]
        
        if budget >= rules["high_budget"]["min"]:
            return rules["high_budget"]["score"]
        elif budget >= rules["medium_budget"]["min"]:
            return rules["medium_budget"]["score"]
        elif budget >= rules["low_budget"]["min"]:
            return rules["low_budget"]["score"]
        else:
            return rules["no_budget"]["score"]
    
    def _calculate_event_type_score(self, event_type: Optional[EventType]) -> float:
        """Calculate score based on event type"""
        if not event_type:
            return 50
        
        return self.scoring_rules["event_type_score"]["rules"].get(event_type, 50)
    
    def _calculate_timing_score(self, event_date: Optional[datetime]) -> float:
        """Calculate score based on event timing"""
        if not event_date:
            return 20
        
        days_until_event = (event_date - datetime.utcnow()).days
        rules = self.scoring_rules["timing_score"]["rules"]
        
        if days_until_event <= rules["immediate"]["days"]:
            return rules["immediate"]["score"]
        elif days_until_event <= rules["near_term"]["days"]:
            return rules["near_term"]["score"]
        elif days_until_event <= rules["medium_term"]["days"]:
            return rules["medium_term"]["score"]
        elif days_until_event <= rules["long_term"]["days"]:
            return rules["long_term"]["score"]
        else:
            return rules["no_date"]["score"]

class CRMAutomationEngine:
    def __init__(self):
        self.automation_rules = []
        self.email_templates = {}
        self.workflow_engine = WorkflowEngine()
    
    async def trigger_lead_created(self, lead: Lead):
        """Trigger automation when lead is created"""
        # Send welcome email
        await self._send_automated_email(
            lead.email,
            "welcome_lead",
            {
                "first_name": lead.first_name,
                "event_type": lead.event_type.value if lead.event_type else "event",
                "estimated_budget": lead.estimated_budget
            }
        )
        
        # Schedule follow-up task
        await self._schedule_follow_up_task(lead)
        
        print(f"Lead creation automation triggered for {lead.lead_id}")
    
    async def trigger_lead_status_changed(self, lead: Lead, old_status: LeadStatus):
        """Trigger automation when lead status changes"""
        if lead.status == LeadStatus.QUALIFIED:
            # Send qualified lead notification to sales team
            await self._notify_sales_team("qualified_lead", lead)
        
        elif lead.status == LeadStatus.PROPOSAL_SENT:
            # Schedule follow-up in 3 days
            await self._schedule_follow_up_task(lead, days=3)
        
        print(f"Lead status change automation triggered: {old_status.value} -> {lead.status.value}")
    
    async def trigger_lead_converted(self, lead: Lead, customer: Customer):
        """Trigger automation when lead is converted"""
        # Send welcome customer email
        await self._send_automated_email(
            customer.email,
            "welcome_customer",
            {
                "first_name": customer.first_name,
                "customer_id": customer.customer_id
            }
        )
        
        # Create onboarding opportunity
        await self._create_onboarding_tasks(customer)
        
        print(f"Lead conversion automation triggered for {lead.lead_id} -> {customer.customer_id}")
    
    async def trigger_customer_created(self, customer: Customer):
        """Trigger automation when customer is created"""
        # Send welcome email if not converted from lead
        await self._send_automated_email(
            customer.email,
            "welcome_customer",
            {
                "first_name": customer.first_name,
                "customer_id": customer.customer_id
            }
        )
        
        print(f"Customer creation automation triggered for {customer.customer_id}")
    
    async def trigger_opportunity_created(self, opportunity: Opportunity):
        """Trigger automation when opportunity is created"""
        # Notify assigned sales rep
        await self._notify_sales_rep("new_opportunity", opportunity)
        
        # Schedule proposal preparation task
        await self._schedule_proposal_task(opportunity)
        
        print(f"Opportunity creation automation triggered for {opportunity.opportunity_id}")
    
    async def trigger_opportunity_stage_changed(self, opportunity: Opportunity, old_stage: str):
        """Trigger automation when opportunity stage changes"""
        if opportunity.stage == "proposal":
            # Send proposal template to sales rep
            await self._send_proposal_template(opportunity)
        
        elif opportunity.stage == "closed_won":
            # Create delivery and setup tasks
            await self._create_delivery_tasks(opportunity)
        
        print(f"Opportunity stage change automation triggered: {old_stage} -> {opportunity.stage}")
    
    async def trigger_activity_created(self, activity: Activity):
        """Trigger automation when activity is created"""
        # Send calendar invite if scheduled
        if activity.scheduled_at:
            await self._send_calendar_invite(activity)
        
        print(f"Activity creation automation triggered for {activity.activity_id}")
    
    async def trigger_activity_completed(self, activity: Activity):
        """Trigger automation when activity is completed"""
        # Create follow-up task if required
        if activity.follow_up_required and activity.next_action:
            await self._create_follow_up_activity(activity)
        
        print(f"Activity completion automation triggered for {activity.activity_id}")
    
    async def _send_automated_email(self, email: str, template: str, variables: Dict[str, Any]):
        """Send automated email using template"""
        # Mock email sending - in real implementation, integrate with email service
        print(f"Sending automated email to {email} using template {template}")
        print(f"Variables: {variables}")
    
    async def _schedule_follow_up_task(self, lead: Lead, days: int = 1):
        """Schedule follow-up task for lead"""
        # Mock task scheduling - in real implementation, create actual task
        follow_up_date = datetime.utcnow() + timedelta(days=days)
        print(f"Scheduling follow-up task for lead {lead.lead_id} on {follow_up_date}")
    
    async def _notify_sales_team(self, notification_type: str, lead: Lead):
        """Notify sales team about lead"""
        print(f"Notifying sales team: {notification_type} for lead {lead.lead_id}")
    
    async def _notify_sales_rep(self, notification_type: str, opportunity: Opportunity):
        """Notify assigned sales rep about opportunity"""
        print(f"Notifying {opportunity.assigned_to}: {notification_type} for opportunity {opportunity.opportunity_id}")
    
    async def _schedule_proposal_task(self, opportunity: Opportunity):
        """Schedule proposal preparation task"""
        print(f"Scheduling proposal task for opportunity {opportunity.opportunity_id}")
    
    async def _send_proposal_template(self, opportunity: Opportunity):
        """Send proposal template to sales rep"""
        print(f"Sending proposal template for opportunity {opportunity.opportunity_id}")
    
    async def _create_delivery_tasks(self, opportunity: Opportunity):
        """Create delivery and setup tasks for won opportunity"""
        print(f"Creating delivery tasks for won opportunity {opportunity.opportunity_id}")
    
    async def _send_calendar_invite(self, activity: Activity):
        """Send calendar invite for scheduled activity"""
        print(f"Sending calendar invite for activity {activity.activity_id}")
    
    async def _create_follow_up_activity(self, activity: Activity):
        """Create follow-up activity"""
        print(f"Creating follow-up activity for {activity.activity_id}: {activity.next_action}")
    
    async def _create_onboarding_tasks(self, customer: Customer):
        """Create onboarding tasks for new customer"""
        print(f"Creating onboarding tasks for customer {customer.customer_id}")

class WorkflowEngine:
    def __init__(self):
        self.workflows = {}
    
    async def execute_workflow(self, workflow_name: str, context: Dict[str, Any]):
        """Execute a workflow"""
        print(f"Executing workflow: {workflow_name}")

class CRMAnalytics:
    async def generate_dashboard_data(
        self, 
        leads: Dict[str, Lead], 
        customers: Dict[str, Customer], 
        opportunities: Dict[str, Opportunity], 
        activities: List[Activity]
    ) -> Dict[str, Any]:
        """Generate CRM dashboard data"""
        
        # Lead metrics
        total_leads = len(leads)
        new_leads_this_month = len([l for l in leads.values() if l.created_at >= datetime.utcnow() - timedelta(days=30)])
        qualified_leads = len([l for l in leads.values() if l.status == LeadStatus.QUALIFIED])
        
        # Customer metrics
        total_customers = len(customers)
        new_customers_this_month = len([c for c in customers.values() if c.created_at >= datetime.utcnow() - timedelta(days=30)])
        total_customer_value = sum(c.total_spent for c in customers.values())
        
        # Opportunity metrics
        total_opportunities = len(opportunities)
        open_opportunities = len([o for o in opportunities.values() if o.stage not in ["closed_won", "closed_lost"]])
        total_pipeline_value = sum(o.estimated_value for o in opportunities.values() if o.stage not in ["closed_won", "closed_lost"])
        won_opportunities = len([o for o in opportunities.values() if o.stage == "closed_won"])
        
        # Activity metrics
        total_activities = len(activities)
        completed_activities = len([a for a in activities if a.status == "completed"])
        pending_activities = len([a for a in activities if a.status == "pending"])
        
        # Conversion rates
        lead_to_customer_rate = (len([l for l in leads.values() if l.status == LeadStatus.WON]) / total_leads * 100) if total_leads > 0 else 0
        opportunity_win_rate = (won_opportunities / total_opportunities * 100) if total_opportunities > 0 else 0
        
        return {
            "lead_metrics": {
                "total_leads": total_leads,
                "new_leads_this_month": new_leads_this_month,
                "qualified_leads": qualified_leads,
                "lead_to_customer_rate": round(lead_to_customer_rate, 2)
            },
            "customer_metrics": {
                "total_customers": total_customers,
                "new_customers_this_month": new_customers_this_month,
                "total_customer_value": total_customer_value,
                "average_customer_value": total_customer_value / total_customers if total_customers > 0 else 0
            },
            "opportunity_metrics": {
                "total_opportunities": total_opportunities,
                "open_opportunities": open_opportunities,
                "total_pipeline_value": total_pipeline_value,
                "won_opportunities": won_opportunities,
                "opportunity_win_rate": round(opportunity_win_rate, 2)
            },
            "activity_metrics": {
                "total_activities": total_activities,
                "completed_activities": completed_activities,
                "pending_activities": pending_activities,
                "completion_rate": round(completed_activities / total_activities * 100, 2) if total_activities > 0 else 0
            },
            "generated_at": datetime.utcnow().isoformat()
        }
    
    async def generate_lead_conversion_report(
        self, 
        leads: Dict[str, Lead], 
        customers: Dict[str, Customer], 
        period_days: int = 30
    ) -> Dict[str, Any]:
        """Generate lead conversion report"""
        
        cutoff_date = datetime.utcnow() - timedelta(days=period_days)
        period_leads = [l for l in leads.values() if l.created_at >= cutoff_date]
        
        # Conversion by source
        conversion_by_source = {}
        for lead in period_leads:
            source = lead.source
            if source not in conversion_by_source:
                conversion_by_source[source] = {"total": 0, "converted": 0}
            
            conversion_by_source[source]["total"] += 1
            if lead.status == LeadStatus.WON:
                conversion_by_source[source]["converted"] += 1
        
        # Calculate conversion rates
        for source_data in conversion_by_source.values():
            source_data["conversion_rate"] = (source_data["converted"] / source_data["total"] * 100) if source_data["total"] > 0 else 0
        
        # Conversion by event type
        conversion_by_event_type = {}
        for lead in period_leads:
            if lead.event_type:
                event_type = lead.event_type.value
                if event_type not in conversion_by_event_type:
                    conversion_by_event_type[event_type] = {"total": 0, "converted": 0}
                
                conversion_by_event_type[event_type]["total"] += 1
                if lead.status == LeadStatus.WON:
                    conversion_by_event_type[event_type]["converted"] += 1
        
        # Calculate conversion rates
        for event_data in conversion_by_event_type.values():
            event_data["conversion_rate"] = (event_data["converted"] / event_data["total"] * 100) if event_data["total"] > 0 else 0
        
        return {
            "period_days": period_days,
            "total_leads": len(period_leads),
            "converted_leads": len([l for l in period_leads if l.status == LeadStatus.WON]),
            "overall_conversion_rate": (len([l for l in period_leads if l.status == LeadStatus.WON]) / len(period_leads) * 100) if period_leads else 0,
            "conversion_by_source": conversion_by_source,
            "conversion_by_event_type": conversion_by_event_type,
            "generated_at": datetime.utcnow().isoformat()
        }
```

## 2. Invoice Ninja Integration Service

### Enhanced Invoice Ninja Integration

```python
# services/invoice_ninja_integration.py
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import aiohttp
import json
import uuid

class InvoiceStatus(Enum):
    DRAFT = "draft"
    SENT = "sent"
    VIEWED = "viewed"
    APPROVED = "approved"
    PARTIAL = "partial"
    PAID = "paid"
    OVERDUE = "overdue"
    CANCELLED = "cancelled"

class PaymentStatus(Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"
    PARTIALLY_REFUNDED = "partially_refunded"

@dataclass
class InvoiceNinjaCustomer:
    id: Optional[str]
    name: str
    email: str
    phone: Optional[str]
    address1: Optional[str]
    address2: Optional[str]
    city: Optional[str]
    state: Optional[str]
    postal_code: Optional[str]
    country: Optional[str]
    vat_number: Optional[str]
    website: Optional[str]
    currency_id: str = "1"  # Default to first currency
    payment_terms: int = 30
    credit_limit: float = 0.0
    custom_fields: Dict[str, Any] = None

@dataclass
class InvoiceLineItem:
    product_key: str
    notes: str
    cost: float
    qty: float
    tax_name1: Optional[str] = None
    tax_rate1: float = 0.0
    tax_name2: Optional[str] = None
    tax_rate2: float = 0.0
    custom_value1: Optional[str] = None
    custom_value2: Optional[str] = None
    discount: float = 0.0

@dataclass
class InvoiceNinjaInvoice:
    id: Optional[str]
    client_id: str
    invoice_number: Optional[str]
    po_number: Optional[str]
    invoice_date: datetime
    due_date: datetime
    discount: float
    partial: float
    tax_name1: Optional[str]
    tax_rate1: float
    tax_name2: Optional[str]
    tax_rate2: float
    terms: Optional[str]
    public_notes: Optional[str]
    private_notes: Optional[str]
    invoice_items: List[InvoiceLineItem]
    custom_value1: Optional[str] = None
    custom_value2: Optional[str] = None
    status: InvoiceStatus = InvoiceStatus.DRAFT

class InvoiceNinjaIntegrationService:
    def __init__(self, api_url: str, api_token: str, company_id: str):
        self.api_url = api_url.rstrip('/')
        self.api_token = api_token
        self.company_id = company_id
        self.session = None
        self.customer_mapping = {}  # RentGuy customer ID -> Invoice Ninja client ID
        self.invoice_mapping = {}   # RentGuy booking ID -> Invoice Ninja invoice ID
        
    async def initialize(self):
        """Initialize the service and create HTTP session"""
        self.session = aiohttp.ClientSession(
            headers={
                'X-API-TOKEN': self.api_token,
                'X-Requested-With': 'XMLHttpRequest',
                'Content-Type': 'application/json'
            },
            timeout=aiohttp.ClientTimeout(total=30)
        )
        
        # Test connection
        await self.test_connection()
    
    async def close(self):
        """Close HTTP session"""
        if self.session:
            await self.session.close()
    
    async def test_connection(self) -> bool:
        """Test connection to Invoice Ninja API"""
        try:
            async with self.session.get(f"{self.api_url}/api/v1/ping") as response:
                if response.status == 200:
                    data = await response.json()
                    print(f"Invoice Ninja connection successful: {data}")
                    return True
                else:
                    print(f"Invoice Ninja connection failed: {response.status}")
                    return False
        except Exception as e:
            print(f"Invoice Ninja connection error: {e}")
            return False
    
    # Customer Management
    async def create_customer(self, customer: 'Customer') -> Optional[str]:
        """Create customer in Invoice Ninja"""
        try:
            # Check if customer already exists
            existing_client_id = self.customer_mapping.get(customer.customer_id)
            if existing_client_id:
                return existing_client_id
            
            # Prepare customer data
            client_data = {
                "name": f"{customer.first_name} {customer.last_name}",
                "email": customer.email,
                "phone": customer.phone or "",
                "address1": customer.billing_address.get("street", ""),
                "address2": customer.billing_address.get("street2", ""),
                "city": customer.billing_address.get("city", ""),
                "state": customer.billing_address.get("state", ""),
                "postal_code": customer.billing_address.get("postal_code", ""),
                "country": customer.billing_address.get("country", ""),
                "vat_number": customer.tax_id or "",
                "website": "",
                "currency_id": "1",
                "payment_terms": self._parse_payment_terms(customer.payment_terms),
                "credit_limit": customer.credit_limit,
                "custom_value1": customer.customer_id,  # Store RentGuy customer ID
                "custom_value2": customer.customer_type.value,
                "public_notes": f"Customer Type: {customer.customer_type.value}",
                "private_notes": f"Created from RentGuy CRM. Customer ID: {customer.customer_id}"
            }
            
            # Create client in Invoice Ninja
            async with self.session.post(
                f"{self.api_url}/api/v1/clients",
                json=client_data
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    client_id = result["data"]["id"]
                    
                    # Store mapping
                    self.customer_mapping[customer.customer_id] = client_id
                    
                    print(f"Customer created in Invoice Ninja: {client_id}")
                    return client_id
                else:
                    error_text = await response.text()
                    print(f"Failed to create customer in Invoice Ninja: {response.status} - {error_text}")
                    return None
                    
        except Exception as e:
            print(f"Error creating customer in Invoice Ninja: {e}")
            return None
    
    async def update_customer(self, customer: 'Customer') -> bool:
        """Update customer in Invoice Ninja"""
        try:
            client_id = self.customer_mapping.get(customer.customer_id)
            if not client_id:
                # Customer doesn't exist, create it
                client_id = await self.create_customer(customer)
                return client_id is not None
            
            # Prepare update data
            client_data = {
                "name": f"{customer.first_name} {customer.last_name}",
                "email": customer.email,
                "phone": customer.phone or "",
                "address1": customer.billing_address.get("street", ""),
                "address2": customer.billing_address.get("street2", ""),
                "city": customer.billing_address.get("city", ""),
                "state": customer.billing_address.get("state", ""),
                "postal_code": customer.billing_address.get("postal_code", ""),
                "country": customer.billing_address.get("country", ""),
                "vat_number": customer.tax_id or "",
                "payment_terms": self._parse_payment_terms(customer.payment_terms),
                "credit_limit": customer.credit_limit,
                "custom_value2": customer.customer_type.value,
                "public_notes": f"Customer Type: {customer.customer_type.value}",
                "private_notes": f"Updated from RentGuy CRM. Customer ID: {customer.customer_id}"
            }
            
            # Update client in Invoice Ninja
            async with self.session.put(
                f"{self.api_url}/api/v1/clients/{client_id}",
                json=client_data
            ) as response:
                
                if response.status == 200:
                    print(f"Customer updated in Invoice Ninja: {client_id}")
                    return True
                else:
                    error_text = await response.text()
                    print(f"Failed to update customer in Invoice Ninja: {response.status} - {error_text}")
                    return False
                    
        except Exception as e:
            print(f"Error updating customer in Invoice Ninja: {e}")
            return False
    
    async def get_customer(self, customer_id: str) -> Optional[Dict[str, Any]]:
        """Get customer from Invoice Ninja"""
        try:
            client_id = self.customer_mapping.get(customer_id)
            if not client_id:
                return None
            
            async with self.session.get(
                f"{self.api_url}/api/v1/clients/{client_id}"
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    return result["data"]
                else:
                    print(f"Failed to get customer from Invoice Ninja: {response.status}")
                    return None
                    
        except Exception as e:
            print(f"Error getting customer from Invoice Ninja: {e}")
            return None
    
    # Invoice Management
    async def create_invoice_from_booking(self, booking_data: Dict[str, Any]) -> Optional[str]:
        """Create invoice from booking data"""
        try:
            # Get client ID
            client_id = self.customer_mapping.get(booking_data["customer_id"])
            if not client_id:
                print(f"Customer not found in Invoice Ninja: {booking_data['customer_id']}")
                return None
            
            # Prepare invoice line items
            invoice_items = []
            
            for equipment in booking_data.get("equipment", []):
                line_item = InvoiceLineItem(
                    product_key=equipment.get("equipment_id", ""),
                    notes=f"{equipment.get('name', 'AV Equipment')} - {equipment.get('description', '')}",
                    cost=float(equipment.get("daily_rate", 0)),
                    qty=float(booking_data.get("duration_days", 1)),
                    tax_name1="VAT",
                    tax_rate1=21.0,  # Dutch VAT rate
                    custom_value1=equipment.get("equipment_id"),
                    custom_value2=equipment.get("category")
                )
                invoice_items.append(line_item)
            
            # Add delivery charges if applicable
            if booking_data.get("delivery_required", False):
                delivery_item = InvoiceLineItem(
                    product_key="DELIVERY",
                    notes=f"Delivery to {booking_data.get('delivery_address', {}).get('city', 'venue')}",
                    cost=float(booking_data.get("delivery_cost", 50)),
                    qty=1.0,
                    tax_name1="VAT",
                    tax_rate1=21.0
                )
                invoice_items.append(delivery_item)
            
            # Add setup charges if applicable
            if booking_data.get("setup_required", False):
                setup_item = InvoiceLineItem(
                    product_key="SETUP",
                    notes="Professional setup and configuration",
                    cost=float(booking_data.get("setup_cost", 100)),
                    qty=1.0,
                    tax_name1="VAT",
                    tax_rate1=21.0
                )
                invoice_items.append(setup_item)
            
            # Create invoice
            invoice_date = datetime.utcnow()
            due_date = invoice_date + timedelta(days=30)  # 30 days payment terms
            
            invoice = InvoiceNinjaInvoice(
                id=None,
                client_id=client_id,
                invoice_number=None,  # Auto-generated
                po_number=booking_data.get("po_number"),
                invoice_date=invoice_date,
                due_date=due_date,
                discount=float(booking_data.get("discount_percentage", 0)),
                partial=0.0,
                tax_name1="VAT",
                tax_rate1=21.0,
                tax_name2=None,
                tax_rate2=0.0,
                terms="Payment due within 30 days. Late payments may incur additional charges.",
                public_notes=f"AV Equipment Rental for {booking_data.get('event_name', 'Event')} on {booking_data.get('event_date', 'TBD')}",
                private_notes=f"Booking ID: {booking_data.get('booking_id')}",
                invoice_items=invoice_items,
                custom_value1=booking_data.get("booking_id"),
                custom_value2=booking_data.get("event_type"),
                status=InvoiceStatus.DRAFT
            )
            
            # Convert to Invoice Ninja format
            invoice_data = await self._convert_to_invoice_ninja_format(invoice)
            
            # Create invoice in Invoice Ninja
            async with self.session.post(
                f"{self.api_url}/api/v1/invoices",
                json=invoice_data
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    invoice_id = result["data"]["id"]
                    
                    # Store mapping
                    self.invoice_mapping[booking_data["booking_id"]] = invoice_id
                    
                    print(f"Invoice created in Invoice Ninja: {invoice_id}")
                    return invoice_id
                else:
                    error_text = await response.text()
                    print(f"Failed to create invoice in Invoice Ninja: {response.status} - {error_text}")
                    return None
                    
        except Exception as e:
            print(f"Error creating invoice in Invoice Ninja: {e}")
            return None
    
    async def send_invoice(self, booking_id: str) -> bool:
        """Send invoice to customer"""
        try:
            invoice_id = self.invoice_mapping.get(booking_id)
            if not invoice_id:
                print(f"Invoice not found for booking: {booking_id}")
                return False
            
            # Send invoice
            async with self.session.post(
                f"{self.api_url}/api/v1/invoices/{invoice_id}/email"
            ) as response:
                
                if response.status == 200:
                    print(f"Invoice sent: {invoice_id}")
                    return True
                else:
                    error_text = await response.text()
                    print(f"Failed to send invoice: {response.status} - {error_text}")
                    return False
                    
        except Exception as e:
            print(f"Error sending invoice: {e}")
            return False
    
    async def mark_invoice_paid(self, booking_id: str, payment_amount: float, payment_date: Optional[datetime] = None) -> bool:
        """Mark invoice as paid"""
        try:
            invoice_id = self.invoice_mapping.get(booking_id)
            if not invoice_id:
                print(f"Invoice not found for booking: {booking_id}")
                return False
            
            # Create payment record
            payment_data = {
                "invoice_id": invoice_id,
                "amount": payment_amount,
                "payment_date": (payment_date or datetime.utcnow()).strftime("%Y-%m-%d"),
                "payment_type_id": "1",  # Default payment type
                "transaction_reference": f"BOOKING-{booking_id}",
                "private_notes": f"Payment for booking {booking_id}"
            }
            
            async with self.session.post(
                f"{self.api_url}/api/v1/payments",
                json=payment_data
            ) as response:
                
                if response.status == 200:
                    print(f"Payment recorded for invoice: {invoice_id}")
                    return True
                else:
                    error_text = await response.text()
                    print(f"Failed to record payment: {response.status} - {error_text}")
                    return False
                    
        except Exception as e:
            print(f"Error recording payment: {e}")
            return False
    
    async def get_invoice_status(self, booking_id: str) -> Optional[Dict[str, Any]]:
        """Get invoice status"""
        try:
            invoice_id = self.invoice_mapping.get(booking_id)
            if not invoice_id:
                return None
            
            async with self.session.get(
                f"{self.api_url}/api/v1/invoices/{invoice_id}"
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    invoice_data = result["data"]
                    
                    return {
                        "invoice_id": invoice_id,
                        "invoice_number": invoice_data.get("invoice_number"),
                        "status": invoice_data.get("status_id"),
                        "amount": invoice_data.get("amount"),
                        "balance": invoice_data.get("balance"),
                        "paid_to_date": invoice_data.get("paid_to_date"),
                        "due_date": invoice_data.get("due_date"),
                        "is_sent": invoice_data.get("is_sent"),
                        "is_viewed": invoice_data.get("is_viewed"),
                        "is_paid": invoice_data.get("balance", 0) == 0
                    }
                else:
                    print(f"Failed to get invoice status: {response.status}")
                    return None
                    
        except Exception as e:
            print(f"Error getting invoice status: {e}")
            return None
    
    # Product Management
    async def sync_equipment_catalog(self, equipment_list: List[Dict[str, Any]]) -> bool:
        """Sync equipment catalog with Invoice Ninja products"""
        try:
            success_count = 0
            
            for equipment in equipment_list:
                product_data = {
                    "product_key": equipment.get("equipment_id"),
                    "notes": equipment.get("description", ""),
                    "cost": float(equipment.get("daily_rate", 0)),
                    "qty": 1,
                    "tax_name1": "VAT",
                    "tax_rate1": 21.0,
                    "custom_value1": equipment.get("category"),
                    "custom_value2": equipment.get("subcategory")
                }
                
                # Check if product exists
                existing_product = await self._get_product_by_key(equipment.get("equipment_id"))
                
                if existing_product:
                    # Update existing product
                    async with self.session.put(
                        f"{self.api_url}/api/v1/products/{existing_product['id']}",
                        json=product_data
                    ) as response:
                        if response.status == 200:
                            success_count += 1
                else:
                    # Create new product
                    async with self.session.post(
                        f"{self.api_url}/api/v1/products",
                        json=product_data
                    ) as response:
                        if response.status == 200:
                            success_count += 1
            
            print(f"Equipment catalog sync completed: {success_count}/{len(equipment_list)} items synced")
            return success_count == len(equipment_list)
            
        except Exception as e:
            print(f"Error syncing equipment catalog: {e}")
            return False
    
    # Reporting
    async def get_financial_report(self, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """Get financial report from Invoice Ninja"""
        try:
            # Get invoices for the period
            params = {
                "start_date": start_date.strftime("%Y-%m-%d"),
                "end_date": end_date.strftime("%Y-%m-%d")
            }
            
            async with self.session.get(
                f"{self.api_url}/api/v1/reports/invoice_report",
                params=params
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    return result
                else:
                    print(f"Failed to get financial report: {response.status}")
                    return {}
                    
        except Exception as e:
            print(f"Error getting financial report: {e}")
            return {}
    
    async def get_customer_statement(self, customer_id: str) -> Optional[Dict[str, Any]]:
        """Get customer statement"""
        try:
            client_id = self.customer_mapping.get(customer_id)
            if not client_id:
                return None
            
            async with self.session.get(
                f"{self.api_url}/api/v1/clients/{client_id}/statement"
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    return result
                else:
                    print(f"Failed to get customer statement: {response.status}")
                    return None
                    
        except Exception as e:
            print(f"Error getting customer statement: {e}")
            return None
    
    # Webhook Handling
    async def handle_webhook(self, webhook_data: Dict[str, Any]) -> bool:
        """Handle webhook from Invoice Ninja"""
        try:
            event_type = webhook_data.get("event_type")
            
            if event_type == "invoice_sent":
                await self._handle_invoice_sent(webhook_data)
            elif event_type == "invoice_viewed":
                await self._handle_invoice_viewed(webhook_data)
            elif event_type == "invoice_paid":
                await self._handle_invoice_paid(webhook_data)
            elif event_type == "payment_created":
                await self._handle_payment_created(webhook_data)
            else:
                print(f"Unhandled webhook event: {event_type}")
            
            return True
            
        except Exception as e:
            print(f"Error handling webhook: {e}")
            return False
    
    async def _handle_invoice_sent(self, webhook_data: Dict[str, Any]):
        """Handle invoice sent webhook"""
        invoice_id = webhook_data.get("invoice_id")
        print(f"Invoice sent webhook received: {invoice_id}")
        
        # Update booking status or trigger notifications
        # Implementation depends on your business logic
    
    async def _handle_invoice_viewed(self, webhook_data: Dict[str, Any]):
        """Handle invoice viewed webhook"""
        invoice_id = webhook_data.get("invoice_id")
        print(f"Invoice viewed webhook received: {invoice_id}")
        
        # Update lead scoring or trigger follow-up actions
    
    async def _handle_invoice_paid(self, webhook_data: Dict[str, Any]):
        """Handle invoice paid webhook"""
        invoice_id = webhook_data.get("invoice_id")
        print(f"Invoice paid webhook received: {invoice_id}")
        
        # Update booking status, trigger delivery scheduling, etc.
    
    async def _handle_payment_created(self, webhook_data: Dict[str, Any]):
        """Handle payment created webhook"""
        payment_id = webhook_data.get("payment_id")
        print(f"Payment created webhook received: {payment_id}")
    
    # Helper Methods
    def _parse_payment_terms(self, payment_terms: str) -> int:
        """Parse payment terms string to days"""
        if payment_terms == "net_30":
            return 30
        elif payment_terms == "net_15":
            return 15
        elif payment_terms == "net_7":
            return 7
        elif payment_terms == "due_on_receipt":
            return 0
        else:
            return 30  # Default
    
    async def _convert_to_invoice_ninja_format(self, invoice: InvoiceNinjaInvoice) -> Dict[str, Any]:
        """Convert internal invoice format to Invoice Ninja API format"""
        
        line_items = []
        for item in invoice.invoice_items:
            line_items.append({
                "product_key": item.product_key,
                "notes": item.notes,
                "cost": item.cost,
                "qty": item.qty,
                "tax_name1": item.tax_name1,
                "tax_rate1": item.tax_rate1,
                "tax_name2": item.tax_name2,
                "tax_rate2": item.tax_rate2,
                "custom_value1": item.custom_value1,
                "custom_value2": item.custom_value2,
                "discount": item.discount
            })
        
        return {
            "client_id": invoice.client_id,
            "invoice_number": invoice.invoice_number,
            "po_number": invoice.po_number,
            "invoice_date": invoice.invoice_date.strftime("%Y-%m-%d"),
            "due_date": invoice.due_date.strftime("%Y-%m-%d"),
            "discount": invoice.discount,
            "partial": invoice.partial,
            "tax_name1": invoice.tax_name1,
            "tax_rate1": invoice.tax_rate1,
            "tax_name2": invoice.tax_name2,
            "tax_rate2": invoice.tax_rate2,
            "terms": invoice.terms,
            "public_notes": invoice.public_notes,
            "private_notes": invoice.private_notes,
            "custom_value1": invoice.custom_value1,
            "custom_value2": invoice.custom_value2,
            "invoice_items": line_items
        }
    
    async def _get_product_by_key(self, product_key: str) -> Optional[Dict[str, Any]]:
        """Get product by product key"""
        try:
            async with self.session.get(
                f"{self.api_url}/api/v1/products",
                params={"product_key": product_key}
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    products = result.get("data", [])
                    
                    for product in products:
                        if product.get("product_key") == product_key:
                            return product
                    
                    return None
                else:
                    return None
                    
        except Exception as e:
            print(f"Error getting product by key: {e}")
            return None
```

## 3. Multi-tenant Support Service

### Comprehensive Multi-tenancy Implementation

```python
# services/multi_tenant_service.py
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import json
import uuid
import hashlib
from abc import ABC, abstractmethod

class TenantTier(Enum):
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"
    CUSTOM = "custom"

class TenantStatus(Enum):
    ACTIVE = "active"
    SUSPENDED = "suspended"
    TRIAL = "trial"
    EXPIRED = "expired"
    CANCELLED = "cancelled"

class IsolationLevel(Enum):
    SHARED_DATABASE = "shared_database"
    SEPARATE_SCHEMA = "separate_schema"
    SEPARATE_DATABASE = "separate_database"
    DEDICATED_INSTANCE = "dedicated_instance"

@dataclass
class TenantConfiguration:
    tenant_id: str
    name: str
    subdomain: str
    tier: TenantTier
    status: TenantStatus
    isolation_level: IsolationLevel
    created_at: datetime
    updated_at: datetime
    expires_at: Optional[datetime] = None
    max_users: int = 10
    max_customers: int = 1000
    max_equipment: int = 500
    max_bookings_per_month: int = 100
    max_storage_gb: int = 10
    custom_domain: Optional[str] = None
    branding_config: Dict[str, Any] = None
    feature_flags: Dict[str, bool] = None
    database_config: Dict[str, Any] = None
    api_limits: Dict[str, int] = None
    billing_config: Dict[str, Any] = None
    contact_info: Dict[str, str] = None
    metadata: Dict[str, Any] = None

@dataclass
class TenantUsage:
    tenant_id: str
    period_start: datetime
    period_end: datetime
    users_count: int
    customers_count: int
    equipment_count: int
    bookings_count: int
    storage_used_gb: float
    api_calls_count: int
    bandwidth_used_gb: float
    invoice_count: int
    revenue_generated: float
    last_activity: datetime
    feature_usage: Dict[str, int] = None

@dataclass
class TenantLimits:
    max_users: int
    max_customers: int
    max_equipment: int
    max_bookings_per_month: int
    max_storage_gb: int
    max_api_calls_per_hour: int
    max_bandwidth_gb_per_month: int
    max_invoices_per_month: int
    custom_features: List[str] = None

class MultiTenantService:
    def __init__(self, database_manager=None, cache_manager=None):
        self.tenants = {}
        self.tenant_usage = {}
        self.tenant_limits = {}
        self.database_manager = database_manager or DatabaseManager()
        self.cache_manager = cache_manager or CacheManager()
        self.isolation_manager = IsolationManager()
        self.billing_manager = BillingManager()
        self.resource_manager = ResourceManager()
        
    # Tenant Management
    async def create_tenant(self, tenant_data: Dict[str, Any]) -> TenantConfiguration:
        """Create a new tenant"""
        try:
            # Generate tenant ID
            tenant_id = str(uuid.uuid4())
            
            # Validate subdomain uniqueness
            subdomain = tenant_data["subdomain"].lower()
            if await self._is_subdomain_taken(subdomain):
                raise ValueError(f"Subdomain '{subdomain}' is already taken")
            
            # Determine tier and limits
            tier = TenantTier(tenant_data.get("tier", "starter"))
            limits = self._get_tier_limits(tier)
            
            # Create tenant configuration
            tenant = TenantConfiguration(
                tenant_id=tenant_id,
                name=tenant_data["name"],
                subdomain=subdomain,
                tier=tier,
                status=TenantStatus.TRIAL if tenant_data.get("trial", False) else TenantStatus.ACTIVE,
                isolation_level=IsolationLevel(tenant_data.get("isolation_level", "shared_database")),
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                expires_at=datetime.utcnow() + timedelta(days=30) if tenant_data.get("trial", False) else None,
                max_users=limits["max_users"],
                max_customers=limits["max_customers"],
                max_equipment=limits["max_equipment"],
                max_bookings_per_month=limits["max_bookings_per_month"],
                max_storage_gb=limits["max_storage_gb"],
                custom_domain=tenant_data.get("custom_domain"),
                branding_config=tenant_data.get("branding_config", {}),
                feature_flags=self._get_tier_features(tier),
                database_config={},
                api_limits=limits["api_limits"],
                billing_config=tenant_data.get("billing_config", {}),
                contact_info=tenant_data.get("contact_info", {}),
                metadata=tenant_data.get("metadata", {})
            )
            
            # Set up tenant isolation
            await self.isolation_manager.setup_tenant_isolation(tenant)
            
            # Initialize tenant database/schema
            await self.database_manager.initialize_tenant_database(tenant)
            
            # Set up tenant cache namespace
            await self.cache_manager.setup_tenant_cache(tenant)
            
            # Store tenant configuration
            self.tenants[tenant_id] = tenant
            self.tenant_limits[tenant_id] = limits
            
            # Initialize usage tracking
            await self._initialize_usage_tracking(tenant_id)
            
            # Set up billing if not trial
            if tenant.status != TenantStatus.TRIAL:
                await self.billing_manager.setup_tenant_billing(tenant)
            
            print(f"Tenant created: {tenant.name} ({tenant_id})")
            return tenant
            
        except Exception as e:
            print(f"Failed to create tenant: {e}")
            raise
    
    async def update_tenant(self, tenant_id: str, updates: Dict[str, Any]) -> Optional[TenantConfiguration]:
        """Update tenant configuration"""
        try:
            if tenant_id not in self.tenants:
                return None
            
            tenant = self.tenants[tenant_id]
            old_tier = tenant.tier
            
            # Update fields
            for key, value in updates.items():
                if hasattr(tenant, key):
                    if key == "tier":
                        tenant.tier = TenantTier(value)
                    elif key == "status":
                        tenant.status = TenantStatus(value)
                    elif key == "isolation_level":
                        tenant.isolation_level = IsolationLevel(value)
                    else:
                        setattr(tenant, key, value)
            
            tenant.updated_at = datetime.utcnow()
            
            # Update limits if tier changed
            if tenant.tier != old_tier:
                new_limits = self._get_tier_limits(tenant.tier)
                self.tenant_limits[tenant_id] = new_limits
                
                # Update tenant limits
                tenant.max_users = new_limits["max_users"]
                tenant.max_customers = new_limits["max_customers"]
                tenant.max_equipment = new_limits["max_equipment"]
                tenant.max_bookings_per_month = new_limits["max_bookings_per_month"]
                tenant.max_storage_gb = new_limits["max_storage_gb"]
                tenant.api_limits = new_limits["api_limits"]
                tenant.feature_flags = self._get_tier_features(tenant.tier)
                
                # Update billing
                await self.billing_manager.update_tenant_billing(tenant, old_tier)
            
            # Update isolation if changed
            if "isolation_level" in updates:
                await self.isolation_manager.update_tenant_isolation(tenant)
            
            print(f"Tenant updated: {tenant_id}")
            return tenant
            
        except Exception as e:
            print(f"Failed to update tenant {tenant_id}: {e}")
            return None
    
    async def delete_tenant(self, tenant_id: str, force: bool = False) -> bool:
        """Delete a tenant"""
        try:
            if tenant_id not in self.tenants:
                return False
            
            tenant = self.tenants[tenant_id]
            
            # Check if tenant can be deleted
            if not force and tenant.status == TenantStatus.ACTIVE:
                # Suspend first, then delete after grace period
                await self.update_tenant(tenant_id, {"status": "suspended"})
                print(f"Tenant suspended for deletion: {tenant_id}")
                return True
            
            # Clean up tenant resources
            await self.isolation_manager.cleanup_tenant_isolation(tenant)
            await self.database_manager.cleanup_tenant_database(tenant)
            await self.cache_manager.cleanup_tenant_cache(tenant)
            await self.billing_manager.cleanup_tenant_billing(tenant)
            
            # Remove from memory
            del self.tenants[tenant_id]
            if tenant_id in self.tenant_limits:
                del self.tenant_limits[tenant_id]
            if tenant_id in self.tenant_usage:
                del self.tenant_usage[tenant_id]
            
            print(f"Tenant deleted: {tenant_id}")
            return True
            
        except Exception as e:
            print(f"Failed to delete tenant {tenant_id}: {e}")
            return False
    
    async def get_tenant(self, tenant_id: str) -> Optional[TenantConfiguration]:
        """Get tenant configuration"""
        return self.tenants.get(tenant_id)
    
    async def get_tenant_by_subdomain(self, subdomain: str) -> Optional[TenantConfiguration]:
        """Get tenant by subdomain"""
        for tenant in self.tenants.values():
            if tenant.subdomain == subdomain.lower():
                return tenant
        return None
    
    async def get_tenant_by_domain(self, domain: str) -> Optional[TenantConfiguration]:
        """Get tenant by custom domain"""
        for tenant in self.tenants.values():
            if tenant.custom_domain == domain.lower():
                return tenant
        return None
    
    # Usage Tracking and Limits
    async def track_usage(self, tenant_id: str, usage_type: str, amount: Union[int, float] = 1):
        """Track tenant usage"""
        try:
            if tenant_id not in self.tenant_usage:
                await self._initialize_usage_tracking(tenant_id)
            
            current_period = self._get_current_billing_period()
            usage_key = f"{tenant_id}:{current_period}"
            
            if usage_key not in self.tenant_usage:
                self.tenant_usage[usage_key] = TenantUsage(
                    tenant_id=tenant_id,
                    period_start=current_period,
                    period_end=current_period + timedelta(days=30),
                    users_count=0,
                    customers_count=0,
                    equipment_count=0,
                    bookings_count=0,
                    storage_used_gb=0.0,
                    api_calls_count=0,
                    bandwidth_used_gb=0.0,
                    invoice_count=0,
                    revenue_generated=0.0,
                    last_activity=datetime.utcnow(),
                    feature_usage={}
                )
            
            usage = self.tenant_usage[usage_key]
            
            # Update usage based on type
            if usage_type == "api_call":
                usage.api_calls_count += int(amount)
            elif usage_type == "storage":
                usage.storage_used_gb = float(amount)
            elif usage_type == "bandwidth":
                usage.bandwidth_used_gb += float(amount)
            elif usage_type == "booking":
                usage.bookings_count += int(amount)
            elif usage_type == "invoice":
                usage.invoice_count += int(amount)
            elif usage_type == "revenue":
                usage.revenue_generated += float(amount)
            elif usage_type.startswith("feature_"):
                feature_name = usage_type[8:]  # Remove "feature_" prefix
                if not usage.feature_usage:
                    usage.feature_usage = {}
                usage.feature_usage[feature_name] = usage.feature_usage.get(feature_name, 0) + int(amount)
            
            usage.last_activity = datetime.utcnow()
            
            # Check limits
            await self._check_usage_limits(tenant_id, usage)
            
        except Exception as e:
            print(f"Failed to track usage for tenant {tenant_id}: {e}")
    
    async def check_tenant_limits(self, tenant_id: str, resource_type: str, requested_amount: int = 1) -> bool:
        """Check if tenant can use more of a resource"""
        try:
            if tenant_id not in self.tenants or tenant_id not in self.tenant_limits:
                return False
            
            tenant = self.tenants[tenant_id]
            limits = self.tenant_limits[tenant_id]
            
            # Get current usage
            current_usage = await self.get_tenant_usage(tenant_id)
            
            # Check specific limits
            if resource_type == "users":
                return current_usage.users_count + requested_amount <= limits["max_users"]
            elif resource_type == "customers":
                return current_usage.customers_count + requested_amount <= limits["max_customers"]
            elif resource_type == "equipment":
                return current_usage.equipment_count + requested_amount <= limits["max_equipment"]
            elif resource_type == "bookings":
                return current_usage.bookings_count + requested_amount <= limits["max_bookings_per_month"]
            elif resource_type == "storage":
                return current_usage.storage_used_gb + requested_amount <= limits["max_storage_gb"]
            elif resource_type == "api_calls":
                # Check hourly limit
                hourly_usage = await self._get_hourly_api_usage(tenant_id)
                return hourly_usage + requested_amount <= limits["api_limits"]["per_hour"]
            else:
                return True  # Unknown resource type, allow by default
                
        except Exception as e:
            print(f"Failed to check limits for tenant {tenant_id}: {e}")
            return False
    
    async def get_tenant_usage(self, tenant_id: str) -> Optional[TenantUsage]:
        """Get current tenant usage"""
        try:
            current_period = self._get_current_billing_period()
            usage_key = f"{tenant_id}:{current_period}"
            
            if usage_key in self.tenant_usage:
                return self.tenant_usage[usage_key]
            
            # Initialize if not exists
            await self._initialize_usage_tracking(tenant_id)
            return self.tenant_usage.get(usage_key)
            
        except Exception as e:
            print(f"Failed to get usage for tenant {tenant_id}: {e}")
            return None
    
    # Feature Management
    async def is_feature_enabled(self, tenant_id: str, feature_name: str) -> bool:
        """Check if a feature is enabled for tenant"""
        if tenant_id not in self.tenants:
            return False
        
        tenant = self.tenants[tenant_id]
        
        # Check tenant status
        if tenant.status not in [TenantStatus.ACTIVE, TenantStatus.TRIAL]:
            return False
        
        # Check feature flags
        return tenant.feature_flags.get(feature_name, False)
    
    async def enable_feature(self, tenant_id: str, feature_name: str) -> bool:
        """Enable a feature for tenant"""
        try:
            if tenant_id not in self.tenants:
                return False
            
            tenant = self.tenants[tenant_id]
            
            if not tenant.feature_flags:
                tenant.feature_flags = {}
            
            tenant.feature_flags[feature_name] = True
            tenant.updated_at = datetime.utcnow()
            
            print(f"Feature enabled for tenant {tenant_id}: {feature_name}")
            return True
            
        except Exception as e:
            print(f"Failed to enable feature for tenant {tenant_id}: {e}")
            return False
    
    async def disable_feature(self, tenant_id: str, feature_name: str) -> bool:
        """Disable a feature for tenant"""
        try:
            if tenant_id not in self.tenants:
                return False
            
            tenant = self.tenants[tenant_id]
            
            if tenant.feature_flags and feature_name in tenant.feature_flags:
                tenant.feature_flags[feature_name] = False
                tenant.updated_at = datetime.utcnow()
                
                print(f"Feature disabled for tenant {tenant_id}: {feature_name}")
                return True
            
            return False
            
        except Exception as e:
            print(f"Failed to disable feature for tenant {tenant_id}: {e}")
            return False
    
    # Tenant Context Management
    async def get_tenant_context(self, request_info: Dict[str, Any]) -> Optional[TenantConfiguration]:
        """Get tenant context from request information"""
        try:
            # Try to identify tenant by subdomain
            host = request_info.get("host", "").lower()
            
            if "." in host:
                subdomain = host.split(".")[0]
                tenant = await self.get_tenant_by_subdomain(subdomain)
                if tenant:
                    return tenant
            
            # Try to identify by custom domain
            tenant = await self.get_tenant_by_domain(host)
            if tenant:
                return tenant
            
            # Try to identify by tenant ID in headers
            tenant_id = request_info.get("headers", {}).get("x-tenant-id")
            if tenant_id:
                return await self.get_tenant(tenant_id)
            
            # Try to identify by API key
            api_key = request_info.get("headers", {}).get("authorization")
            if api_key:
                tenant_id = await self._get_tenant_by_api_key(api_key)
                if tenant_id:
                    return await self.get_tenant(tenant_id)
            
            return None
            
        except Exception as e:
            print(f"Failed to get tenant context: {e}")
            return None
    
    # Reporting and Analytics
    async def get_tenant_analytics(self, tenant_id: str, period_days: int = 30) -> Dict[str, Any]:
        """Get tenant analytics"""
        try:
            tenant = await self.get_tenant(tenant_id)
            if not tenant:
                return {}
            
            usage = await self.get_tenant_usage(tenant_id)
            limits = self.tenant_limits.get(tenant_id, {})
            
            # Calculate utilization percentages
            utilization = {}
            if usage and limits:
                utilization = {
                    "users": (usage.users_count / limits["max_users"] * 100) if limits["max_users"] > 0 else 0,
                    "customers": (usage.customers_count / limits["max_customers"] * 100) if limits["max_customers"] > 0 else 0,
                    "equipment": (usage.equipment_count / limits["max_equipment"] * 100) if limits["max_equipment"] > 0 else 0,
                    "bookings": (usage.bookings_count / limits["max_bookings_per_month"] * 100) if limits["max_bookings_per_month"] > 0 else 0,
                    "storage": (usage.storage_used_gb / limits["max_storage_gb"] * 100) if limits["max_storage_gb"] > 0 else 0
                }
            
            return {
                "tenant_info": {
                    "id": tenant.tenant_id,
                    "name": tenant.name,
                    "tier": tenant.tier.value,
                    "status": tenant.status.value,
                    "created_at": tenant.created_at.isoformat(),
                    "days_active": (datetime.utcnow() - tenant.created_at).days
                },
                "current_usage": asdict(usage) if usage else {},
                "limits": limits,
                "utilization": utilization,
                "feature_flags": tenant.feature_flags or {},
                "billing_info": {
                    "tier": tenant.tier.value,
                    "expires_at": tenant.expires_at.isoformat() if tenant.expires_at else None,
                    "revenue_generated": usage.revenue_generated if usage else 0
                }
            }
            
        except Exception as e:
            print(f"Failed to get analytics for tenant {tenant_id}: {e}")
            return {}
    
    async def get_platform_analytics(self) -> Dict[str, Any]:
        """Get platform-wide analytics"""
        try:
            total_tenants = len(self.tenants)
            active_tenants = len([t for t in self.tenants.values() if t.status == TenantStatus.ACTIVE])
            trial_tenants = len([t for t in self.tenants.values() if t.status == TenantStatus.TRIAL])
            
            # Tier distribution
            tier_distribution = {}
            for tenant in self.tenants.values():
                tier = tenant.tier.value
                tier_distribution[tier] = tier_distribution.get(tier, 0) + 1
            
            # Calculate total usage
            total_usage = {
                "total_users": 0,
                "total_customers": 0,
                "total_equipment": 0,
                "total_bookings": 0,
                "total_storage_gb": 0.0,
                "total_api_calls": 0,
                "total_revenue": 0.0
            }
            
            for usage in self.tenant_usage.values():
                total_usage["total_users"] += usage.users_count
                total_usage["total_customers"] += usage.customers_count
                total_usage["total_equipment"] += usage.equipment_count
                total_usage["total_bookings"] += usage.bookings_count
                total_usage["total_storage_gb"] += usage.storage_used_gb
                total_usage["total_api_calls"] += usage.api_calls_count
                total_usage["total_revenue"] += usage.revenue_generated
            
            return {
                "platform_summary": {
                    "total_tenants": total_tenants,
                    "active_tenants": active_tenants,
                    "trial_tenants": trial_tenants,
                    "suspended_tenants": len([t for t in self.tenants.values() if t.status == TenantStatus.SUSPENDED])
                },
                "tier_distribution": tier_distribution,
                "total_usage": total_usage,
                "generated_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            print(f"Failed to get platform analytics: {e}")
            return {}
    
    # Helper Methods
    async def _is_subdomain_taken(self, subdomain: str) -> bool:
        """Check if subdomain is already taken"""
        for tenant in self.tenants.values():
            if tenant.subdomain == subdomain:
                return True
        return False
    
    def _get_tier_limits(self, tier: TenantTier) -> Dict[str, Any]:
        """Get limits for a specific tier"""
        limits = {
            TenantTier.STARTER: {
                "max_users": 3,
                "max_customers": 100,
                "max_equipment": 50,
                "max_bookings_per_month": 25,
                "max_storage_gb": 1,
                "api_limits": {"per_hour": 1000, "per_day": 10000},
                "max_bandwidth_gb_per_month": 10,
                "max_invoices_per_month": 25
            },
            TenantTier.PROFESSIONAL: {
                "max_users": 10,
                "max_customers": 1000,
                "max_equipment": 500,
                "max_bookings_per_month": 200,
                "max_storage_gb": 10,
                "api_limits": {"per_hour": 5000, "per_day": 50000},
                "max_bandwidth_gb_per_month": 100,
                "max_invoices_per_month": 200
            },
            TenantTier.ENTERPRISE: {
                "max_users": 50,
                "max_customers": 10000,
                "max_equipment": 5000,
                "max_bookings_per_month": 2000,
                "max_storage_gb": 100,
                "api_limits": {"per_hour": 25000, "per_day": 250000},
                "max_bandwidth_gb_per_month": 1000,
                "max_invoices_per_month": 2000
            },
            TenantTier.CUSTOM: {
                "max_users": 999999,
                "max_customers": 999999,
                "max_equipment": 999999,
                "max_bookings_per_month": 999999,
                "max_storage_gb": 999999,
                "api_limits": {"per_hour": 999999, "per_day": 999999},
                "max_bandwidth_gb_per_month": 999999,
                "max_invoices_per_month": 999999
            }
        }
        
        return limits.get(tier, limits[TenantTier.STARTER])
    
    def _get_tier_features(self, tier: TenantTier) -> Dict[str, bool]:
        """Get feature flags for a specific tier"""
        features = {
            TenantTier.STARTER: {
                "basic_equipment_catalog": True,
                "basic_booking_management": True,
                "basic_customer_management": True,
                "email_notifications": True,
                "basic_reporting": True,
                "api_access": False,
                "custom_branding": False,
                "advanced_analytics": False,
                "multi_location": False,
                "inventory_tracking": False,
                "automated_workflows": False,
                "custom_integrations": False,
                "priority_support": False,
                "white_labeling": False,
                "advanced_security": False
            },
            TenantTier.PROFESSIONAL: {
                "basic_equipment_catalog": True,
                "basic_booking_management": True,
                "basic_customer_management": True,
                "email_notifications": True,
                "basic_reporting": True,
                "api_access": True,
                "custom_branding": True,
                "advanced_analytics": True,
                "multi_location": True,
                "inventory_tracking": True,
                "automated_workflows": True,
                "custom_integrations": False,
                "priority_support": False,
                "white_labeling": False,
                "advanced_security": True
            },
            TenantTier.ENTERPRISE: {
                "basic_equipment_catalog": True,
                "basic_booking_management": True,
                "basic_customer_management": True,
                "email_notifications": True,
                "basic_reporting": True,
                "api_access": True,
                "custom_branding": True,
                "advanced_analytics": True,
                "multi_location": True,
                "inventory_tracking": True,
                "automated_workflows": True,
                "custom_integrations": True,
                "priority_support": True,
                "white_labeling": True,
                "advanced_security": True
            },
            TenantTier.CUSTOM: {
                "basic_equipment_catalog": True,
                "basic_booking_management": True,
                "basic_customer_management": True,
                "email_notifications": True,
                "basic_reporting": True,
                "api_access": True,
                "custom_branding": True,
                "advanced_analytics": True,
                "multi_location": True,
                "inventory_tracking": True,
                "automated_workflows": True,
                "custom_integrations": True,
                "priority_support": True,
                "white_labeling": True,
                "advanced_security": True
            }
        }
        
        return features.get(tier, features[TenantTier.STARTER])
    
    def _get_current_billing_period(self) -> datetime:
        """Get current billing period start date"""
        now = datetime.utcnow()
        return datetime(now.year, now.month, 1)
    
    async def _initialize_usage_tracking(self, tenant_id: str):
        """Initialize usage tracking for tenant"""
        current_period = self._get_current_billing_period()
        usage_key = f"{tenant_id}:{current_period}"
        
        if usage_key not in self.tenant_usage:
            self.tenant_usage[usage_key] = TenantUsage(
                tenant_id=tenant_id,
                period_start=current_period,
                period_end=current_period + timedelta(days=30),
                users_count=0,
                customers_count=0,
                equipment_count=0,
                bookings_count=0,
                storage_used_gb=0.0,
                api_calls_count=0,
                bandwidth_used_gb=0.0,
                invoice_count=0,
                revenue_generated=0.0,
                last_activity=datetime.utcnow(),
                feature_usage={}
            )
    
    async def _check_usage_limits(self, tenant_id: str, usage: TenantUsage):
        """Check if tenant has exceeded usage limits"""
        if tenant_id not in self.tenant_limits:
            return
        
        limits = self.tenant_limits[tenant_id]
        tenant = self.tenants[tenant_id]
        
        # Check various limits and take action if exceeded
        warnings = []
        
        if usage.bookings_count >= limits["max_bookings_per_month"]:
            warnings.append("Monthly booking limit reached")
        
        if usage.storage_used_gb >= limits["max_storage_gb"]:
            warnings.append("Storage limit reached")
        
        if usage.api_calls_count >= limits["api_limits"]["per_day"]:
            warnings.append("Daily API limit reached")
        
        # Log warnings or take action
        if warnings:
            print(f"Usage warnings for tenant {tenant_id}: {', '.join(warnings)}")
    
    async def _get_hourly_api_usage(self, tenant_id: str) -> int:
        """Get API usage for the current hour"""
        # Mock implementation - in real system, track hourly usage
        return 0
    
    async def _get_tenant_by_api_key(self, api_key: str) -> Optional[str]:
        """Get tenant ID by API key"""
        # Mock implementation - in real system, maintain API key to tenant mapping
        return None

# Supporting Classes
class DatabaseManager:
    async def initialize_tenant_database(self, tenant: TenantConfiguration):
        """Initialize tenant database/schema"""
        print(f"Initializing database for tenant: {tenant.tenant_id}")
    
    async def cleanup_tenant_database(self, tenant: TenantConfiguration):
        """Clean up tenant database/schema"""
        print(f"Cleaning up database for tenant: {tenant.tenant_id}")

class CacheManager:
    async def setup_tenant_cache(self, tenant: TenantConfiguration):
        """Set up tenant cache namespace"""
        print(f"Setting up cache for tenant: {tenant.tenant_id}")
    
    async def cleanup_tenant_cache(self, tenant: TenantConfiguration):
        """Clean up tenant cache"""
        print(f"Cleaning up cache for tenant: {tenant.tenant_id}")

class IsolationManager:
    async def setup_tenant_isolation(self, tenant: TenantConfiguration):
        """Set up tenant isolation"""
        print(f"Setting up isolation for tenant: {tenant.tenant_id} (level: {tenant.isolation_level.value})")
    
    async def update_tenant_isolation(self, tenant: TenantConfiguration):
        """Update tenant isolation"""
        print(f"Updating isolation for tenant: {tenant.tenant_id}")
    
    async def cleanup_tenant_isolation(self, tenant: TenantConfiguration):
        """Clean up tenant isolation"""
        print(f"Cleaning up isolation for tenant: {tenant.tenant_id}")

class BillingManager:
    async def setup_tenant_billing(self, tenant: TenantConfiguration):
        """Set up tenant billing"""
        print(f"Setting up billing for tenant: {tenant.tenant_id}")
    
    async def update_tenant_billing(self, tenant: TenantConfiguration, old_tier: TenantTier):
        """Update tenant billing"""
        print(f"Updating billing for tenant: {tenant.tenant_id} (tier: {old_tier.value} -> {tenant.tier.value})")
    
    async def cleanup_tenant_billing(self, tenant: TenantConfiguration):
        """Clean up tenant billing"""
        print(f"Cleaning up billing for tenant: {tenant.tenant_id}")

class ResourceManager:
    async def allocate_resources(self, tenant: TenantConfiguration):
        """Allocate resources for tenant"""
        print(f"Allocating resources for tenant: {tenant.tenant_id}")
    
    async def deallocate_resources(self, tenant: TenantConfiguration):
        """Deallocate resources for tenant"""
        print(f"Deallocating resources for tenant: {tenant.tenant_id}")
```

## 4. GDPR Compliance Service

### Data Privacy and Anonymization Implementation

```python
# services/gdpr_compliance_service.py
from typing import Dict, List, Any, Optional, Union, Callable
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import json
import uuid
import hashlib
import re
from abc import ABC, abstractmethod

class DataCategory(Enum):
    PERSONAL_IDENTIFIABLE = "personal_identifiable"
    SENSITIVE_PERSONAL = "sensitive_personal"
    FINANCIAL = "financial"
    BEHAVIORAL = "behavioral"
    TECHNICAL = "technical"
    COMMUNICATION = "communication"

class ProcessingPurpose(Enum):
    CONTRACT_PERFORMANCE = "contract_performance"
    LEGITIMATE_INTEREST = "legitimate_interest"
    CONSENT = "consent"
    LEGAL_OBLIGATION = "legal_obligation"
    VITAL_INTERESTS = "vital_interests"
    PUBLIC_TASK = "public_task"

class DataSubjectRight(Enum):
    ACCESS = "access"
    RECTIFICATION = "rectification"
    ERASURE = "erasure"
    RESTRICT_PROCESSING = "restrict_processing"
    DATA_PORTABILITY = "data_portability"
    OBJECT = "object"
    WITHDRAW_CONSENT = "withdraw_consent"

class ConsentStatus(Enum):
    GIVEN = "given"
    WITHDRAWN = "withdrawn"
    EXPIRED = "expired"
    PENDING = "pending"

@dataclass
class DataField:
    field_name: str
    data_category: DataCategory
    is_required: bool
    processing_purposes: List[ProcessingPurpose]
    retention_period_days: int
    anonymization_method: str
    description: str
    legal_basis: str

@dataclass
class ConsentRecord:
    consent_id: str
    data_subject_id: str
    tenant_id: str
    processing_purposes: List[ProcessingPurpose]
    data_categories: List[DataCategory]
    consent_given_at: datetime
    consent_withdrawn_at: Optional[datetime]
    consent_expires_at: Optional[datetime]
    status: ConsentStatus
    consent_method: str  # web_form, email, phone, etc.
    consent_evidence: Dict[str, Any]
    ip_address: Optional[str]
    user_agent: Optional[str]
    version: str = "1.0"

@dataclass
class DataProcessingRecord:
    record_id: str
    data_subject_id: str
    tenant_id: str
    processing_activity: str
    data_categories: List[DataCategory]
    processing_purposes: List[ProcessingPurpose]
    legal_basis: ProcessingPurpose
    data_fields: List[str]
    processed_at: datetime
    retention_until: datetime
    automated_decision_making: bool = False
    third_party_sharing: bool = False
    cross_border_transfer: bool = False
    security_measures: List[str] = None

@dataclass
class DataSubjectRequest:
    request_id: str
    data_subject_id: str
    tenant_id: str
    request_type: DataSubjectRight
    requested_at: datetime
    verified_at: Optional[datetime]
    completed_at: Optional[datetime]
    status: str
    verification_method: str
    request_details: Dict[str, Any]
    response_data: Optional[Dict[str, Any]] = None
    notes: List[str] = None

class GDPRComplianceService:
    def __init__(self, encryption_service=None, audit_service=None):
        self.data_mappings = {}
        self.consent_records = {}
        self.processing_records = []
        self.data_subject_requests = {}
        self.anonymization_engine = AnonymizationEngine()
        self.consent_manager = ConsentManager()
        self.retention_manager = RetentionManager()
        self.encryption_service = encryption_service or EncryptionService()
        self.audit_service = audit_service or AuditService()
        
        # Initialize data field mappings for AV rental system
        self._initialize_av_rental_data_mappings()
    
    def _initialize_av_rental_data_mappings(self):
        """Initialize data field mappings for AV rental system"""
        
        # Customer data fields
        customer_fields = [
            DataField(
                field_name="first_name",
                data_category=DataCategory.PERSONAL_IDENTIFIABLE,
                is_required=True,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE, ProcessingPurpose.LEGITIMATE_INTEREST],
                retention_period_days=2555,  # 7 years
                anonymization_method="pseudonymization",
                description="Customer first name",
                legal_basis="Contract performance and legitimate business interest"
            ),
            DataField(
                field_name="last_name",
                data_category=DataCategory.PERSONAL_IDENTIFIABLE,
                is_required=True,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE, ProcessingPurpose.LEGITIMATE_INTEREST],
                retention_period_days=2555,
                anonymization_method="pseudonymization",
                description="Customer last name",
                legal_basis="Contract performance and legitimate business interest"
            ),
            DataField(
                field_name="email",
                data_category=DataCategory.PERSONAL_IDENTIFIABLE,
                is_required=True,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE, ProcessingPurpose.CONSENT],
                retention_period_days=2555,
                anonymization_method="hashing",
                description="Customer email address",
                legal_basis="Contract performance and marketing consent"
            ),
            DataField(
                field_name="phone",
                data_category=DataCategory.PERSONAL_IDENTIFIABLE,
                is_required=False,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE, ProcessingPurpose.LEGITIMATE_INTEREST],
                retention_period_days=2555,
                anonymization_method="masking",
                description="Customer phone number",
                legal_basis="Contract performance and legitimate business interest"
            ),
            DataField(
                field_name="billing_address",
                data_category=DataCategory.PERSONAL_IDENTIFIABLE,
                is_required=True,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE, ProcessingPurpose.LEGAL_OBLIGATION],
                retention_period_days=2555,
                anonymization_method="generalization",
                description="Customer billing address",
                legal_basis="Contract performance and tax obligations"
            ),
            DataField(
                field_name="delivery_address",
                data_category=DataCategory.PERSONAL_IDENTIFIABLE,
                is_required=False,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE],
                retention_period_days=1095,  # 3 years
                anonymization_method="generalization",
                description="Equipment delivery address",
                legal_basis="Contract performance"
            ),
            DataField(
                field_name="tax_id",
                data_category=DataCategory.FINANCIAL,
                is_required=False,
                processing_purposes=[ProcessingPurpose.LEGAL_OBLIGATION],
                retention_period_days=2555,
                anonymization_method="encryption",
                description="Customer tax identification number",
                legal_basis="Legal obligation for tax reporting"
            ),
            DataField(
                field_name="payment_information",
                data_category=DataCategory.FINANCIAL,
                is_required=True,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE],
                retention_period_days=1095,
                anonymization_method="tokenization",
                description="Payment method details",
                legal_basis="Contract performance"
            ),
            DataField(
                field_name="rental_history",
                data_category=DataCategory.BEHAVIORAL,
                is_required=False,
                processing_purposes=[ProcessingPurpose.LEGITIMATE_INTEREST],
                retention_period_days=1825,  # 5 years
                anonymization_method="aggregation",
                description="Customer rental history and preferences",
                legal_basis="Legitimate business interest for service improvement"
            ),
            DataField(
                field_name="communication_preferences",
                data_category=DataCategory.COMMUNICATION,
                is_required=False,
                processing_purposes=[ProcessingPurpose.CONSENT],
                retention_period_days=1095,
                anonymization_method="deletion",
                description="Marketing and communication preferences",
                legal_basis="Explicit consent for marketing communications"
            ),
            DataField(
                field_name="ip_address",
                data_category=DataCategory.TECHNICAL,
                is_required=False,
                processing_purposes=[ProcessingPurpose.LEGITIMATE_INTEREST],
                retention_period_days=365,
                anonymization_method="ip_anonymization",
                description="IP address for security and analytics",
                legal_basis="Legitimate interest for security and fraud prevention"
            ),
            DataField(
                field_name="device_information",
                data_category=DataCategory.TECHNICAL,
                is_required=False,
                processing_purposes=[ProcessingPurpose.LEGITIMATE_INTEREST],
                retention_period_days=365,
                anonymization_method="generalization",
                description="Device and browser information",
                legal_basis="Legitimate interest for service optimization"
            )
        ]
        
        self.data_mappings["customer"] = customer_fields
        
        # Booking data fields
        booking_fields = [
            DataField(
                field_name="event_details",
                data_category=DataCategory.PERSONAL_IDENTIFIABLE,
                is_required=True,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE],
                retention_period_days=2555,
                anonymization_method="generalization",
                description="Event details and requirements",
                legal_basis="Contract performance"
            ),
            DataField(
                field_name="special_requirements",
                data_category=DataCategory.PERSONAL_IDENTIFIABLE,
                is_required=False,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE],
                retention_period_days=1095,
                anonymization_method="generalization",
                description="Special requirements or accessibility needs",
                legal_basis="Contract performance"
            ),
            DataField(
                field_name="crew_notes",
                data_category=DataCategory.PERSONAL_IDENTIFIABLE,
                is_required=False,
                processing_purposes=[ProcessingPurpose.CONTRACT_PERFORMANCE],
                retention_period_days=1095,
                anonymization_method="redaction",
                description="Internal crew notes about customer or event",
                legal_basis="Contract performance"
            )
        ]
        
        self.data_mappings["booking"] = booking_fields
    
    # Consent Management
    async def record_consent(
        self, 
        data_subject_id: str, 
        tenant_id: str, 
        consent_data: Dict[str, Any]
    ) -> ConsentRecord:
        """Record consent from data subject"""
        try:
            consent_record = ConsentRecord(
                consent_id=str(uuid.uuid4()),
                data_subject_id=data_subject_id,
                tenant_id=tenant_id,
                processing_purposes=[ProcessingPurpose(p) for p in consent_data["processing_purposes"]],
                data_categories=[DataCategory(c) for c in consent_data["data_categories"]],
                consent_given_at=datetime.utcnow(),
                consent_withdrawn_at=None,
                consent_expires_at=consent_data.get("expires_at"),
                status=ConsentStatus.GIVEN,
                consent_method=consent_data.get("method", "web_form"),
                consent_evidence=consent_data.get("evidence", {}),
                ip_address=consent_data.get("ip_address"),
                user_agent=consent_data.get("user_agent"),
                version=consent_data.get("version", "1.0")
            )
            
            # Store consent record
            consent_key = f"{tenant_id}:{data_subject_id}"
            if consent_key not in self.consent_records:
                self.consent_records[consent_key] = []
            
            self.consent_records[consent_key].append(consent_record)
            
            # Log consent for audit
            await self.audit_service.log_consent_event(
                "consent_given",
                consent_record,
                {"ip_address": consent_data.get("ip_address")}
            )
            
            print(f"Consent recorded: {consent_record.consent_id}")
            return consent_record
            
        except Exception as e:
            print(f"Failed to record consent: {e}")
            raise
    
    async def withdraw_consent(
        self, 
        data_subject_id: str, 
        tenant_id: str, 
        processing_purposes: List[str]
    ) -> bool:
        """Withdraw consent for specific processing purposes"""
        try:
            consent_key = f"{tenant_id}:{data_subject_id}"
            
            if consent_key not in self.consent_records:
                return False
            
            # Find and update relevant consent records
            updated_records = []
            
            for consent_record in self.consent_records[consent_key]:
                if consent_record.status == ConsentStatus.GIVEN:
                    # Check if any of the processing purposes match
                    matching_purposes = [
                        p for p in consent_record.processing_purposes 
                        if p.value in processing_purposes
                    ]
                    
                    if matching_purposes:
                        consent_record.status = ConsentStatus.WITHDRAWN
                        consent_record.consent_withdrawn_at = datetime.utcnow()
                        updated_records.append(consent_record)
            
            if updated_records:
                # Log withdrawal for audit
                for record in updated_records:
                    await self.audit_service.log_consent_event(
                        "consent_withdrawn",
                        record,
                        {"processing_purposes": processing_purposes}
                    )
                
                # Trigger data processing restrictions
                await self._apply_consent_withdrawal(data_subject_id, tenant_id, processing_purposes)
                
                print(f"Consent withdrawn for {len(updated_records)} records")
                return True
            
            return False
            
        except Exception as e:
            print(f"Failed to withdraw consent: {e}")
            return False
    
    async def check_consent(
        self, 
        data_subject_id: str, 
        tenant_id: str, 
        processing_purpose: ProcessingPurpose,
        data_category: DataCategory
    ) -> bool:
        """Check if valid consent exists for processing"""
        try:
            consent_key = f"{tenant_id}:{data_subject_id}"
            
            if consent_key not in self.consent_records:
                return False
            
            current_time = datetime.utcnow()
            
            for consent_record in self.consent_records[consent_key]:
                # Check if consent is active
                if consent_record.status != ConsentStatus.GIVEN:
                    continue
                
                # Check if consent has expired
                if consent_record.consent_expires_at and consent_record.consent_expires_at < current_time:
                    consent_record.status = ConsentStatus.EXPIRED
                    continue
                
                # Check if processing purpose and data category are covered
                if (processing_purpose in consent_record.processing_purposes and 
                    data_category in consent_record.data_categories):
                    return True
            
            return False
            
        except Exception as e:
            print(f"Failed to check consent: {e}")
            return False
    
    # Data Processing Records
    async def record_processing_activity(
        self, 
        data_subject_id: str, 
        tenant_id: str, 
        processing_data: Dict[str, Any]
    ) -> DataProcessingRecord:
        """Record data processing activity"""
        try:
            # Calculate retention period
            retention_days = max([
                self._get_field_retention_period(field) 
                for field in processing_data.get("data_fields", [])
            ], default=365)
            
            processing_record = DataProcessingRecord(
                record_id=str(uuid.uuid4()),
                data_subject_id=data_subject_id,
                tenant_id=tenant_id,
                processing_activity=processing_data["activity"],
                data_categories=[DataCategory(c) for c in processing_data["data_categories"]],
                processing_purposes=[ProcessingPurpose(p) for p in processing_data["processing_purposes"]],
                legal_basis=ProcessingPurpose(processing_data["legal_basis"]),
                data_fields=processing_data.get("data_fields", []),
                processed_at=datetime.utcnow(),
                retention_until=datetime.utcnow() + timedelta(days=retention_days),
                automated_decision_making=processing_data.get("automated_decision_making", False),
                third_party_sharing=processing_data.get("third_party_sharing", False),
                cross_border_transfer=processing_data.get("cross_border_transfer", False),
                security_measures=processing_data.get("security_measures", [])
            )
            
            # Store processing record
            self.processing_records.append(processing_record)
            
            # Log processing activity for audit
            await self.audit_service.log_processing_activity(processing_record)
            
            print(f"Processing activity recorded: {processing_record.record_id}")
            return processing_record
            
        except Exception as e:
            print(f"Failed to record processing activity: {e}")
            raise
    
    # Data Subject Rights
    async def handle_data_subject_request(
        self, 
        data_subject_id: str, 
        tenant_id: str, 
        request_data: Dict[str, Any]
    ) -> DataSubjectRequest:
        """Handle data subject rights request"""
        try:
            request = DataSubjectRequest(
                request_id=str(uuid.uuid4()),
                data_subject_id=data_subject_id,
                tenant_id=tenant_id,
                request_type=DataSubjectRight(request_data["request_type"]),
                requested_at=datetime.utcnow(),
                verified_at=None,
                completed_at=None,
                status="pending_verification",
                verification_method=request_data.get("verification_method", "email"),
                request_details=request_data.get("details", {}),
                notes=[]
            )
            
            # Store request
            self.data_subject_requests[request.request_id] = request
            
            # Start verification process
            await self._initiate_identity_verification(request)
            
            # Log request for audit
            await self.audit_service.log_data_subject_request(request)
            
            print(f"Data subject request created: {request.request_id} ({request.request_type.value})")
            return request
            
        except Exception as e:
            print(f"Failed to handle data subject request: {e}")
            raise
    
    async def process_verified_request(self, request_id: str) -> bool:
        """Process a verified data subject request"""
        try:
            if request_id not in self.data_subject_requests:
                return False
            
            request = self.data_subject_requests[request_id]
            
            if request.status != "verified":
                return False
            
            # Process based on request type
            if request.request_type == DataSubjectRight.ACCESS:
                response_data = await self._process_access_request(request)
            elif request.request_type == DataSubjectRight.RECTIFICATION:
                response_data = await self._process_rectification_request(request)
            elif request.request_type == DataSubjectRight.ERASURE:
                response_data = await self._process_erasure_request(request)
            elif request.request_type == DataSubjectRight.RESTRICT_PROCESSING:
                response_data = await self._process_restriction_request(request)
            elif request.request_type == DataSubjectRight.DATA_PORTABILITY:
                response_data = await self._process_portability_request(request)
            elif request.request_type == DataSubjectRight.OBJECT:
                response_data = await self._process_objection_request(request)
            elif request.request_type == DataSubjectRight.WITHDRAW_CONSENT:
                response_data = await self._process_consent_withdrawal_request(request)
            else:
                return False
            
            # Update request
            request.response_data = response_data
            request.completed_at = datetime.utcnow()
            request.status = "completed"
            
            # Log completion for audit
            await self.audit_service.log_request_completion(request)
            
            print(f"Data subject request completed: {request_id}")
            return True
            
        except Exception as e:
            print(f"Failed to process verified request {request_id}: {e}")
            return False
    
    # Data Anonymization
    async def anonymize_data(
        self, 
        data: Dict[str
