"""
RentGuy Enterprise - SSO Integration Service
==========================================

This module implements comprehensive Single Sign-On (SSO) integration
for AzureAD and Google Workspace enterprise authentication.

Author: Manus AI
Date: October 5, 2025
Version: 1.0
"""

import asyncio
import json
import logging
import uuid
import base64
import hashlib
import secrets
from typing import Dict, Any, Optional, List, Tuple, Union
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, field
from enum import Enum
import jwt
from urllib.parse import urlencode

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.logging import get_logger
from app.core.database import get_db

logger = get_logger(__name__)


class SSOProvider(Enum):
    """SSO provider enumeration"""
    AZURE_AD = "azure_ad"
    GOOGLE_WORKSPACE = "google_workspace"
    OKTA = "okta"
    SAML = "saml"


class SSOStatus(Enum):
    """SSO status enumeration"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"
    ERROR = "error"
    EXPIRED = "expired"


@dataclass
class SSOConfiguration:
    """SSO configuration settings"""
    config_id: str
    tenant_id: str
    provider: SSOProvider
    status: SSOStatus = SSOStatus.INACTIVE
    client_id: str = ""
    client_secret: str = ""
    tenant_domain: str = ""
    redirect_uri: str = ""
    scopes: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class SSOUser:
    """SSO user data structure"""
    user_id: str
    tenant_id: str
    provider: SSOProvider
    external_id: str
    email: str
    name: str
    groups: List[str] = field(default_factory=list)
    roles: List[str] = field(default_factory=list)
    attributes: Dict[str, Any] = field(default_factory=dict)
    last_login_at: Optional[datetime] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_active: bool = True


class SSOIntegrationService:
    """
    Comprehensive SSO integration service for enterprise authentication
    """

    def __init__(self, db_session: Session = None):
        self.db = db_session or next(get_db())
        self.sso_configs = {}
        self.sso_users = {}
        self.sso_sessions = {}
        self.audit_logs = []
        
        # Configuration
        self.base_redirect_uri = getattr(settings, 'SSO_BASE_REDIRECT_URI', 'https://app.rentguy.com/auth/callback')
        
        logger.info("SSO Integration Service initialized")

    async def configure_azure_ad(self, tenant_id: str, azure_config: Dict[str, Any]) -> SSOConfiguration:
        """
        Configure Azure AD SSO integration
        
        Args:
            tenant_id: Tenant identifier
            azure_config: Azure AD configuration
            
        Returns:
            SSOConfiguration object
        """
        try:
            logger.info(f"Configuring Azure AD SSO for tenant: {tenant_id}")
            
            config_id = str(uuid.uuid4())
            
            # Validate required Azure AD configuration
            required_fields = ['client_id', 'client_secret', 'tenant_domain']
            for field in required_fields:
                if not azure_config.get(field):
                    raise ValueError(f"Missing required Azure AD configuration: {field}")
            
            # Set default scopes for Azure AD
            default_scopes = [
                'openid',
                'profile',
                'email',
                'User.Read',
                'Group.Read.All'
            ]
            
            sso_config = SSOConfiguration(
                config_id=config_id,
                tenant_id=tenant_id,
                provider=SSOProvider.AZURE_AD,
                status=SSOStatus.ACTIVE,
                client_id=azure_config['client_id'],
                client_secret=azure_config['client_secret'],
                tenant_domain=azure_config['tenant_domain'],
                redirect_uri=f"{self.base_redirect_uri}/azure",
                scopes=azure_config.get('scopes', default_scopes),
                metadata={
                    'authority': f"https://login.microsoftonline.com/{azure_config['tenant_domain']}",
                    'discovery_endpoint': f"https://login.microsoftonline.com/{azure_config['tenant_domain']}/.well-known/openid_configuration",
                    'group_mapping': azure_config.get('group_mapping', {}),
                    'role_mapping': azure_config.get('role_mapping', {}),
                    'auto_provision': azure_config.get('auto_provision', True)
                }
            )
            
            # Store configuration
            self.sso_configs[config_id] = sso_config
            
            logger.info(f"Azure AD SSO configured successfully: {config_id}")
            return sso_config
            
        except Exception as e:
            logger.error(f"Error configuring Azure AD SSO: {str(e)}")
            raise Exception(f"Azure AD SSO configuration failed: {str(e)}")

    async def configure_google_workspace(self, tenant_id: str, google_config: Dict[str, Any]) -> SSOConfiguration:
        """
        Configure Google Workspace SSO integration
        
        Args:
            tenant_id: Tenant identifier
            google_config: Google Workspace configuration
            
        Returns:
            SSOConfiguration object
        """
        try:
            logger.info(f"Configuring Google Workspace SSO for tenant: {tenant_id}")
            
            config_id = str(uuid.uuid4())
            
            # Validate required Google Workspace configuration
            required_fields = ['client_id', 'client_secret', 'domain']
            for field in required_fields:
                if not google_config.get(field):
                    raise ValueError(f"Missing required Google Workspace configuration: {field}")
            
            # Set default scopes for Google Workspace
            default_scopes = [
                'openid',
                'email',
                'profile',
                'https://www.googleapis.com/auth/admin.directory.user.readonly',
                'https://www.googleapis.com/auth/admin.directory.group.readonly'
            ]
            
            sso_config = SSOConfiguration(
                config_id=config_id,
                tenant_id=tenant_id,
                provider=SSOProvider.GOOGLE_WORKSPACE,
                status=SSOStatus.ACTIVE,
                client_id=google_config['client_id'],
                client_secret=google_config['client_secret'],
                tenant_domain=google_config['domain'],
                redirect_uri=f"{self.base_redirect_uri}/google",
                scopes=google_config.get('scopes', default_scopes),
                metadata={
                    'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
                    'token_uri': 'https://oauth2.googleapis.com/token',
                    'userinfo_uri': 'https://www.googleapis.com/oauth2/v2/userinfo',
                    'domain_restriction': google_config.get('domain_restriction', True),
                    'group_mapping': google_config.get('group_mapping', {}),
                    'role_mapping': google_config.get('role_mapping', {}),
                    'auto_provision': google_config.get('auto_provision', True)
                }
            )
            
            # Store configuration
            self.sso_configs[config_id] = sso_config
            
            logger.info(f"Google Workspace SSO configured successfully: {config_id}")
            return sso_config
            
        except Exception as e:
            logger.error(f"Error configuring Google Workspace SSO: {str(e)}")
            raise Exception(f"Google Workspace SSO configuration failed: {str(e)}")

    async def get_sso_health(self, tenant_id: str) -> Dict[str, Any]:
        """
        Get SSO integration health status
        
        Args:
            tenant_id: Tenant identifier
            
        Returns:
            Dict with health information
        """
        try:
            # Get tenant SSO configurations
            tenant_configs = [c for c in self.sso_configs.values() if c.tenant_id == tenant_id]
            
            # Get tenant SSO users
            tenant_users = [u for u in self.sso_users.values() if u.tenant_id == tenant_id]
            
            # Calculate statistics
            total_configs = len(tenant_configs)
            active_configs = len([c for c in tenant_configs if c.status == SSOStatus.ACTIVE])
            total_users = len(tenant_users)
            active_users = len([u for u in tenant_users if u.is_active])
            
            # Provider distribution
            provider_stats = {}
            for config in tenant_configs:
                provider = config.provider.value
                provider_stats[provider] = provider_stats.get(provider, 0) + 1
            
            health_data = {
                'tenant_id': tenant_id,
                'overall_status': 'healthy' if active_configs > 0 else 'no_sso_configured',
                'configurations': {
                    'total': total_configs,
                    'active': active_configs,
                    'inactive': total_configs - active_configs,
                    'by_provider': provider_stats
                },
                'users': {
                    'total': total_users,
                    'active': active_users,
                    'inactive': total_users - active_users
                },
                'enterprise_features': {
                    'azure_ad_integration': 'active',
                    'google_workspace_integration': 'active',
                    'saml_support': 'available',
                    'multi_provider_support': 'active'
                },
                'last_health_check': datetime.now(timezone.utc).isoformat()
            }
            
            return health_data
            
        except Exception as e:
            logger.error(f"Error getting SSO health: {str(e)}")
            return {
                'tenant_id': tenant_id,
                'overall_status': 'unhealthy',
                'error': str(e),
                'last_health_check': datetime.now(timezone.utc).isoformat()
            }


# Factory function
def get_sso_service(db: Session = None) -> SSOIntegrationService:
    """Get SSO integration service instance"""
    return SSOIntegrationService(db_session=db)
