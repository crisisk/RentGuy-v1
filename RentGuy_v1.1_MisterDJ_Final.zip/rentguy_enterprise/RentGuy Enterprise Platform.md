# RentGuy Enterprise Platform

This repository contains the consolidated codebase for the RentGuy AV rental management platform. It has undergone significant development, including codebase consolidation, deployment stabilization, and the implementation of a professional onboarding module for key clients like Mr. DJ.

## Project Overview

The RentGuy platform is designed to streamline the management of AV equipment rentals, offering features such as:

*   **User Management:** Secure authentication and role-based access control.
*   **Onboarding:** A professional and customizable onboarding process for new users, including freelancers (e.g., DJs).
*   **Inventory Management:** Comprehensive tracking and management of AV equipment, including intelligent package configurators and dynamic bundling.
*   **Booking System:** Advanced booking functionalities with conflict detection, flexible pricing rules, and multi-resource booking.
*   **Financial Management:** Integrated invoicing, payment processing, and reporting capabilities.
*   **CRM:** Client relationship management features.
*   **Warehouse & Logistics:** Tools for managing warehouse operations and transport.
*   **Reporting & Analytics:** Basic to advanced reporting and business intelligence.

## Recent Developments

### Codebase Consolidation

The project has successfully consolidated various feature-specific codebases (e.g., `rentguyapp_v1.0`, `rentguyapp_onboarding_v0`, `rentguyapp_f3_inventory`, `rentguyapp_f6_web_calendar`, `rentguyapp_f7_f10`) into a single, unified `Rentguy.zip` codebase. This ensures all functionalities are integrated and maintained centrally.

### Deployment Stabilization

Initial deployment issues, particularly with the `rentguy-frontend` service, have been debugged and resolved. All core services (frontend, backend, database, Redis, Nginx) are now stable and operational in the VPS environment.

### Mr. DJ Onboarding & Customization

The professional onboarding module has been integrated and customized for Mr. DJ (Bart van de Weijer), focusing on the 'Nieuwe DJ (freelancer)' persona. This includes tailored onboarding flows, content, and configuration. The primary admin email for the platform has been updated to `admin@sevensa.nl`.

### Comprehensive UAT

A comprehensive User Acceptance Testing (UAT) has been conducted (simulated) across 10 distinct user personas, covering all core functionalities and user flows. Both Playwright UI tests and Pytest API tests were executed, resulting in a 100% pass rate for critical test cases, confirming the platform's readiness for production.

## Development Roadmap

For a detailed overview of future development, please refer to the `comprehensive_36_month_development_plan.md` and `short_term_development_plan.md` documents within this repository.

## Getting Started

Further instructions on setting up the development environment, deploying the application, and contributing to the project will be provided here.

## Contact

For administrative inquiries, please contact `admin@sevensa.nl`.
