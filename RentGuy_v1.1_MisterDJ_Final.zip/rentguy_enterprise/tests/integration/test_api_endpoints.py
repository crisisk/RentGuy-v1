"""
Integration tests for RentGuy Enterprise API endpoints.
"""

import pytest
from httpx import AsyncClient
from fastapi import status

from tests.conftest import assert_valid_uuid, assert_valid_email


@pytest.mark.integration
class TestAuthenticationEndpoints:
    """Test authentication API endpoints."""

    async def test_register_user_success(self, async_client: AsyncClient):
        """Test successful user registration."""
        user_data = {
            "email": "newuser@example.com",
            "password": "securepassword123",
            "full_name": "New User",
        }
        
        response = await async_client.post("/api/v1/auth/register", json=user_data)
        
        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["email"] == user_data["email"]
        assert data["full_name"] == user_data["full_name"]
        assert "id" in data
        assert_valid_uuid(data["id"])
        assert "password" not in data  # Password should not be returned

    async def test_register_user_duplicate_email(self, async_client: AsyncClient):
        """Test registration with duplicate email."""
        user_data = {
            "email": "duplicate@example.com",
            "password": "securepassword123",
            "full_name": "First User",
        }
        
        # Register first user
        await async_client.post("/api/v1/auth/register", json=user_data)
        
        # Try to register second user with same email
        user_data["full_name"] = "Second User"
        response = await async_client.post("/api/v1/auth/register", json=user_data)
        
        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "email already registered" in response.json()["detail"].lower()

    async def test_login_success(self, async_client: AsyncClient):
        """Test successful user login."""
        # Register user first
        user_data = {
            "email": "logintest@example.com",
            "password": "securepassword123",
            "full_name": "Login Test User",
        }
        await async_client.post("/api/v1/auth/register", json=user_data)
        
        # Login
        login_data = {
            "username": user_data["email"],
            "password": user_data["password"],
        }
        response = await async_client.post("/api/v1/auth/login", data=login_data)
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"

    async def test_login_invalid_credentials(self, async_client: AsyncClient):
        """Test login with invalid credentials."""
        login_data = {
            "username": "nonexistent@example.com",
            "password": "wrongpassword",
        }
        response = await async_client.post("/api/v1/auth/login", data=login_data)
        
        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    async def test_get_current_user(self, async_client: AsyncClient):
        """Test getting current user information."""
        # Register and login user
        user_data = {
            "email": "currentuser@example.com",
            "password": "securepassword123",
            "full_name": "Current User",
        }
        await async_client.post("/api/v1/auth/register", json=user_data)
        
        login_response = await async_client.post(
            "/api/v1/auth/login",
            data={"username": user_data["email"], "password": user_data["password"]}
        )
        token = login_response.json()["access_token"]
        
        # Get current user
        headers = {"Authorization": f"Bearer {token}"}
        response = await async_client.get("/api/v1/auth/me", headers=headers)
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["email"] == user_data["email"]
        assert data["full_name"] == user_data["full_name"]


@pytest.mark.integration
class TestEquipmentEndpoints:
    """Test equipment API endpoints."""

    async def test_create_equipment_success(self, async_client: AsyncClient, authenticated_headers):
        """Test successful equipment creation."""
        equipment_data = {
            "name": "Professional Microphone",
            "description": "High-quality wireless microphone",
            "category": "audio",
            "daily_rate": 25.00,
            "weekly_rate": 150.00,
            "monthly_rate": 500.00,
            "serial_number": "MIC-001",
            "brand": "Shure",
            "model": "SM58",
        }
        
        response = await async_client.post(
            "/api/v1/equipment/",
            json=equipment_data,
            headers=authenticated_headers
        )
        
        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["name"] == equipment_data["name"]
        assert data["category"] == equipment_data["category"]
        assert data["daily_rate"] == equipment_data["daily_rate"]
        assert data["is_available"] is True
        assert_valid_uuid(data["id"])

    async def test_get_equipment_list(self, async_client: AsyncClient):
        """Test getting equipment list."""
        response = await async_client.get("/api/v1/equipment/")
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)

    async def test_get_equipment_by_id(self, async_client: AsyncClient, authenticated_headers):
        """Test getting equipment by ID."""
        # Create equipment first
        equipment_data = {
            "name": "Test Equipment",
            "category": "audio",
            "daily_rate": 30.00,
        }
        create_response = await async_client.post(
            "/api/v1/equipment/",
            json=equipment_data,
            headers=authenticated_headers
        )
        equipment_id = create_response.json()["id"]
        
        # Get equipment by ID
        response = await async_client.get(f"/api/v1/equipment/{equipment_id}")
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == equipment_id
        assert data["name"] == equipment_data["name"]

    async def test_update_equipment(self, async_client: AsyncClient, authenticated_headers):
        """Test updating equipment."""
        # Create equipment first
        equipment_data = {
            "name": "Original Name",
            "category": "audio",
            "daily_rate": 30.00,
        }
        create_response = await async_client.post(
            "/api/v1/equipment/",
            json=equipment_data,
            headers=authenticated_headers
        )
        equipment_id = create_response.json()["id"]
        
        # Update equipment
        update_data = {
            "name": "Updated Name",
            "daily_rate": 35.00,
        }
        response = await async_client.patch(
            f"/api/v1/equipment/{equipment_id}",
            json=update_data,
            headers=authenticated_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["name"] == update_data["name"]
        assert data["daily_rate"] == update_data["daily_rate"]

    async def test_delete_equipment(self, async_client: AsyncClient, authenticated_headers):
        """Test deleting equipment."""
        # Create equipment first
        equipment_data = {
            "name": "Equipment to Delete",
            "category": "audio",
            "daily_rate": 30.00,
        }
        create_response = await async_client.post(
            "/api/v1/equipment/",
            json=equipment_data,
            headers=authenticated_headers
        )
        equipment_id = create_response.json()["id"]
        
        # Delete equipment
        response = await async_client.delete(
            f"/api/v1/equipment/{equipment_id}",
            headers=authenticated_headers
        )
        
        assert response.status_code == status.HTTP_204_NO_CONTENT
        
        # Verify equipment is deleted
        get_response = await async_client.get(f"/api/v1/equipment/{equipment_id}")
        assert get_response.status_code == status.HTTP_404_NOT_FOUND

    async def test_search_equipment(self, async_client: AsyncClient, authenticated_headers):
        """Test equipment search functionality."""
        # Create test equipment
        equipment_items = [
            {"name": "Wireless Microphone", "category": "audio", "daily_rate": 25.00},
            {"name": "LED Light Panel", "category": "lighting", "daily_rate": 40.00},
            {"name": "Professional Speaker", "category": "audio", "daily_rate": 60.00},
        ]
        
        for item in equipment_items:
            await async_client.post(
                "/api/v1/equipment/",
                json=item,
                headers=authenticated_headers
            )
        
        # Search by category
        response = await async_client.get("/api/v1/equipment/search?category=audio")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data) == 2  # Two audio items
        
        # Search by name
        response = await async_client.get("/api/v1/equipment/search?q=microphone")
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert len(data) == 1
        assert "microphone" in data[0]["name"].lower()


@pytest.mark.integration
class TestRentalEndpoints:
    """Test rental API endpoints."""

    async def test_create_rental_success(self, async_client: AsyncClient, authenticated_headers):
        """Test successful rental creation."""
        # Create equipment first
        equipment_data = {
            "name": "Rental Equipment",
            "category": "audio",
            "daily_rate": 50.00,
        }
        equipment_response = await async_client.post(
            "/api/v1/equipment/",
            json=equipment_data,
            headers=authenticated_headers
        )
        equipment_id = equipment_response.json()["id"]
        
        # Create rental
        rental_data = {
            "start_date": "2024-12-15T10:00:00",
            "end_date": "2024-12-18T18:00:00",
            "customer_name": "John Doe",
            "customer_email": "john@example.com",
            "customer_phone": "+1234567890",
            "event_name": "Corporate Event",
            "event_location": "Convention Center",
            "equipment_ids": [equipment_id],
        }
        
        response = await async_client.post(
            "/api/v1/rentals/",
            json=rental_data,
            headers=authenticated_headers
        )
        
        assert response.status_code == status.HTTP_201_CREATED
        data = response.json()
        assert data["customer_name"] == rental_data["customer_name"]
        assert data["customer_email"] == rental_data["customer_email"]
        assert data["event_name"] == rental_data["event_name"]
        assert data["status"] == "pending"
        assert len(data["equipment"]) == 1
        assert_valid_uuid(data["id"])

    async def test_get_rental_list(self, async_client: AsyncClient, authenticated_headers):
        """Test getting rental list."""
        response = await async_client.get(
            "/api/v1/rentals/",
            headers=authenticated_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert isinstance(data, list)

    async def test_get_rental_by_id(self, async_client: AsyncClient, authenticated_headers):
        """Test getting rental by ID."""
        # Create equipment and rental first
        equipment_response = await async_client.post(
            "/api/v1/equipment/",
            json={"name": "Test Equipment", "category": "audio", "daily_rate": 30.00},
            headers=authenticated_headers
        )
        equipment_id = equipment_response.json()["id"]
        
        rental_data = {
            "start_date": "2024-12-15T10:00:00",
            "end_date": "2024-12-16T18:00:00",
            "customer_name": "Jane Doe",
            "customer_email": "jane@example.com",
            "equipment_ids": [equipment_id],
        }
        create_response = await async_client.post(
            "/api/v1/rentals/",
            json=rental_data,
            headers=authenticated_headers
        )
        rental_id = create_response.json()["id"]
        
        # Get rental by ID
        response = await async_client.get(
            f"/api/v1/rentals/{rental_id}",
            headers=authenticated_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["id"] == rental_id
        assert data["customer_name"] == rental_data["customer_name"]

    async def test_update_rental_status(self, async_client: AsyncClient, authenticated_headers):
        """Test updating rental status."""
        # Create equipment and rental first
        equipment_response = await async_client.post(
            "/api/v1/equipment/",
            json={"name": "Status Test Equipment", "category": "audio", "daily_rate": 30.00},
            headers=authenticated_headers
        )
        equipment_id = equipment_response.json()["id"]
        
        rental_data = {
            "start_date": "2024-12-15T10:00:00",
            "end_date": "2024-12-16T18:00:00",
            "customer_name": "Status Test Customer",
            "customer_email": "status@example.com",
            "equipment_ids": [equipment_id],
        }
        create_response = await async_client.post(
            "/api/v1/rentals/",
            json=rental_data,
            headers=authenticated_headers
        )
        rental_id = create_response.json()["id"]
        
        # Update status to confirmed
        response = await async_client.patch(
            f"/api/v1/rentals/{rental_id}/status",
            json={"status": "confirmed"},
            headers=authenticated_headers
        )
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["status"] == "confirmed"

    async def test_rental_availability_check(self, async_client: AsyncClient, authenticated_headers):
        """Test rental availability checking."""
        # Create equipment
        equipment_response = await async_client.post(
            "/api/v1/equipment/",
            json={"name": "Availability Test Equipment", "category": "audio", "daily_rate": 30.00},
            headers=authenticated_headers
        )
        equipment_id = equipment_response.json()["id"]
        
        # Create first rental
        rental_data = {
            "start_date": "2024-12-15T10:00:00",
            "end_date": "2024-12-17T18:00:00",
            "customer_name": "First Customer",
            "customer_email": "first@example.com",
            "equipment_ids": [equipment_id],
        }
        await async_client.post(
            "/api/v1/rentals/",
            json=rental_data,
            headers=authenticated_headers
        )
        
        # Try to create overlapping rental
        overlapping_rental_data = {
            "start_date": "2024-12-16T10:00:00",
            "end_date": "2024-12-18T18:00:00",
            "customer_name": "Second Customer",
            "customer_email": "second@example.com",
            "equipment_ids": [equipment_id],
        }
        response = await async_client.post(
            "/api/v1/rentals/",
            json=overlapping_rental_data,
            headers=authenticated_headers
        )
        
        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "not available" in response.json()["detail"].lower()


@pytest.mark.integration
class TestHealthEndpoints:
    """Test health check endpoints."""

    async def test_health_check(self, async_client: AsyncClient):
        """Test basic health check endpoint."""
        response = await async_client.get("/health")
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
        assert "version" in data

    async def test_detailed_health_check(self, async_client: AsyncClient):
        """Test detailed health check endpoint."""
        response = await async_client.get("/health/detailed")
        
        assert response.status_code == status.HTTP_200_OK
        data = response.json()
        assert data["status"] == "healthy"
        assert "database" in data["checks"]
        assert "redis" in data["checks"]
        assert "services" in data


@pytest.mark.integration
class TestErrorHandling:
    """Test API error handling."""

    async def test_404_not_found(self, async_client: AsyncClient):
        """Test 404 error handling."""
        response = await async_client.get("/api/v1/nonexistent-endpoint")
        
        assert response.status_code == status.HTTP_404_NOT_FOUND
        data = response.json()
        assert "detail" in data

    async def test_validation_error(self, async_client: AsyncClient, authenticated_headers):
        """Test validation error handling."""
        invalid_equipment_data = {
            "name": "",  # Empty name should be invalid
            "daily_rate": -10.00,  # Negative rate should be invalid
        }
        
        response = await async_client.post(
            "/api/v1/equipment/",
            json=invalid_equipment_data,
            headers=authenticated_headers
        )
        
        assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY
        data = response.json()
        assert "detail" in data
        assert isinstance(data["detail"], list)

    async def test_unauthorized_access(self, async_client: AsyncClient):
        """Test unauthorized access handling."""
        response = await async_client.post(
            "/api/v1/equipment/",
            json={"name": "Test Equipment", "daily_rate": 30.00}
        )
        
        assert response.status_code == status.HTTP_401_UNAUTHORIZED
