"""
Pytest configuration and fixtures for RentGuy Enterprise tests.
"""

import asyncio
import os
from typing import AsyncGenerator, Generator
from unittest.mock import AsyncMock, MagicMock

import pytest
import pytest_asyncio
from fastapi.testclient import TestClient
from httpx import AsyncClient
from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from rentguy.core.config import Settings
from rentguy.core.database import Base, get_db
from rentguy.main import app


# Test database configuration
TEST_DATABASE_URL = "sqlite+aiosqlite:///./test.db"
TEST_SYNC_DATABASE_URL = "sqlite:///./test.db"


@pytest.fixture(scope="session")
def event_loop() -> Generator[asyncio.AbstractEventLoop, None, None]:
    """Create an instance of the default event loop for the test session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
def test_settings() -> Settings:
    """Create test settings."""
    return Settings(
        database_url=TEST_DATABASE_URL,
        redis_url="redis://localhost:6379/1",
        secret_key="test-secret-key",
        environment="test",
        debug=True,
        testing=True,
    )


@pytest.fixture(scope="session")
async def async_engine():
    """Create async database engine for tests."""
    engine = create_async_engine(
        TEST_DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=False,
    )
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    yield engine
    
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    
    await engine.dispose()


@pytest.fixture(scope="session")
def sync_engine():
    """Create sync database engine for tests."""
    engine = create_engine(
        TEST_SYNC_DATABASE_URL,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=False,
    )
    
    Base.metadata.create_all(bind=engine)
    yield engine
    Base.metadata.drop_all(bind=engine)
    engine.dispose()


@pytest.fixture
async def async_session(async_engine) -> AsyncGenerator[AsyncSession, None]:
    """Create async database session for tests."""
    async_session_maker = sessionmaker(
        async_engine, class_=AsyncSession, expire_on_commit=False
    )
    
    async with async_session_maker() as session:
        yield session
        await session.rollback()


@pytest.fixture
def sync_session(sync_engine):
    """Create sync database session for tests."""
    Session = sessionmaker(bind=sync_engine)
    session = Session()
    yield session
    session.rollback()
    session.close()


@pytest.fixture
def override_get_db(async_session):
    """Override the get_db dependency for testing."""
    async def _override_get_db():
        yield async_session
    
    return _override_get_db


@pytest.fixture
def test_client(override_get_db) -> TestClient:
    """Create test client with overridden dependencies."""
    app.dependency_overrides[get_db] = override_get_db
    client = TestClient(app)
    yield client
    app.dependency_overrides.clear()


@pytest.fixture
async def async_client(override_get_db) -> AsyncGenerator[AsyncClient, None]:
    """Create async test client."""
    app.dependency_overrides[get_db] = override_get_db
    
    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client
    
    app.dependency_overrides.clear()


@pytest.fixture
def mock_redis():
    """Mock Redis client."""
    mock = MagicMock()
    mock.get = AsyncMock(return_value=None)
    mock.set = AsyncMock(return_value=True)
    mock.delete = AsyncMock(return_value=1)
    mock.exists = AsyncMock(return_value=False)
    mock.expire = AsyncMock(return_value=True)
    return mock


@pytest.fixture
def mock_celery():
    """Mock Celery app."""
    mock = MagicMock()
    mock.send_task = MagicMock(return_value=MagicMock(id="test-task-id"))
    return mock


@pytest.fixture
def mock_email_service():
    """Mock email service."""
    mock = AsyncMock()
    mock.send_email = AsyncMock(return_value=True)
    mock.send_bulk_email = AsyncMock(return_value=True)
    return mock


@pytest.fixture
def mock_file_storage():
    """Mock file storage service."""
    mock = AsyncMock()
    mock.upload_file = AsyncMock(return_value="https://example.com/file.pdf")
    mock.delete_file = AsyncMock(return_value=True)
    mock.get_file_url = AsyncMock(return_value="https://example.com/file.pdf")
    return mock


@pytest.fixture
def sample_user_data():
    """Sample user data for testing."""
    return {
        "email": "test@example.com",
        "password": "testpassword123",
        "full_name": "Test User",
        "is_active": True,
        "is_superuser": False,
    }


@pytest.fixture
def sample_equipment_data():
    """Sample equipment data for testing."""
    return {
        "name": "Test Microphone",
        "description": "Professional wireless microphone",
        "category": "audio",
        "daily_rate": 25.00,
        "weekly_rate": 150.00,
        "monthly_rate": 500.00,
        "is_available": True,
        "serial_number": "MIC-001",
        "brand": "Shure",
        "model": "SM58",
    }


@pytest.fixture
def sample_rental_data():
    """Sample rental data for testing."""
    return {
        "start_date": "2024-01-15",
        "end_date": "2024-01-20",
        "customer_name": "John Doe",
        "customer_email": "john@example.com",
        "customer_phone": "+1234567890",
        "event_name": "Corporate Event",
        "event_location": "Convention Center",
        "notes": "Handle with care",
        "status": "pending",
    }


@pytest.fixture
def authenticated_headers(test_client):
    """Get authentication headers for API requests."""
    # Create a test user and get auth token
    user_data = {
        "email": "test@example.com",
        "password": "testpassword123",
        "full_name": "Test User",
    }
    
    # Register user
    test_client.post("/api/v1/auth/register", json=user_data)
    
    # Login and get token
    login_data = {"username": user_data["email"], "password": user_data["password"]}
    response = test_client.post("/api/v1/auth/login", data=login_data)
    token = response.json()["access_token"]
    
    return {"Authorization": f"Bearer {token}"}


# Pytest markers
pytest.mark.unit = pytest.mark.unit
pytest.mark.integration = pytest.mark.integration
pytest.mark.e2e = pytest.mark.e2e
pytest.mark.slow = pytest.mark.slow
pytest.mark.security = pytest.mark.security
pytest.mark.performance = pytest.mark.performance


# Custom assertions
def assert_valid_uuid(uuid_string: str) -> None:
    """Assert that a string is a valid UUID."""
    import uuid
    try:
        uuid.UUID(uuid_string)
    except ValueError:
        pytest.fail(f"'{uuid_string}' is not a valid UUID")


def assert_valid_email(email: str) -> None:
    """Assert that a string is a valid email address."""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    if not re.match(pattern, email):
        pytest.fail(f"'{email}' is not a valid email address")


def assert_valid_phone(phone: str) -> None:
    """Assert that a string is a valid phone number."""
    import re
    pattern = r'^\+?1?\d{9,15}$'
    if not re.match(pattern, phone.replace('-', '').replace(' ', '')):
        pytest.fail(f"'{phone}' is not a valid phone number")


# Test data cleanup
@pytest.fixture(autouse=True)
def cleanup_test_files():
    """Clean up test files after each test."""
    yield
    
    # Clean up test database files
    test_files = ["test.db", "test.db-shm", "test.db-wal"]
    for file in test_files:
        if os.path.exists(file):
            try:
                os.remove(file)
            except OSError:
                pass  # File might be in use, ignore


# Environment setup
@pytest.fixture(autouse=True)
def setup_test_environment(monkeypatch):
    """Set up test environment variables."""
    monkeypatch.setenv("ENVIRONMENT", "test")
    monkeypatch.setenv("DATABASE_URL", TEST_DATABASE_URL)
    monkeypatch.setenv("REDIS_URL", "redis://localhost:6379/1")
    monkeypatch.setenv("SECRET_KEY", "test-secret-key")
    monkeypatch.setenv("DEBUG", "true")
    monkeypatch.setenv("TESTING", "true")
