"""
Unit tests for RentGuy Enterprise models.
"""

import pytest
from datetime import datetime, timedelta
from decimal import Decimal

from rentguy.models.equipment import Equipment
from rentguy.models.rental import Rental
from rentguy.models.user import User
from rentguy.core.exceptions import ValidationError


class TestUserModel:
    """Test cases for User model."""

    def test_create_user_with_valid_data(self):
        """Test creating a user with valid data."""
        user = User(
            email="test@example.com",
            full_name="Test User",
            hashed_password="hashed_password_here",
            is_active=True,
            is_superuser=False,
        )
        
        assert user.email == "test@example.com"
        assert user.full_name == "Test User"
        assert user.is_active is True
        assert user.is_superuser is False
        assert user.created_at is not None

    def test_user_email_validation(self):
        """Test user email validation."""
        with pytest.raises(ValidationError):
            User(
                email="invalid-email",
                full_name="Test User",
                hashed_password="hashed_password_here",
            )

    def test_user_password_hashing(self):
        """Test password hashing functionality."""
        user = User(
            email="test@example.com",
            full_name="Test User",
        )
        
        user.set_password("plaintext_password")
        assert user.hashed_password != "plaintext_password"
        assert user.verify_password("plaintext_password") is True
        assert user.verify_password("wrong_password") is False

    def test_user_string_representation(self):
        """Test user string representation."""
        user = User(
            email="test@example.com",
            full_name="Test User",
        )
        
        assert str(user) == "Test User <test@example.com>"

    def test_user_is_authenticated(self):
        """Test user authentication status."""
        active_user = User(
            email="active@example.com",
            full_name="Active User",
            is_active=True,
        )
        
        inactive_user = User(
            email="inactive@example.com",
            full_name="Inactive User",
            is_active=False,
        )
        
        assert active_user.is_authenticated is True
        assert inactive_user.is_authenticated is False


class TestEquipmentModel:
    """Test cases for Equipment model."""

    def test_create_equipment_with_valid_data(self):
        """Test creating equipment with valid data."""
        equipment = Equipment(
            name="Test Microphone",
            description="Professional wireless microphone",
            category="audio",
            daily_rate=Decimal("25.00"),
            weekly_rate=Decimal("150.00"),
            monthly_rate=Decimal("500.00"),
            is_available=True,
            serial_number="MIC-001",
            brand="Shure",
            model="SM58",
        )
        
        assert equipment.name == "Test Microphone"
        assert equipment.category == "audio"
        assert equipment.daily_rate == Decimal("25.00")
        assert equipment.is_available is True
        assert equipment.serial_number == "MIC-001"

    def test_equipment_rate_validation(self):
        """Test equipment rate validation."""
        with pytest.raises(ValidationError):
            Equipment(
                name="Test Equipment",
                daily_rate=Decimal("-10.00"),  # Negative rate should be invalid
            )

    def test_equipment_availability_check(self):
        """Test equipment availability checking."""
        equipment = Equipment(
            name="Test Equipment",
            is_available=True,
        )
        
        assert equipment.is_available_for_period(
            datetime.now(),
            datetime.now() + timedelta(days=1)
        ) is True

    def test_equipment_calculate_rental_cost(self):
        """Test rental cost calculation."""
        equipment = Equipment(
            name="Test Equipment",
            daily_rate=Decimal("25.00"),
            weekly_rate=Decimal("150.00"),
            monthly_rate=Decimal("500.00"),
        )
        
        start_date = datetime.now()
        
        # Test daily rate (1 day)
        end_date = start_date + timedelta(days=1)
        cost = equipment.calculate_rental_cost(start_date, end_date)
        assert cost == Decimal("25.00")
        
        # Test weekly rate (7 days)
        end_date = start_date + timedelta(days=7)
        cost = equipment.calculate_rental_cost(start_date, end_date)
        assert cost == Decimal("150.00")
        
        # Test monthly rate (30 days)
        end_date = start_date + timedelta(days=30)
        cost = equipment.calculate_rental_cost(start_date, end_date)
        assert cost == Decimal("500.00")

    def test_equipment_string_representation(self):
        """Test equipment string representation."""
        equipment = Equipment(
            name="Test Microphone",
            brand="Shure",
            model="SM58",
        )
        
        assert str(equipment) == "Test Microphone (Shure SM58)"


class TestRentalModel:
    """Test cases for Rental model."""

    def test_create_rental_with_valid_data(self):
        """Test creating a rental with valid data."""
        start_date = datetime.now()
        end_date = start_date + timedelta(days=3)
        
        rental = Rental(
            start_date=start_date,
            end_date=end_date,
            customer_name="John Doe",
            customer_email="john@example.com",
            customer_phone="+1234567890",
            event_name="Corporate Event",
            event_location="Convention Center",
            status="pending",
            total_amount=Decimal("150.00"),
        )
        
        assert rental.customer_name == "John Doe"
        assert rental.customer_email == "john@example.com"
        assert rental.status == "pending"
        assert rental.total_amount == Decimal("150.00")
        assert rental.duration_days == 3

    def test_rental_date_validation(self):
        """Test rental date validation."""
        start_date = datetime.now()
        end_date = start_date - timedelta(days=1)  # End before start
        
        with pytest.raises(ValidationError):
            Rental(
                start_date=start_date,
                end_date=end_date,
                customer_name="John Doe",
                customer_email="john@example.com",
            )

    def test_rental_status_transitions(self):
        """Test rental status transitions."""
        rental = Rental(
            start_date=datetime.now(),
            end_date=datetime.now() + timedelta(days=1),
            customer_name="John Doe",
            customer_email="john@example.com",
            status="pending",
        )
        
        # Test valid transitions
        rental.confirm()
        assert rental.status == "confirmed"
        
        rental.start()
        assert rental.status == "active"
        
        rental.complete()
        assert rental.status == "completed"

    def test_rental_invalid_status_transition(self):
        """Test invalid rental status transitions."""
        rental = Rental(
            start_date=datetime.now(),
            end_date=datetime.now() + timedelta(days=1),
            customer_name="John Doe",
            customer_email="john@example.com",
            status="completed",
        )
        
        # Cannot confirm a completed rental
        with pytest.raises(ValidationError):
            rental.confirm()

    def test_rental_calculate_total_amount(self):
        """Test rental total amount calculation."""
        rental = Rental(
            start_date=datetime.now(),
            end_date=datetime.now() + timedelta(days=3),
            customer_name="John Doe",
            customer_email="john@example.com",
        )
        
        # Mock equipment with daily rate
        equipment = Equipment(
            name="Test Equipment",
            daily_rate=Decimal("50.00"),
        )
        
        rental.equipment.append(equipment)
        total = rental.calculate_total_amount()
        
        assert total == Decimal("150.00")  # 3 days * $50/day

    def test_rental_is_overdue(self):
        """Test rental overdue checking."""
        # Past rental
        past_rental = Rental(
            start_date=datetime.now() - timedelta(days=5),
            end_date=datetime.now() - timedelta(days=2),
            customer_name="John Doe",
            customer_email="john@example.com",
            status="active",
        )
        
        # Future rental
        future_rental = Rental(
            start_date=datetime.now() + timedelta(days=1),
            end_date=datetime.now() + timedelta(days=3),
            customer_name="Jane Doe",
            customer_email="jane@example.com",
            status="active",
        )
        
        assert past_rental.is_overdue is True
        assert future_rental.is_overdue is False

    def test_rental_string_representation(self):
        """Test rental string representation."""
        rental = Rental(
            start_date=datetime.now(),
            end_date=datetime.now() + timedelta(days=1),
            customer_name="John Doe",
            event_name="Corporate Event",
        )
        
        assert "John Doe" in str(rental)
        assert "Corporate Event" in str(rental)


@pytest.mark.unit
class TestModelRelationships:
    """Test model relationships and associations."""

    def test_user_rental_relationship(self):
        """Test user-rental relationship."""
        user = User(
            email="test@example.com",
            full_name="Test User",
        )
        
        rental = Rental(
            start_date=datetime.now(),
            end_date=datetime.now() + timedelta(days=1),
            customer_name="John Doe",
            customer_email="john@example.com",
            created_by=user,
        )
        
        assert rental.created_by == user
        assert rental in user.created_rentals

    def test_equipment_rental_relationship(self):
        """Test equipment-rental many-to-many relationship."""
        equipment1 = Equipment(name="Microphone")
        equipment2 = Equipment(name="Speaker")
        
        rental = Rental(
            start_date=datetime.now(),
            end_date=datetime.now() + timedelta(days=1),
            customer_name="John Doe",
            customer_email="john@example.com",
        )
        
        rental.equipment.extend([equipment1, equipment2])
        
        assert equipment1 in rental.equipment
        assert equipment2 in rental.equipment
        assert rental in equipment1.rentals
        assert rental in equipment2.rentals
