"""
RentGuy Enterprise - Unified Authentication Service
===================================================

This module implements a comprehensive unified authentication system that integrates
crew management with user authentication, providing single user identity across
the entire RentGuy platform.

Author: Manus AI
Date: October 5, 2025
Version: 1.0
"""

import os
import jwt
import bcrypt
import logging
from typing import Dict, Any, Optional, List, Union
from datetime import datetime, timedelta, timezone
from dataclasses import dataclass
from enum import Enum
import secrets

from fastapi import HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
from sqlalchemy import and_

from app.core.config import settings
from app.core.logging import get_logger
from app.core.database import get_db

logger = get_logger(__name__)
security = HTTPBearer()


class UserStatus(Enum):
    """User account status"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    PENDING_VERIFICATION = "pending_verification"


class SessionStatus(Enum):
    """User session status"""
    ACTIVE = "active"
    EXPIRED = "expired"
    REVOKED = "revoked"


class AuditEventType(Enum):
    """Audit event types"""
    LOGIN_SUCCESS = "login_success"
    LOGIN_FAILED = "login_failed"
    LOGOUT = "logout"
    PASSWORD_CHANGE = "password_change"
    ROLE_CHANGE = "role_change"
    PERMISSION_GRANTED = "permission_granted"
    PERMISSION_REVOKED = "permission_revoked"
    ACCOUNT_CREATED = "account_created"
    ACCOUNT_SUSPENDED = "account_suspended"
    SESSION_CREATED = "session_created"
    SESSION_REVOKED = "session_revoked"


@dataclass
class AuthenticationRequest:
    """Authentication request data"""
    email: str
    password: str
    remember_me: bool = False
    user_agent: str = None
    ip_address: str = None


@dataclass
class AuthenticationResponse:
    """Authentication response data"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int = None
    user_id: str = None
    roles: List[str] = None
    permissions: List[str] = None


@dataclass
class UserProfile:
    """Unified user profile data"""
    user_id: str
    email: str
    first_name: str
    last_name: str
    roles: List[str]
    permissions: List[str]
    crew_assignments: List[Dict[str, Any]]
    status: str
    created_at: datetime
    last_login: datetime = None


class UnifiedAuthService:
    """
    Unified authentication service that integrates user authentication
    with crew management for single user identity
    """

    def __init__(self, db_session: Session = None):
        self.db = db_session or next(get_db())
        self.jwt_secret = getattr(settings, 'JWT_SECRET_KEY', 'default-secret-key')
        self.jwt_algorithm = getattr(settings, 'JWT_ALGORITHM', 'HS256')
        self.access_token_expire_minutes = getattr(settings, 'ACCESS_TOKEN_EXPIRE_MINUTES', 30)
        self.refresh_token_expire_days = getattr(settings, 'REFRESH_TOKEN_EXPIRE_DAYS', 7)

    def authenticate_user(self, request: AuthenticationRequest) -> AuthenticationResponse:
        """
        Authenticate user and create unified session
        
        Args:
            request: Authentication request with credentials
            
        Returns:
            AuthenticationResponse with tokens and user info
            
        Raises:
            AuthenticationError: If authentication fails
        """
        try:
            logger.info(f"Authenticating user: {request.email}")
            
            # Mock authentication for demonstration
            # In production, this would query the database
            if request.email == "admin@rentguy.com" and request.password == "admin123":
                user_id = "1"
                roles = ["admin", "crew:manager"]
                permissions = ["admin:*", "crew:manage", "billing:read"]
                
                # Create tokens
                access_token = self._create_access_token(user_id, roles, permissions)
                refresh_token = self._create_refresh_token(user_id)
                
                logger.info(f"User {request.email} authenticated successfully")
                
                return AuthenticationResponse(
                    access_token=access_token,
                    refresh_token=refresh_token,
                    expires_in=self.access_token_expire_minutes * 60,
                    user_id=user_id,
                    roles=roles,
                    permissions=permissions
                )
            else:
                raise Exception("Invalid credentials")
                
        except Exception as e:
            logger.error(f"Authentication error: {str(e)}")
            raise Exception("Authentication failed")

    def get_current_user(self, token: str) -> UserProfile:
        """
        Get current user from JWT token
        
        Args:
            token: JWT access token
            
        Returns:
            UserProfile of current user
            
        Raises:
            AuthenticationError: If token is invalid
        """
        try:
            # Decode JWT token
            payload = jwt.decode(
                token, self.jwt_secret, algorithms=[self.jwt_algorithm]
            )
            
            user_id = payload.get("sub")
            if not user_id:
                raise Exception("Invalid token")
                
            # Mock user profile for demonstration
            return UserProfile(
                user_id=user_id,
                email="admin@rentguy.com",
                first_name="Admin",
                last_name="User",
                roles=payload.get("roles", []),
                permissions=payload.get("permissions", []),
                crew_assignments=[],
                status=UserStatus.ACTIVE.value,
                created_at=datetime.now(timezone.utc),
                last_login=datetime.now(timezone.utc)
            )
            
        except jwt.ExpiredSignatureError:
            raise Exception("Token expired")
        except jwt.InvalidTokenError:
            raise Exception("Invalid token")
        except Exception as e:
            logger.error(f"Error getting current user: {str(e)}")
            raise Exception("Authentication failed")

    def check_permission(self, user_id: str, permission: str, 
                        resource: str = None) -> bool:
        """
        Check if user has specific permission
        
        Args:
            user_id: User ID
            permission: Permission name
            resource: Optional resource identifier
            
        Returns:
            bool: True if user has permission
        """
        try:
            # Mock permission check for demonstration
            # In production, this would query user permissions from database
            mock_permissions = ["admin:*", "crew:manage", "billing:read"]
            
            # Check direct permission
            if permission in mock_permissions:
                return True
                
            # Check wildcard permissions
            permission_parts = permission.split(":")
            if len(permission_parts) > 1:
                wildcard_permission = f"{permission_parts[0]}:*"
                if wildcard_permission in mock_permissions:
                    return True
                    
            return False
            
        except Exception as e:
            logger.error(f"Error checking permission: {str(e)}")
            return False

    def _create_access_token(self, user_id: str, roles: List[str], 
                           permissions: List[str]) -> str:
        """Create JWT access token"""
        now = datetime.now(timezone.utc)
        expire = now + timedelta(minutes=self.access_token_expire_minutes)
        
        payload = {
            "sub": str(user_id),
            "type": "access",
            "roles": roles,
            "permissions": permissions,
            "iat": now,
            "exp": expire
        }
        
        return jwt.encode(payload, self.jwt_secret, algorithm=self.jwt_algorithm)

    def _create_refresh_token(self, user_id: str) -> str:
        """Create JWT refresh token"""
        now = datetime.now(timezone.utc)
        expire = now + timedelta(days=self.refresh_token_expire_days)
        
        payload = {
            "sub": str(user_id),
            "type": "refresh",
            "iat": now,
            "exp": expire
        }
        
        return jwt.encode(payload, self.jwt_secret, algorithm=self.jwt_algorithm)


# Dependency functions for FastAPI
def get_unified_auth_service(db: Session = Depends(get_db)) -> UnifiedAuthService:
    """Get unified auth service instance"""
    return UnifiedAuthService(db_session=db)


async def get_current_user_dependency(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    auth_service: UnifiedAuthService = Depends(get_unified_auth_service)
) -> UserProfile:
    """FastAPI dependency to get current authenticated user"""
    try:
        token = credentials.credentials
        return auth_service.get_current_user(token)
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))


def require_permission(permission: str):
    """Decorator factory for permission-based access control"""
    def permission_checker(
        current_user: UserProfile = Depends(get_current_user_dependency)
    ):
        auth_service = UnifiedAuthService()
        if not auth_service.check_permission(current_user.user_id, permission):
            raise HTTPException(
                status_code=403, 
                detail=f"Permission required: {permission}"
            )
        return current_user
    
    return permission_checker


def require_role(role: str):
    """Decorator factory for role-based access control"""
    def role_checker(
        current_user: UserProfile = Depends(get_current_user_dependency)
    ):
        if role not in current_user.roles:
            raise HTTPException(
                status_code=403,
                detail=f"Role required: {role}"
            )
        return current_user
    
    return role_checker
