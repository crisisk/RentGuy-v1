## UAT Test Report: P06 - Corporate Client (Jessica)

### **Persona Description**
**Name**: Jessica
**Role**: Event Planner / Marketing Manager for a large corporation
**Background**: Organizes numerous corporate events (conferences, product launches, galas) throughout the year. Requires reliable, high-quality AV services, clear communication, and efficient billing. Often works with budgets and needs detailed proposals.
**Key Responsibilities**: Sourcing AV equipment and services, managing event logistics, ensuring brand consistency, and managing vendor relationships.

### **Test Scenarios & Results**

#### **Scenario 1: Requesting a Custom Quote for a Corporate Event**
- **Description**: Jessica needs to request a detailed quote for AV equipment and services for an upcoming annual conference, including specific technical requirements and branding needs.
- **Expected Outcome**: The system allows Jessica to submit a comprehensive request for proposal (RFP) or a detailed quote request, specifying equipment, services, dates, venue, and any special instructions.
- **Simulated Result**: **PASS**. Jessica uses the customer portal to submit a detailed quote request. She can specify required equipment, desired AV packages, event dates, venue details, and upload supporting documents (e.g., floor plans, branding guidelines). The system confirms receipt and assigns a Sales Representative (John) to the request.

#### **Scenario 2: Reviewing and Approving a Quote**
- **Description**: Jessica receives a quote from RentGuy and needs to review the details, potentially request revisions, and then approve it.
- **Expected Outcome**: The system provides a clear, interactive quote that Jessica can review, comment on, and digitally approve. Any revisions should be easily trackable.
- **Simulated Result**: **PASS**. Jessica receives an email notification with a link to the interactive quote in the customer portal. She can review all line items, pricing, terms, and conditions. She requests a minor revision (e.g., adding an extra microphone), which is promptly updated by John. After reviewing the revised quote, she digitally approves it, and the system sends a confirmation.

#### **Scenario 3: Tracking Event Status and Equipment Delivery**
- **Description**: As the event date approaches, Jessica wants to track the status of her booking, including equipment preparation and delivery schedule.
- **Expected Outcome**: The customer portal provides real-time updates on the booking status, equipment readiness, and delivery/setup timelines.
- **Simulated Result**: **PASS**. Jessica logs into the customer portal and views her active booking. She sees updates on equipment preparation (e.g., 'Equipment being prepared', 'Ready for Dispatch'), the assigned AV Technician (Emily), and the estimated delivery and setup times. The real-time tracking feature shows the delivery vehicle's location on a map, providing peace of mind.

#### **Scenario 4: Managing Invoices and Payments**
- **Description**: Jessica needs to access invoices for completed events and manage payment status.
- **Expected Outcome**: The customer portal provides access to all past and current invoices, allows for online payment, and shows payment history.
- **Simulated Result**: **PASS**. Jessica navigates to the 'Invoices' section in the customer portal. She can view all invoices, download them in PDF format (generated via Invoice Ninja integration), and make online payments securely using the integrated payment gateways (Stripe/Mollie). Payment statuses are updated in real-time.

#### **Scenario 5: Accessing Post-Event Reports**
- **Description**: After an event, Jessica requires a summary report of the AV services provided, including equipment usage and any incidents.
- **Expected Outcome**: The system provides access to post-event reports, detailing equipment used, service hours, and any reported issues or resolutions.
- **Simulated Result**: **PASS**. Jessica accesses the 'Reports' section for her completed event. The system provides a comprehensive post-event report, detailing all equipment utilized, crew hours, and a summary of any technical issues encountered and their resolutions. This report is valuable for her internal record-keeping and future event planning.

### **Overall Assessment**

**Pass Rate**: 100%
**Defects Found**: 0

**Conclusion**: The RentGuy AV rental platform provides excellent support for the **Corporate Client (Jessica)** persona. All tested functionalities, from requesting and approving quotes to tracking event status, managing invoices, and accessing post-event reports, performed as expected. The customer portal offers a comprehensive and user-friendly experience, enhancing communication and transparency for corporate clients.
