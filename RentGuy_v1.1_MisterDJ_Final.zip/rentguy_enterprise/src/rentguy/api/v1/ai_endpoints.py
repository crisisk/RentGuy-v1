"""
AI-powered API endpoints for RentGuy Enterprise.
Provides REST API access to AI capabilities.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from ...ai.ensemble_architecture import (
    TaskType, TaskPriority, EnsembleStrategy,
    create_and_process_task, AITask, AIResponse
)
from ...ai.business_intelligence import (
    get_bi_engine, generate_daily_insights, generate_weekly_recommendations,
    BusinessInsight, AIRecommendation, InsightType, RecommendationType
)
from ...ai.customer_service import (
    get_customer_service_ai, process_customer_message, handle_customer_complaint,
    ConversationType, SentimentType, UrgencyLevel
)
from ...core.database import get_async_session
from ...core.security import get_current_user, require_permissions
from ...core.logging import get_logger
from ...models.models import User

logger = get_logger(__name__)
router = APIRouter(prefix="/ai", tags=["AI Services"])


# Request/Response Models
class AITaskRequest(BaseModel):
    """Request model for AI task processing."""
    task_type: TaskType
    prompt: str
    priority: TaskPriority = TaskPriority.NORMAL
    context: Optional[Dict[str, Any]] = None
    constraints: Optional[Dict[str, Any]] = None
    expected_format: str = "text"
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    strategy: EnsembleStrategy = EnsembleStrategy.SINGLE_BEST


class AITaskResponse(BaseModel):
    """Response model for AI task results."""
    task_id: str
    provider: str
    model: str
    content: str
    confidence: float
    processing_time: float
    token_usage: Dict[str, int]
    cost: float
    metadata: Dict[str, Any]
    created_at: datetime
    error: Optional[str] = None


class CustomerMessageRequest(BaseModel):
    """Request model for customer message processing."""
    customer_id: str
    content: str
    channel: str = "api"
    conversation_type: Optional[ConversationType] = None
    metadata: Optional[Dict[str, Any]] = None


class CustomerMessageResponse(BaseModel):
    """Response model for customer message processing."""
    message_id: str
    ai_response: str
    confidence: float
    conversation_type: str
    sentiment: str
    urgency: str
    suggested_actions: List[str]
    escalation_needed: bool
    follow_up_required: bool
    analysis: Dict[str, Any]


class ComplaintRequest(BaseModel):
    """Request model for complaint handling."""
    customer_id: str
    complaint: str
    channel: str = "api"
    severity: Optional[str] = None


class ComplaintResponse(BaseModel):
    """Response model for complaint handling."""
    complaint_category: str
    severity: str
    root_cause_analysis: str
    immediate_actions: List[str]
    resolution_steps: List[str]
    compensation_suggested: str
    escalation_required: bool
    follow_up_timeline: str
    ai_response: str
    confidence: float


class InsightRequest(BaseModel):
    """Request model for business insights."""
    insight_type: InsightType
    period_days: Optional[int] = 30
    filters: Optional[Dict[str, Any]] = None


class RecommendationRequest(BaseModel):
    """Request model for AI recommendations."""
    recommendation_type: RecommendationType
    context: Optional[Dict[str, Any]] = None


# AI Task Processing Endpoints
@router.post("/tasks", response_model=AITaskResponse)
async def process_ai_task(
    request: AITaskRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """Process an AI task using the ensemble architecture."""
    try:
        # Check permissions
        await require_permissions(current_user, ["ai:use"])
        
        # Create AI task
        import uuid
        task = AITask(
            id=str(uuid.uuid4()),
            task_type=request.task_type,
            priority=request.priority,
            prompt=request.prompt,
            context=request.context or {},
            constraints=request.constraints or {},
            expected_format=request.expected_format,
            max_tokens=request.max_tokens,
            temperature=request.temperature,
            user_id=str(current_user.id)
        )
        
        # Process task
        response = await create_and_process_task(
            task_type=request.task_type,
            prompt=request.prompt,
            priority=request.priority,
            context=request.context,
            strategy=request.strategy,
            expected_format=request.expected_format,
            max_tokens=request.max_tokens,
            temperature=request.temperature
        )
        
        # Log usage
        logger.info(f"AI task processed for user {current_user.id}: {task.task_type}")
        
        return AITaskResponse(
            task_id=response.task_id,
            provider=response.provider.value,
            model=response.model,
            content=response.content,
            confidence=response.confidence,
            processing_time=response.processing_time,
            token_usage=response.token_usage,
            cost=response.cost,
            metadata=response.metadata,
            created_at=response.created_at,
            error=response.error
        )
        
    except Exception as e:
        logger.error(f"AI task processing failed: {e}")
        raise HTTPException(status_code=500, detail=f"AI task processing failed: {str(e)}")


@router.get("/tasks/performance")
async def get_ai_performance(
    current_user: User = Depends(get_current_user)
):
    """Get AI ensemble performance metrics."""
    try:
        await require_permissions(current_user, ["ai:admin"])
        
        from ...ai.ensemble_architecture import get_llm_ensemble
        ensemble = get_llm_ensemble()
        
        performance_report = ensemble.get_performance_report()
        
        return performance_report
        
    except Exception as e:
        logger.error(f"Failed to get AI performance: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get performance metrics: {str(e)}")


# Business Intelligence Endpoints
@router.post("/insights", response_model=Dict[str, Any])
async def generate_business_insight(
    request: InsightRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """Generate business insights using AI."""
    try:
        await require_permissions(current_user, ["ai:insights"])
        
        bi_engine = get_bi_engine()
        
        # Generate insight based on type
        if request.insight_type == InsightType.REVENUE_ANALYSIS:
            insight = await bi_engine.generate_revenue_analysis(request.period_days or 30)
        elif request.insight_type == InsightType.UTILIZATION_OPTIMIZATION:
            insight = await bi_engine.generate_utilization_optimization()
        elif request.insight_type == InsightType.CUSTOMER_BEHAVIOR:
            insight = await bi_engine.analyze_customer_behavior()
        elif request.insight_type == InsightType.PREDICTIVE_MAINTENANCE:
            insight = await bi_engine.predict_equipment_maintenance()
        elif request.insight_type == InsightType.OPERATIONAL_EFFICIENCY:
            insight = await bi_engine.analyze_operational_efficiency()
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported insight type: {request.insight_type}")
        
        return {
            "insight_id": insight.id,
            "insight_type": insight.insight_type.value,
            "title": insight.title,
            "description": insight.description,
            "confidence": insight.confidence,
            "impact_score": insight.impact_score,
            "data_sources": insight.data_sources,
            "recommendations": insight.recommendations,
            "metrics": insight.metrics,
            "created_at": insight.created_at.isoformat(),
            "tags": insight.tags
        }
        
    except Exception as e:
        logger.error(f"Business insight generation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Insight generation failed: {str(e)}")


@router.post("/recommendations", response_model=Dict[str, Any])
async def generate_ai_recommendation(
    request: RecommendationRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """Generate AI recommendations."""
    try:
        await require_permissions(current_user, ["ai:recommendations"])
        
        bi_engine = get_bi_engine()
        
        # Generate recommendation based on type
        if request.recommendation_type == RecommendationType.PRICING_OPTIMIZATION:
            recommendation = await bi_engine.generate_pricing_recommendations()
        elif request.recommendation_type == RecommendationType.INVENTORY_MANAGEMENT:
            recommendation = await bi_engine.recommend_inventory_management()
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported recommendation type: {request.recommendation_type}")
        
        return {
            "recommendation_id": recommendation.id,
            "recommendation_type": recommendation.recommendation_type.value,
            "title": recommendation.title,
            "description": recommendation.description,
            "action_items": recommendation.action_items,
            "expected_impact": recommendation.expected_impact,
            "confidence": recommendation.confidence,
            "priority": recommendation.priority,
            "estimated_roi": recommendation.estimated_roi,
            "implementation_effort": recommendation.implementation_effort,
            "created_at": recommendation.created_at.isoformat(),
            "valid_until": recommendation.valid_until.isoformat() if recommendation.valid_until else None
        }
        
    except Exception as e:
        logger.error(f"AI recommendation generation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Recommendation generation failed: {str(e)}")


@router.get("/insights/daily")
async def get_daily_insights(
    current_user: User = Depends(get_current_user)
):
    """Get daily business insights."""
    try:
        await require_permissions(current_user, ["ai:insights"])
        
        insights = await generate_daily_insights()
        
        return {
            "insights": [
                {
                    "insight_id": insight.id,
                    "insight_type": insight.insight_type.value,
                    "title": insight.title,
                    "description": insight.description,
                    "confidence": insight.confidence,
                    "impact_score": insight.impact_score,
                    "recommendations": insight.recommendations,
                    "created_at": insight.created_at.isoformat()
                }
                for insight in insights
            ],
            "generated_at": datetime.utcnow().isoformat(),
            "total_insights": len(insights)
        }
        
    except Exception as e:
        logger.error(f"Daily insights generation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Daily insights failed: {str(e)}")


@router.get("/recommendations/weekly")
async def get_weekly_recommendations(
    current_user: User = Depends(get_current_user)
):
    """Get weekly AI recommendations."""
    try:
        await require_permissions(current_user, ["ai:recommendations"])
        
        recommendations = await generate_weekly_recommendations()
        
        return {
            "recommendations": [
                {
                    "recommendation_id": rec.id,
                    "recommendation_type": rec.recommendation_type.value,
                    "title": rec.title,
                    "description": rec.description,
                    "action_items": rec.action_items,
                    "expected_impact": rec.expected_impact,
                    "confidence": rec.confidence,
                    "priority": rec.priority,
                    "estimated_roi": rec.estimated_roi,
                    "created_at": rec.created_at.isoformat()
                }
                for rec in recommendations
            ],
            "generated_at": datetime.utcnow().isoformat(),
            "total_recommendations": len(recommendations)
        }
        
    except Exception as e:
        logger.error(f"Weekly recommendations generation failed: {e}")
        raise HTTPException(status_code=500, detail=f"Weekly recommendations failed: {str(e)}")


# Customer Service AI Endpoints
@router.post("/customer-service/message", response_model=CustomerMessageResponse)
async def process_customer_message_endpoint(
    request: CustomerMessageRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """Process customer message with AI."""
    try:
        await require_permissions(current_user, ["ai:customer_service"])
        
        # Process message
        ai_response, analysis = await process_customer_message(
            customer_id=request.customer_id,
            content=request.content,
            channel=request.channel
        )
        
        return CustomerMessageResponse(
            message_id=ai_response.message_id,
            ai_response=ai_response.content,
            confidence=ai_response.confidence,
            conversation_type=ai_response.response_type,
            sentiment=analysis.get("sentiment", "neutral"),
            urgency=analysis.get("urgency", "medium"),
            suggested_actions=ai_response.suggested_actions,
            escalation_needed=ai_response.escalation_needed,
            follow_up_required=ai_response.follow_up_required,
            analysis=analysis
        )
        
    except Exception as e:
        logger.error(f"Customer message processing failed: {e}")
        raise HTTPException(status_code=500, detail=f"Message processing failed: {str(e)}")


@router.post("/customer-service/complaint", response_model=ComplaintResponse)
async def handle_customer_complaint_endpoint(
    request: ComplaintRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """Handle customer complaint with AI."""
    try:
        await require_permissions(current_user, ["ai:customer_service"])
        
        # Handle complaint
        resolution = await handle_customer_complaint(
            customer_id=request.customer_id,
            complaint=request.complaint,
            channel=request.channel
        )
        
        return ComplaintResponse(
            complaint_category=resolution.get("complaint_category", "other"),
            severity=resolution.get("severity", "medium"),
            root_cause_analysis=resolution.get("root_cause_analysis", ""),
            immediate_actions=resolution.get("immediate_actions", []),
            resolution_steps=resolution.get("resolution_steps", []),
            compensation_suggested=resolution.get("compensation_suggested", "none"),
            escalation_required=resolution.get("escalation_required", False),
            follow_up_timeline=resolution.get("follow_up_timeline", "48h"),
            ai_response=resolution.get("ai_response", ""),
            confidence=resolution.get("response_confidence", 0.0)
        )
        
    except Exception as e:
        logger.error(f"Complaint handling failed: {e}")
        raise HTTPException(status_code=500, detail=f"Complaint handling failed: {str(e)}")


@router.get("/customer-service/recommendations/{customer_id}")
async def get_customer_recommendations(
    customer_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """Get personalized recommendations for customer."""
    try:
        await require_permissions(current_user, ["ai:customer_service"])
        
        cs_ai = get_customer_service_ai()
        recommendations = await cs_ai.generate_personalized_recommendations(customer_id)
        
        return {
            "customer_id": customer_id,
            "recommendations": recommendations,
            "generated_at": datetime.utcnow().isoformat(),
            "total_recommendations": len(recommendations)
        }
        
    except Exception as e:
        logger.error(f"Customer recommendations failed: {e}")
        raise HTTPException(status_code=500, detail=f"Recommendations failed: {str(e)}")


@router.get("/customer-service/satisfaction/{customer_id}")
async def analyze_customer_satisfaction_endpoint(
    customer_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_async_session)
):
    """Analyze customer satisfaction."""
    try:
        await require_permissions(current_user, ["ai:customer_service"])
        
        cs_ai = get_customer_service_ai()
        
        # Get interaction history (mock for now)
        interaction_history = cs_ai._get_conversation_history(customer_id)
        
        # Analyze satisfaction
        satisfaction_insight = await cs_ai.analyze_customer_satisfaction(
            customer_id, interaction_history
        )
        
        return {
            "customer_id": customer_id,
            "insight_type": satisfaction_insight.insight_type,
            "description": satisfaction_insight.description,
            "confidence": satisfaction_insight.confidence,
            "recommendations": satisfaction_insight.recommendations,
            "created_at": satisfaction_insight.created_at.isoformat()
        }
        
    except Exception as e:
        logger.error(f"Customer satisfaction analysis failed: {e}")
        raise HTTPException(status_code=500, detail=f"Satisfaction analysis failed: {str(e)}")


# Utility Endpoints
@router.get("/health")
async def ai_health_check():
    """Check AI services health."""
    try:
        from ...ai.ensemble_architecture import get_llm_ensemble
        ensemble = get_llm_ensemble()
        
        # Check provider availability
        available_providers = sum(1 for p in ensemble.providers.values() if p.is_available())
        total_providers = len(ensemble.providers)
        
        health_status = {
            "status": "healthy" if available_providers > 0 else "degraded",
            "available_providers": available_providers,
            "total_providers": total_providers,
            "services": {
                "ensemble": available_providers > 0,
                "business_intelligence": True,
                "customer_service": True
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        return health_status
        
    except Exception as e:
        logger.error(f"AI health check failed: {e}")
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }


@router.get("/capabilities")
async def get_ai_capabilities(
    current_user: User = Depends(get_current_user)
):
    """Get available AI capabilities."""
    try:
        from ...ai.ensemble_architecture import get_llm_ensemble
        ensemble = get_llm_ensemble()
        
        capabilities = {
            "task_types": [task_type.value for task_type in TaskType],
            "ensemble_strategies": [strategy.value for strategy in EnsembleStrategy],
            "insight_types": [insight_type.value for insight_type in InsightType],
            "recommendation_types": [rec_type.value for rec_type in RecommendationType],
            "conversation_types": [conv_type.value for conv_type in ConversationType],
            "providers": {
                provider_key: {
                    "model": provider.config.model,
                    "capabilities": [cap.value for cap in provider.config.capabilities],
                    "available": provider.is_available(),
                    "performance_score": provider.config.performance_score
                }
                for provider_key, provider in ensemble.providers.items()
            },
            "permissions_required": {
                "ai:use": "Basic AI task processing",
                "ai:insights": "Business intelligence insights",
                "ai:recommendations": "AI recommendations",
                "ai:customer_service": "Customer service AI",
                "ai:admin": "AI administration and metrics"
            }
        }
        
        return capabilities
        
    except Exception as e:
        logger.error(f"Failed to get AI capabilities: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get capabilities: {str(e)}")


# Background task endpoints
@router.post("/tasks/background/daily-insights")
async def trigger_daily_insights(
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user)
):
    """Trigger daily insights generation in background."""
    try:
        await require_permissions(current_user, ["ai:admin"])
        
        background_tasks.add_task(generate_daily_insights)
        
        return {
            "message": "Daily insights generation triggered",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to trigger daily insights: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to trigger insights: {str(e)}")


@router.post("/tasks/background/weekly-recommendations")
async def trigger_weekly_recommendations(
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user)
):
    """Trigger weekly recommendations generation in background."""
    try:
        await require_permissions(current_user, ["ai:admin"])
        
        background_tasks.add_task(generate_weekly_recommendations)
        
        return {
            "message": "Weekly recommendations generation triggered",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to trigger weekly recommendations: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to trigger recommendations: {str(e)}")
