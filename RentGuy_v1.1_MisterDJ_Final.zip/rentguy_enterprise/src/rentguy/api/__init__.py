"""
Enterprise API module for RentGuy.
Provides versioned API endpoints with comprehensive documentation.
"""

from .v1 import api_router as v1_router
from .versioning import APIVersionManager

__all__ = ["v1_router", "APIVersionManager"]
