"""
Enterprise API versioning system for RentGuy.
Provides comprehensive version management, deprecation handling, and migration support.
"""

import re
from datetime import datetime, timedelta
from enum import Enum
from typing import Dict, List, Optional, Tuple

from fastapi import Header, HTTPException, Request
from pydantic import BaseModel

from ..core.logging import get_logger

logger = get_logger(__name__)


class APIVersionStatus(str, Enum):
    """API version status enumeration."""
    DEVELOPMENT = "development"
    BETA = "beta"
    STABLE = "stable"
    DEPRECATED = "deprecated"
    SUNSET = "sunset"


class APIVersion(BaseModel):
    """API version information model."""
    version: str
    status: APIVersionStatus
    release_date: datetime
    deprecation_date: Optional[datetime] = None
    sunset_date: Optional[datetime] = None
    description: str
    breaking_changes: List[str] = []
    migration_guide_url: Optional[str] = None
    changelog_url: Optional[str] = None


class APIVersionManager:
    """
    Enterprise API version management system.
    Handles version routing, deprecation warnings, and migration support.
    """
    
    def __init__(self):
        self.versions: Dict[str, APIVersion] = {}
        self.default_version = "1.0"
        self.supported_versions = ["1.0", "1.1", "2.0"]
        self._initialize_versions()
    
    def _initialize_versions(self):
        """Initialize supported API versions."""
        self.versions = {
            "1.0": APIVersion(
                version="1.0",
                status=APIVersionStatus.STABLE,
                release_date=datetime(2024, 1, 1),
                description="Initial stable release of RentGuy API",
                changelog_url="/docs/changelog/v1.0"
            ),
            "1.1": APIVersion(
                version="1.1",
                status=APIVersionStatus.STABLE,
                release_date=datetime(2024, 6, 1),
                description="Enhanced features and performance improvements",
                breaking_changes=[
                    "Equipment model now requires 'category' field",
                    "Date format changed to ISO 8601"
                ],
                changelog_url="/docs/changelog/v1.1"
            ),
            "2.0": APIVersion(
                version="2.0",
                status=APIVersionStatus.BETA,
                release_date=datetime(2024, 10, 1),
                description="Major API redesign with improved architecture",
                breaking_changes=[
                    "Complete API restructure",
                    "New authentication system",
                    "Updated response formats"
                ],
                migration_guide_url="/docs/migration/v2.0",
                changelog_url="/docs/changelog/v2.0"
            )
        }
    
    def get_version_from_header(self, accept_version: Optional[str] = None) -> str:
        """Extract API version from Accept-Version header."""
        if not accept_version:
            return self.default_version
        
        # Parse version from header (e.g., "application/vnd.rentguy.v1+json")
        version_pattern = r'v(\d+(?:\.\d+)?)'
        match = re.search(version_pattern, accept_version)
        
        if match:
            version = match.group(1)
            if version in self.supported_versions:
                return version
        
        # Fallback to simple version string
        if accept_version in self.supported_versions:
            return accept_version
        
        logger.warning(
            "Unsupported API version requested",
            requested_version=accept_version,
            supported_versions=self.supported_versions
        )
        
        return self.default_version
    
    def get_version_from_url(self, path: str) -> Optional[str]:
        """Extract API version from URL path."""
        version_pattern = r'/api/v(\d+(?:\.\d+)?)'
        match = re.search(version_pattern, path)
        
        if match:
            version = match.group(1)
            if version in self.supported_versions:
                return version
        
        return None
    
    def validate_version(self, version: str) -> APIVersion:
        """Validate and return API version information."""
        if version not in self.versions:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported API version: {version}. "
                       f"Supported versions: {', '.join(self.supported_versions)}"
            )
        
        api_version = self.versions[version]
        
        # Check if version is sunset
        if api_version.status == APIVersionStatus.SUNSET:
            raise HTTPException(
                status_code=410,
                detail=f"API version {version} has been sunset and is no longer available. "
                       f"Please migrate to a supported version."
            )
        
        return api_version
    
    def get_deprecation_warning(self, version: str) -> Optional[str]:
        """Get deprecation warning for API version."""
        api_version = self.versions.get(version)
        
        if not api_version or api_version.status != APIVersionStatus.DEPRECATED:
            return None
        
        warning = f"API version {version} is deprecated"
        
        if api_version.sunset_date:
            warning += f" and will be sunset on {api_version.sunset_date.strftime('%Y-%m-%d')}"
        
        if api_version.migration_guide_url:
            warning += f". Migration guide: {api_version.migration_guide_url}"
        
        return warning
    
    def get_version_info(self, version: str) -> Dict:
        """Get comprehensive version information."""
        api_version = self.validate_version(version)
        
        return {
            "version": api_version.version,
            "status": api_version.status.value,
            "release_date": api_version.release_date.isoformat(),
            "deprecation_date": api_version.deprecation_date.isoformat() if api_version.deprecation_date else None,
            "sunset_date": api_version.sunset_date.isoformat() if api_version.sunset_date else None,
            "description": api_version.description,
            "breaking_changes": api_version.breaking_changes,
            "migration_guide_url": api_version.migration_guide_url,
            "changelog_url": api_version.changelog_url,
            "supported_versions": self.supported_versions,
            "default_version": self.default_version
        }
    
    def deprecate_version(
        self,
        version: str,
        deprecation_date: Optional[datetime] = None,
        sunset_date: Optional[datetime] = None
    ):
        """Mark an API version as deprecated."""
        if version not in self.versions:
            raise ValueError(f"Version {version} not found")
        
        api_version = self.versions[version]
        api_version.status = APIVersionStatus.DEPRECATED
        api_version.deprecation_date = deprecation_date or datetime.utcnow()
        
        if sunset_date:
            api_version.sunset_date = sunset_date
        
        logger.info(
            "API version deprecated",
            version=version,
            deprecation_date=api_version.deprecation_date,
            sunset_date=api_version.sunset_date
        )
    
    def sunset_version(self, version: str):
        """Mark an API version as sunset (no longer available)."""
        if version not in self.versions:
            raise ValueError(f"Version {version} not found")
        
        api_version = self.versions[version]
        api_version.status = APIVersionStatus.SUNSET
        
        # Remove from supported versions
        if version in self.supported_versions:
            self.supported_versions.remove(version)
        
        logger.info("API version sunset", version=version)


# Global version manager instance
version_manager = APIVersionManager()


class APIVersionMiddleware:
    """
    Middleware for handling API versioning and deprecation warnings.
    """
    
    def __init__(self, version_manager: APIVersionManager):
        self.version_manager = version_manager
    
    async def __call__(self, request: Request, call_next):
        """Process API version and add appropriate headers."""
        # Determine API version
        version = None
        
        # Try URL-based versioning first
        version = self.version_manager.get_version_from_url(str(request.url.path))
        
        # Fallback to header-based versioning
        if not version:
            accept_version = request.headers.get("Accept-Version")
            version = self.version_manager.get_version_from_header(accept_version)
        
        # Validate version
        try:
            api_version = self.version_manager.validate_version(version)
        except HTTPException as e:
            # Return error response for invalid versions
            from fastapi.responses import JSONResponse
            return JSONResponse(
                status_code=e.status_code,
                content={"error": e.detail}
            )
        
        # Add version to request state
        request.state.api_version = version
        request.state.api_version_info = api_version
        
        # Process request
        response = await call_next(request)
        
        # Add version headers to response
        response.headers["API-Version"] = version
        response.headers["API-Version-Status"] = api_version.status.value
        
        # Add deprecation warning if applicable
        deprecation_warning = self.version_manager.get_deprecation_warning(version)
        if deprecation_warning:
            response.headers["Deprecation"] = "true"
            response.headers["Sunset"] = api_version.sunset_date.strftime('%a, %d %b %Y %H:%M:%S GMT') if api_version.sunset_date else ""
            response.headers["Warning"] = f'299 - "{deprecation_warning}"'
        
        # Add supported versions header
        response.headers["API-Supported-Versions"] = ", ".join(self.version_manager.supported_versions)
        
        return response


def get_api_version(request: Request) -> str:
    """Dependency to get current API version from request."""
    return getattr(request.state, "api_version", version_manager.default_version)


def get_api_version_info(request: Request) -> APIVersion:
    """Dependency to get current API version info from request."""
    return getattr(request.state, "api_version_info", version_manager.versions[version_manager.default_version])


class APIDocumentationGenerator:
    """
    Generate comprehensive API documentation with version-specific information.
    """
    
    def __init__(self, version_manager: APIVersionManager):
        self.version_manager = version_manager
    
    def generate_openapi_spec(self, version: str, app) -> Dict:
        """Generate OpenAPI specification for specific API version."""
        api_version = self.version_manager.validate_version(version)
        
        # Base OpenAPI spec
        openapi_spec = {
            "openapi": "3.0.2",
            "info": {
                "title": "RentGuy Enterprise API",
                "version": version,
                "description": api_version.description,
                "contact": {
                    "name": "RentGuy Support",
                    "email": "support@rentguy.com",
                    "url": "https://rentguy.com/support"
                },
                "license": {
                    "name": "MIT",
                    "url": "https://opensource.org/licenses/MIT"
                }
            },
            "servers": [
                {
                    "url": f"/api/v{version}",
                    "description": f"RentGuy API v{version}"
                }
            ]
        }
        
        # Add version-specific information
        if api_version.status == APIVersionStatus.DEPRECATED:
            openapi_spec["info"]["x-deprecated"] = True
            openapi_spec["info"]["x-deprecation-date"] = api_version.deprecation_date.isoformat() if api_version.deprecation_date else None
            openapi_spec["info"]["x-sunset-date"] = api_version.sunset_date.isoformat() if api_version.sunset_date else None
        
        if api_version.breaking_changes:
            openapi_spec["info"]["x-breaking-changes"] = api_version.breaking_changes
        
        if api_version.migration_guide_url:
            openapi_spec["info"]["x-migration-guide"] = api_version.migration_guide_url
        
        if api_version.changelog_url:
            openapi_spec["info"]["x-changelog"] = api_version.changelog_url
        
        return openapi_spec
    
    def generate_version_comparison(self, from_version: str, to_version: str) -> Dict:
        """Generate comparison between two API versions."""
        from_api = self.version_manager.validate_version(from_version)
        to_api = self.version_manager.validate_version(to_version)
        
        return {
            "from_version": {
                "version": from_api.version,
                "status": from_api.status.value,
                "release_date": from_api.release_date.isoformat()
            },
            "to_version": {
                "version": to_api.version,
                "status": to_api.status.value,
                "release_date": to_api.release_date.isoformat()
            },
            "breaking_changes": to_api.breaking_changes,
            "migration_guide": to_api.migration_guide_url,
            "changelog": to_api.changelog_url
        }


# Global documentation generator
doc_generator = APIDocumentationGenerator(version_manager)


class APIVersioningConfig:
    """Configuration for API versioning behavior."""
    
    def __init__(self):
        self.version_header_name = "Accept-Version"
        self.version_query_param = "version"
        self.url_versioning_enabled = True
        self.header_versioning_enabled = True
        self.query_versioning_enabled = False
        self.strict_versioning = False  # If True, reject requests without version
        self.auto_deprecation_warnings = True
        self.version_metrics_enabled = True
    
    def get_version_from_request(self, request: Request) -> Tuple[str, str]:
        """
        Get API version from request using configured methods.
        Returns (version, source) tuple.
        """
        # URL-based versioning (highest priority)
        if self.url_versioning_enabled:
            url_version = version_manager.get_version_from_url(str(request.url.path))
            if url_version:
                return url_version, "url"
        
        # Header-based versioning
        if self.header_versioning_enabled:
            header_version = request.headers.get(self.version_header_name)
            if header_version:
                parsed_version = version_manager.get_version_from_header(header_version)
                if parsed_version != version_manager.default_version:
                    return parsed_version, "header"
        
        # Query parameter versioning
        if self.query_versioning_enabled:
            query_version = request.query_params.get(self.version_query_param)
            if query_version and query_version in version_manager.supported_versions:
                return query_version, "query"
        
        # Default version
        if self.strict_versioning:
            raise HTTPException(
                status_code=400,
                detail="API version must be specified"
            )
        
        return version_manager.default_version, "default"


# Global versioning configuration
versioning_config = APIVersioningConfig()
