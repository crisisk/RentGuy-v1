import React, { useState, useEffect } from 'react';
import { 
  OnboardingOrchestrator, 
  useOnboardingTrigger,
  OnboardingUtils,
  OnboardingAnalytics,
  useOnboardingStatus
} from '../index';
import { Button } from '../../../design-system/components/Button';
import { Badge } from '../../../design-system/components/Badge';
import { Card, CardHeader, CardTitle, CardContent } from '../../../design-system/components/Card';
import { Icon } from '../../../design-system/components/Icon';

// Example: Main App Component with Onboarding Integration
export const AppWithOnboarding: React.FC = () => {
  const [userRole, setUserRole] = useState<'manager' | 'warehouse' | 'sales'>('manager');
  const { isOnboardingActive, startOnboarding, stopOnboarding } = useOnboardingTrigger();
  const { isCompleted, shouldShowOnboarding } = useOnboardingStatus(userRole);

  // Auto-start onboarding for new users
  useEffect(() => {
    if (shouldShowOnboarding && !isOnboardingActive) {
      // Small delay to ensure app is fully loaded
      const timer = setTimeout(() => {
        startOnboarding(userRole);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [shouldShowOnboarding, isOnboardingActive, userRole, startOnboarding]);

  const handleOnboardingComplete = () => {
    OnboardingUtils.markAsCompleted(userRole);
    OnboardingAnalytics.track({
      userRole,
      stepId: 'completion',
      stepIndex: -1,
      action: 'complete'
    });
    
    stopOnboarding();
    
    // Show success message or redirect
    console.log('Onboarding completed for', userRole);
  };

  const handleOnboardingSkip = () => {
    OnboardingAnalytics.track({
      userRole,
      stepId: 'skip',
      stepIndex: -1,
      action: 'skip'
    });
    
    stopOnboarding();
  };

  return (
    <div className="min-h-screen bg-secondary-50">
      {/* Main App Content */}
      <div className="p-8">
        <h1 className="text-3xl font-bold text-sevensa-dark mb-8">
          RentGuy Enterprise Dashboard
        </h1>
        
        {/* User Role Selector (for demo) */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Demo: Selecteer Gebruikersrol</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-4">
              {(['manager', 'warehouse', 'sales'] as const).map((role) => (
                <Button
                  key={role}
                  variant={userRole === role ? 'primary' : 'secondary'}
                  onClick={() => setUserRole(role)}
                >
                  <Icon 
                    name={role === 'manager' ? 'dashboard' : role === 'warehouse' ? 'inventory' : 'customers'} 
                    size="sm" 
                    className="mr-2" 
                  />
                  {role === 'manager' ? 'Manager' : role === 'warehouse' ? 'Magazijn' : 'Sales'}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Onboarding Status */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Onboarding Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Badge variant={isCompleted ? 'available' : 'maintenance'}>
                  {isCompleted ? 'Voltooid' : 'Niet Voltooid'}
                </Badge>
                <span className="text-sm text-secondary-600">
                  Rol: {userRole} • Geschatte tijd: {OnboardingUtils.getEstimatedTime(userRole)}
                </span>
              </div>
              
              <div className="flex space-x-2">
                {!isCompleted && (
                  <Button onClick={() => startOnboarding(userRole)}>
                    <Icon name="tour-start" size="sm" className="mr-2" />
                    Start Onboarding
                  </Button>
                )}
                
                {isCompleted && (
                  <Button 
                    variant="secondary" 
                    onClick={() => {
                      OnboardingUtils.resetOnboarding(userRole);
                      window.location.reload(); // Refresh to reset state
                    }}
                  >
                    <Icon name="settings" size="sm" className="mr-2" />
                    Reset Onboarding
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sample Dashboard Content */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="revenue-widget">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Icon name="revenue" className="mr-2 text-sevensa-teal" />
                Revenue Overzicht
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-sevensa-dark">€24,580</div>
              <p className="text-sm text-secondary-600">Deze maand</p>
            </CardContent>
          </Card>

          <Card className="equipment-status">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Icon name="inventory" className="mr-2 text-sevensa-teal" />
                Equipment Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Beschikbaar</span>
                  <Badge variant="available">24</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Verhuurd</span>
                  <Badge variant="rented">18</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Onderhoud</span>
                  <Badge variant="maintenance">3</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="ai-insights-panel">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Icon name="ai-insight" className="mr-2 text-sevensa-teal" />
                AI Inzichten
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-3 bg-sevensa-teal/5 rounded-lg">
                  <p className="text-sm text-sevensa-dark font-medium">
                    Verhoog camera prijzen met 8% voor optimale ROI
                  </p>
                  <p className="text-xs text-secondary-600 mt-1">
                    Gebaseerd op vraag analyse
                  </p>
                </div>
                <Button size="sm" variant="ai" className="w-full">
                  <Icon name="analytics" size="sm" className="mr-2" />
                  Meer Inzichten
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Onboarding Orchestrator */}
      {isOnboardingActive && (
        <OnboardingOrchestrator
          userRole={userRole}
          onComplete={handleOnboardingComplete}
          onSkip={handleOnboardingSkip}
        />
      )}
    </div>
  );
};

// Example: Contextual Onboarding Trigger
export const ContextualOnboardingTrigger: React.FC<{
  userRole: 'manager' | 'warehouse' | 'sales';
  currentPage: string;
}> = ({ userRole, currentPage }) => {
  const [showTips, setShowTips] = useState(false);
  const tips = OnboardingUtils.generateContextualTips(userRole, currentPage);

  if (tips.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-40">
      {showTips && (
        <Card className="mb-4 w-80">
          <CardHeader>
            <CardTitle className="text-sm flex items-center justify-between">
              <span className="flex items-center">
                <Icon name="tip" size="sm" className="mr-2 text-sevensa-teal" />
                Handige Tips
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowTips(false)}
                className="p-1 h-auto"
              >
                <Icon name="delete" size="xs" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {tips.map((tip, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-sevensa-teal/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon name={tip.icon} size="sm" className="text-sevensa-teal" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-sevensa-dark text-sm">{tip.title}</h4>
                  <p className="text-xs text-secondary-600">{tip.description}</p>
                  {tip.action && (
                    <Button size="sm" variant="ghost" className="mt-1 p-0 h-auto text-xs">
                      Probeer nu
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
      
      <Button
        onClick={() => setShowTips(!showTips)}
        className="rounded-full w-12 h-12 shadow-lg"
      >
        <Icon name="help" size="sm" />
      </Button>
    </div>
  );
};

// Example: Onboarding Analytics Dashboard
export const OnboardingAnalyticsDashboard: React.FC = () => {
  const [analytics, setAnalytics] = useState({
    managerCompletion: 0,
    warehouseCompletion: 0,
    salesCompletion: 0,
    averageTime: 0
  });

  useEffect(() => {
    // Calculate analytics
    const managerCompletion = OnboardingAnalytics.getCompletionRate('manager');
    const warehouseCompletion = OnboardingAnalytics.getCompletionRate('warehouse');
    const salesCompletion = OnboardingAnalytics.getCompletionRate('sales');
    const averageTime = OnboardingAnalytics.getAverageTimeToComplete('manager');

    setAnalytics({
      managerCompletion,
      warehouseCompletion,
      salesCompletion,
      averageTime
    });
  }, []);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Onboarding Analytics</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-sevensa-dark">
              {analytics.managerCompletion.toFixed(1)}%
            </div>
            <p className="text-sm text-secondary-600">Manager Completion</p>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-sevensa-dark">
              {analytics.warehouseCompletion.toFixed(1)}%
            </div>
            <p className="text-sm text-secondary-600">Warehouse Completion</p>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-sevensa-dark">
              {analytics.salesCompletion.toFixed(1)}%
            </div>
            <p className="text-sm text-secondary-600">Sales Completion</p>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-sevensa-dark">
              {Math.round(analytics.averageTime / 1000 / 60)}m
            </div>
            <p className="text-sm text-secondary-600">Avg. Time</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AppWithOnboarding;
