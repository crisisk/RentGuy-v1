import React from 'react';
import { cn } from '../../../design-system/utils/cn';

export interface OnboardingOverlayProps {
  className?: string;
  opacity?: number;
}

export const OnboardingOverlay: React.FC<OnboardingOverlayProps> = ({
  className,
  opacity = 0.8
}) => {
  return (
    <div 
      className={cn(
        'fixed inset-0 bg-sevensa-dark transition-opacity duration-300 z-40',
        className
      )}
      style={{ opacity }}
      aria-hidden="true"
    />
  );
};

export default OnboardingOverlay;
