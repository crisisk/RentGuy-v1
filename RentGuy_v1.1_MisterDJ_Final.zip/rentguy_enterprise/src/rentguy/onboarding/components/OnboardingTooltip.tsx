import React, { useEffect, useState, useRef } from 'react';
import { Button } from '../../../design-system/components/Button';
import { Icon } from '../../../design-system/components/Icon';
import { cn } from '../../../design-system/utils/cn';

export interface OnboardingTooltipProps {
  target: HTMLElement;
  content: {
    title: string;
    description: string;
    icon?: string;
    action?: string;
  };
  onClose: () => void;
  className?: string;
}

export const OnboardingTooltip: React.FC<OnboardingTooltipProps> = ({
  target,
  content,
  onClose,
  className
}) => {
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const [placement, setPlacement] = useState<'top' | 'bottom' | 'left' | 'right'>('bottom');
  const tooltipRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!target || !tooltipRef.current) return;

    const updatePosition = () => {
      const targetRect = target.getBoundingClientRect();
      const tooltipRect = tooltipRef.current!.getBoundingClientRect();
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;

      let newPlacement: typeof placement = 'bottom';
      let top = 0;
      let left = 0;

      // Determine best placement
      const spaceBelow = viewportHeight - targetRect.bottom;
      const spaceAbove = targetRect.top;
      const spaceRight = viewportWidth - targetRect.right;
      const spaceLeft = targetRect.left;

      if (spaceBelow >= tooltipRect.height + 10) {
        newPlacement = 'bottom';
        top = targetRect.bottom + 10;
        left = targetRect.left + (targetRect.width - tooltipRect.width) / 2;
      } else if (spaceAbove >= tooltipRect.height + 10) {
        newPlacement = 'top';
        top = targetRect.top - tooltipRect.height - 10;
        left = targetRect.left + (targetRect.width - tooltipRect.width) / 2;
      } else if (spaceRight >= tooltipRect.width + 10) {
        newPlacement = 'right';
        top = targetRect.top + (targetRect.height - tooltipRect.height) / 2;
        left = targetRect.right + 10;
      } else if (spaceLeft >= tooltipRect.width + 10) {
        newPlacement = 'left';
        top = targetRect.top + (targetRect.height - tooltipRect.height) / 2;
        left = targetRect.left - tooltipRect.width - 10;
      }

      // Ensure tooltip stays within viewport
      left = Math.max(10, Math.min(left, viewportWidth - tooltipRect.width - 10));
      top = Math.max(10, Math.min(top, viewportHeight - tooltipRect.height - 10));

      setPosition({ top, left });
      setPlacement(newPlacement);
    };

    updatePosition();
    window.addEventListener('resize', updatePosition);
    window.addEventListener('scroll', updatePosition);

    return () => {
      window.removeEventListener('resize', updatePosition);
      window.removeEventListener('scroll', updatePosition);
    };
  }, [target]);

  // Highlight the target element
  useEffect(() => {
    if (!target) return;

    const originalStyle = {
      outline: target.style.outline,
      outlineOffset: target.style.outlineOffset,
      zIndex: target.style.zIndex,
      position: target.style.position
    };

    // Add highlight
    target.style.outline = '3px solid #00A896';
    target.style.outlineOffset = '2px';
    target.style.zIndex = '45';
    if (target.style.position === 'static') {
      target.style.position = 'relative';
    }

    return () => {
      // Restore original styles
      target.style.outline = originalStyle.outline;
      target.style.outlineOffset = originalStyle.outlineOffset;
      target.style.zIndex = originalStyle.zIndex;
      target.style.position = originalStyle.position;
    };
  }, [target]);

  const getArrowClasses = () => {
    const baseClasses = 'absolute w-3 h-3 bg-white border transform rotate-45';
    
    switch (placement) {
      case 'top':
        return `${baseClasses} -bottom-1.5 left-1/2 -translate-x-1/2 border-t-0 border-l-0`;
      case 'bottom':
        return `${baseClasses} -top-1.5 left-1/2 -translate-x-1/2 border-b-0 border-r-0`;
      case 'left':
        return `${baseClasses} -right-1.5 top-1/2 -translate-y-1/2 border-l-0 border-b-0`;
      case 'right':
        return `${baseClasses} -left-1.5 top-1/2 -translate-y-1/2 border-r-0 border-t-0`;
      default:
        return baseClasses;
    }
  };

  return (
    <div
      ref={tooltipRef}
      className={cn(
        'fixed z-50 bg-white rounded-lg shadow-lg border border-secondary-200 p-4 max-w-sm animate-fade-in',
        className
      )}
      style={{
        top: position.top,
        left: position.left
      }}
    >
      {/* Arrow */}
      <div className={getArrowClasses()} />
      
      {/* Content */}
      <div className="space-y-3">
        <div className="flex items-start space-x-3">
          {content.icon && (
            <div className="w-8 h-8 bg-sevensa-teal/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <Icon name={content.icon} size="sm" className="text-sevensa-teal" />
            </div>
          )}
          <div className="flex-1">
            <h4 className="font-semibold text-sevensa-dark text-sm mb-1">
              {content.title}
            </h4>
            <p className="text-xs text-secondary-600">
              {content.description}
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="p-1 h-auto"
          >
            <Icon name="delete" size="xs" className="text-secondary-400" />
          </Button>
        </div>
        
        {content.action && (
          <div className="flex justify-end">
            <Button size="sm" onClick={onClose}>
              {content.action}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default OnboardingTooltip;
