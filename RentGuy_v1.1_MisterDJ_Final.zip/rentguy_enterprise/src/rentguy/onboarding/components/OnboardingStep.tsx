import React, { useState, useEffect } from 'react';
import { Button } from '../../../design-system/components/Button';
import { Badge } from '../../../design-system/components/Badge';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '../../../design-system/components/Card';
import { Icon } from '../../../design-system/components/Icon';
import { cn } from '../../../design-system/utils/cn';

export interface OnboardingStepProps {
  step: any; // Step data from onboarding-flows.json
  stepIndex: number;
  totalSteps: number;
  onNext: () => void;
  onPrevious?: () => void;
  onSkip?: () => void;
}

export const OnboardingStep: React.FC<OnboardingStepProps> = ({
  step,
  stepIndex,
  totalSteps,
  onNext,
  onPrevious,
  onSkip
}) => {
  const [simulationState, setSimulationState] = useState<{
    currentSimulationStep: number;
    isSimulationActive: boolean;
    completedActions: string[];
  }>({
    currentSimulationStep: 0,
    isSimulationActive: false,
    completedActions: []
  });

  // Handle different step types
  const renderStepContent = () => {
    switch (step.type) {
      case 'introduction':
        return renderIntroduction();
      case 'interactive-tour':
        return renderInteractiveTour();
      case 'hands-on-simulation':
        return renderHandsOnSimulation();
      case 'feature-showcase':
        return renderFeatureShowcase();
      case 'feature-tour':
        return renderFeatureTour();
      case 'completion':
        return renderCompletion();
      default:
        return renderDefault();
    }
  };

  const renderIntroduction = () => (
    <div className="text-center space-y-6">
      <div className="flex justify-center">
        <div className="w-20 h-20 bg-gradient-to-br from-sevensa-teal to-sevensa-dark rounded-full flex items-center justify-center">
          <Icon name={step.icon} size="xl" className="text-white" />
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-sevensa-dark">{step.content.heading}</h2>
        <p className="text-lg text-secondary-600">{step.content.subheading}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
        {step.content.highlights.map((highlight: any, index: number) => (
          <Card key={index} className="text-center p-4">
            <CardContent className="pt-4">
              <div className="flex justify-center mb-3">
                <div className="w-12 h-12 bg-sevensa-teal/10 rounded-lg flex items-center justify-center">
                  <Icon name={highlight.icon} className="text-sevensa-teal" />
                </div>
              </div>
              <h3 className="font-semibold text-sevensa-dark mb-2">{highlight.title}</h3>
              <p className="text-sm text-secondary-600">{highlight.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderInteractiveTour = () => (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-sevensa-teal rounded-full flex items-center justify-center">
            <Icon name={step.icon} size="lg" className="text-white" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-sevensa-dark">{step.content.heading}</h2>
        <p className="text-secondary-600">{step.content.description}</p>
      </div>

      <div className="space-y-4">
        {step.content.interactiveElements.map((element: any, index: number) => (
          <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-sevensa-teal/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon name={element.icon} className="text-sevensa-teal" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sevensa-dark mb-1">{element.title}</h3>
                  <p className="text-sm text-secondary-600 mb-2">{element.description}</p>
                  <Badge variant="ai" className="text-xs">
                    <Icon name="tip" size="xs" className="mr-1" />
                    {element.tooltip}
                  </Badge>
                </div>
                <Icon name="tour-next" className="text-secondary-400" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderHandsOnSimulation = () => {
    const simulation = step.simulation;
    const currentSimStep = simulation.steps[simulationState.currentSimulationStep];
    
    return (
      <div className="space-y-6">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-gradient-to-br from-sevensa-teal to-sevensa-dark rounded-full flex items-center justify-center">
              <Icon name={step.icon} size="lg" className="text-white" />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-sevensa-dark">{step.content.heading}</h2>
          <p className="text-secondary-600">{step.content.description}</p>
        </div>

        {/* Scenario Info */}
        <Card className="bg-sevensa-teal/5 border-sevensa-teal/20">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2 mb-3">
              <Icon name="info" className="text-sevensa-teal" />
              <span className="font-semibold text-sevensa-dark">Demo Scenario</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              {Object.entries(step.content.scenario).map(([key, value]) => (
                <div key={key}>
                  <span className="text-secondary-500 capitalize">{key}:</span>
                  <div className="font-medium text-sevensa-dark">{value as string}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Simulation Steps */}
        <div className="space-y-3">
          {simulation.steps.map((simStep: any, index: number) => {
            const isCompleted = simulationState.completedActions.includes(simStep.action);
            const isCurrent = index === simulationState.currentSimulationStep;
            const isUpcoming = index > simulationState.currentSimulationStep;

            return (
              <Card 
                key={index} 
                className={cn(
                  'transition-all duration-300',
                  isCompleted && 'bg-green-50 border-green-200',
                  isCurrent && 'bg-sevensa-teal/5 border-sevensa-teal/30 shadow-md',
                  isUpcoming && 'opacity-60'
                )}
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className={cn(
                      'w-10 h-10 rounded-full flex items-center justify-center',
                      isCompleted && 'bg-green-100',
                      isCurrent && 'bg-sevensa-teal/10',
                      isUpcoming && 'bg-secondary-100'
                    )}>
                      <Icon 
                        name={isCompleted ? 'tour-complete' : simStep.icon} 
                        className={cn(
                          isCompleted && 'text-green-600',
                          isCurrent && 'text-sevensa-teal',
                          isUpcoming && 'text-secondary-400'
                        )}
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className={cn(
                        'font-semibold mb-1',
                        isCompleted && 'text-green-800',
                        isCurrent && 'text-sevensa-dark',
                        isUpcoming && 'text-secondary-500'
                      )}>
                        {simStep.title}
                      </h3>
                      <p className={cn(
                        'text-sm',
                        isCompleted && 'text-green-600',
                        isCurrent && 'text-secondary-600',
                        isUpcoming && 'text-secondary-400'
                      )}>
                        {simStep.description}
                      </p>
                    </div>
                    {isCurrent && (
                      <Button
                        size="sm"
                        onClick={() => {
                          setSimulationState(prev => ({
                            ...prev,
                            completedActions: [...prev.completedActions, simStep.action],
                            currentSimulationStep: Math.min(prev.currentSimulationStep + 1, simulation.steps.length - 1)
                          }));
                        }}
                      >
                        <Icon name="tour-next" size="sm" className="mr-1" />
                        Uitvoeren
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Completion Message */}
        {simulationState.completedActions.length === simulation.steps.length && step.completion && (
          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4 text-center">
              <div className="flex justify-center mb-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <Icon name="tour-complete" className="text-green-600" />
                </div>
              </div>
              <h3 className="font-semibold text-green-800 mb-2">{step.completion.message}</h3>
              <div className="flex justify-center space-x-4">
                {step.completion.achievements.map((achievement: any, index: number) => (
                  <Badge key={index} variant="available" className="flex items-center">
                    <Icon name={achievement.icon} size="xs" className="mr-1" />
                    {achievement.title}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  const renderFeatureShowcase = () => (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-gradient-to-br from-sevensa-teal to-sevensa-dark rounded-full flex items-center justify-center">
            <Icon name={step.icon} size="lg" className="text-white" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-sevensa-dark">{step.content.heading}</h2>
        <p className="text-secondary-600">{step.content.description}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {(step.content.features || step.content.reportTypes || []).map((feature: any, index: number) => (
          <Card key={index} className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6 text-center">
              <div className="flex justify-center mb-4">
                <div className="w-14 h-14 bg-sevensa-teal/10 rounded-xl flex items-center justify-center">
                  <Icon name={feature.icon} size="lg" className="text-sevensa-teal" />
                </div>
              </div>
              <h3 className="font-semibold text-sevensa-dark mb-2">{feature.title}</h3>
              <p className="text-sm text-secondary-600 mb-4">{feature.description}</p>
              {feature.demo && (
                <Badge variant="ai" className="text-xs">
                  <Icon name="ai-insight" size="xs" className="mr-1" />
                  Live Demo
                </Badge>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderFeatureTour = () => (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-sevensa-teal rounded-full flex items-center justify-center">
            <Icon name={step.icon} size="lg" className="text-white" />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-sevensa-dark">{step.content.heading}</h2>
        <p className="text-secondary-600">{step.content.description}</p>
      </div>

      <div className="space-y-4">
        {step.content.keyFeatures.map((feature: any, index: number) => (
          <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-sevensa-teal/10 rounded-lg flex items-center justify-center">
                  <Icon name={feature.icon} className="text-sevensa-teal" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-sevensa-dark mb-1">{feature.title}</h3>
                  <p className="text-sm text-secondary-600">{feature.description}</p>
                </div>
                <Button variant="ghost" size="sm">
                  <Icon name="view" size="sm" className="mr-1" />
                  Bekijken
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderCompletion = () => (
    <div className="text-center space-y-6">
      <div className="flex justify-center">
        <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center">
          <Icon name="tour-complete" size="xl" className="text-white" />
        </div>
      </div>
      
      <div className="space-y-4">
        <h2 className="text-3xl font-bold text-sevensa-dark">{step.content.heading}</h2>
        <p className="text-lg text-secondary-600">{step.content.description}</p>
      </div>

      {/* Achievements */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {step.content.achievements.map((achievement: any, index: number) => (
          <Card key={index} className="text-center p-4 bg-green-50 border-green-200">
            <CardContent className="pt-4">
              <div className="flex justify-center mb-3">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Icon name={achievement.icon} className="text-green-600" />
                </div>
              </div>
              <h3 className="font-semibold text-green-800 text-sm mb-1">{achievement.title}</h3>
              <p className="text-xs text-green-600">{achievement.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Next Steps */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-sevensa-dark">Volgende Stappen</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {step.content.nextSteps.map((nextStep: any, index: number) => (
            <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="p-4 text-center">
                <div className="flex justify-center mb-3">
                  <div className="w-10 h-10 bg-sevensa-teal/10 rounded-lg flex items-center justify-center">
                    <Icon name={nextStep.icon} className="text-sevensa-teal" />
                  </div>
                </div>
                <h4 className="font-semibold text-sevensa-dark mb-2">{nextStep.title}</h4>
                <p className="text-sm text-secondary-600">{nextStep.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );

  const renderDefault = () => (
    <div className="text-center space-y-4">
      <div className="flex justify-center">
        <div className="w-16 h-16 bg-sevensa-teal rounded-full flex items-center justify-center">
          <Icon name={step.icon || 'help'} size="lg" className="text-white" />
        </div>
      </div>
      <h2 className="text-2xl font-bold text-sevensa-dark">{step.title}</h2>
      <p className="text-secondary-600">{step.description}</p>
    </div>
  );

  return (
    <div className="fixed inset-0 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="text-center border-b">
          <div className="flex items-center justify-between">
            <Badge variant="secondary">
              Stap {stepIndex + 1} van {totalSteps}
            </Badge>
            <Badge variant="ai">
              <Icon name={step.icon} size="xs" className="mr-1" />
              {step.title}
            </Badge>
          </div>
        </CardHeader>
        
        <CardContent className="p-8">
          {renderStepContent()}
        </CardContent>
        
        <CardFooter className="flex justify-between border-t p-6">
          <div className="flex space-x-2">
            {onPrevious && (
              <Button variant="secondary" onClick={onPrevious}>
                <Icon name="tour-previous" size="sm" className="mr-2" />
                Vorige
              </Button>
            )}
            {onSkip && (
              <Button variant="ghost" onClick={onSkip}>
                Overslaan
              </Button>
            )}
          </div>
          
          <Button onClick={onNext} className="ml-auto">
            {stepIndex === totalSteps - 1 ? (
              <>
                <Icon name="tour-complete" size="sm" className="mr-2" />
                Voltooien
              </>
            ) : (
              <>
                Volgende
                <Icon name="tour-next" size="sm" className="ml-2" />
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default OnboardingStep;
