import React from 'react';
import { Icon } from '../../../design-system/components/Icon';
import { Badge } from '../../../design-system/components/Badge';
import { cn } from '../../../design-system/utils/cn';

export interface OnboardingProgressProps {
  current: number;
  total: number;
  title: string;
  estimatedTime?: string;
  className?: string;
}

export const OnboardingProgress: React.FC<OnboardingProgressProps> = ({
  current,
  total,
  title,
  estimatedTime,
  className
}) => {
  const progressPercentage = (current / total) * 100;

  return (
    <div className={cn(
      'fixed top-0 left-0 right-0 z-60 bg-white/95 backdrop-blur-sm border-b border-secondary-200 shadow-sm',
      className
    )}>
      <div className="max-w-4xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-sevensa-teal rounded-full flex items-center justify-center">
              <Icon name="tour-start" size="sm" className="text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-sevensa-dark text-sm">{title}</h3>
              <p className="text-xs text-secondary-500">
                Stap {current} van {total}
                {estimatedTime && ` • ${estimatedTime}`}
              </p>
            </div>
          </div>
          
          <Badge variant="ai" className="text-xs">
            {Math.round(progressPercentage)}% voltooid
          </Badge>
        </div>
        
        {/* Progress Bar */}
        <div className="w-full bg-secondary-200 rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-sevensa-teal to-sevensa-dark h-2 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default OnboardingProgress;
