import React, { useState, useEffect, useCallback } from 'react';
import { OnboardingProvider, useOnboarding } from '../utils/OnboardingContext';
import { OnboardingStep } from './OnboardingStep';
import { OnboardingProgress } from './OnboardingProgress';
import { OnboardingOverlay } from './OnboardingOverlay';
import { OnboardingTooltip } from './OnboardingTooltip';
import { Button } from '../../../design-system/components/Button';
import { Icon } from '../../../design-system/components/Icon';
import { cn } from '../../../design-system/utils/cn';
import onboardingFlows from '../data/onboarding-flows.json';

export interface OnboardingOrchestratorProps {
  userRole: 'manager' | 'warehouse' | 'sales';
  onComplete?: () => void;
  onSkip?: () => void;
  className?: string;
}

const OnboardingOrchestratorInner: React.FC<OnboardingOrchestratorProps> = ({
  userRole,
  onComplete,
  onSkip,
  className
}) => {
  const {
    currentStep,
    isActive,
    progress,
    nextStep,
    previousStep,
    skipOnboarding,
    completeOnboarding,
    setTooltipTarget,
    tooltipTarget
  } = useOnboarding();

  const flow = onboardingFlows.flows[userRole];
  const currentStepData = flow?.steps[currentStep];

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!isActive) return;

      switch (event.key) {
        case 'Escape':
          if (onboardingFlows.globalSettings.allowSkip) {
            skipOnboarding();
          }
          break;
        case 'ArrowRight':
        case 'Enter':
          if (currentStep < flow.steps.length - 1) {
            nextStep();
          } else {
            completeOnboarding();
          }
          break;
        case 'ArrowLeft':
          if (currentStep > 0) {
            previousStep();
          }
          break;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isActive, currentStep, flow.steps.length, nextStep, previousStep, skipOnboarding, completeOnboarding]);

  // Handle completion
  const handleComplete = useCallback(() => {
    completeOnboarding();
    onComplete?.();
  }, [completeOnboarding, onComplete]);

  // Handle skip
  const handleSkip = useCallback(() => {
    skipOnboarding();
    onSkip?.();
  }, [skipOnboarding, onSkip]);

  if (!isActive || !currentStepData) {
    return null;
  }

  return (
    <div className={cn('fixed inset-0 z-50', className)}>
      {/* Overlay */}
      <OnboardingOverlay />
      
      {/* Progress Bar */}
      <OnboardingProgress
        current={currentStep + 1}
        total={flow.steps.length}
        title={flow.title}
        estimatedTime={flow.estimatedTime}
      />

      {/* Main Step Content */}
      <div className="relative z-60">
        <OnboardingStep
          step={currentStepData}
          stepIndex={currentStep}
          totalSteps={flow.steps.length}
          onNext={currentStep < flow.steps.length - 1 ? nextStep : handleComplete}
          onPrevious={currentStep > 0 ? previousStep : undefined}
          onSkip={onboardingFlows.globalSettings.allowSkip ? handleSkip : undefined}
        />
      </div>

      {/* Tooltip System */}
      {tooltipTarget && (
        <OnboardingTooltip
          target={tooltipTarget.element}
          content={tooltipTarget.content}
          onClose={() => setTooltipTarget(null)}
        />
      )}

      {/* Skip Button (Global) */}
      {onboardingFlows.globalSettings.allowSkip && (
        <div className="fixed top-4 right-4 z-70">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleSkip}
            className="text-white hover:bg-white/10"
          >
            <Icon name="tour-complete" size="sm" className="mr-2" />
            Overslaan
          </Button>
        </div>
      )}
    </div>
  );
};

export const OnboardingOrchestrator: React.FC<OnboardingOrchestratorProps> = (props) => {
  return (
    <OnboardingProvider userRole={props.userRole}>
      <OnboardingOrchestratorInner {...props} />
    </OnboardingProvider>
  );
};

// Hook for triggering onboarding from anywhere in the app
export const useOnboardingTrigger = () => {
  const [isOnboardingActive, setIsOnboardingActive] = useState(false);
  const [userRole, setUserRole] = useState<'manager' | 'warehouse' | 'sales'>('manager');

  const startOnboarding = useCallback((role: 'manager' | 'warehouse' | 'sales') => {
    setUserRole(role);
    setIsOnboardingActive(true);
  }, []);

  const stopOnboarding = useCallback(() => {
    setIsOnboardingActive(false);
  }, []);

  return {
    isOnboardingActive,
    userRole,
    startOnboarding,
    stopOnboarding
  };
};

export default OnboardingOrchestrator;
