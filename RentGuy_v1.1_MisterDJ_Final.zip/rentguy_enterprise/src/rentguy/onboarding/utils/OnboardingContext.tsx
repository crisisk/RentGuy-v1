import React, { createContext, useContext, useReducer, useCallback, useEffect } from 'react';
import onboardingFlows from '../data/onboarding-flows.json';

// Types
export interface OnboardingState {
  isActive: boolean;
  userRole: 'manager' | 'warehouse' | 'sales';
  currentStep: number;
  progress: number;
  completedSteps: number[];
  skippedSteps: number[];
  startTime: number | null;
  tooltipTarget: {
    element: HTMLElement;
    content: {
      title: string;
      description: string;
      icon?: string;
      action?: string;
    };
  } | null;
}

export interface OnboardingActions {
  startOnboarding: (role: 'manager' | 'warehouse' | 'sales') => void;
  nextStep: () => void;
  previousStep: () => void;
  goToStep: (stepIndex: number) => void;
  skipStep: () => void;
  skipOnboarding: () => void;
  completeOnboarding: () => void;
  setTooltipTarget: (target: OnboardingState['tooltipTarget']) => void;
  resetOnboarding: () => void;
}

type OnboardingContextType = OnboardingState & OnboardingActions;

// Action types
type OnboardingAction =
  | { type: 'START_ONBOARDING'; payload: { role: 'manager' | 'warehouse' | 'sales' } }
  | { type: 'NEXT_STEP' }
  | { type: 'PREVIOUS_STEP' }
  | { type: 'GO_TO_STEP'; payload: { stepIndex: number } }
  | { type: 'SKIP_STEP' }
  | { type: 'SKIP_ONBOARDING' }
  | { type: 'COMPLETE_ONBOARDING' }
  | { type: 'SET_TOOLTIP_TARGET'; payload: { target: OnboardingState['tooltipTarget'] } }
  | { type: 'RESET_ONBOARDING' };

// Initial state
const initialState: OnboardingState = {
  isActive: false,
  userRole: 'manager',
  currentStep: 0,
  progress: 0,
  completedSteps: [],
  skippedSteps: [],
  startTime: null,
  tooltipTarget: null
};

// Reducer
const onboardingReducer = (state: OnboardingState, action: OnboardingAction): OnboardingState => {
  switch (action.type) {
    case 'START_ONBOARDING':
      return {
        ...state,
        isActive: true,
        userRole: action.payload.role,
        currentStep: 0,
        progress: 0,
        completedSteps: [],
        skippedSteps: [],
        startTime: Date.now(),
        tooltipTarget: null
      };

    case 'NEXT_STEP': {
      const flow = onboardingFlows.flows[state.userRole];
      const nextStep = Math.min(state.currentStep + 1, flow.steps.length - 1);
      const newCompletedSteps = [...state.completedSteps];
      
      if (!newCompletedSteps.includes(state.currentStep)) {
        newCompletedSteps.push(state.currentStep);
      }

      return {
        ...state,
        currentStep: nextStep,
        progress: ((nextStep + 1) / flow.steps.length) * 100,
        completedSteps: newCompletedSteps,
        tooltipTarget: null
      };
    }

    case 'PREVIOUS_STEP': {
      const prevStep = Math.max(state.currentStep - 1, 0);
      return {
        ...state,
        currentStep: prevStep,
        progress: ((prevStep + 1) / onboardingFlows.flows[state.userRole].steps.length) * 100,
        tooltipTarget: null
      };
    }

    case 'GO_TO_STEP': {
      const { stepIndex } = action.payload;
      const flow = onboardingFlows.flows[state.userRole];
      const validStepIndex = Math.max(0, Math.min(stepIndex, flow.steps.length - 1));
      
      return {
        ...state,
        currentStep: validStepIndex,
        progress: ((validStepIndex + 1) / flow.steps.length) * 100,
        tooltipTarget: null
      };
    }

    case 'SKIP_STEP': {
      const flow = onboardingFlows.flows[state.userRole];
      const nextStep = Math.min(state.currentStep + 1, flow.steps.length - 1);
      const newSkippedSteps = [...state.skippedSteps];
      
      if (!newSkippedSteps.includes(state.currentStep)) {
        newSkippedSteps.push(state.currentStep);
      }

      return {
        ...state,
        currentStep: nextStep,
        progress: ((nextStep + 1) / flow.steps.length) * 100,
        skippedSteps: newSkippedSteps,
        tooltipTarget: null
      };
    }

    case 'SKIP_ONBOARDING':
    case 'COMPLETE_ONBOARDING':
      return {
        ...state,
        isActive: false,
        progress: 100,
        tooltipTarget: null
      };

    case 'SET_TOOLTIP_TARGET':
      return {
        ...state,
        tooltipTarget: action.payload.target
      };

    case 'RESET_ONBOARDING':
      return initialState;

    default:
      return state;
  }
};

// Context
const OnboardingContext = createContext<OnboardingContextType | null>(null);

// Provider
export interface OnboardingProviderProps {
  children: React.ReactNode;
  userRole: 'manager' | 'warehouse' | 'sales';
  autoStart?: boolean;
}

export const OnboardingProvider: React.FC<OnboardingProviderProps> = ({
  children,
  userRole,
  autoStart = true
}) => {
  const [state, dispatch] = useReducer(onboardingReducer, {
    ...initialState,
    userRole
  });

  // Auto-start onboarding if enabled
  useEffect(() => {
    if (autoStart && !state.isActive) {
      dispatch({ type: 'START_ONBOARDING', payload: { role: userRole } });
    }
  }, [autoStart, userRole, state.isActive]);

  // Save progress to localStorage
  useEffect(() => {
    if (onboardingFlows.globalSettings.saveProgress) {
      const progressData = {
        userRole: state.userRole,
        currentStep: state.currentStep,
        completedSteps: state.completedSteps,
        skippedSteps: state.skippedSteps,
        startTime: state.startTime
      };
      localStorage.setItem('rentguy-onboarding-progress', JSON.stringify(progressData));
    }
  }, [state.currentStep, state.completedSteps, state.skippedSteps, state.userRole, state.startTime]);

  // Load progress from localStorage
  useEffect(() => {
    if (onboardingFlows.globalSettings.saveProgress) {
      const savedProgress = localStorage.getItem('rentguy-onboarding-progress');
      if (savedProgress) {
        try {
          const progressData = JSON.parse(savedProgress);
          if (progressData.userRole === userRole) {
            // Restore progress for the same user role
            dispatch({ type: 'GO_TO_STEP', payload: { stepIndex: progressData.currentStep } });
          }
        } catch (error) {
          console.warn('Failed to load onboarding progress:', error);
        }
      }
    }
  }, [userRole]);

  // Actions
  const startOnboarding = useCallback((role: 'manager' | 'warehouse' | 'sales') => {
    dispatch({ type: 'START_ONBOARDING', payload: { role } });
  }, []);

  const nextStep = useCallback(() => {
    dispatch({ type: 'NEXT_STEP' });
  }, []);

  const previousStep = useCallback(() => {
    dispatch({ type: 'PREVIOUS_STEP' });
  }, []);

  const goToStep = useCallback((stepIndex: number) => {
    dispatch({ type: 'GO_TO_STEP', payload: { stepIndex } });
  }, []);

  const skipStep = useCallback(() => {
    dispatch({ type: 'SKIP_STEP' });
  }, []);

  const skipOnboarding = useCallback(() => {
    dispatch({ type: 'SKIP_ONBOARDING' });
    
    // Clear saved progress
    if (onboardingFlows.globalSettings.saveProgress) {
      localStorage.removeItem('rentguy-onboarding-progress');
    }
  }, []);

  const completeOnboarding = useCallback(() => {
    dispatch({ type: 'COMPLETE_ONBOARDING' });
    
    // Mark onboarding as completed
    localStorage.setItem(`rentguy-onboarding-completed-${state.userRole}`, 'true');
    
    // Clear progress
    if (onboardingFlows.globalSettings.saveProgress) {
      localStorage.removeItem('rentguy-onboarding-progress');
    }
  }, [state.userRole]);

  const setTooltipTarget = useCallback((target: OnboardingState['tooltipTarget']) => {
    dispatch({ type: 'SET_TOOLTIP_TARGET', payload: { target } });
  }, []);

  const resetOnboarding = useCallback(() => {
    dispatch({ type: 'RESET_ONBOARDING' });
    localStorage.removeItem('rentguy-onboarding-progress');
    localStorage.removeItem(`rentguy-onboarding-completed-${state.userRole}`);
  }, [state.userRole]);

  const contextValue: OnboardingContextType = {
    ...state,
    startOnboarding,
    nextStep,
    previousStep,
    goToStep,
    skipStep,
    skipOnboarding,
    completeOnboarding,
    setTooltipTarget,
    resetOnboarding
  };

  return (
    <OnboardingContext.Provider value={contextValue}>
      {children}
    </OnboardingContext.Provider>
  );
};

// Hook
export const useOnboarding = (): OnboardingContextType => {
  const context = useContext(OnboardingContext);
  if (!context) {
    throw new Error('useOnboarding must be used within an OnboardingProvider');
  }
  return context;
};

// Utility hooks
export const useOnboardingStatus = (userRole: 'manager' | 'warehouse' | 'sales') => {
  const isCompleted = localStorage.getItem(`rentguy-onboarding-completed-${userRole}`) === 'true';
  const hasProgress = localStorage.getItem('rentguy-onboarding-progress') !== null;
  
  return {
    isCompleted,
    hasProgress,
    shouldShowOnboarding: !isCompleted
  };
};

export default OnboardingContext;
