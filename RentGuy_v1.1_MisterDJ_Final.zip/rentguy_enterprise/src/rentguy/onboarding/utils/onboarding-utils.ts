import onboardingFlows from '../data/onboarding-flows.json';

// Types
export type UserRole = 'manager' | 'warehouse' | 'sales';
export type StepType = 'introduction' | 'interactive-tour' | 'hands-on-simulation' | 'feature-showcase' | 'feature-tour' | 'completion';

export interface OnboardingAnalytics {
  userRole: UserRole;
  stepId: string;
  stepIndex: number;
  action: 'start' | 'complete' | 'skip' | 'next' | 'previous';
  timestamp: number;
  timeSpent?: number;
}

// Analytics tracking
export class OnboardingAnalytics {
  private static events: OnboardingAnalytics[] = [];

  static track(event: Omit<OnboardingAnalytics, 'timestamp'>) {
    const analyticsEvent: OnboardingAnalytics = {
      ...event,
      timestamp: Date.now()
    };
    
    this.events.push(analyticsEvent);
    
    // Send to analytics service (placeholder)
    this.sendToAnalytics(analyticsEvent);
  }

  private static sendToAnalytics(event: OnboardingAnalytics) {
    // In a real implementation, this would send to your analytics service
    console.log('Onboarding Analytics:', event);
    
    // Example: Send to Google Analytics, Mixpanel, etc.
    // gtag('event', 'onboarding_action', {
    //   user_role: event.userRole,
    //   step_id: event.stepId,
    //   action: event.action
    // });
  }

  static getEvents(): OnboardingAnalytics[] {
    return [...this.events];
  }

  static getCompletionRate(userRole: UserRole): number {
    const roleEvents = this.events.filter(e => e.userRole === userRole);
    const startEvents = roleEvents.filter(e => e.action === 'start');
    const completeEvents = roleEvents.filter(e => e.action === 'complete');
    
    if (startEvents.length === 0) return 0;
    return (completeEvents.length / startEvents.length) * 100;
  }

  static getAverageTimeToComplete(userRole: UserRole): number {
    const roleEvents = this.events.filter(e => e.userRole === userRole);
    const completedSessions = new Map<string, { start: number; end: number }>();
    
    roleEvents.forEach(event => {
      const sessionKey = `${event.userRole}-${Math.floor(event.timestamp / (1000 * 60 * 60))}`; // Group by hour
      
      if (event.action === 'start') {
        if (!completedSessions.has(sessionKey)) {
          completedSessions.set(sessionKey, { start: event.timestamp, end: 0 });
        }
      } else if (event.action === 'complete') {
        const session = completedSessions.get(sessionKey);
        if (session) {
          session.end = event.timestamp;
        }
      }
    });
    
    const completedTimes = Array.from(completedSessions.values())
      .filter(session => session.end > 0)
      .map(session => session.end - session.start);
    
    if (completedTimes.length === 0) return 0;
    return completedTimes.reduce((sum, time) => sum + time, 0) / completedTimes.length;
  }
}

// Onboarding utilities
export class OnboardingUtils {
  // Check if user should see onboarding
  static shouldShowOnboarding(userRole: UserRole): boolean {
    const completedKey = `rentguy-onboarding-completed-${userRole}`;
    return localStorage.getItem(completedKey) !== 'true';
  }

  // Mark onboarding as completed
  static markAsCompleted(userRole: UserRole): void {
    const completedKey = `rentguy-onboarding-completed-${userRole}`;
    localStorage.setItem(completedKey, 'true');
    localStorage.setItem(`rentguy-onboarding-completed-date-${userRole}`, new Date().toISOString());
  }

  // Reset onboarding for a user role
  static resetOnboarding(userRole: UserRole): void {
    const completedKey = `rentguy-onboarding-completed-${userRole}`;
    const dateKey = `rentguy-onboarding-completed-date-${userRole}`;
    const progressKey = 'rentguy-onboarding-progress';
    
    localStorage.removeItem(completedKey);
    localStorage.removeItem(dateKey);
    localStorage.removeItem(progressKey);
  }

  // Get onboarding flow for user role
  static getFlow(userRole: UserRole) {
    return onboardingFlows.flows[userRole];
  }

  // Get step by ID
  static getStep(userRole: UserRole, stepId: string) {
    const flow = this.getFlow(userRole);
    return flow?.steps.find(step => step.id === stepId);
  }

  // Get estimated time for flow
  static getEstimatedTime(userRole: UserRole): string {
    const flow = this.getFlow(userRole);
    return flow?.estimatedTime || '5-7 minuten';
  }

  // Check if step requires interaction
  static isInteractiveStep(stepType: StepType): boolean {
    return ['interactive-tour', 'hands-on-simulation'].includes(stepType);
  }

  // Get next recommended action for user
  static getNextAction(userRole: UserRole): string | null {
    if (this.shouldShowOnboarding(userRole)) {
      return 'start-onboarding';
    }
    
    // Check if user has completed basic setup
    const hasCustomers = localStorage.getItem('rentguy-has-customers') === 'true';
    const hasInventory = localStorage.getItem('rentguy-has-inventory') === 'true';
    
    if (!hasCustomers) return 'add-customers';
    if (!hasInventory) return 'add-inventory';
    
    return null;
  }

  // Generate onboarding tips based on user behavior
  static generateContextualTips(userRole: UserRole, currentPage: string): Array<{
    icon: string;
    title: string;
    description: string;
    action?: string;
  }> {
    const tips: Array<{
      icon: string;
      title: string;
      description: string;
      action?: string;
    }> = [];

    // Role-specific tips
    if (userRole === 'manager') {
      if (currentPage === 'dashboard') {
        tips.push({
          icon: 'ai-insight',
          title: 'AI Inzichten Bekijken',
          description: 'Ontdek slimme aanbevelingen voor uw verhuurstrategie',
          action: 'view-ai-insights'
        });
      }
      
      if (currentPage === 'inventory') {
        tips.push({
          icon: 'analytics',
          title: 'Utilization Analyseren',
          description: 'Bekijk welke apparatuur het meest wordt verhuurd',
          action: 'view-utilization'
        });
      }
    }

    if (userRole === 'warehouse') {
      if (currentPage === 'inventory') {
        tips.push({
          icon: 'view',
          title: 'QR Codes Scannen',
          description: 'Gebruik de scanner voor snelle status updates',
          action: 'open-scanner'
        });
      }
    }

    if (userRole === 'sales') {
      if (currentPage === 'customers') {
        tips.push({
          icon: 'customers',
          title: 'Klanthistorie Bekijken',
          description: 'Zie eerdere verhuurgeschiedenis voor betere service',
          action: 'view-history'
        });
      }
    }

    return tips;
  }

  // Validate onboarding flow data
  static validateFlow(userRole: UserRole): boolean {
    const flow = this.getFlow(userRole);
    
    if (!flow) return false;
    if (!flow.steps || flow.steps.length === 0) return false;
    
    // Check if all steps have required fields
    return flow.steps.every(step => 
      step.id && 
      step.title && 
      step.description && 
      step.icon && 
      step.type
    );
  }

  // Get accessibility settings
  static getAccessibilitySettings() {
    return {
      keyboardNavigation: onboardingFlows.accessibility.keyboardNavigation,
      screenReaderSupport: onboardingFlows.accessibility.screenReaderSupport,
      highContrast: localStorage.getItem('rentguy-high-contrast') === 'true',
      reducedMotion: localStorage.getItem('rentguy-reduced-motion') === 'true' || 
                     window.matchMedia('(prefers-reduced-motion: reduce)').matches
    };
  }

  // Update accessibility settings
  static updateAccessibilitySettings(settings: {
    highContrast?: boolean;
    reducedMotion?: boolean;
  }) {
    if (settings.highContrast !== undefined) {
      localStorage.setItem('rentguy-high-contrast', settings.highContrast.toString());
    }
    
    if (settings.reducedMotion !== undefined) {
      localStorage.setItem('rentguy-reduced-motion', settings.reducedMotion.toString());
    }
  }
}

// Element highlighting utilities
export class OnboardingHighlight {
  private static highlightedElements = new Set<HTMLElement>();

  static highlight(element: HTMLElement, options: {
    color?: string;
    offset?: number;
    zIndex?: number;
  } = {}) {
    const {
      color = '#00A896',
      offset = 2,
      zIndex = 45
    } = options;

    // Store original styles
    const originalStyles = {
      outline: element.style.outline,
      outlineOffset: element.style.outlineOffset,
      zIndex: element.style.zIndex,
      position: element.style.position
    };

    element.dataset.originalStyles = JSON.stringify(originalStyles);

    // Apply highlight
    element.style.outline = `3px solid ${color}`;
    element.style.outlineOffset = `${offset}px`;
    element.style.zIndex = zIndex.toString();
    
    if (element.style.position === 'static') {
      element.style.position = 'relative';
    }

    this.highlightedElements.add(element);
  }

  static removeHighlight(element: HTMLElement) {
    const originalStylesData = element.dataset.originalStyles;
    
    if (originalStylesData) {
      try {
        const originalStyles = JSON.parse(originalStylesData);
        
        element.style.outline = originalStyles.outline;
        element.style.outlineOffset = originalStyles.outlineOffset;
        element.style.zIndex = originalStyles.zIndex;
        element.style.position = originalStyles.position;
        
        delete element.dataset.originalStyles;
      } catch (error) {
        console.warn('Failed to restore original styles:', error);
      }
    }

    this.highlightedElements.delete(element);
  }

  static removeAllHighlights() {
    this.highlightedElements.forEach(element => {
      this.removeHighlight(element);
    });
    this.highlightedElements.clear();
  }

  static getHighlightedElements(): HTMLElement[] {
    return Array.from(this.highlightedElements);
  }
}

// Export all utilities
export {
  onboardingFlows,
  OnboardingAnalytics as Analytics,
  OnboardingUtils as Utils,
  OnboardingHighlight as Highlight
};
