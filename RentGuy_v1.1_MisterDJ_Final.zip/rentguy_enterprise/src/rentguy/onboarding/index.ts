// Main Onboarding System Export
export { OnboardingOrchestrator, useOnboardingTrigger } from './components/OnboardingOrchestrator';
export { OnboardingStep } from './components/OnboardingStep';
export { OnboardingProgress } from './components/OnboardingProgress';
export { OnboardingOverlay } from './components/OnboardingOverlay';
export { OnboardingTooltip } from './components/OnboardingTooltip';

// Context and State Management
export { 
  OnboardingProvider, 
  useOnboarding, 
  useOnboardingStatus 
} from './utils/OnboardingContext';

// Utilities and Analytics
export {
  OnboardingAnalytics,
  OnboardingUtils,
  OnboardingHighlight,
  onboardingFlows
} from './utils/onboarding-utils';

// Types
export type { 
  OnboardingState, 
  OnboardingActions 
} from './utils/OnboardingContext';

export type { 
  UserRole, 
  StepType 
} from './utils/onboarding-utils';

// Re-export flow data for external use
export { default as onboardingFlowsData } from './data/onboarding-flows.json';
