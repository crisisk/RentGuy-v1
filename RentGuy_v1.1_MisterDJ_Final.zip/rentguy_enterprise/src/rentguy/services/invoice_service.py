"""
Enhanced Invoice Service for RentGuy Enterprise.
Provides PDF generation, bulk download, and advanced invoice management capabilities.
"""

import io
import os
import zipfile
from datetime import datetime, date
from decimal import Decimal
from typing import List, Optional, Dict, Any, Tuple, BinaryIO
from uuid import UUID
import tempfile

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, desc
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.platypus.flowables import HRFlowable
from reportlab.lib.enums import TA_LEFT, TA_RIGHT, TA_CENTER

from ..core.logging import get_logger
from ..models.models import Invoice, User, Rental, PaymentStatus
from ..core.config import get_settings

logger = get_logger(__name__)
settings = get_settings()


class InvoicePDFGenerator:
    """
    Professional PDF generator for RentGuy invoices.
    Creates branded, compliant invoice documents.
    """
    
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _setup_custom_styles(self):
        """Setup custom styles for invoice PDF."""
        # Company header style
        self.styles.add(ParagraphStyle(
            name='CompanyHeader',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#1E40AF'),  # Sevensa Blue
            spaceAfter=6,
            alignment=TA_LEFT
        ))
        
        # Invoice title style
        self.styles.add(ParagraphStyle(
            name='InvoiceTitle',
            parent=self.styles['Heading2'],
            fontSize=18,
            textColor=colors.HexColor('#374151'),
            spaceAfter=12,
            alignment=TA_RIGHT
        ))
        
        # Address style
        self.styles.add(ParagraphStyle(
            name='Address',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#6B7280'),
            spaceAfter=3,
            alignment=TA_LEFT
        ))
        
        # Invoice details style
        self.styles.add(ParagraphStyle(
            name='InvoiceDetails',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.HexColor('#374151'),
            spaceAfter=3,
            alignment=TA_RIGHT
        ))
        
        # Table header style
        self.styles.add(ParagraphStyle(
            name='TableHeader',
            parent=self.styles['Normal'],
            fontSize=10,
            textColor=colors.white,
            alignment=TA_CENTER
        ))
        
        # Footer style
        self.styles.add(ParagraphStyle(
            name='Footer',
            parent=self.styles['Normal'],
            fontSize=8,
            textColor=colors.HexColor('#9CA3AF'),
            alignment=TA_CENTER
        ))
    
    def generate_invoice_pdf(self, invoice: Invoice, output_path: Optional[str] = None) -> bytes:
        """
        Generate a professional PDF for an invoice.
        
        Args:
            invoice: Invoice model instance
            output_path: Optional file path to save PDF
            
        Returns:
            PDF content as bytes
        """
        # Create PDF buffer
        buffer = io.BytesIO()
        
        # Create PDF document
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )
        
        # Build PDF content
        story = []
        
        # Header section
        story.extend(self._build_header(invoice))
        story.append(Spacer(1, 20))
        
        # Invoice details section
        story.extend(self._build_invoice_details(invoice))
        story.append(Spacer(1, 20))
        
        # Customer information section
        story.extend(self._build_customer_info(invoice))
        story.append(Spacer(1, 20))
        
        # Line items section
        story.extend(self._build_line_items(invoice))
        story.append(Spacer(1, 20))
        
        # Totals section
        story.extend(self._build_totals(invoice))
        story.append(Spacer(1, 20))
        
        # Payment information section
        story.extend(self._build_payment_info(invoice))
        story.append(Spacer(1, 20))
        
        # Terms and conditions section
        story.extend(self._build_terms(invoice))
        story.append(Spacer(1, 20))
        
        # Footer section
        story.extend(self._build_footer())
        
        # Build PDF
        doc.build(story)
        
        # Get PDF content
        pdf_content = buffer.getvalue()
        buffer.close()
        
        # Save to file if path provided
        if output_path:
            with open(output_path, 'wb') as f:
                f.write(pdf_content)
        
        logger.info(
            "Invoice PDF generated successfully",
            invoice_id=str(invoice.id),
            invoice_number=invoice.invoice_number,
            file_size=len(pdf_content)
        )
        
        return pdf_content
    
    def _build_header(self, invoice: Invoice) -> List:
        """Build PDF header with company branding."""
        elements = []
        
        # Company name and logo area
        company_name = Paragraph("RentGuy Enterprise", self.styles['CompanyHeader'])
        invoice_title = Paragraph(f"FACTUUR", self.styles['InvoiceTitle'])
        
        # Create header table
        header_data = [
            [company_name, invoice_title]
        ]
        
        header_table = Table(header_data, colWidths=[3*inch, 3*inch])
        header_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (0, 0), 'LEFT'),
            ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        
        elements.append(header_table)
        elements.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor('#1E40AF')))
        
        return elements
    
    def _build_invoice_details(self, invoice: Invoice) -> List:
        """Build invoice details section."""
        elements = []
        
        # Company address (left side)
        company_address = [
            "RentGuy Enterprise B.V.",
            "Hoofdstraat 123",
            "1234 AB Amsterdam",
            "Nederland",
            "",
            "KvK: 12345678",
            "BTW: NL123456789B01",
            "IBAN: NL91 ABNA 0417 1643 00"
        ]
        
        company_info = []
        for line in company_address:
            company_info.append(Paragraph(line, self.styles['Address']))
        
        # Invoice details (right side)
        invoice_details = [
            f"Factuurnummer: {invoice.invoice_number}",
            f"Factuurdatum: {invoice.invoice_date.strftime('%d-%m-%Y')}",
            f"Vervaldatum: {invoice.due_date.strftime('%d-%m-%Y')}",
            f"Betalingstermijn: {(invoice.due_date - invoice.invoice_date).days} dagen",
            "",
            f"Status: {self._get_payment_status_dutch(invoice.payment_status)}"
        ]
        
        if invoice.payment_reference:
            invoice_details.append(f"Betalingsreferentie: {invoice.payment_reference}")
        
        invoice_info = []
        for line in invoice_details:
            invoice_info.append(Paragraph(line, self.styles['InvoiceDetails']))
        
        # Create details table
        details_data = [
            [company_info, invoice_info]
        ]
        
        details_table = Table(details_data, colWidths=[3*inch, 3*inch])
        details_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (0, 0), 'LEFT'),
            ('ALIGN', (1, 0), (1, 0), 'RIGHT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        
        elements.append(details_table)
        
        return elements
    
    def _build_customer_info(self, invoice: Invoice) -> List:
        """Build customer information section."""
        elements = []
        
        # Customer header
        elements.append(Paragraph("Factuuradres:", self.styles['Heading3']))
        elements.append(Spacer(1, 6))
        
        # Customer details
        customer = invoice.user
        customer_lines = []
        
        if customer.company_name:
            customer_lines.append(customer.company_name)
        
        customer_lines.append(f"T.a.v. {customer.full_name}")
        
        if customer.address_line1:
            customer_lines.append(customer.address_line1)
        
        if customer.address_line2:
            customer_lines.append(customer.address_line2)
        
        if customer.city and customer.postal_code:
            customer_lines.append(f"{customer.postal_code} {customer.city}")
        
        if customer.country and customer.country != "Netherlands":
            customer_lines.append(customer.country)
        
        if customer.vat_number:
            customer_lines.append(f"BTW-nummer: {customer.vat_number}")
        
        for line in customer_lines:
            elements.append(Paragraph(line, self.styles['Normal']))
        
        return elements
    
    def _build_line_items(self, invoice: Invoice) -> List:
        """Build line items table."""
        elements = []
        
        # Table header
        elements.append(Paragraph("Specificatie:", self.styles['Heading3']))
        elements.append(Spacer(1, 6))
        
        # Table data
        table_data = [
            [
                Paragraph("Omschrijving", self.styles['TableHeader']),
                Paragraph("Periode", self.styles['TableHeader']),
                Paragraph("Aantal dagen", self.styles['TableHeader']),
                Paragraph("Tarief per dag", self.styles['TableHeader']),
                Paragraph("Bedrag", self.styles['TableHeader'])
            ]
        ]
        
        # Add rental line items
        if invoice.rental:
            rental = invoice.rental
            equipment_name = rental.equipment.name if rental.equipment else "Verhuuritem"
            
            # Calculate rental period
            period_str = f"{rental.start_date.strftime('%d-%m-%Y')} t/m {rental.end_date.strftime('%d-%m-%Y')}"
            days = (rental.end_date - rental.start_date).days
            daily_rate = rental.daily_rate
            line_total = daily_rate * days
            
            table_data.append([
                Paragraph(equipment_name, self.styles['Normal']),
                Paragraph(period_str, self.styles['Normal']),
                Paragraph(str(days), self.styles['Normal']),
                Paragraph(f"€ {daily_rate:.2f}", self.styles['Normal']),
                Paragraph(f"€ {line_total:.2f}", self.styles['Normal'])
            ])
            
            # Add deposit if applicable
            if rental.deposit_amount > 0:
                table_data.append([
                    Paragraph("Borg (terugbetaalbaar)", self.styles['Normal']),
                    Paragraph("-", self.styles['Normal']),
                    Paragraph("1", self.styles['Normal']),
                    Paragraph(f"€ {rental.deposit_amount:.2f}", self.styles['Normal']),
                    Paragraph(f"€ {rental.deposit_amount:.2f}", self.styles['Normal'])
                ])
        else:
            # Generic line item if no rental linked
            table_data.append([
                Paragraph("Verhuurservice", self.styles['Normal']),
                Paragraph("-", self.styles['Normal']),
                Paragraph("1", self.styles['Normal']),
                Paragraph(f"€ {invoice.subtotal:.2f}", self.styles['Normal']),
                Paragraph(f"€ {invoice.subtotal:.2f}", self.styles['Normal'])
            ])
        
        # Create table
        line_items_table = Table(table_data, colWidths=[2.5*inch, 1.5*inch, 0.8*inch, 1*inch, 1*inch])
        line_items_table.setStyle(TableStyle([
            # Header styling
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E40AF')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            
            # Data styling
            ('ALIGN', (2, 1), (-1, -1), 'RIGHT'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 9),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F9FAFB')]),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#E5E7EB')),
        ]))
        
        elements.append(line_items_table)
        
        return elements
    
    def _build_totals(self, invoice: Invoice) -> List:
        """Build totals section."""
        elements = []
        
        # Totals table
        totals_data = [
            ["Subtotaal:", f"€ {invoice.subtotal:.2f}"],
            [f"BTW ({invoice.tax_rate * 100:.0f}%):", f"€ {invoice.tax_amount:.2f}"],
            ["", ""],  # Spacer row
            ["Totaal:", f"€ {invoice.total_amount:.2f}"]
        ]
        
        if invoice.paid_amount > 0:
            totals_data.extend([
                ["Betaald:", f"€ {invoice.paid_amount:.2f}"],
                ["Openstaand:", f"€ {invoice.balance_due:.2f}"]
            ])
        
        totals_table = Table(totals_data, colWidths=[4*inch, 1.5*inch])
        totals_table.setStyle(TableStyle([
            ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
            ('FONTNAME', (0, 0), (-1, -2), 'Helvetica'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('LINEBELOW', (0, -2), (-1, -2), 1, colors.HexColor('#1E40AF')),
            ('TEXTCOLOR', (0, -1), (-1, -1), colors.HexColor('#1E40AF')),
        ]))
        
        elements.append(totals_table)
        
        return elements
    
    def _build_payment_info(self, invoice: Invoice) -> List:
        """Build payment information section."""
        elements = []
        
        elements.append(Paragraph("Betalingsinformatie:", self.styles['Heading3']))
        elements.append(Spacer(1, 6))
        
        payment_info = [
            f"Gelieve het totaalbedrag van € {invoice.total_amount:.2f} over te maken naar:",
            "",
            "IBAN: NL91 ABNA 0417 1643 00",
            "BIC: ABNANL2A",
            "T.n.v.: RentGuy Enterprise B.V.",
            f"Onder vermelding van: {invoice.invoice_number}",
            "",
            f"Betalingstermijn: {(invoice.due_date - invoice.invoice_date).days} dagen"
        ]
        
        if invoice.is_overdue:
            payment_info.extend([
                "",
                "⚠️ Deze factuur is vervallen. Gelieve zo spoedig mogelijk te betalen."
            ])
        
        for line in payment_info:
            style = self.styles['Normal']
            if "⚠️" in line:
                style = ParagraphStyle(
                    name='Warning',
                    parent=self.styles['Normal'],
                    textColor=colors.red,
                    fontName='Helvetica-Bold'
                )
            elements.append(Paragraph(line, style))
        
        return elements
    
    def _build_terms(self, invoice: Invoice) -> List:
        """Build terms and conditions section."""
        elements = []
        
        if invoice.terms_and_conditions:
            elements.append(Paragraph("Voorwaarden:", self.styles['Heading3']))
            elements.append(Spacer(1, 6))
            elements.append(Paragraph(invoice.terms_and_conditions, self.styles['Normal']))
        else:
            # Default terms
            default_terms = [
                "Algemene voorwaarden:",
                "• Betaling dient te geschieden binnen de gestelde betalingstermijn",
                "• Bij te late betaling worden wettelijke rente en incassokosten in rekening gebracht",
                "• Op alle leveringen en diensten zijn onze algemene voorwaarden van toepassing",
                "• Geschillen worden voorgelegd aan de bevoegde rechter te Amsterdam"
            ]
            
            elements.append(Paragraph("Voorwaarden:", self.styles['Heading3']))
            elements.append(Spacer(1, 6))
            
            for term in default_terms:
                elements.append(Paragraph(term, self.styles['Normal']))
        
        return elements
    
    def _build_footer(self) -> List:
        """Build PDF footer."""
        elements = []
        
        elements.append(Spacer(1, 20))
        elements.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#E5E7EB')))
        elements.append(Spacer(1, 6))
        
        footer_text = [
            "RentGuy Enterprise B.V. | Hoofdstraat 123, 1234 AB Amsterdam | www.rentguy.com",
            "KvK: 12345678 | BTW: NL123456789B01 | Tel: +31 20 123 4567 | Email: facturen@rentguy.com"
        ]
        
        for line in footer_text:
            elements.append(Paragraph(line, self.styles['Footer']))
        
        return elements
    
    def _get_payment_status_dutch(self, status: PaymentStatus) -> str:
        """Convert payment status to Dutch."""
        status_map = {
            PaymentStatus.PENDING: "In behandeling",
            PaymentStatus.PAID: "Betaald",
            PaymentStatus.PARTIAL: "Gedeeltelijk betaald",
            PaymentStatus.OVERDUE: "Vervallen",
            PaymentStatus.REFUNDED: "Terugbetaald"
        }
        return status_map.get(status, str(status))


class InvoiceService:
    """
    Enhanced invoice service with PDF generation and bulk download capabilities.
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.pdf_generator = InvoicePDFGenerator()
    
    def generate_invoice_pdf(self, invoice_id: UUID) -> Tuple[bytes, str]:
        """
        Generate PDF for a single invoice.
        
        Args:
            invoice_id: UUID of the invoice
            
        Returns:
            Tuple of (PDF content as bytes, filename)
        """
        invoice = self.db.query(Invoice).filter(Invoice.id == invoice_id).first()
        if not invoice:
            raise ValueError(f"Invoice {invoice_id} not found")
        
        pdf_content = self.pdf_generator.generate_invoice_pdf(invoice)
        filename = f"factuur_{invoice.invoice_number}_{invoice.invoice_date.strftime('%Y%m%d')}.pdf"
        
        logger.info(
            "Invoice PDF generated",
            invoice_id=str(invoice_id),
            invoice_number=invoice.invoice_number,
            filename=filename
        )
        
        return pdf_content, filename
    
    def generate_bulk_invoice_zip(
        self,
        invoice_ids: List[UUID],
        user_id: Optional[UUID] = None,
        date_range: Optional[Tuple[date, date]] = None
    ) -> Tuple[bytes, str]:
        """
        Generate ZIP file containing multiple invoice PDFs.
        
        Args:
            invoice_ids: List of invoice UUIDs to include
            user_id: Optional user ID to filter invoices
            date_range: Optional date range (start_date, end_date) to filter invoices
            
        Returns:
            Tuple of (ZIP content as bytes, filename)
        """
        # Build query
        query = self.db.query(Invoice).filter(Invoice.id.in_(invoice_ids))
        
        if user_id:
            query = query.filter(Invoice.user_id == user_id)
        
        if date_range:
            start_date, end_date = date_range
            query = query.filter(
                and_(
                    Invoice.invoice_date >= start_date,
                    Invoice.invoice_date <= end_date
                )
            )
        
        invoices = query.all()
        
        if not invoices:
            raise ValueError("No invoices found matching criteria")
        
        # Create ZIP file in memory
        zip_buffer = io.BytesIO()
        
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
            for invoice in invoices:
                try:
                    # Generate PDF for each invoice
                    pdf_content = self.pdf_generator.generate_invoice_pdf(invoice)
                    pdf_filename = f"factuur_{invoice.invoice_number}_{invoice.invoice_date.strftime('%Y%m%d')}.pdf"
                    
                    # Add PDF to ZIP
                    zip_file.writestr(pdf_filename, pdf_content)
                    
                except Exception as e:
                    logger.error(
                        "Failed to generate PDF for invoice in bulk download",
                        invoice_id=str(invoice.id),
                        invoice_number=invoice.invoice_number,
                        error=str(e)
                    )
                    # Continue with other invoices
                    continue
        
        zip_content = zip_buffer.getvalue()
        zip_buffer.close()
        
        # Generate ZIP filename
        if len(invoices) == 1:
            zip_filename = f"factuur_{invoices[0].invoice_number}.zip"
        elif user_id:
            user = self.db.query(User).filter(User.id == user_id).first()
            customer_name = user.company_name or user.full_name if user else "klant"
            zip_filename = f"facturen_{customer_name}_{datetime.now().strftime('%Y%m%d')}.zip"
        else:
            zip_filename = f"facturen_bulk_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        
        # Clean filename
        zip_filename = "".join(c for c in zip_filename if c.isalnum() or c in "._-").strip()
        
        logger.info(
            "Bulk invoice ZIP generated",
            invoice_count=len(invoices),
            zip_size=len(zip_content),
            filename=zip_filename
        )
        
        return zip_content, zip_filename
    
    def get_user_invoices_for_download(
        self,
        user_id: UUID,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        payment_status: Optional[List[PaymentStatus]] = None
    ) -> List[Invoice]:
        """
        Get invoices for a user that can be downloaded.
        
        Args:
            user_id: User UUID
            start_date: Optional start date filter
            end_date: Optional end date filter
            payment_status: Optional payment status filter
            
        Returns:
            List of Invoice objects
        """
        query = self.db.query(Invoice).filter(Invoice.user_id == user_id)
        
        if start_date:
            query = query.filter(Invoice.invoice_date >= start_date)
        
        if end_date:
            query = query.filter(Invoice.invoice_date <= end_date)
        
        if payment_status:
            query = query.filter(Invoice.payment_status.in_(payment_status))
        
        invoices = query.order_by(desc(Invoice.invoice_date)).all()
        
        return invoices
    
    def get_invoice_download_summary(self, invoice_ids: List[UUID]) -> Dict[str, Any]:
        """
        Get summary information for invoice download.
        
        Args:
            invoice_ids: List of invoice UUIDs
            
        Returns:
            Dictionary with download summary
        """
        invoices = self.db.query(Invoice).filter(Invoice.id.in_(invoice_ids)).all()
        
        if not invoices:
            return {
                "count": 0,
                "total_amount": Decimal('0.00'),
                "date_range": None,
                "customers": []
            }
        
        # Calculate summary
        total_amount = sum(invoice.total_amount for invoice in invoices)
        
        # Get date range
        invoice_dates = [invoice.invoice_date for invoice in invoices]
        date_range = {
            "start": min(invoice_dates),
            "end": max(invoice_dates)
        }
        
        # Get unique customers
        customers = list(set(
            invoice.user.company_name or invoice.user.full_name 
            for invoice in invoices 
            if invoice.user
        ))
        
        # Payment status breakdown
        status_counts = {}
        for invoice in invoices:
            status = invoice.payment_status
            status_counts[status] = status_counts.get(status, 0) + 1
        
        return {
            "count": len(invoices),
            "total_amount": float(total_amount),
            "date_range": {
                "start": date_range["start"].isoformat(),
                "end": date_range["end"].isoformat()
            },
            "customers": customers,
            "payment_status_breakdown": {
                status.value: count for status, count in status_counts.items()
            },
            "invoice_numbers": [invoice.invoice_number for invoice in invoices]
        }
    
    def create_invoice_download_link(self, invoice_ids: List[UUID], expires_in_hours: int = 24) -> str:
        """
        Create a temporary download link for invoice(s).
        
        Args:
            invoice_ids: List of invoice UUIDs
            expires_in_hours: Link expiration time in hours
            
        Returns:
            Download link token/ID
        """
        import uuid
        import json
        from datetime import timedelta
        
        # Generate unique download token
        download_token = str(uuid.uuid4())
        
        # Store download request (in production, use Redis or database)
        download_data = {
            "invoice_ids": [str(id) for id in invoice_ids],
            "created_at": datetime.utcnow().isoformat(),
            "expires_at": (datetime.utcnow() + timedelta(hours=expires_in_hours)).isoformat(),
            "download_count": 0,
            "max_downloads": 5  # Limit downloads for security
        }
        
        # In production, store this in Redis or a temporary downloads table
        # For now, we'll return the token (implementation depends on caching strategy)
        
        logger.info(
            "Invoice download link created",
            download_token=download_token,
            invoice_count=len(invoice_ids),
            expires_in_hours=expires_in_hours
        )
        
        return download_token
