"""
Enterprise security hardening system for RentGuy.
Provides comprehensive security measures, compliance, and threat protection.
"""

import hashlib
import hmac
import ipaddress
import re
import secrets
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Set, Tuple
from urllib.parse import urlparse

from fastapi import Request, HTTPException, status
from pydantic import BaseModel, validator
import bcrypt
import jwt
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

from .config import settings
from .logging import audit_logger, get_logger

logger = get_logger(__name__)


class SecurityPolicy(BaseModel):
    """Security policy configuration."""
    
    # Password policy
    min_password_length: int = 12
    max_password_length: int = 128
    require_uppercase: bool = True
    require_lowercase: bool = True
    require_digits: bool = True
    require_special_chars: bool = True
    password_history_count: int = 12
    password_expiry_days: int = 90
    
    # Account lockout policy
    max_failed_attempts: int = 5
    lockout_duration_minutes: int = 30
    lockout_threshold_minutes: int = 15
    
    # Session policy
    session_timeout_minutes: int = 30
    max_concurrent_sessions: int = 3
    require_session_renewal: bool = True
    
    # IP restrictions
    allowed_ip_ranges: List[str] = []
    blocked_ip_ranges: List[str] = []
    enable_geo_blocking: bool = False
    allowed_countries: List[str] = ["NL", "BE", "DE", "FR", "GB"]
    
    # Rate limiting
    api_rate_limit_per_minute: int = 100
    login_rate_limit_per_hour: int = 10
    password_reset_rate_limit_per_day: int = 3
    
    # Content security
    max_file_size_mb: int = 10
    allowed_file_types: List[str] = ["pdf", "jpg", "jpeg", "png", "doc", "docx"]
    scan_uploads_for_malware: bool = True
    
    # Encryption requirements
    require_https: bool = True
    min_tls_version: str = "1.2"
    require_certificate_pinning: bool = False
    
    # Compliance settings
    enable_gdpr_compliance: bool = True
    data_retention_days: int = 2555  # 7 years
    require_consent_tracking: bool = True
    
    @validator('allowed_ip_ranges', 'blocked_ip_ranges')
    def validate_ip_ranges(cls, v):
        """Validate IP ranges format."""
        for ip_range in v:
            try:
                ipaddress.ip_network(ip_range, strict=False)
            except ValueError:
                raise ValueError(f"Invalid IP range: {ip_range}")
        return v


class ThreatDetection:
    """Advanced threat detection and prevention system."""
    
    def __init__(self):
        self.suspicious_patterns = self._load_suspicious_patterns()
        self.threat_scores = {}
        self.blocked_ips = set()
        self.rate_limiters = {}
    
    def _load_suspicious_patterns(self) -> Dict[str, List[str]]:
        """Load suspicious patterns for threat detection."""
        return {
            "sql_injection": [
                r"(\bunion\b.*\bselect\b)",
                r"(\bselect\b.*\bfrom\b.*\bwhere\b)",
                r"(\bdrop\b.*\btable\b)",
                r"(\binsert\b.*\binto\b)",
                r"(\bupdate\b.*\bset\b)",
                r"(\bdelete\b.*\bfrom\b)",
                r"(\bor\b.*1\s*=\s*1)",
                r"(\band\b.*1\s*=\s*1)",
                r"(\bexec\b.*\bxp_)",
                r"(\bsp_executesql\b)"
            ],
            "xss": [
                r"<script[^>]*>.*?</script>",
                r"javascript:",
                r"on\w+\s*=",
                r"<iframe[^>]*>",
                r"<object[^>]*>",
                r"<embed[^>]*>",
                r"<link[^>]*>",
                r"<meta[^>]*>"
            ],
            "path_traversal": [
                r"\.\./",
                r"\.\.\\",
                r"%2e%2e%2f",
                r"%2e%2e\\",
                r"..%2f",
                r"..%5c"
            ],
            "command_injection": [
                r";\s*(rm|del|format|shutdown)",
                r";\s*(cat|type|more|less)",
                r";\s*(ps|tasklist|netstat)",
                r";\s*(wget|curl|nc|telnet)",
                r"\|\s*(rm|del|format|shutdown)",
                r"&\s*(rm|del|format|shutdown)"
            ]
        }
    
    def analyze_request(self, request: Request) -> Dict[str, Any]:
        """Analyze request for potential threats."""
        threat_score = 0
        detected_threats = []
        
        # Get request data
        url = str(request.url)
        method = request.method
        headers = dict(request.headers)
        client_ip = self._get_client_ip(request)
        user_agent = headers.get("user-agent", "")
        
        # Check IP reputation
        if self._is_suspicious_ip(client_ip):
            threat_score += 50
            detected_threats.append("suspicious_ip")
        
        # Check for suspicious patterns in URL
        for threat_type, patterns in self.suspicious_patterns.items():
            for pattern in patterns:
                if re.search(pattern, url, re.IGNORECASE):
                    threat_score += 30
                    detected_threats.append(f"url_{threat_type}")
        
        # Check User-Agent
        if self._is_suspicious_user_agent(user_agent):
            threat_score += 20
            detected_threats.append("suspicious_user_agent")
        
        # Check for automated requests
        if self._is_automated_request(headers):
            threat_score += 15
            detected_threats.append("automated_request")
        
        # Check rate limiting
        if self._check_rate_limit(client_ip, method):
            threat_score += 40
            detected_threats.append("rate_limit_exceeded")
        
        # Store threat score
        self.threat_scores[client_ip] = {
            "score": threat_score,
            "threats": detected_threats,
            "timestamp": datetime.utcnow(),
            "request_count": self.threat_scores.get(client_ip, {}).get("request_count", 0) + 1
        }
        
        return {
            "threat_score": threat_score,
            "detected_threats": detected_threats,
            "action": self._determine_action(threat_score),
            "client_ip": client_ip
        }
    
    def _get_client_ip(self, request: Request) -> str:
        """Get real client IP address."""
        # Check for forwarded headers
        forwarded_for = request.headers.get("x-forwarded-for")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        
        real_ip = request.headers.get("x-real-ip")
        if real_ip:
            return real_ip
        
        return request.client.host if request.client else "unknown"
    
    def _is_suspicious_ip(self, ip: str) -> bool:
        """Check if IP is suspicious."""
        if ip in self.blocked_ips:
            return True
        
        # Check against known malicious IP ranges
        try:
            ip_obj = ipaddress.ip_address(ip)
            
            # Check for private/local IPs in production
            if settings.is_production and ip_obj.is_private:
                return True
            
            # Check for Tor exit nodes (simplified check)
            if str(ip).startswith(("185.220.", "199.87.", "176.10.")):
                return True
                
        except ValueError:
            return True  # Invalid IP is suspicious
        
        return False
    
    def _is_suspicious_user_agent(self, user_agent: str) -> bool:
        """Check if User-Agent is suspicious."""
        if not user_agent:
            return True
        
        suspicious_agents = [
            "sqlmap", "nikto", "nmap", "masscan", "zap", "burp",
            "python-requests", "curl", "wget", "bot", "crawler",
            "scanner", "exploit", "hack"
        ]
        
        user_agent_lower = user_agent.lower()
        return any(agent in user_agent_lower for agent in suspicious_agents)
    
    def _is_automated_request(self, headers: Dict[str, str]) -> bool:
        """Check if request appears to be automated."""
        # Missing common browser headers
        browser_headers = ["accept", "accept-language", "accept-encoding"]
        missing_headers = sum(1 for header in browser_headers if header not in headers)
        
        if missing_headers >= 2:
            return True
        
        # Check for automation indicators
        automation_indicators = [
            "selenium", "phantomjs", "headless", "automation",
            "webdriver", "robot", "spider"
        ]
        
        user_agent = headers.get("user-agent", "").lower()
        return any(indicator in user_agent for indicator in automation_indicators)
    
    def _check_rate_limit(self, ip: str, method: str) -> bool:
        """Check if request exceeds rate limits."""
        now = time.time()
        key = f"{ip}:{method}"
        
        if key not in self.rate_limiters:
            self.rate_limiters[key] = []
        
        # Clean old entries
        self.rate_limiters[key] = [
            timestamp for timestamp in self.rate_limiters[key]
            if now - timestamp < 60  # 1 minute window
        ]
        
        # Check rate limit
        if len(self.rate_limiters[key]) >= 100:  # 100 requests per minute
            return True
        
        # Add current request
        self.rate_limiters[key].append(now)
        return False
    
    def _determine_action(self, threat_score: int) -> str:
        """Determine action based on threat score."""
        if threat_score >= 100:
            return "block"
        elif threat_score >= 50:
            return "challenge"
        elif threat_score >= 30:
            return "monitor"
        else:
            return "allow"
    
    def block_ip(self, ip: str, reason: str, duration_hours: int = 24):
        """Block an IP address."""
        self.blocked_ips.add(ip)
        
        audit_logger.log_security_event(
            event="ip_blocked",
            details={
                "ip": ip,
                "reason": reason,
                "duration_hours": duration_hours
            },
            severity="warning"
        )
    
    def unblock_ip(self, ip: str):
        """Unblock an IP address."""
        self.blocked_ips.discard(ip)
        
        audit_logger.log_security_event(
            event="ip_unblocked",
            details={"ip": ip}
        )


class DataProtection:
    """Data protection and privacy compliance system."""
    
    def __init__(self):
        self.encryption_key = self._get_or_create_encryption_key()
        self.cipher = Fernet(self.encryption_key)
        self.pii_patterns = self._load_pii_patterns()
    
    def _get_or_create_encryption_key(self) -> bytes:
        """Get or create encryption key for data protection."""
        # In production, this should be stored securely
        key_material = settings.secret_key.encode()
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b'rentguy_salt',  # Use a proper salt in production
            iterations=100000,
        )
        key = kdf.derive(key_material)
        return Fernet.generate_key()  # Use derived key in production
    
    def _load_pii_patterns(self) -> Dict[str, str]:
        """Load PII detection patterns."""
        return {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "phone": r'\b(?:\+31|0031|0)[1-9][0-9]{8}\b',  # Dutch phone numbers
            "ssn": r'\b\d{9}\b',  # BSN (Dutch social security number)
            "iban": r'\b[A-Z]{2}[0-9]{2}[A-Z0-9]{4}[0-9]{7}([A-Z0-9]?){0,16}\b',
            "credit_card": r'\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3[0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})\b'
        }
    
    def encrypt_sensitive_data(self, data: str) -> str:
        """Encrypt sensitive data."""
        if not data:
            return data
        
        encrypted = self.cipher.encrypt(data.encode())
        return encrypted.decode()
    
    def decrypt_sensitive_data(self, encrypted_data: str) -> str:
        """Decrypt sensitive data."""
        if not encrypted_data:
            return encrypted_data
        
        try:
            decrypted = self.cipher.decrypt(encrypted_data.encode())
            return decrypted.decode()
        except Exception as e:
            logger.error(f"Failed to decrypt data: {e}")
            return ""
    
    def detect_pii(self, text: str) -> Dict[str, List[str]]:
        """Detect PII in text."""
        detected_pii = {}
        
        for pii_type, pattern in self.pii_patterns.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                detected_pii[pii_type] = matches
        
        return detected_pii
    
    def anonymize_data(self, data: str, pii_types: List[str] = None) -> str:
        """Anonymize PII in data."""
        if not data:
            return data
        
        anonymized = data
        pii_types = pii_types or list(self.pii_patterns.keys())
        
        for pii_type in pii_types:
            if pii_type in self.pii_patterns:
                pattern = self.pii_patterns[pii_type]
                anonymized = re.sub(pattern, f"[{pii_type.upper()}_REDACTED]", anonymized, flags=re.IGNORECASE)
        
        return anonymized
    
    def hash_pii(self, data: str, salt: str = None) -> str:
        """Hash PII for pseudonymization."""
        if not data:
            return data
        
        salt = salt or secrets.token_hex(16)
        salted_data = f"{data}{salt}"
        
        return hashlib.sha256(salted_data.encode()).hexdigest()
    
    def generate_consent_token(self, user_id: str, purposes: List[str]) -> str:
        """Generate consent token for GDPR compliance."""
        consent_data = {
            "user_id": user_id,
            "purposes": purposes,
            "timestamp": datetime.utcnow().isoformat(),
            "version": "1.0"
        }
        
        token = jwt.encode(consent_data, settings.secret_key, algorithm="HS256")
        
        audit_logger.log_user_action(
            action="consent_granted",
            user_id=user_id,
            details={
                "purposes": purposes,
                "token": token[:20] + "..."  # Log partial token
            }
        )
        
        return token
    
    def verify_consent(self, token: str) -> Dict[str, Any]:
        """Verify consent token."""
        try:
            consent_data = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
            return consent_data
        except jwt.InvalidTokenError:
            return {}


class ComplianceManager:
    """Compliance management for various regulations."""
    
    def __init__(self):
        self.gdpr_processor = GDPRProcessor()
        self.audit_trail = []
    
    def log_data_processing(self, user_id: str, data_type: str, 
                          purpose: str, legal_basis: str):
        """Log data processing activity for compliance."""
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "user_id": user_id,
            "data_type": data_type,
            "purpose": purpose,
            "legal_basis": legal_basis,
            "processor": "RentGuy Enterprise"
        }
        
        self.audit_trail.append(entry)
        
        audit_logger.log_data_access(
            operation="process",
            table="compliance_log",
            user_id=user_id,
            fields=[data_type]
        )
    
    def handle_data_subject_request(self, request_type: str, user_id: str) -> Dict[str, Any]:
        """Handle data subject requests (GDPR Article 15-22)."""
        if request_type == "access":
            return self._handle_access_request(user_id)
        elif request_type == "rectification":
            return self._handle_rectification_request(user_id)
        elif request_type == "erasure":
            return self._handle_erasure_request(user_id)
        elif request_type == "portability":
            return self._handle_portability_request(user_id)
        else:
            return {"error": "Unknown request type"}
    
    def _handle_access_request(self, user_id: str) -> Dict[str, Any]:
        """Handle data access request (GDPR Article 15)."""
        # This would collect all data for the user
        return {
            "request_type": "access",
            "user_id": user_id,
            "status": "processed",
            "data_categories": ["profile", "rentals", "payments", "communications"],
            "processing_purposes": ["service_provision", "contract_fulfillment", "legal_compliance"],
            "retention_period": "7 years",
            "recipients": ["internal_staff", "payment_processors"],
            "rights": ["rectification", "erasure", "portability", "objection"]
        }
    
    def _handle_rectification_request(self, user_id: str) -> Dict[str, Any]:
        """Handle data rectification request (GDPR Article 16)."""
        return {
            "request_type": "rectification",
            "user_id": user_id,
            "status": "pending_verification",
            "message": "Please provide correct information to update your data"
        }
    
    def _handle_erasure_request(self, user_id: str) -> Dict[str, Any]:
        """Handle data erasure request (GDPR Article 17)."""
        return {
            "request_type": "erasure",
            "user_id": user_id,
            "status": "under_review",
            "message": "Request is being reviewed for legal obligations and legitimate interests"
        }
    
    def _handle_portability_request(self, user_id: str) -> Dict[str, Any]:
        """Handle data portability request (GDPR Article 20)."""
        return {
            "request_type": "portability",
            "user_id": user_id,
            "status": "processed",
            "format": "JSON",
            "download_link": f"/api/v1/users/{user_id}/export"
        }


class GDPRProcessor:
    """GDPR-specific processing and compliance."""
    
    def __init__(self):
        self.lawful_bases = [
            "consent",
            "contract",
            "legal_obligation",
            "vital_interests",
            "public_task",
            "legitimate_interests"
        ]
    
    def validate_processing(self, purpose: str, legal_basis: str, 
                          data_categories: List[str]) -> bool:
        """Validate data processing against GDPR requirements."""
        if legal_basis not in self.lawful_bases:
            return False
        
        # Check purpose limitation
        if not self._is_purpose_compatible(purpose):
            return False
        
        # Check data minimization
        if not self._is_data_minimized(data_categories, purpose):
            return False
        
        return True
    
    def _is_purpose_compatible(self, purpose: str) -> bool:
        """Check if purpose is compatible with original collection purpose."""
        compatible_purposes = [
            "service_provision",
            "contract_fulfillment",
            "legal_compliance",
            "fraud_prevention",
            "security"
        ]
        return purpose in compatible_purposes
    
    def _is_data_minimized(self, data_categories: List[str], purpose: str) -> bool:
        """Check if data collection is minimized for the purpose."""
        purpose_data_map = {
            "service_provision": ["profile", "contact", "preferences"],
            "contract_fulfillment": ["profile", "contact", "payment", "rental_history"],
            "legal_compliance": ["profile", "contact", "transactions"],
            "fraud_prevention": ["profile", "contact", "behavior", "device_info"],
            "security": ["access_logs", "security_events"]
        }
        
        allowed_categories = purpose_data_map.get(purpose, [])
        return all(category in allowed_categories for category in data_categories)


class SecurityHardeningManager:
    """Main security hardening manager."""
    
    def __init__(self):
        self.policy = SecurityPolicy()
        self.threat_detection = ThreatDetection()
        self.data_protection = DataProtection()
        self.compliance_manager = ComplianceManager()
        self.security_headers = self._get_security_headers()
    
    def _get_security_headers(self) -> Dict[str, str]:
        """Get security headers for HTTP responses."""
        return {
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "X-XSS-Protection": "1; mode=block",
            "Strict-Transport-Security": "max-age=31536000; includeSubDomains; preload",
            "Content-Security-Policy": (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: https:; "
                "font-src 'self' https:; "
                "connect-src 'self' https:; "
                "frame-ancestors 'none';"
            ),
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "Permissions-Policy": (
                "geolocation=(), "
                "microphone=(), "
                "camera=(), "
                "payment=(), "
                "usb=(), "
                "magnetometer=(), "
                "gyroscope=(), "
                "speaker=()"
            )
        }
    
    async def process_request(self, request: Request) -> Dict[str, Any]:
        """Process incoming request through security pipeline."""
        # Threat detection
        threat_analysis = self.threat_detection.analyze_request(request)
        
        # IP validation
        client_ip = threat_analysis["client_ip"]
        if not self._is_ip_allowed(client_ip):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied from this IP address"
            )
        
        # Rate limiting
        if threat_analysis["action"] == "block":
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Request blocked due to security policy"
            )
        
        # Log security event
        if threat_analysis["threat_score"] > 0:
            audit_logger.log_security_event(
                event="threat_detected",
                details=threat_analysis,
                ip_address=client_ip,
                severity="warning" if threat_analysis["threat_score"] < 50 else "error"
            )
        
        return threat_analysis
    
    def _is_ip_allowed(self, ip: str) -> bool:
        """Check if IP is allowed based on policy."""
        try:
            ip_obj = ipaddress.ip_address(ip)
            
            # Check blocked ranges
            for blocked_range in self.policy.blocked_ip_ranges:
                if ip_obj in ipaddress.ip_network(blocked_range):
                    return False
            
            # Check allowed ranges (if configured)
            if self.policy.allowed_ip_ranges:
                for allowed_range in self.policy.allowed_ip_ranges:
                    if ip_obj in ipaddress.ip_network(allowed_range):
                        return True
                return False  # Not in any allowed range
            
            return True  # No restrictions
            
        except ValueError:
            return False  # Invalid IP
    
    def get_security_headers(self) -> Dict[str, str]:
        """Get security headers for responses."""
        return self.security_headers.copy()
    
    def validate_file_upload(self, filename: str, content: bytes) -> bool:
        """Validate file upload for security."""
        # Check file extension
        file_ext = filename.split('.')[-1].lower()
        if file_ext not in self.policy.allowed_file_types:
            return False
        
        # Check file size
        if len(content) > self.policy.max_file_size_mb * 1024 * 1024:
            return False
        
        # Basic malware detection (simplified)
        if self.policy.scan_uploads_for_malware:
            return self._scan_for_malware(content)
        
        return True
    
    def _scan_for_malware(self, content: bytes) -> bool:
        """Basic malware scanning (simplified implementation)."""
        # Check for suspicious patterns
        suspicious_patterns = [
            b'<script',
            b'javascript:',
            b'vbscript:',
            b'onload=',
            b'onerror=',
            b'<?php',
            b'<%',
            b'eval(',
            b'exec(',
            b'system(',
            b'shell_exec('
        ]
        
        content_lower = content.lower()
        for pattern in suspicious_patterns:
            if pattern in content_lower:
                return False
        
        return True


# Global security hardening manager
security_hardening = SecurityHardeningManager()

# Convenience functions
def get_threat_detection() -> ThreatDetection:
    """Get the global threat detection system."""
    return security_hardening.threat_detection

def get_data_protection() -> DataProtection:
    """Get the global data protection system."""
    return security_hardening.data_protection

def get_compliance_manager() -> ComplianceManager:
    """Get the global compliance manager."""
    return security_hardening.compliance_manager
