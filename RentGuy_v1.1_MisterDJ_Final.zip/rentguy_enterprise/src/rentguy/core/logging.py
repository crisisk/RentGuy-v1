"""
Enterprise-grade structured logging system for RentGuy.
Provides comprehensive logging with structured output, correlation IDs, and observability.
"""

import json
import logging
import logging.handlers
import sys
import traceback
import uuid
from contextvars import ContextVar
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Union

import structlog
from pythonjsonlogger import jsonlogger

from .config import settings


# Context variables for request correlation
correlation_id: ContextVar[Optional[str]] = ContextVar("correlation_id", default=None)
user_id: ContextVar[Optional[str]] = ContextVar("user_id", default=None)
request_id: ContextVar[Optional[str]] = ContextVar("request_id", default=None)


class CorrelationIDProcessor:
    """Processor to add correlation ID to log records."""
    
    def __call__(self, logger, method_name, event_dict):
        """Add correlation context to log records."""
        event_dict["correlation_id"] = correlation_id.get()
        event_dict["user_id"] = user_id.get()
        event_dict["request_id"] = request_id.get()
        return event_dict


class TimestampProcessor:
    """Processor to add ISO timestamp to log records."""
    
    def __call__(self, logger, method_name, event_dict):
        """Add ISO timestamp to log records."""
        event_dict["timestamp"] = datetime.utcnow().isoformat() + "Z"
        return event_dict


class ServiceInfoProcessor:
    """Processor to add service information to log records."""
    
    def __call__(self, logger, method_name, event_dict):
        """Add service information to log records."""
        event_dict["service"] = settings.app_name
        event_dict["version"] = settings.app_version
        event_dict["environment"] = settings.environment
        return event_dict


class SecurityLogProcessor:
    """Processor to handle security-sensitive log data."""
    
    SENSITIVE_FIELDS = {
        "password", "token", "secret", "key", "authorization",
        "cookie", "session", "credit_card", "ssn", "email"
    }
    
    def __call__(self, logger, method_name, event_dict):
        """Sanitize sensitive information from log records."""
        return self._sanitize_dict(event_dict)
    
    def _sanitize_dict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Recursively sanitize sensitive fields in dictionary."""
        sanitized = {}
        
        for key, value in data.items():
            if isinstance(value, dict):
                sanitized[key] = self._sanitize_dict(value)
            elif isinstance(value, list):
                sanitized[key] = [
                    self._sanitize_dict(item) if isinstance(item, dict) else item
                    for item in value
                ]
            elif any(sensitive in key.lower() for sensitive in self.SENSITIVE_FIELDS):
                sanitized[key] = "[REDACTED]"
            else:
                sanitized[key] = value
        
        return sanitized


class PerformanceLogProcessor:
    """Processor to add performance metrics to log records."""
    
    def __call__(self, logger, method_name, event_dict):
        """Add performance context to log records."""
        # Add memory usage, CPU time, etc. if available
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        event_dict["memory_usage_mb"] = round(process.memory_info().rss / 1024 / 1024, 2)
        event_dict["cpu_percent"] = process.cpu_percent()
        
        return event_dict


class CustomJSONFormatter(jsonlogger.JsonFormatter):
    """Custom JSON formatter with additional fields."""
    
    def add_fields(self, log_record, record, message_dict):
        """Add custom fields to log record."""
        super().add_fields(log_record, record, message_dict)
        
        # Add standard fields
        log_record["level"] = record.levelname
        log_record["logger"] = record.name
        log_record["module"] = record.module
        log_record["function"] = record.funcName
        log_record["line"] = record.lineno
        
        # Add exception information if present
        if record.exc_info:
            log_record["exception"] = {
                "type": record.exc_info[0].__name__,
                "message": str(record.exc_info[1]),
                "traceback": traceback.format_exception(*record.exc_info)
            }


class LoggingManager:
    """Central logging management for the application."""
    
    def __init__(self):
        self.configured = False
        self._setup_logging()
    
    def _setup_logging(self):
        """Setup structured logging configuration."""
        if self.configured:
            return
        
        # Configure structlog
        structlog.configure(
            processors=[
                structlog.contextvars.merge_contextvars,
                CorrelationIDProcessor(),
                TimestampProcessor(),
                ServiceInfoProcessor(),
                SecurityLogProcessor(),
                PerformanceLogProcessor(),
                structlog.processors.add_log_level,
                structlog.processors.StackInfoRenderer(),
                structlog.dev.set_exc_info,
                structlog.processors.JSONRenderer() if settings.log_format == "json" 
                else structlog.dev.ConsoleRenderer(colors=True)
            ],
            wrapper_class=structlog.make_filtering_bound_logger(
                getattr(logging, settings.log_level)
            ),
            logger_factory=structlog.PrintLoggerFactory(),
            cache_logger_on_first_use=True,
        )
        
        # Configure standard logging
        self._configure_standard_logging()
        
        self.configured = True
    
    def _configure_standard_logging(self):
        """Configure standard Python logging."""
        # Create log directory if it doesn't exist
        if settings.log_file:
            log_path = Path(settings.log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Root logger configuration
        root_logger = logging.getLogger()
        root_logger.setLevel(getattr(logging, settings.log_level))
        
        # Remove existing handlers
        for handler in root_logger.handlers[:]:
            root_logger.removeHandler(handler)
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(getattr(logging, settings.log_level))
        
        if settings.log_format == "json":
            console_formatter = CustomJSONFormatter(
                fmt="%(timestamp)s %(level)s %(name)s %(message)s"
            )
        else:
            console_formatter = logging.Formatter(
                fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S"
            )
        
        console_handler.setFormatter(console_formatter)
        root_logger.addHandler(console_handler)
        
        # File handler (if configured)
        if settings.log_file:
            file_handler = logging.handlers.RotatingFileHandler(
                filename=settings.log_file,
                maxBytes=settings.log_max_size,
                backupCount=settings.log_backup_count,
                encoding="utf-8"
            )
            file_handler.setLevel(getattr(logging, settings.log_level))
            
            if settings.log_format == "json":
                file_formatter = CustomJSONFormatter(
                    fmt="%(timestamp)s %(level)s %(name)s %(message)s"
                )
            else:
                file_formatter = logging.Formatter(
                    fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S"
                )
            
            file_handler.setFormatter(file_formatter)
            root_logger.addHandler(file_handler)
        
        # Suppress noisy loggers in production
        if settings.is_production:
            logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
            logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
    
    def get_logger(self, name: str) -> structlog.BoundLogger:
        """Get a structured logger instance."""
        return structlog.get_logger(name)
    
    def set_correlation_id(self, correlation_id_value: Optional[str] = None) -> str:
        """Set correlation ID for request tracking."""
        if correlation_id_value is None:
            correlation_id_value = str(uuid.uuid4())
        
        correlation_id.set(correlation_id_value)
        return correlation_id_value
    
    def set_user_context(self, user_id_value: Optional[str] = None) -> None:
        """Set user context for logging."""
        user_id.set(user_id_value)
    
    def set_request_context(self, request_id_value: Optional[str] = None) -> None:
        """Set request context for logging."""
        if request_id_value is None:
            request_id_value = str(uuid.uuid4())
        
        request_id.set(request_id_value)
    
    def clear_context(self) -> None:
        """Clear all logging context."""
        correlation_id.set(None)
        user_id.set(None)
        request_id.set(None)


class AuditLogger:
    """Specialized logger for audit events."""
    
    def __init__(self):
        self.logger = structlog.get_logger("audit")
    
    def log_user_action(
        self,
        action: str,
        user_id: str,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None
    ) -> None:
        """Log user action for audit purposes."""
        self.logger.info(
            "User action performed",
            action=action,
            user_id=user_id,
            resource_type=resource_type,
            resource_id=resource_id,
            details=details or {},
            ip_address=ip_address,
            user_agent=user_agent,
            event_type="user_action"
        )
    
    def log_system_event(
        self,
        event: str,
        component: str,
        details: Optional[Dict[str, Any]] = None,
        severity: str = "info"
    ) -> None:
        """Log system event for audit purposes."""
        log_method = getattr(self.logger, severity.lower(), self.logger.info)
        log_method(
            "System event occurred",
            event=event,
            component=component,
            details=details or {},
            event_type="system_event"
        )
    
    def log_security_event(
        self,
        event: str,
        user_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        severity: str = "warning"
    ) -> None:
        """Log security event for audit purposes."""
        log_method = getattr(self.logger, severity.lower(), self.logger.warning)
        log_method(
            "Security event detected",
            event=event,
            user_id=user_id,
            ip_address=ip_address,
            details=details or {},
            event_type="security_event"
        )
    
    def log_data_access(
        self,
        operation: str,
        table: str,
        user_id: str,
        record_id: Optional[str] = None,
        fields: Optional[list] = None
    ) -> None:
        """Log data access for compliance."""
        self.logger.info(
            "Data access performed",
            operation=operation,
            table=table,
            user_id=user_id,
            record_id=record_id,
            fields=fields or [],
            event_type="data_access"
        )


class PerformanceLogger:
    """Specialized logger for performance monitoring."""
    
    def __init__(self):
        self.logger = structlog.get_logger("performance")
    
    def log_request_timing(
        self,
        method: str,
        path: str,
        duration_ms: float,
        status_code: int,
        user_id: Optional[str] = None
    ) -> None:
        """Log request timing information."""
        self.logger.info(
            "Request completed",
            method=method,
            path=path,
            duration_ms=duration_ms,
            status_code=status_code,
            user_id=user_id,
            event_type="request_timing"
        )
    
    def log_database_query(
        self,
        query_type: str,
        table: str,
        duration_ms: float,
        rows_affected: Optional[int] = None
    ) -> None:
        """Log database query performance."""
        self.logger.info(
            "Database query executed",
            query_type=query_type,
            table=table,
            duration_ms=duration_ms,
            rows_affected=rows_affected,
            event_type="database_query"
        )
    
    def log_external_api_call(
        self,
        service: str,
        endpoint: str,
        duration_ms: float,
        status_code: int,
        success: bool
    ) -> None:
        """Log external API call performance."""
        self.logger.info(
            "External API call completed",
            service=service,
            endpoint=endpoint,
            duration_ms=duration_ms,
            status_code=status_code,
            success=success,
            event_type="external_api_call"
        )


class ErrorLogger:
    """Specialized logger for error tracking and alerting."""
    
    def __init__(self):
        self.logger = structlog.get_logger("error")
    
    def log_application_error(
        self,
        error: Exception,
        context: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        request_path: Optional[str] = None
    ) -> None:
        """Log application error with context."""
        self.logger.error(
            "Application error occurred",
            error_type=type(error).__name__,
            error_message=str(error),
            context=context or {},
            user_id=user_id,
            request_path=request_path,
            event_type="application_error",
            exc_info=True
        )
    
    def log_validation_error(
        self,
        field: str,
        value: Any,
        error_message: str,
        user_id: Optional[str] = None
    ) -> None:
        """Log validation error."""
        self.logger.warning(
            "Validation error occurred",
            field=field,
            value=str(value)[:100],  # Truncate long values
            error_message=error_message,
            user_id=user_id,
            event_type="validation_error"
        )
    
    def log_business_rule_violation(
        self,
        rule: str,
        details: Dict[str, Any],
        user_id: Optional[str] = None
    ) -> None:
        """Log business rule violation."""
        self.logger.warning(
            "Business rule violation",
            rule=rule,
            details=details,
            user_id=user_id,
            event_type="business_rule_violation"
        )


# Global logging instances
logging_manager = LoggingManager()
audit_logger = AuditLogger()
performance_logger = PerformanceLogger()
error_logger = ErrorLogger()

# Convenience function to get logger
def get_logger(name: str) -> structlog.BoundLogger:
    """Get a structured logger instance."""
    return logging_manager.get_logger(name)


# Context managers for logging
class LoggingContext:
    """Context manager for setting logging context."""
    
    def __init__(
        self,
        correlation_id_value: Optional[str] = None,
        user_id_value: Optional[str] = None,
        request_id_value: Optional[str] = None
    ):
        self.correlation_id_value = correlation_id_value
        self.user_id_value = user_id_value
        self.request_id_value = request_id_value
        self.previous_correlation_id = None
        self.previous_user_id = None
        self.previous_request_id = None
    
    def __enter__(self):
        """Enter logging context."""
        self.previous_correlation_id = correlation_id.get()
        self.previous_user_id = user_id.get()
        self.previous_request_id = request_id.get()
        
        if self.correlation_id_value:
            correlation_id.set(self.correlation_id_value)
        if self.user_id_value:
            user_id.set(self.user_id_value)
        if self.request_id_value:
            request_id.set(self.request_id_value)
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit logging context."""
        correlation_id.set(self.previous_correlation_id)
        user_id.set(self.previous_user_id)
        request_id.set(self.previous_request_id)


# Decorator for automatic performance logging
def log_performance(operation_name: str):
    """Decorator to automatically log function performance."""
    def decorator(func):
        def wrapper(*args, **kwargs):
            import time
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                duration_ms = (time.time() - start_time) * 1000
                
                performance_logger.logger.info(
                    "Operation completed",
                    operation=operation_name,
                    duration_ms=round(duration_ms, 2),
                    success=True,
                    event_type="operation_performance"
                )
                
                return result
            except Exception as e:
                duration_ms = (time.time() - start_time) * 1000
                
                performance_logger.logger.error(
                    "Operation failed",
                    operation=operation_name,
                    duration_ms=round(duration_ms, 2),
                    success=False,
                    error=str(e),
                    event_type="operation_performance"
                )
                raise
        
        return wrapper
    return decorator
