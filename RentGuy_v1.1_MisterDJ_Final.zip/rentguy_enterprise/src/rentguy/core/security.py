"""
Enterprise-grade security system for RentGuy.
Provides comprehensive authentication, authorization, and security features.
"""

import hashlib
import secrets
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union

import bcrypt
import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from passlib.context import CryptContext
from pydantic import BaseModel, EmailStr

from .config import settings
from .logging import audit_logger, get_logger

logger = get_logger(__name__)


class TokenType(str):
    """Token type enumeration."""
    ACCESS = "access"
    REFRESH = "refresh"
    RESET = "reset"
    VERIFICATION = "verification"


class UserRole(str):
    """User role enumeration."""
    ADMIN = "admin"
    MANAGER = "manager"
    EMPLOYEE = "employee"
    CLIENT = "client"
    GUEST = "guest"


class Permission(str):
    """Permission enumeration."""
    # User management
    USER_CREATE = "user:create"
    USER_READ = "user:read"
    USER_UPDATE = "user:update"
    USER_DELETE = "user:delete"
    
    # Equipment management
    EQUIPMENT_CREATE = "equipment:create"
    EQUIPMENT_READ = "equipment:read"
    EQUIPMENT_UPDATE = "equipment:update"
    EQUIPMENT_DELETE = "equipment:delete"
    
    # Rental management
    RENTAL_CREATE = "rental:create"
    RENTAL_READ = "rental:read"
    RENTAL_UPDATE = "rental:update"
    RENTAL_DELETE = "rental:delete"
    RENTAL_APPROVE = "rental:approve"
    
    # Financial operations
    INVOICE_CREATE = "invoice:create"
    INVOICE_READ = "invoice:read"
    INVOICE_UPDATE = "invoice:update"
    INVOICE_DELETE = "invoice:delete"
    PAYMENT_PROCESS = "payment:process"
    
    # Reporting
    REPORT_VIEW = "report:view"
    REPORT_EXPORT = "report:export"
    
    # System administration
    SYSTEM_CONFIG = "system:config"
    SYSTEM_BACKUP = "system:backup"
    SYSTEM_LOGS = "system:logs"


class TokenData(BaseModel):
    """Token payload data model."""
    user_id: str
    email: str
    roles: List[str]
    permissions: List[str]
    token_type: str
    issued_at: datetime
    expires_at: datetime
    session_id: Optional[str] = None


class SecurityConfig:
    """Security configuration and constants."""
    
    # Password requirements
    MIN_PASSWORD_LENGTH = 8
    MAX_PASSWORD_LENGTH = 128
    REQUIRE_UPPERCASE = True
    REQUIRE_LOWERCASE = True
    REQUIRE_DIGITS = True
    REQUIRE_SPECIAL_CHARS = True
    
    # Token settings
    ACCESS_TOKEN_EXPIRE_MINUTES = 30
    REFRESH_TOKEN_EXPIRE_DAYS = 7
    RESET_TOKEN_EXPIRE_HOURS = 1
    VERIFICATION_TOKEN_EXPIRE_HOURS = 24
    
    # Rate limiting
    MAX_LOGIN_ATTEMPTS = 5
    LOCKOUT_DURATION_MINUTES = 15
    
    # Session management
    MAX_CONCURRENT_SESSIONS = 5
    SESSION_TIMEOUT_MINUTES = 60
    
    # Security headers
    SECURITY_HEADERS = {
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block",
        "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
        "Content-Security-Policy": "default-src 'self'",
        "Referrer-Policy": "strict-origin-when-cross-origin"
    }


class PasswordManager:
    """Advanced password management with security features."""
    
    def __init__(self):
        self.pwd_context = CryptContext(
            schemes=["bcrypt"],
            deprecated="auto",
            bcrypt__rounds=12
        )
        self.common_passwords = self._load_common_passwords()
    
    def _load_common_passwords(self) -> set:
        """Load common passwords for validation."""
        # In production, load from a file or database
        return {
            "password", "123456", "password123", "admin", "qwerty",
            "letmein", "welcome", "monkey", "dragon", "master"
        }
    
    def hash_password(self, password: str) -> str:
        """Hash password using bcrypt."""
        return self.pwd_context.hash(password)
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify password against hash."""
        return self.pwd_context.verify(plain_password, hashed_password)
    
    def validate_password_strength(self, password: str) -> Dict[str, Any]:
        """Validate password strength and return detailed feedback."""
        issues = []
        score = 0
        
        # Length check
        if len(password) < SecurityConfig.MIN_PASSWORD_LENGTH:
            issues.append(f"Password must be at least {SecurityConfig.MIN_PASSWORD_LENGTH} characters long")
        else:
            score += 1
        
        if len(password) > SecurityConfig.MAX_PASSWORD_LENGTH:
            issues.append(f"Password must not exceed {SecurityConfig.MAX_PASSWORD_LENGTH} characters")
        
        # Character requirements
        if SecurityConfig.REQUIRE_UPPERCASE and not any(c.isupper() for c in password):
            issues.append("Password must contain at least one uppercase letter")
        else:
            score += 1
        
        if SecurityConfig.REQUIRE_LOWERCASE and not any(c.islower() for c in password):
            issues.append("Password must contain at least one lowercase letter")
        else:
            score += 1
        
        if SecurityConfig.REQUIRE_DIGITS and not any(c.isdigit() for c in password):
            issues.append("Password must contain at least one digit")
        else:
            score += 1
        
        if SecurityConfig.REQUIRE_SPECIAL_CHARS and not any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?" for c in password):
            issues.append("Password must contain at least one special character")
        else:
            score += 1
        
        # Common password check
        if password.lower() in self.common_passwords:
            issues.append("Password is too common")
            score = max(0, score - 2)
        
        # Determine strength
        if score >= 5:
            strength = "strong"
        elif score >= 3:
            strength = "medium"
        else:
            strength = "weak"
        
        return {
            "valid": len(issues) == 0,
            "strength": strength,
            "score": score,
            "issues": issues
        }
    
    def generate_secure_password(self, length: int = 16) -> str:
        """Generate a cryptographically secure password."""
        import string
        
        characters = (
            string.ascii_lowercase +
            string.ascii_uppercase +
            string.digits +
            "!@#$%^&*()_+-="
        )
        
        password = ''.join(secrets.choice(characters) for _ in range(length))
        
        # Ensure password meets requirements
        validation = self.validate_password_strength(password)
        if not validation["valid"]:
            return self.generate_secure_password(length)  # Retry
        
        return password


class TokenManager:
    """JWT token management with advanced security features."""
    
    def __init__(self):
        self.algorithm = "HS256"
        self.secret_key = settings.secret_key
        self.active_tokens = set()  # In production, use Redis
        self.revoked_tokens = set()  # In production, use Redis
    
    def create_token(
        self,
        user_id: str,
        email: str,
        roles: List[str],
        permissions: List[str],
        token_type: str = TokenType.ACCESS,
        expires_delta: Optional[timedelta] = None
    ) -> str:
        """Create JWT token with user information."""
        now = datetime.utcnow()
        
        if expires_delta:
            expire = now + expires_delta
        else:
            if token_type == TokenType.ACCESS:
                expire = now + timedelta(minutes=SecurityConfig.ACCESS_TOKEN_EXPIRE_MINUTES)
            elif token_type == TokenType.REFRESH:
                expire = now + timedelta(days=SecurityConfig.REFRESH_TOKEN_EXPIRE_DAYS)
            elif token_type == TokenType.RESET:
                expire = now + timedelta(hours=SecurityConfig.RESET_TOKEN_EXPIRE_HOURS)
            else:
                expire = now + timedelta(hours=SecurityConfig.VERIFICATION_TOKEN_EXPIRE_HOURS)
        
        # Create token payload
        payload = {
            "user_id": user_id,
            "email": email,
            "roles": roles,
            "permissions": permissions,
            "token_type": token_type,
            "iat": now,
            "exp": expire,
            "jti": secrets.token_urlsafe(16),  # JWT ID for revocation
            "iss": "rentguy-api",
            "aud": "rentguy-client"
        }
        
        token = jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
        self.active_tokens.add(payload["jti"])
        
        audit_logger.log_security_event(
            event="token_created",
            user_id=user_id,
            details={
                "token_type": token_type,
                "expires_at": expire.isoformat(),
                "jti": payload["jti"]
            }
        )
        
        return token
    
    def verify_token(self, token: str) -> TokenData:
        """Verify and decode JWT token."""
        try:
            payload = jwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm],
                audience="rentguy-client",
                issuer="rentguy-api"
            )
            
            # Check if token is revoked
            jti = payload.get("jti")
            if jti in self.revoked_tokens:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Token has been revoked"
                )
            
            # Create token data
            token_data = TokenData(
                user_id=payload["user_id"],
                email=payload["email"],
                roles=payload["roles"],
                permissions=payload["permissions"],
                token_type=payload["token_type"],
                issued_at=datetime.fromtimestamp(payload["iat"]),
                expires_at=datetime.fromtimestamp(payload["exp"]),
                session_id=payload.get("session_id")
            )
            
            return token_data
            
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except jwt.InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    
    def revoke_token(self, token: str, user_id: str):
        """Revoke a JWT token."""
        try:
            payload = jwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm],
                options={"verify_exp": False}  # Allow expired tokens for revocation
            )
            
            jti = payload.get("jti")
            if jti:
                self.revoked_tokens.add(jti)
                self.active_tokens.discard(jti)
                
                audit_logger.log_security_event(
                    event="token_revoked",
                    user_id=user_id,
                    details={"jti": jti}
                )
                
        except jwt.InvalidTokenError:
            logger.warning("Attempted to revoke invalid token", user_id=user_id)
    
    def revoke_all_user_tokens(self, user_id: str):
        """Revoke all tokens for a specific user."""
        # In production, this would query the database/Redis
        # for all active tokens for the user
        audit_logger.log_security_event(
            event="all_tokens_revoked",
            user_id=user_id
        )


class RolePermissionManager:
    """Role-based access control (RBAC) management."""
    
    def __init__(self):
        self.role_permissions = self._initialize_role_permissions()
    
    def _initialize_role_permissions(self) -> Dict[str, List[str]]:
        """Initialize role-permission mappings."""
        return {
            UserRole.ADMIN: [
                # All permissions
                Permission.USER_CREATE, Permission.USER_READ, Permission.USER_UPDATE, Permission.USER_DELETE,
                Permission.EQUIPMENT_CREATE, Permission.EQUIPMENT_READ, Permission.EQUIPMENT_UPDATE, Permission.EQUIPMENT_DELETE,
                Permission.RENTAL_CREATE, Permission.RENTAL_READ, Permission.RENTAL_UPDATE, Permission.RENTAL_DELETE, Permission.RENTAL_APPROVE,
                Permission.INVOICE_CREATE, Permission.INVOICE_READ, Permission.INVOICE_UPDATE, Permission.INVOICE_DELETE,
                Permission.PAYMENT_PROCESS, Permission.REPORT_VIEW, Permission.REPORT_EXPORT,
                Permission.SYSTEM_CONFIG, Permission.SYSTEM_BACKUP, Permission.SYSTEM_LOGS
            ],
            UserRole.MANAGER: [
                Permission.USER_READ, Permission.USER_UPDATE,
                Permission.EQUIPMENT_CREATE, Permission.EQUIPMENT_READ, Permission.EQUIPMENT_UPDATE,
                Permission.RENTAL_CREATE, Permission.RENTAL_READ, Permission.RENTAL_UPDATE, Permission.RENTAL_APPROVE,
                Permission.INVOICE_CREATE, Permission.INVOICE_READ, Permission.INVOICE_UPDATE,
                Permission.PAYMENT_PROCESS, Permission.REPORT_VIEW, Permission.REPORT_EXPORT
            ],
            UserRole.EMPLOYEE: [
                Permission.EQUIPMENT_READ, Permission.EQUIPMENT_UPDATE,
                Permission.RENTAL_CREATE, Permission.RENTAL_READ, Permission.RENTAL_UPDATE,
                Permission.INVOICE_READ, Permission.REPORT_VIEW
            ],
            UserRole.CLIENT: [
                Permission.EQUIPMENT_READ,
                Permission.RENTAL_CREATE, Permission.RENTAL_READ,
                Permission.INVOICE_READ
            ],
            UserRole.GUEST: [
                Permission.EQUIPMENT_READ
            ]
        }
    
    def get_permissions_for_role(self, role: str) -> List[str]:
        """Get all permissions for a specific role."""
        return self.role_permissions.get(role, [])
    
    def get_permissions_for_roles(self, roles: List[str]) -> List[str]:
        """Get combined permissions for multiple roles."""
        permissions = set()
        for role in roles:
            permissions.update(self.get_permissions_for_role(role))
        return list(permissions)
    
    def has_permission(self, user_roles: List[str], required_permission: str) -> bool:
        """Check if user roles have required permission."""
        user_permissions = self.get_permissions_for_roles(user_roles)
        return required_permission in user_permissions
    
    def has_any_permission(self, user_roles: List[str], required_permissions: List[str]) -> bool:
        """Check if user roles have any of the required permissions."""
        user_permissions = set(self.get_permissions_for_roles(user_roles))
        return bool(user_permissions.intersection(required_permissions))
    
    def has_all_permissions(self, user_roles: List[str], required_permissions: List[str]) -> bool:
        """Check if user roles have all required permissions."""
        user_permissions = set(self.get_permissions_for_roles(user_roles))
        return set(required_permissions).issubset(user_permissions)


class SecurityMiddleware:
    """Security middleware for request processing."""
    
    def __init__(self):
        self.failed_attempts = {}  # In production, use Redis
        self.active_sessions = {}  # In production, use Redis
    
    async def __call__(self, request: Request, call_next):
        """Process security for incoming requests."""
        # Add security headers
        response = await call_next(request)
        
        for header, value in SecurityConfig.SECURITY_HEADERS.items():
            response.headers[header] = value
        
        # Log security events
        if hasattr(request.state, "user_id"):
            audit_logger.log_user_action(
                action="api_request",
                user_id=request.state.user_id,
                details={
                    "method": request.method,
                    "path": str(request.url.path),
                    "status_code": response.status_code
                },
                ip_address=request.client.host if request.client else None,
                user_agent=request.headers.get("user-agent")
            )
        
        return response
    
    def check_rate_limit(self, identifier: str, max_attempts: int, window_minutes: int) -> bool:
        """Check if request is within rate limits."""
        now = datetime.utcnow()
        window_start = now - timedelta(minutes=window_minutes)
        
        if identifier not in self.failed_attempts:
            self.failed_attempts[identifier] = []
        
        # Clean old attempts
        self.failed_attempts[identifier] = [
            attempt for attempt in self.failed_attempts[identifier]
            if attempt > window_start
        ]
        
        return len(self.failed_attempts[identifier]) < max_attempts
    
    def record_failed_attempt(self, identifier: str):
        """Record a failed authentication attempt."""
        now = datetime.utcnow()
        
        if identifier not in self.failed_attempts:
            self.failed_attempts[identifier] = []
        
        self.failed_attempts[identifier].append(now)
        
        audit_logger.log_security_event(
            event="failed_authentication",
            details={"identifier": identifier},
            severity="warning"
        )


# Global instances
password_manager = PasswordManager()
token_manager = TokenManager()
rbac_manager = RolePermissionManager()
security_middleware = SecurityMiddleware()

# FastAPI security scheme
security_scheme = HTTPBearer()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security_scheme)
) -> TokenData:
    """Dependency to get current authenticated user."""
    token = credentials.credentials
    return token_manager.verify_token(token)


def require_permission(permission: str):
    """Decorator to require specific permission."""
    def decorator(current_user: TokenData = Depends(get_current_user)):
        if not rbac_manager.has_permission(current_user.roles, permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions. Required: {permission}"
            )
        return current_user
    return decorator


def require_any_permission(permissions: List[str]):
    """Decorator to require any of the specified permissions."""
    def decorator(current_user: TokenData = Depends(get_current_user)):
        if not rbac_manager.has_any_permission(current_user.roles, permissions):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient permissions. Required any of: {', '.join(permissions)}"
            )
        return current_user
    return decorator


def require_role(role: str):
    """Decorator to require specific role."""
    def decorator(current_user: TokenData = Depends(get_current_user)):
        if role not in current_user.roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Insufficient role. Required: {role}"
            )
        return current_user
    return decorator


class TwoFactorAuth:
    """Two-factor authentication implementation."""
    
    def __init__(self):
        self.totp_secrets = {}  # In production, store in database
    
    def generate_secret(self, user_id: str) -> str:
        """Generate TOTP secret for user."""
        import pyotp
        
        secret = pyotp.random_base32()
        self.totp_secrets[user_id] = secret
        
        audit_logger.log_security_event(
            event="2fa_secret_generated",
            user_id=user_id
        )
        
        return secret
    
    def generate_qr_code(self, user_id: str, email: str, secret: str) -> str:
        """Generate QR code for TOTP setup."""
        import pyotp
        import qrcode
        import io
        import base64
        
        totp = pyotp.TOTP(secret)
        provisioning_uri = totp.provisioning_uri(
            name=email,
            issuer_name="RentGuy Enterprise"
        )
        
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(provisioning_uri)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        
        return base64.b64encode(buffer.getvalue()).decode()
    
    def verify_totp(self, user_id: str, token: str) -> bool:
        """Verify TOTP token."""
        import pyotp
        
        secret = self.totp_secrets.get(user_id)
        if not secret:
            return False
        
        totp = pyotp.TOTP(secret)
        is_valid = totp.verify(token, valid_window=1)
        
        audit_logger.log_security_event(
            event="2fa_verification",
            user_id=user_id,
            details={"success": is_valid}
        )
        
        return is_valid


# Global 2FA instance
two_factor_auth = TwoFactorAuth()
