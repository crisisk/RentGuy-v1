"""
Enterprise performance optimization system for RentGuy.
Provides comprehensive performance monitoring, caching, and optimization.
"""

import asyncio
import functools
import hashlib
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import Any, Callable, Dict, List, Optional, Union
from collections import defaultdict, deque

import redis.asyncio as redis
from sqlalchemy import event, text
from sqlalchemy.engine import Engine
from sqlalchemy.pool import Pool

from .config import settings
from .logging import performance_logger, get_logger

logger = get_logger(__name__)


class CacheManager:
    """Advanced caching system with multiple backends and strategies."""
    
    def __init__(self):
        self.redis_client = None
        self.local_cache = {}
        self.cache_stats = defaultdict(int)
        self.cache_config = {
            "default_ttl": 3600,  # 1 hour
            "max_local_cache_size": 1000,
            "compression_threshold": 1024,  # Compress values > 1KB
        }
        self._initialize_redis()
    
    async def _initialize_redis(self):
        """Initialize Redis connection."""
        try:
            self.redis_client = redis.from_url(
                settings.redis_url,
                encoding="utf-8",
                decode_responses=True,
                max_connections=20,
                retry_on_timeout=True
            )
            await self.redis_client.ping()
            logger.info("Redis cache initialized successfully")
        except Exception as e:
            logger.warning(f"Redis initialization failed: {e}. Using local cache only.")
            self.redis_client = None
    
    def _generate_cache_key(self, prefix: str, *args, **kwargs) -> str:
        """Generate a consistent cache key."""
        key_parts = [prefix]
        
        # Add positional arguments
        for arg in args:
            if isinstance(arg, (str, int, float, bool)):
                key_parts.append(str(arg))
            else:
                key_parts.append(hashlib.md5(str(arg).encode()).hexdigest()[:8])
        
        # Add keyword arguments
        for key, value in sorted(kwargs.items()):
            if isinstance(value, (str, int, float, bool)):
                key_parts.append(f"{key}:{value}")
            else:
                key_parts.append(f"{key}:{hashlib.md5(str(value).encode()).hexdigest()[:8]}")
        
        return ":".join(key_parts)
    
    async def get(self, key: str, default: Any = None) -> Any:
        """Get value from cache."""
        start_time = time.time()
        
        try:
            # Try Redis first
            if self.redis_client:
                value = await self.redis_client.get(key)
                if value is not None:
                    self.cache_stats["redis_hits"] += 1
                    performance_logger.log_cache_operation("redis", "hit", time.time() - start_time)
                    return self._deserialize_value(value)
                else:
                    self.cache_stats["redis_misses"] += 1
            
            # Try local cache
            if key in self.local_cache:
                entry = self.local_cache[key]
                if entry["expires_at"] > time.time():
                    self.cache_stats["local_hits"] += 1
                    performance_logger.log_cache_operation("local", "hit", time.time() - start_time)
                    return entry["value"]
                else:
                    # Expired entry
                    del self.local_cache[key]
            
            self.cache_stats["total_misses"] += 1
            performance_logger.log_cache_operation("all", "miss", time.time() - start_time)
            return default
            
        except Exception as e:
            logger.error(f"Cache get error for key {key}: {e}")
            return default
    
    async def set(self, key: str, value: Any, ttl: int = None) -> bool:
        """Set value in cache."""
        start_time = time.time()
        ttl = ttl or self.cache_config["default_ttl"]
        
        try:
            serialized_value = self._serialize_value(value)
            
            # Set in Redis
            if self.redis_client:
                await self.redis_client.setex(key, ttl, serialized_value)
                self.cache_stats["redis_sets"] += 1
            
            # Set in local cache
            self._set_local_cache(key, value, ttl)
            
            performance_logger.log_cache_operation("all", "set", time.time() - start_time)
            return True
            
        except Exception as e:
            logger.error(f"Cache set error for key {key}: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete value from cache."""
        try:
            # Delete from Redis
            if self.redis_client:
                await self.redis_client.delete(key)
            
            # Delete from local cache
            self.local_cache.pop(key, None)
            
            self.cache_stats["deletes"] += 1
            return True
            
        except Exception as e:
            logger.error(f"Cache delete error for key {key}: {e}")
            return False
    
    async def clear_pattern(self, pattern: str) -> int:
        """Clear cache keys matching pattern."""
        try:
            count = 0
            
            # Clear from Redis
            if self.redis_client:
                keys = await self.redis_client.keys(pattern)
                if keys:
                    count += await self.redis_client.delete(*keys)
            
            # Clear from local cache
            keys_to_delete = [key for key in self.local_cache.keys() if pattern in key]
            for key in keys_to_delete:
                del self.local_cache[key]
                count += 1
            
            return count
            
        except Exception as e:
            logger.error(f"Cache clear pattern error for {pattern}: {e}")
            return 0
    
    def _set_local_cache(self, key: str, value: Any, ttl: int):
        """Set value in local cache with size management."""
        # Clean expired entries
        current_time = time.time()
        expired_keys = [
            k for k, v in self.local_cache.items()
            if v["expires_at"] <= current_time
        ]
        for k in expired_keys:
            del self.local_cache[k]
        
        # Manage cache size
        if len(self.local_cache) >= self.cache_config["max_local_cache_size"]:
            # Remove oldest entries
            sorted_items = sorted(
                self.local_cache.items(),
                key=lambda x: x[1]["created_at"]
            )
            for k, _ in sorted_items[:len(sorted_items) // 4]:  # Remove 25%
                del self.local_cache[k]
        
        # Set new entry
        self.local_cache[key] = {
            "value": value,
            "created_at": current_time,
            "expires_at": current_time + ttl
        }
        
        self.cache_stats["local_sets"] += 1
    
    def _serialize_value(self, value: Any) -> str:
        """Serialize value for storage."""
        import json
        try:
            return json.dumps(value, default=str)
        except (TypeError, ValueError):
            return str(value)
    
    def _deserialize_value(self, value: str) -> Any:
        """Deserialize value from storage."""
        import json
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return value
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total_requests = (
            self.cache_stats["redis_hits"] + 
            self.cache_stats["local_hits"] + 
            self.cache_stats["total_misses"]
        )
        
        hit_rate = 0
        if total_requests > 0:
            total_hits = self.cache_stats["redis_hits"] + self.cache_stats["local_hits"]
            hit_rate = (total_hits / total_requests) * 100
        
        return {
            "hit_rate_percent": round(hit_rate, 2),
            "total_requests": total_requests,
            "redis_hits": self.cache_stats["redis_hits"],
            "local_hits": self.cache_stats["local_hits"],
            "total_misses": self.cache_stats["total_misses"],
            "redis_sets": self.cache_stats["redis_sets"],
            "local_sets": self.cache_stats["local_sets"],
            "deletes": self.cache_stats["deletes"],
            "local_cache_size": len(self.local_cache),
            "redis_available": self.redis_client is not None
        }


class QueryOptimizer:
    """Database query optimization and monitoring."""
    
    def __init__(self):
        self.slow_queries = deque(maxlen=100)
        self.query_stats = defaultdict(lambda: {
            "count": 0,
            "total_time": 0,
            "avg_time": 0,
            "max_time": 0,
            "min_time": float('inf')
        })
        self.query_cache = {}
        self._setup_sqlalchemy_events()
    
    def _setup_sqlalchemy_events(self):
        """Setup SQLAlchemy event listeners for query monitoring."""
        
        @event.listens_for(Engine, "before_cursor_execute")
        def before_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            context._query_start_time = time.time()
            context._query_statement = statement
        
        @event.listens_for(Engine, "after_cursor_execute")
        def after_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            if hasattr(context, '_query_start_time'):
                execution_time = time.time() - context._query_start_time
                self._record_query_execution(statement, execution_time)
        
        @event.listens_for(Pool, "connect")
        def set_sqlite_pragma(dbapi_connection, connection_record):
            # Optimize SQLite connections if used
            if 'sqlite' in str(dbapi_connection):
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.execute("PRAGMA synchronous=NORMAL")
                cursor.execute("PRAGMA cache_size=10000")
                cursor.execute("PRAGMA temp_store=MEMORY")
                cursor.close()
    
    def _record_query_execution(self, statement: str, execution_time: float):
        """Record query execution statistics."""
        # Normalize query for statistics
        normalized_query = self._normalize_query(statement)
        
        # Update statistics
        stats = self.query_stats[normalized_query]
        stats["count"] += 1
        stats["total_time"] += execution_time
        stats["avg_time"] = stats["total_time"] / stats["count"]
        stats["max_time"] = max(stats["max_time"], execution_time)
        stats["min_time"] = min(stats["min_time"], execution_time)
        
        # Log slow queries
        if execution_time > 1.0:  # Queries slower than 1 second
            slow_query = {
                "statement": statement[:500],  # Truncate long queries
                "execution_time": execution_time,
                "timestamp": datetime.utcnow().isoformat()
            }
            self.slow_queries.append(slow_query)
            
            performance_logger.log_slow_query(
                query=normalized_query,
                execution_time=execution_time,
                full_query=statement[:200]
            )
    
    def _normalize_query(self, statement: str) -> str:
        """Normalize query for statistics grouping."""
        # Remove parameter values and normalize whitespace
        import re
        
        # Replace parameter placeholders
        normalized = re.sub(r'\$\d+|\?|%\([^)]+\)s', '?', statement)
        
        # Replace numeric literals
        normalized = re.sub(r'\b\d+\b', '?', normalized)
        
        # Replace string literals
        normalized = re.sub(r"'[^']*'", "'?'", normalized)
        
        # Normalize whitespace
        normalized = ' '.join(normalized.split())
        
        return normalized.lower()
    
    def get_slow_queries(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent slow queries."""
        return list(self.slow_queries)[-limit:]
    
    def get_query_stats(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get query statistics sorted by total time."""
        stats_list = []
        
        for query, stats in self.query_stats.items():
            stats_list.append({
                "query": query[:100],  # Truncate for display
                "count": stats["count"],
                "total_time": round(stats["total_time"], 3),
                "avg_time": round(stats["avg_time"], 3),
                "max_time": round(stats["max_time"], 3),
                "min_time": round(stats["min_time"], 3)
            })
        
        # Sort by total time descending
        stats_list.sort(key=lambda x: x["total_time"], reverse=True)
        
        return stats_list[:limit]
    
    async def optimize_query(self, query: str) -> Dict[str, Any]:
        """Analyze and suggest optimizations for a query."""
        suggestions = []
        
        query_lower = query.lower()
        
        # Check for common anti-patterns
        if "select *" in query_lower:
            suggestions.append("Avoid SELECT * - specify only needed columns")
        
        if "order by" in query_lower and "limit" not in query_lower:
            suggestions.append("Consider adding LIMIT to ORDER BY queries")
        
        if query_lower.count("join") > 3:
            suggestions.append("Complex joins detected - consider query restructuring")
        
        if "like '%%" in query_lower:
            suggestions.append("Leading wildcard LIKE patterns prevent index usage")
        
        if "or" in query_lower:
            suggestions.append("OR conditions may prevent index usage - consider UNION")
        
        return {
            "query": query[:200],
            "suggestions": suggestions,
            "complexity_score": self._calculate_complexity_score(query)
        }
    
    def _calculate_complexity_score(self, query: str) -> int:
        """Calculate query complexity score."""
        score = 0
        query_lower = query.lower()
        
        # Count various complexity factors
        score += query_lower.count("join") * 2
        score += query_lower.count("subquery") * 3
        score += query_lower.count("union") * 2
        score += query_lower.count("group by") * 1
        score += query_lower.count("order by") * 1
        score += query_lower.count("having") * 2
        score += query_lower.count("case when") * 1
        
        return score


class PerformanceProfiler:
    """Application performance profiling and monitoring."""
    
    def __init__(self):
        self.profiles = deque(maxlen=1000)
        self.endpoint_stats = defaultdict(lambda: {
            "count": 0,
            "total_time": 0,
            "avg_time": 0,
            "max_time": 0,
            "min_time": float('inf'),
            "error_count": 0
        })
    
    @asynccontextmanager
    async def profile_operation(self, operation_name: str, **metadata):
        """Context manager for profiling operations."""
        start_time = time.time()
        start_memory = self._get_memory_usage()
        
        profile_data = {
            "operation": operation_name,
            "start_time": start_time,
            "start_memory": start_memory,
            "metadata": metadata
        }
        
        try:
            yield profile_data
            
            # Success metrics
            end_time = time.time()
            end_memory = self._get_memory_usage()
            
            profile_data.update({
                "end_time": end_time,
                "duration": end_time - start_time,
                "end_memory": end_memory,
                "memory_delta": end_memory - start_memory,
                "status": "success"
            })
            
        except Exception as e:
            # Error metrics
            end_time = time.time()
            end_memory = self._get_memory_usage()
            
            profile_data.update({
                "end_time": end_time,
                "duration": end_time - start_time,
                "end_memory": end_memory,
                "memory_delta": end_memory - start_memory,
                "status": "error",
                "error": str(e)
            })
            
            raise
        
        finally:
            self._record_profile(profile_data)
    
    def _get_memory_usage(self) -> float:
        """Get current memory usage in MB."""
        try:
            import psutil
            process = psutil.Process()
            return process.memory_info().rss / 1024 / 1024  # MB
        except ImportError:
            return 0.0
    
    def _record_profile(self, profile_data: Dict[str, Any]):
        """Record profile data."""
        self.profiles.append(profile_data)
        
        # Update endpoint statistics
        operation = profile_data["operation"]
        duration = profile_data["duration"]
        
        stats = self.endpoint_stats[operation]
        stats["count"] += 1
        stats["total_time"] += duration
        stats["avg_time"] = stats["total_time"] / stats["count"]
        stats["max_time"] = max(stats["max_time"], duration)
        stats["min_time"] = min(stats["min_time"], duration)
        
        if profile_data["status"] == "error":
            stats["error_count"] += 1
        
        # Log slow operations
        if duration > 2.0:  # Operations slower than 2 seconds
            performance_logger.log_slow_operation(
                operation=operation,
                duration=duration,
                metadata=profile_data.get("metadata", {})
            )
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary."""
        if not self.profiles:
            return {"message": "No performance data available"}
        
        recent_profiles = list(self.profiles)[-100:]  # Last 100 operations
        
        durations = [p["duration"] for p in recent_profiles]
        memory_deltas = [p["memory_delta"] for p in recent_profiles if p["memory_delta"] is not None]
        
        return {
            "total_operations": len(self.profiles),
            "recent_operations": len(recent_profiles),
            "avg_duration": sum(durations) / len(durations) if durations else 0,
            "max_duration": max(durations) if durations else 0,
            "min_duration": min(durations) if durations else 0,
            "avg_memory_delta": sum(memory_deltas) / len(memory_deltas) if memory_deltas else 0,
            "error_rate": len([p for p in recent_profiles if p["status"] == "error"]) / len(recent_profiles) * 100,
            "slow_operations": len([p for p in recent_profiles if p["duration"] > 1.0])
        }
    
    def get_endpoint_stats(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get endpoint performance statistics."""
        stats_list = []
        
        for endpoint, stats in self.endpoint_stats.items():
            error_rate = (stats["error_count"] / stats["count"]) * 100 if stats["count"] > 0 else 0
            
            stats_list.append({
                "endpoint": endpoint,
                "count": stats["count"],
                "avg_time": round(stats["avg_time"], 3),
                "max_time": round(stats["max_time"], 3),
                "min_time": round(stats["min_time"], 3),
                "total_time": round(stats["total_time"], 3),
                "error_count": stats["error_count"],
                "error_rate": round(error_rate, 2)
            })
        
        # Sort by average time descending
        stats_list.sort(key=lambda x: x["avg_time"], reverse=True)
        
        return stats_list[:limit]


def cached(ttl: int = 3600, key_prefix: str = "cache"):
    """Decorator for caching function results."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            # Generate cache key
            cache_key = cache_manager._generate_cache_key(
                f"{key_prefix}:{func.__name__}", *args, **kwargs
            )
            
            # Try to get from cache
            cached_result = await cache_manager.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            # Execute function and cache result
            result = await func(*args, **kwargs)
            await cache_manager.set(cache_key, result, ttl)
            
            return result
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            # For sync functions, we need to handle caching differently
            cache_key = cache_manager._generate_cache_key(
                f"{key_prefix}:{func.__name__}", *args, **kwargs
            )
            
            # Check local cache only for sync functions
            if cache_key in cache_manager.local_cache:
                entry = cache_manager.local_cache[cache_key]
                if entry["expires_at"] > time.time():
                    return entry["value"]
            
            # Execute function and cache result locally
            result = func(*args, **kwargs)
            cache_manager._set_local_cache(cache_key, result, ttl)
            
            return result
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    
    return decorator


def timed(operation_name: str = None):
    """Decorator for timing function execution."""
    def decorator(func: Callable) -> Callable:
        op_name = operation_name or f"{func.__module__}.{func.__name__}"
        
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            async with profiler.profile_operation(op_name):
                return await func(*args, **kwargs)
        
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                duration = time.time() - start_time
                
                performance_logger.log_operation_timing(
                    operation=op_name,
                    duration=duration,
                    status="success"
                )
                
                return result
            except Exception as e:
                duration = time.time() - start_time
                
                performance_logger.log_operation_timing(
                    operation=op_name,
                    duration=duration,
                    status="error",
                    error=str(e)
                )
                
                raise
        
        return async_wrapper if asyncio.iscoroutinefunction(func) else sync_wrapper
    
    return decorator


class PerformanceManager:
    """Central performance management system."""
    
    def __init__(self):
        self.cache_manager = CacheManager()
        self.query_optimizer = QueryOptimizer()
        self.profiler = PerformanceProfiler()
        self.is_monitoring = False
    
    async def start_monitoring(self):
        """Start performance monitoring."""
        if self.is_monitoring:
            return
        
        self.is_monitoring = True
        
        # Initialize cache manager
        await self.cache_manager._initialize_redis()
        
        logger.info("Performance monitoring started")
    
    async def stop_monitoring(self):
        """Stop performance monitoring."""
        self.is_monitoring = False
        
        # Close Redis connection
        if self.cache_manager.redis_client:
            await self.cache_manager.redis_client.close()
        
        logger.info("Performance monitoring stopped")
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Get comprehensive performance report."""
        return {
            "cache_stats": self.cache_manager.get_stats(),
            "query_stats": self.query_optimizer.get_query_stats(10),
            "slow_queries": self.query_optimizer.get_slow_queries(5),
            "performance_summary": self.profiler.get_performance_summary(),
            "endpoint_stats": self.profiler.get_endpoint_stats(10),
            "timestamp": datetime.utcnow().isoformat()
        }


# Global instances
performance_manager = PerformanceManager()
cache_manager = performance_manager.cache_manager
query_optimizer = performance_manager.query_optimizer
profiler = performance_manager.profiler

# Convenience functions
def get_cache_manager() -> CacheManager:
    """Get the global cache manager."""
    return cache_manager

def get_query_optimizer() -> QueryOptimizer:
    """Get the global query optimizer."""
    return query_optimizer

def get_profiler() -> PerformanceProfiler:
    """Get the global profiler."""
    return profiler
