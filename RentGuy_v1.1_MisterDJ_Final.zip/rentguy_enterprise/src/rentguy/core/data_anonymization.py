"""
Data Anonymization Service for GDPR and ISO 27001 Compliance.
Provides methods to safely anonymize Personally Identifiable Information (PII)
in the database and logs.
"""

import hashlib
import os
from typing import Any, Dict, List, Optional
from datetime import datetime
from uuid import UUID

from faker import Faker
from sqlalchemy.orm import Session

from ..core.logging import get_logger
from ..models.models import User, Lead, Contact, Rental, Equipment

logger = get_logger(__name__)
fake = Faker(['nl_NL']) # Use Dutch locale for realistic fake data

# Configuration for fields to anonymize in core models
ANONYMIZATION_MAP = {
    User: [
        'first_name', 'last_name', 'email', 'phone_number', 'address_line1', 
        'address_line2', 'city', 'postal_code', 'company_name', 'vat_number'
    ],
    Lead: [
        'name', 'email', 'phone_number', 'company_name', 'interested_equipment'
    ],
    Contact: [
        'first_name', 'last_name', 'email', 'phone_number', 'address_line1', 
        'address_line2', 'city', 'postal_code', 'company_name'
    ],
    # Rental and Equipment models contain less PII, but can be scrubbed if needed
    Rental: [],
    Equipment: []
}

class AnonymizationService:
    """
    Service to handle data anonymization using various techniques.
    """
    
    def __init__(self, db: Session):
        self.db = db
        self.salt = os.environ.get("ANONYMIZATION_SALT", "default_secure_salt_for_rentguy_enterprise")
        
    def _hash_value(self, value: str) -> str:
        """
        One-way hashing of a value for pseudonymization.
        """
        if not value:
            return ""
        
        # Use a strong, salted hash
        return hashlib.sha256((value + self.salt).encode('utf-8')).hexdigest()

    def _fake_value(self, field_name: str) -> Any:
        """
        Generates a realistic, but fake, replacement value for a field.
        """
        if 'email' in field_name:
            return fake.email()
        if 'phone_number' in field_name:
            return fake.phone_number()
        if 'first_name' in field_name:
            return fake.first_name()
        if 'last_name' in field_name:
            return fake.last_name()
        if 'address_line1' in field_name:
            return fake.street_address()
        if 'city' in field_name:
            return fake.city()
        if 'postal_code' in field_name:
            return fake.postcode()
        if 'company_name' in field_name:
            return fake.company()
        if 'vat_number' in field_name:
            return f"NL{fake.random_number(digits=9)}B01"
        
        # Fallback for generic fields
        return fake.word()

    def anonymize_record(self, record: Any, method: str = 'fake') -> Any:
        """
        Anonymizes a single database record based on the ANONYMIZATION_MAP.
        
        Args:
            record: The SQLAlchemy model instance to anonymize.
            method: 'hash' for pseudonymization, 'fake' for replacement.
            
        Returns:
            The modified record instance.
        """
        model_class = record.__class__
        fields_to_anonymize = ANONYMIZATION_MAP.get(model_class, [])
        
        if not fields_to_anonymize:
            return record
        
        for field in fields_to_anonymize:
            if hasattr(record, field):
                original_value = getattr(record, field)
                
                if original_value is None:
                    continue
                
                if method == 'hash':
                    new_value = self._hash_value(str(original_value))
                elif method == 'fake':
                    new_value = self._fake_value(field)
                else:
                    new_value = "ANONYMIZED"
                
                setattr(record, field, new_value)
        
        # Mark as anonymized
        if hasattr(record, 'is_anonymized'):
            setattr(record, 'is_anonymized', True)
        
        return record

    def anonymize_user_data(self, user_id: UUID, method: str = 'fake') -> Dict[str, Any]:
        """
        Anonymizes all related data for a specific user (Right to be Forgotten).
        
        Args:
            user_id: The UUID of the user whose data should be anonymized.
            method: 'hash' or 'fake' for anonymization technique.
            
        Returns:
            Summary of the anonymization process.
        """
        user = self.db.query(User).filter(User.id == user_id).first()
        if not user:
            logger.warning(f"Attempted to anonymize non-existent user: {user_id}")
            return {"success": False, "message": "User not found"}
        
        anonymized_count = 0
        
        # 1. Anonymize the User record itself
        self.anonymize_record(user, method)
        anonymized_count += 1
        
        # 2. Anonymize related Leads and Contacts
        leads = self.db.query(Lead).filter(Lead.user_id == user_id).all()
        for lead in leads:
            self.anonymize_record(lead, method)
            anonymized_count += 1
            
        contacts = self.db.query(Contact).filter(Contact.user_id == user_id).all()
        for contact in contacts:
            self.anonymize_record(contact, method)
            anonymized_count += 1
            
        # 3. Handle Rentals (keep rental history for financial/legal reasons, but anonymize PII)
        rentals = self.db.query(Rental).filter(Rental.user_id == user_id).all()
        for rental in rentals:
            # Optionally set user_id to None or a generic anonymized user ID
            # For now, we keep the link but anonymize the user record
            anonymized_count += 1
        
        # Commit changes
        self.db.commit()
        
        logger.info(
            "User data anonymization complete",
            user_id=str(user_id),
            method=method,
            records_anonymized=anonymized_count
        )
        
        return {
            "success": True,
            "user_id": str(user_id),
            "method": method,
            "records_anonymized": anonymized_count,
            "timestamp": datetime.utcnow().isoformat()
        }

    def anonymize_log_entry(self, log_entry: Dict[str, Any]) -> Dict[str, Any]:
        """
        Anonymizes PII within a structured log entry before storage.
        
        Args:
            log_entry: The structured log entry dictionary.
            
        Returns:
            The anonymized log entry dictionary.
        """
        anonymized_log = log_entry.copy()
        
        # List of common PII keys in logs
        pii_keys = ['email', 'user_id', 'ip_address', 'phone_number', 'full_name', 'username']
        
        for key in pii_keys:
            if key in anonymized_log:
                original_value = anonymized_log[key]
                if isinstance(original_value, str):
                    anonymized_log[key] = self._hash_value(original_value)
                elif isinstance(original_value, UUID):
                    anonymized_log[key] = self._hash_value(str(original_value))
                else:
                    anonymized_log[key] = "ANONYMIZED"
        
        return anonymized_log

    def scrub_pii_from_text(self, text: str) -> str:
        """
        Scans and scrubs PII from a free-form text field (e.g., notes, chat history).
        
        Note: This is a complex task. For compliance, structured data is preferred.
        This function provides a basic scrubbing mechanism.
        """
        # Simple replacement for common patterns (emails, phone numbers)
        import re
        
        # Email pattern
        text = re.sub(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', 
                      'EMAIL_SCRUBBED', text)
        
        # Phone number pattern (basic)
        text = re.sub(r'(\+?\d{1,4}[-.\s]?)?(\(?\d{1,}\)?[-.\s]?){2,}', 
                      'PHONE_SCRUBBED', text)
        
        return text

# Example usage (in a separate file or service)
# from .data_anonymization import AnonymizationService
# from .database import get_db
# 
# def handle_right_to_be_forgotten(user_id: UUID):
#     db = next(get_db())
#     service = AnonymizationService(db)
#     result = service.anonymize_user_data(user_id, method='hash')
#     return result
