"""
Enterprise-grade database configuration and management for RentGuy.
Includes connection pooling, health checks, and migration support.
"""

import asyncio
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional

from sqlalchemy import create_engine, event, pool
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import QueuePool

from .config import settings
from .logging import get_logger

logger = get_logger(__name__)

# Base class for all models
Base = declarative_base()

# Database engines
async_engine = None
sync_engine = None

# Session makers
AsyncSessionLocal = None
SessionLocal = None


class DatabaseManager:
    """Enterprise database management with connection pooling and health checks."""
    
    def __init__(self):
        self.async_engine = None
        self.sync_engine = None
        self.async_session_maker = None
        self.sync_session_maker = None
        self._initialized = False
    
    async def initialize(self):
        """Initialize database connections and session makers."""
        if self._initialized:
            return
        
        logger.info("Initializing database connections")
        
        # Create async engine
        self.async_engine = create_async_engine(
            settings.get_database_url(async_driver=True),
            poolclass=QueuePool,
            pool_size=settings.database_pool_size,
            max_overflow=settings.database_max_overflow,
            pool_timeout=settings.database_pool_timeout,
            pool_recycle=settings.database_pool_recycle,
            pool_pre_ping=True,
            echo=settings.debug,
            future=True,
        )
        
        # Create sync engine for migrations and admin tasks
        self.sync_engine = create_engine(
            settings.get_database_url(async_driver=False),
            poolclass=QueuePool,
            pool_size=10,
            max_overflow=20,
            pool_timeout=30,
            pool_recycle=3600,
            pool_pre_ping=True,
            echo=settings.debug,
            future=True,
        )
        
        # Create session makers
        self.async_session_maker = async_sessionmaker(
            bind=self.async_engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=True,
            autocommit=False,
        )
        
        self.sync_session_maker = sessionmaker(
            bind=self.sync_engine,
            autoflush=True,
            autocommit=False,
        )
        
        # Set up event listeners
        self._setup_event_listeners()
        
        # Test connections
        await self._test_connections()
        
        self._initialized = True
        logger.info("Database connections initialized successfully")
    
    def _setup_event_listeners(self):
        """Set up database event listeners for monitoring and logging."""
        
        @event.listens_for(self.async_engine.sync_engine, "connect")
        def set_sqlite_pragma(dbapi_connection, connection_record):
            """Set SQLite pragmas for better performance (if using SQLite)."""
            if "sqlite" in str(dbapi_connection):
                cursor = dbapi_connection.cursor()
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.execute("PRAGMA synchronous=NORMAL")
                cursor.execute("PRAGMA cache_size=1000")
                cursor.execute("PRAGMA temp_store=MEMORY")
                cursor.close()
        
        @event.listens_for(self.async_engine.sync_engine, "before_cursor_execute")
        def receive_before_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            """Log slow queries."""
            import time
            context._query_start_time = time.time()
        
        @event.listens_for(self.async_engine.sync_engine, "after_cursor_execute")
        def receive_after_cursor_execute(conn, cursor, statement, parameters, context, executemany):
            """Log query execution time."""
            import time
            total = time.time() - context._query_start_time
            
            if total > 1.0:  # Log queries taking more than 1 second
                logger.warning(
                    "Slow query detected",
                    duration_seconds=total,
                    statement=statement[:200] + "..." if len(statement) > 200 else statement
                )
    
    async def _test_connections(self):
        """Test database connections."""
        try:
            # Test async connection
            async with self.async_engine.begin() as conn:
                await conn.execute("SELECT 1")
            
            # Test sync connection
            with self.sync_engine.begin() as conn:
                conn.execute("SELECT 1")
            
            logger.info("Database connection tests passed")
        except Exception as e:
            logger.error("Database connection test failed", error=str(e))
            raise
    
    async def get_async_session(self) -> AsyncSession:
        """Get async database session."""
        if not self._initialized:
            await self.initialize()
        
        return self.async_session_maker()
    
    def get_sync_session(self):
        """Get sync database session."""
        if not self._initialized:
            raise RuntimeError("Database not initialized. Call initialize() first.")
        
        return self.sync_session_maker()
    
    async def health_check(self) -> dict:
        """Perform database health check."""
        try:
            async with self.async_engine.begin() as conn:
                result = await conn.execute("SELECT 1 as health_check")
                row = result.fetchone()
                
                if row and row.health_check == 1:
                    # Get connection pool status
                    pool_status = {
                        "size": self.async_engine.pool.size(),
                        "checked_in": self.async_engine.pool.checkedin(),
                        "checked_out": self.async_engine.pool.checkedout(),
                        "overflow": self.async_engine.pool.overflow(),
                    }
                    
                    return {
                        "status": "healthy",
                        "pool": pool_status,
                        "database": "connected"
                    }
                else:
                    return {"status": "unhealthy", "error": "Query failed"}
        
        except Exception as e:
            logger.error("Database health check failed", error=str(e))
            return {"status": "unhealthy", "error": str(e)}
    
    async def close(self):
        """Close database connections."""
        if self.async_engine:
            await self.async_engine.dispose()
        
        if self.sync_engine:
            self.sync_engine.dispose()
        
        logger.info("Database connections closed")


# Global database manager instance
db_manager = DatabaseManager()


# Dependency for FastAPI
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency to get database session."""
    async with db_manager.get_async_session() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# Context manager for database sessions
@asynccontextmanager
async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """Context manager for database sessions."""
    async with db_manager.get_async_session() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


class DatabaseTransaction:
    """Context manager for database transactions with automatic rollback."""
    
    def __init__(self, session: AsyncSession):
        self.session = session
        self.transaction = None
    
    async def __aenter__(self):
        """Start transaction."""
        self.transaction = await self.session.begin()
        return self.session
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Commit or rollback transaction."""
        if exc_type is not None:
            await self.transaction.rollback()
            logger.error(
                "Transaction rolled back due to exception",
                exception_type=exc_type.__name__,
                exception_message=str(exc_val)
            )
        else:
            await self.transaction.commit()


# Utility functions
async def create_tables():
    """Create all database tables."""
    async with db_manager.async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables created")


async def drop_tables():
    """Drop all database tables."""
    async with db_manager.async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    logger.info("Database tables dropped")


class DatabaseMigrationManager:
    """Manage database migrations and schema changes."""
    
    def __init__(self):
        self.logger = get_logger("migration")
    
    async def run_migrations(self):
        """Run pending database migrations."""
        try:
            from alembic import command
            from alembic.config import Config
            
            # Configure Alembic
            alembic_cfg = Config("alembic.ini")
            alembic_cfg.set_main_option("sqlalchemy.url", settings.get_database_url(async_driver=False))
            
            # Run migrations
            command.upgrade(alembic_cfg, "head")
            self.logger.info("Database migrations completed successfully")
            
        except Exception as e:
            self.logger.error("Database migration failed", error=str(e))
            raise
    
    async def create_migration(self, message: str):
        """Create a new database migration."""
        try:
            from alembic import command
            from alembic.config import Config
            
            alembic_cfg = Config("alembic.ini")
            alembic_cfg.set_main_option("sqlalchemy.url", settings.get_database_url(async_driver=False))
            
            command.revision(alembic_cfg, autogenerate=True, message=message)
            self.logger.info("Migration created", message=message)
            
        except Exception as e:
            self.logger.error("Migration creation failed", error=str(e))
            raise
    
    async def get_migration_history(self):
        """Get database migration history."""
        try:
            from alembic import command
            from alembic.config import Config
            from io import StringIO
            
            alembic_cfg = Config("alembic.ini")
            alembic_cfg.set_main_option("sqlalchemy.url", settings.get_database_url(async_driver=False))
            
            # Capture output
            output = StringIO()
            alembic_cfg.set_main_option("file", output)
            
            command.history(alembic_cfg)
            return output.getvalue()
            
        except Exception as e:
            self.logger.error("Failed to get migration history", error=str(e))
            raise


# Global migration manager
migration_manager = DatabaseMigrationManager()


class DatabaseBackupManager:
    """Manage database backups and restoration."""
    
    def __init__(self):
        self.logger = get_logger("backup")
    
    async def create_backup(self, backup_path: str) -> bool:
        """Create database backup."""
        try:
            import subprocess
            import os
            from datetime import datetime
            
            # Generate backup filename
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = f"{backup_path}/rentguy_backup_{timestamp}.sql"
            
            # Create backup directory if it doesn't exist
            os.makedirs(backup_path, exist_ok=True)
            
            # Extract database connection details
            db_url = settings.get_database_url(async_driver=False)
            # Parse database URL and create pg_dump command
            # This is a simplified version - in production, you'd want more robust URL parsing
            
            cmd = [
                "pg_dump",
                db_url,
                "-f", backup_file,
                "--verbose",
                "--no-owner",
                "--no-privileges"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                self.logger.info("Database backup created successfully", backup_file=backup_file)
                return True
            else:
                self.logger.error("Database backup failed", error=result.stderr)
                return False
                
        except Exception as e:
            self.logger.error("Database backup failed", error=str(e))
            return False
    
    async def restore_backup(self, backup_file: str) -> bool:
        """Restore database from backup."""
        try:
            import subprocess
            
            db_url = settings.get_database_url(async_driver=False)
            
            cmd = [
                "psql",
                db_url,
                "-f", backup_file,
                "--verbose"
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                self.logger.info("Database restored successfully", backup_file=backup_file)
                return True
            else:
                self.logger.error("Database restore failed", error=result.stderr)
                return False
                
        except Exception as e:
            self.logger.error("Database restore failed", error=str(e))
            return False


# Global backup manager
backup_manager = DatabaseBackupManager()


# Startup and shutdown events
async def startup_database():
    """Initialize database on application startup."""
    await db_manager.initialize()
    logger.info("Database startup completed")


async def shutdown_database():
    """Close database connections on application shutdown."""
    await db_manager.close()
    logger.info("Database shutdown completed")
