"""
Enterprise-grade configuration management for RentGuy.
Optimized for VPS deployment with secure secret handling.
"""

import os
import secrets
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseSettings, Field, validator
from pydantic.env_settings import SettingsSourceCallable


class VPSSecretManager:
    """
    VPS-optimized secret management system.
    Handles encrypted storage and retrieval of sensitive configuration.
    """
    
    def __init__(self, secrets_dir: str = "/opt/rentguy/secrets"):
        self.secrets_dir = Path(secrets_dir)
        self.secrets_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        self._encryption_key = self._get_or_create_encryption_key()
    
    def _get_or_create_encryption_key(self) -> bytes:
        """Get or create encryption key for secrets."""
        key_file = self.secrets_dir / ".encryption_key"
        
        if key_file.exists():
            return key_file.read_bytes()
        
        # Generate new encryption key
        key = secrets.token_bytes(32)
        key_file.write_bytes(key)
        key_file.chmod(0o600)
        return key
    
    def store_secret(self, key: str, value: str) -> None:
        """Store encrypted secret on VPS."""
        from cryptography.fernet import Fernet
        import base64
        
        fernet_key = base64.urlsafe_b64encode(self._encryption_key)
        cipher = Fernet(fernet_key)
        
        encrypted_value = cipher.encrypt(value.encode())
        secret_file = self.secrets_dir / f"{key}.secret"
        secret_file.write_bytes(encrypted_value)
        secret_file.chmod(0o600)
    
    def get_secret(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Retrieve and decrypt secret from VPS."""
        secret_file = self.secrets_dir / f"{key}.secret"
        
        if not secret_file.exists():
            return default
        
        try:
            from cryptography.fernet import Fernet
            import base64
            
            fernet_key = base64.urlsafe_b64encode(self._encryption_key)
            cipher = Fernet(fernet_key)
            
            encrypted_value = secret_file.read_bytes()
            decrypted_value = cipher.decrypt(encrypted_value)
            return decrypted_value.decode()
        except Exception:
            return default
    
    def list_secrets(self) -> List[str]:
        """List available secret keys."""
        return [
            f.stem for f in self.secrets_dir.glob("*.secret")
            if not f.name.startswith(".")
        ]
    
    def delete_secret(self, key: str) -> bool:
        """Delete a secret from VPS storage."""
        secret_file = self.secrets_dir / f"{key}.secret"
        if secret_file.exists():
            secret_file.unlink()
            return True
        return False


class Settings(BaseSettings):
    """
    Enterprise-grade application settings with VPS-optimized secret management.
    """
    
    # Application Settings
    app_name: str = Field(default="RentGuy Enterprise", env="APP_NAME")
    app_version: str = Field(default="2.0.0", env="APP_VERSION")
    environment: str = Field(default="production", env="ENVIRONMENT")
    debug: bool = Field(default=False, env="DEBUG")
    testing: bool = Field(default=False, env="TESTING")
    
    # Server Settings
    host: str = Field(default="0.0.0.0", env="HOST")
    port: int = Field(default=8000, env="PORT")
    workers: int = Field(default=4, env="WORKERS")
    reload: bool = Field(default=False, env="RELOAD")
    
    # Database Settings
    database_url: str = Field(env="DATABASE_URL")
    database_pool_size: int = Field(default=20, env="DATABASE_POOL_SIZE")
    database_max_overflow: int = Field(default=30, env="DATABASE_MAX_OVERFLOW")
    database_pool_timeout: int = Field(default=30, env="DATABASE_POOL_TIMEOUT")
    database_pool_recycle: int = Field(default=3600, env="DATABASE_POOL_RECYCLE")
    
    # Redis Settings
    redis_url: str = Field(env="REDIS_URL")
    redis_max_connections: int = Field(default=50, env="REDIS_MAX_CONNECTIONS")
    redis_retry_on_timeout: bool = Field(default=True, env="REDIS_RETRY_ON_TIMEOUT")
    
    # Security Settings
    secret_key: str = Field(env="SECRET_KEY")
    access_token_expire_minutes: int = Field(default=30, env="ACCESS_TOKEN_EXPIRE_MINUTES")
    refresh_token_expire_days: int = Field(default=7, env="REFRESH_TOKEN_EXPIRE_DAYS")
    password_min_length: int = Field(default=8, env="PASSWORD_MIN_LENGTH")
    max_login_attempts: int = Field(default=5, env="MAX_LOGIN_ATTEMPTS")
    lockout_duration_minutes: int = Field(default=15, env="LOCKOUT_DURATION_MINUTES")
    
    # CORS Settings
    cors_origins: List[str] = Field(default=["*"], env="CORS_ORIGINS")
    cors_allow_credentials: bool = Field(default=True, env="CORS_ALLOW_CREDENTIALS")
    cors_allow_methods: List[str] = Field(default=["*"], env="CORS_ALLOW_METHODS")
    cors_allow_headers: List[str] = Field(default=["*"], env="CORS_ALLOW_HEADERS")
    
    # Email Settings
    smtp_host: Optional[str] = Field(default=None, env="SMTP_HOST")
    smtp_port: int = Field(default=587, env="SMTP_PORT")
    smtp_username: Optional[str] = Field(default=None, env="SMTP_USERNAME")
    smtp_password: Optional[str] = Field(default=None, env="SMTP_PASSWORD")
    smtp_use_tls: bool = Field(default=True, env="SMTP_USE_TLS")
    email_from: Optional[str] = Field(default=None, env="EMAIL_FROM")
    
    # File Storage Settings
    upload_dir: str = Field(default="/opt/rentguy/uploads", env="UPLOAD_DIR")
    max_file_size: int = Field(default=10 * 1024 * 1024, env="MAX_FILE_SIZE")  # 10MB
    allowed_file_types: List[str] = Field(
        default=["pdf", "jpg", "jpeg", "png", "doc", "docx"],
        env="ALLOWED_FILE_TYPES"
    )
    
    # Logging Settings
    log_level: str = Field(default="INFO", env="LOG_LEVEL")
    log_format: str = Field(default="json", env="LOG_FORMAT")
    log_file: Optional[str] = Field(default="/var/log/rentguy/app.log", env="LOG_FILE")
    log_max_size: int = Field(default=100 * 1024 * 1024, env="LOG_MAX_SIZE")  # 100MB
    log_backup_count: int = Field(default=5, env="LOG_BACKUP_COUNT")
    
    # Monitoring Settings
    enable_metrics: bool = Field(default=True, env="ENABLE_METRICS")
    metrics_port: int = Field(default=9090, env="METRICS_PORT")
    enable_tracing: bool = Field(default=True, env="ENABLE_TRACING")
    jaeger_endpoint: Optional[str] = Field(default=None, env="JAEGER_ENDPOINT")
    
    # Celery Settings
    celery_broker_url: Optional[str] = Field(default=None, env="CELERY_BROKER_URL")
    celery_result_backend: Optional[str] = Field(default=None, env="CELERY_RESULT_BACKEND")
    celery_task_serializer: str = Field(default="json", env="CELERY_TASK_SERIALIZER")
    celery_result_serializer: str = Field(default="json", env="CELERY_RESULT_SERIALIZER")
    
    # Rate Limiting Settings
    rate_limit_enabled: bool = Field(default=True, env="RATE_LIMIT_ENABLED")
    rate_limit_requests: int = Field(default=100, env="RATE_LIMIT_REQUESTS")
    rate_limit_window: int = Field(default=60, env="RATE_LIMIT_WINDOW")  # seconds
    
    # Backup Settings
    backup_enabled: bool = Field(default=True, env="BACKUP_ENABLED")
    backup_schedule: str = Field(default="0 2 * * *", env="BACKUP_SCHEDULE")  # Daily at 2 AM
    backup_retention_days: int = Field(default=30, env="BACKUP_RETENTION_DAYS")
    backup_location: str = Field(default="/opt/rentguy/backups", env="BACKUP_LOCATION")
    
    # Feature Flags
    enable_registration: bool = Field(default=True, env="ENABLE_REGISTRATION")
    enable_password_reset: bool = Field(default=True, env="ENABLE_PASSWORD_RESET")
    enable_email_verification: bool = Field(default=True, env="ENABLE_EMAIL_VERIFICATION")
    enable_two_factor_auth: bool = Field(default=False, env="ENABLE_TWO_FACTOR_AUTH")
    
    # VPS-specific Settings
    vps_secrets_dir: str = Field(default="/opt/rentguy/secrets", env="VPS_SECRETS_DIR")
    vps_config_dir: str = Field(default="/opt/rentguy/config", env="VPS_CONFIG_DIR")
    vps_data_dir: str = Field(default="/opt/rentguy/data", env="VPS_DATA_DIR")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        
        @classmethod
        def customise_sources(
            cls,
            init_settings: SettingsSourceCallable,
            env_settings: SettingsSourceCallable,
            file_secret_settings: SettingsSourceCallable,
        ) -> tuple[SettingsSourceCallable, ...]:
            """Custom settings sources with VPS secret manager integration."""
            return (
                init_settings,
                vps_secret_settings,
                env_settings,
                file_secret_settings,
            )
    
    @validator("cors_origins", pre=True)
    def parse_cors_origins(cls, v: Union[str, List[str]]) -> List[str]:
        """Parse CORS origins from string or list."""
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",")]
        return v
    
    @validator("allowed_file_types", pre=True)
    def parse_allowed_file_types(cls, v: Union[str, List[str]]) -> List[str]:
        """Parse allowed file types from string or list."""
        if isinstance(v, str):
            return [file_type.strip() for file_type in v.split(",")]
        return v
    
    @validator("environment")
    def validate_environment(cls, v: str) -> str:
        """Validate environment setting."""
        allowed_environments = ["development", "staging", "production", "test"]
        if v.lower() not in allowed_environments:
            raise ValueError(f"Environment must be one of: {allowed_environments}")
        return v.lower()
    
    @validator("log_level")
    def validate_log_level(cls, v: str) -> str:
        """Validate log level setting."""
        allowed_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in allowed_levels:
            raise ValueError(f"Log level must be one of: {allowed_levels}")
        return v.upper()
    
    @property
    def is_development(self) -> bool:
        """Check if running in development environment."""
        return self.environment == "development"
    
    @property
    def is_production(self) -> bool:
        """Check if running in production environment."""
        return self.environment == "production"
    
    @property
    def is_testing(self) -> bool:
        """Check if running in testing environment."""
        return self.environment == "test" or self.testing
    
    def get_database_url(self, async_driver: bool = True) -> str:
        """Get database URL with appropriate driver."""
        if async_driver and not self.database_url.startswith("postgresql+asyncpg"):
            return self.database_url.replace("postgresql://", "postgresql+asyncpg://")
        return self.database_url
    
    def create_directories(self) -> None:
        """Create necessary directories on VPS."""
        directories = [
            self.vps_secrets_dir,
            self.vps_config_dir,
            self.vps_data_dir,
            self.upload_dir,
            self.backup_location,
        ]
        
        for directory in directories:
            Path(directory).mkdir(parents=True, exist_ok=True, mode=0o755)
        
        # Set restrictive permissions for secrets directory
        Path(self.vps_secrets_dir).chmod(0o700)


def vps_secret_settings(settings: Settings) -> Dict[str, Any]:
    """
    Custom settings source that loads secrets from VPS secret manager.
    """
    secret_manager = VPSSecretManager(settings.vps_secrets_dir)
    
    # Map of setting names to secret keys
    secret_mappings = {
        "secret_key": "app_secret_key",
        "database_url": "database_url",
        "redis_url": "redis_url",
        "smtp_password": "smtp_password",
        "jaeger_endpoint": "jaeger_endpoint",
        "celery_broker_url": "celery_broker_url",
        "celery_result_backend": "celery_result_backend",
    }
    
    secrets_dict = {}
    for setting_name, secret_key in secret_mappings.items():
        secret_value = secret_manager.get_secret(secret_key)
        if secret_value:
            secrets_dict[setting_name] = secret_value
    
    return secrets_dict


@lru_cache()
def get_settings() -> Settings:
    """
    Get cached application settings.
    """
    settings = Settings()
    
    # Create necessary directories
    settings.create_directories()
    
    return settings


# Global settings instance
settings = get_settings()


class ConfigManager:
    """
    Advanced configuration management for enterprise deployment.
    """
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.secret_manager = VPSSecretManager(settings.vps_secrets_dir)
    
    def setup_secrets(self) -> None:
        """Setup initial secrets if they don't exist."""
        required_secrets = {
            "app_secret_key": self._generate_secret_key,
            "database_url": lambda: os.getenv("DATABASE_URL"),
            "redis_url": lambda: os.getenv("REDIS_URL", "redis://localhost:6379/0"),
        }
        
        for secret_key, default_generator in required_secrets.items():
            if not self.secret_manager.get_secret(secret_key):
                default_value = default_generator()
                if default_value:
                    self.secret_manager.store_secret(secret_key, default_value)
    
    def _generate_secret_key(self) -> str:
        """Generate a secure secret key."""
        return secrets.token_urlsafe(32)
    
    def validate_configuration(self) -> Dict[str, bool]:
        """Validate current configuration."""
        checks = {
            "database_connection": self._check_database_connection,
            "redis_connection": self._check_redis_connection,
            "secrets_directory": self._check_secrets_directory,
            "upload_directory": self._check_upload_directory,
            "log_directory": self._check_log_directory,
        }
        
        results = {}
        for check_name, check_func in checks.items():
            try:
                results[check_name] = check_func()
            except Exception:
                results[check_name] = False
        
        return results
    
    def _check_database_connection(self) -> bool:
        """Check database connection."""
        # Implementation would test actual database connection
        return True
    
    def _check_redis_connection(self) -> bool:
        """Check Redis connection."""
        # Implementation would test actual Redis connection
        return True
    
    def _check_secrets_directory(self) -> bool:
        """Check secrets directory permissions."""
        secrets_path = Path(self.settings.vps_secrets_dir)
        return secrets_path.exists() and oct(secrets_path.stat().st_mode)[-3:] == "700"
    
    def _check_upload_directory(self) -> bool:
        """Check upload directory."""
        upload_path = Path(self.settings.upload_dir)
        return upload_path.exists() and upload_path.is_dir()
    
    def _check_log_directory(self) -> bool:
        """Check log directory."""
        if self.settings.log_file:
            log_path = Path(self.settings.log_file).parent
            return log_path.exists() and log_path.is_dir()
        return True
    
    def export_config_template(self) -> str:
        """Export configuration template for deployment."""
        template = """
# RentGuy Enterprise Configuration Template
# Copy this file to .env and customize for your environment

# Application Settings
APP_NAME=RentGuy Enterprise
APP_VERSION=2.0.0
ENVIRONMENT=production
DEBUG=false

# Server Settings
HOST=0.0.0.0
PORT=8000
WORKERS=4

# Database Settings (will be stored as secret)
DATABASE_URL=postgresql://user:password@localhost:5432/rentguy

# Redis Settings (will be stored as secret)
REDIS_URL=redis://localhost:6379/0

# Security Settings (will be generated automatically)
# SECRET_KEY=<auto-generated>
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Email Settings
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USERNAME=noreply@example.com
EMAIL_FROM=noreply@example.com

# Logging Settings
LOG_LEVEL=INFO
LOG_FORMAT=json
LOG_FILE=/var/log/rentguy/app.log

# Monitoring Settings
ENABLE_METRICS=true
ENABLE_TRACING=true

# VPS Settings
VPS_SECRETS_DIR=/opt/rentguy/secrets
VPS_CONFIG_DIR=/opt/rentguy/config
VPS_DATA_DIR=/opt/rentguy/data
"""
        return template.strip()


# Initialize configuration manager
config_manager = ConfigManager(settings)
