"""
Enterprise-grade monitoring and observability system for RentGuy.
Provides comprehensive metrics, tracing, and health monitoring.
"""

import asyncio
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union

import psutil
from prometheus_client import (
    Counter, Histogram, Gauge, Info, CollectorRegistry,
    generate_latest, CONTENT_TYPE_LATEST, start_http_server
)
from opentelemetry import trace, metrics
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.exporter.prometheus import PrometheusMetricReader
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor
from opentelemetry.instrumentation.redis import RedisInstrumentor
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.resources import Resource

from .config import settings
from .logging import get_logger, performance_logger

logger = get_logger(__name__)


class MetricsCollector:
    """
    Comprehensive metrics collection for application monitoring.
    """
    
    def __init__(self):
        self.registry = CollectorRegistry()
        self._setup_metrics()
    
    def _setup_metrics(self):
        """Initialize Prometheus metrics."""
        
        # HTTP Request metrics
        self.http_requests_total = Counter(
            'http_requests_total',
            'Total HTTP requests',
            ['method', 'endpoint', 'status_code'],
            registry=self.registry
        )
        
        self.http_request_duration = Histogram(
            'http_request_duration_seconds',
            'HTTP request duration in seconds',
            ['method', 'endpoint'],
            registry=self.registry
        )
        
        self.http_request_size = Histogram(
            'http_request_size_bytes',
            'HTTP request size in bytes',
            ['method', 'endpoint'],
            registry=self.registry
        )
        
        self.http_response_size = Histogram(
            'http_response_size_bytes',
            'HTTP response size in bytes',
            ['method', 'endpoint'],
            registry=self.registry
        )
        
        # Database metrics
        self.db_connections_active = Gauge(
            'db_connections_active',
            'Active database connections',
            registry=self.registry
        )
        
        self.db_connections_idle = Gauge(
            'db_connections_idle',
            'Idle database connections',
            registry=self.registry
        )
        
        self.db_query_duration = Histogram(
            'db_query_duration_seconds',
            'Database query duration in seconds',
            ['operation', 'table'],
            registry=self.registry
        )
        
        self.db_queries_total = Counter(
            'db_queries_total',
            'Total database queries',
            ['operation', 'table', 'status'],
            registry=self.registry
        )
        
        # Business metrics
        self.users_total = Gauge(
            'users_total',
            'Total number of users',
            ['status'],
            registry=self.registry
        )
        
        self.equipment_total = Gauge(
            'equipment_total',
            'Total number of equipment items',
            ['status'],
            registry=self.registry
        )
        
        self.rentals_total = Counter(
            'rentals_total',
            'Total number of rentals',
            ['status'],
            registry=self.registry
        )
        
        self.rental_revenue = Counter(
            'rental_revenue_total',
            'Total rental revenue',
            ['currency'],
            registry=self.registry
        )
        
        self.equipment_utilization = Gauge(
            'equipment_utilization_rate',
            'Equipment utilization rate',
            ['equipment_id', 'category'],
            registry=self.registry
        )
        
        # System metrics
        self.system_cpu_usage = Gauge(
            'system_cpu_usage_percent',
            'System CPU usage percentage',
            registry=self.registry
        )
        
        self.system_memory_usage = Gauge(
            'system_memory_usage_bytes',
            'System memory usage in bytes',
            registry=self.registry
        )
        
        self.system_disk_usage = Gauge(
            'system_disk_usage_bytes',
            'System disk usage in bytes',
            ['mount_point'],
            registry=self.registry
        )
        
        # Application metrics
        self.app_startup_time = Gauge(
            'app_startup_time_seconds',
            'Application startup time in seconds',
            registry=self.registry
        )
        
        self.app_errors_total = Counter(
            'app_errors_total',
            'Total application errors',
            ['error_type', 'component'],
            registry=self.registry
        )
        
        self.app_cache_hits = Counter(
            'app_cache_hits_total',
            'Total cache hits',
            ['cache_type'],
            registry=self.registry
        )
        
        self.app_cache_misses = Counter(
            'app_cache_misses_total',
            'Total cache misses',
            ['cache_type'],
            registry=self.registry
        )
        
        # Security metrics
        self.auth_attempts_total = Counter(
            'auth_attempts_total',
            'Total authentication attempts',
            ['result', 'method'],
            registry=self.registry
        )
        
        self.failed_logins_total = Counter(
            'failed_logins_total',
            'Total failed login attempts',
            ['reason'],
            registry=self.registry
        )
        
        self.active_sessions = Gauge(
            'active_sessions_total',
            'Total active user sessions',
            registry=self.registry
        )
        
        # Application info
        self.app_info = Info(
            'app_info',
            'Application information',
            registry=self.registry
        )
        
        self.app_info.info({
            'version': settings.app_version,
            'environment': settings.environment,
            'name': settings.app_name
        })
    
    def record_http_request(self, method: str, endpoint: str, status_code: int, 
                           duration: float, request_size: int = 0, response_size: int = 0):
        """Record HTTP request metrics."""
        self.http_requests_total.labels(
            method=method,
            endpoint=endpoint,
            status_code=status_code
        ).inc()
        
        self.http_request_duration.labels(
            method=method,
            endpoint=endpoint
        ).observe(duration)
        
        if request_size > 0:
            self.http_request_size.labels(
                method=method,
                endpoint=endpoint
            ).observe(request_size)
        
        if response_size > 0:
            self.http_response_size.labels(
                method=method,
                endpoint=endpoint
            ).observe(response_size)
    
    def record_db_query(self, operation: str, table: str, duration: float, status: str = "success"):
        """Record database query metrics."""
        self.db_queries_total.labels(
            operation=operation,
            table=table,
            status=status
        ).inc()
        
        self.db_query_duration.labels(
            operation=operation,
            table=table
        ).observe(duration)
    
    def update_db_connections(self, active: int, idle: int):
        """Update database connection metrics."""
        self.db_connections_active.set(active)
        self.db_connections_idle.set(idle)
    
    def record_business_metrics(self, users_by_status: Dict[str, int], 
                               equipment_by_status: Dict[str, int]):
        """Update business metrics."""
        for status, count in users_by_status.items():
            self.users_total.labels(status=status).set(count)
        
        for status, count in equipment_by_status.items():
            self.equipment_total.labels(status=status).set(count)
    
    def record_rental(self, status: str, revenue: float = 0.0, currency: str = "EUR"):
        """Record rental metrics."""
        self.rentals_total.labels(status=status).inc()
        
        if revenue > 0:
            self.rental_revenue.labels(currency=currency).inc(revenue)
    
    def update_equipment_utilization(self, equipment_id: str, category: str, rate: float):
        """Update equipment utilization metrics."""
        self.equipment_utilization.labels(
            equipment_id=equipment_id,
            category=category
        ).set(rate)
    
    def update_system_metrics(self):
        """Update system resource metrics."""
        # CPU usage
        cpu_percent = psutil.cpu_percent(interval=1)
        self.system_cpu_usage.set(cpu_percent)
        
        # Memory usage
        memory = psutil.virtual_memory()
        self.system_memory_usage.set(memory.used)
        
        # Disk usage
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                self.system_disk_usage.labels(
                    mount_point=partition.mountpoint
                ).set(usage.used)
            except PermissionError:
                continue
    
    def record_error(self, error_type: str, component: str):
        """Record application error."""
        self.app_errors_total.labels(
            error_type=error_type,
            component=component
        ).inc()
    
    def record_cache_operation(self, cache_type: str, hit: bool):
        """Record cache operation."""
        if hit:
            self.app_cache_hits.labels(cache_type=cache_type).inc()
        else:
            self.app_cache_misses.labels(cache_type=cache_type).inc()
    
    def record_auth_attempt(self, result: str, method: str = "password"):
        """Record authentication attempt."""
        self.auth_attempts_total.labels(result=result, method=method).inc()
        
        if result == "failed":
            self.failed_logins_total.labels(reason="invalid_credentials").inc()
    
    def update_active_sessions(self, count: int):
        """Update active sessions count."""
        self.active_sessions.set(count)
    
    def get_metrics(self) -> str:
        """Get Prometheus metrics in text format."""
        return generate_latest(self.registry).decode('utf-8')


class DistributedTracing:
    """
    Distributed tracing implementation using OpenTelemetry.
    """
    
    def __init__(self):
        self.tracer_provider = None
        self.tracer = None
        self._setup_tracing()
    
    def _setup_tracing(self):
        """Setup OpenTelemetry tracing."""
        if not settings.enable_tracing:
            return
        
        # Create resource
        resource = Resource.create({
            "service.name": settings.app_name,
            "service.version": settings.app_version,
            "service.environment": settings.environment,
        })
        
        # Create tracer provider
        self.tracer_provider = TracerProvider(resource=resource)
        trace.set_tracer_provider(self.tracer_provider)
        
        # Setup Jaeger exporter if configured
        if settings.jaeger_endpoint:
            jaeger_exporter = JaegerExporter(
                agent_host_name="localhost",
                agent_port=14268,
                collector_endpoint=settings.jaeger_endpoint,
            )
            
            span_processor = BatchSpanProcessor(jaeger_exporter)
            self.tracer_provider.add_span_processor(span_processor)
        
        # Get tracer
        self.tracer = trace.get_tracer(__name__)
        
        logger.info("Distributed tracing initialized")
    
    @asynccontextmanager
    async def trace_operation(self, operation_name: str, **attributes):
        """Context manager for tracing operations."""
        if not self.tracer:
            yield None
            return
        
        with self.tracer.start_as_current_span(operation_name) as span:
            # Add attributes
            for key, value in attributes.items():
                span.set_attribute(key, str(value))
            
            try:
                yield span
            except Exception as e:
                span.record_exception(e)
                span.set_status(trace.Status(trace.StatusCode.ERROR, str(e)))
                raise
    
    def instrument_fastapi(self, app):
        """Instrument FastAPI application."""
        if self.tracer_provider:
            FastAPIInstrumentor.instrument_app(app, tracer_provider=self.tracer_provider)
    
    def instrument_sqlalchemy(self, engine):
        """Instrument SQLAlchemy engine."""
        if self.tracer_provider:
            SQLAlchemyInstrumentor().instrument(
                engine=engine,
                tracer_provider=self.tracer_provider
            )
    
    def instrument_redis(self):
        """Instrument Redis client."""
        if self.tracer_provider:
            RedisInstrumentor().instrument(tracer_provider=self.tracer_provider)


class HealthChecker:
    """
    Comprehensive health checking system.
    """
    
    def __init__(self):
        self.checks = {}
        self.last_check_results = {}
        self._register_default_checks()
    
    def _register_default_checks(self):
        """Register default health checks."""
        self.register_check("database", self._check_database)
        self.register_check("redis", self._check_redis)
        self.register_check("disk_space", self._check_disk_space)
        self.register_check("memory", self._check_memory)
        self.register_check("external_apis", self._check_external_apis)
    
    def register_check(self, name: str, check_func):
        """Register a health check function."""
        self.checks[name] = check_func
        logger.info(f"Health check registered: {name}")
    
    async def _check_database(self) -> Dict[str, Any]:
        """Check database connectivity and performance."""
        try:
            from .database import db_manager
            
            start_time = time.time()
            health_info = await db_manager.health_check()
            duration = time.time() - start_time
            
            return {
                "status": "healthy" if health_info["status"] == "healthy" else "unhealthy",
                "response_time_ms": round(duration * 1000, 2),
                "details": health_info
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "response_time_ms": None
            }
    
    async def _check_redis(self) -> Dict[str, Any]:
        """Check Redis connectivity."""
        try:
            import redis.asyncio as redis
            
            client = redis.from_url(settings.redis_url)
            start_time = time.time()
            
            await client.ping()
            duration = time.time() - start_time
            
            info = await client.info()
            await client.close()
            
            return {
                "status": "healthy",
                "response_time_ms": round(duration * 1000, 2),
                "details": {
                    "version": info.get("redis_version"),
                    "connected_clients": info.get("connected_clients"),
                    "used_memory": info.get("used_memory_human")
                }
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "response_time_ms": None
            }
    
    async def _check_disk_space(self) -> Dict[str, Any]:
        """Check disk space availability."""
        try:
            disk_usage = psutil.disk_usage('/')
            free_percent = (disk_usage.free / disk_usage.total) * 100
            
            status = "healthy" if free_percent > 10 else "unhealthy"
            
            return {
                "status": status,
                "details": {
                    "total_gb": round(disk_usage.total / (1024**3), 2),
                    "used_gb": round(disk_usage.used / (1024**3), 2),
                    "free_gb": round(disk_usage.free / (1024**3), 2),
                    "free_percent": round(free_percent, 2)
                }
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    async def _check_memory(self) -> Dict[str, Any]:
        """Check memory usage."""
        try:
            memory = psutil.virtual_memory()
            available_percent = memory.available / memory.total * 100
            
            status = "healthy" if available_percent > 10 else "unhealthy"
            
            return {
                "status": status,
                "details": {
                    "total_gb": round(memory.total / (1024**3), 2),
                    "available_gb": round(memory.available / (1024**3), 2),
                    "used_percent": round(memory.percent, 2),
                    "available_percent": round(available_percent, 2)
                }
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    async def _check_external_apis(self) -> Dict[str, Any]:
        """Check external API dependencies."""
        # This would check external services like payment processors, etc.
        return {
            "status": "healthy",
            "details": {
                "external_services": "No external dependencies configured"
            }
        }
    
    async def run_check(self, check_name: str) -> Dict[str, Any]:
        """Run a specific health check."""
        if check_name not in self.checks:
            return {
                "status": "unknown",
                "error": f"Check '{check_name}' not found"
            }
        
        try:
            start_time = time.time()
            result = await self.checks[check_name]()
            duration = time.time() - start_time
            
            result["check_duration_ms"] = round(duration * 1000, 2)
            result["timestamp"] = datetime.utcnow().isoformat()
            
            self.last_check_results[check_name] = result
            return result
            
        except Exception as e:
            error_result = {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
            self.last_check_results[check_name] = error_result
            return error_result
    
    async def run_all_checks(self) -> Dict[str, Any]:
        """Run all registered health checks."""
        results = {}
        overall_status = "healthy"
        
        for check_name in self.checks.keys():
            result = await self.run_check(check_name)
            results[check_name] = result
            
            if result["status"] in ["unhealthy", "error"]:
                overall_status = "unhealthy"
        
        return {
            "status": overall_status,
            "timestamp": datetime.utcnow().isoformat(),
            "checks": results
        }
    
    def get_last_results(self) -> Dict[str, Any]:
        """Get last health check results."""
        return self.last_check_results


class AlertManager:
    """
    Alert management system for monitoring events.
    """
    
    def __init__(self):
        self.alert_rules = []
        self.active_alerts = {}
        self.alert_history = []
        self._setup_default_rules()
    
    def _setup_default_rules(self):
        """Setup default alert rules."""
        self.add_rule(
            name="high_cpu_usage",
            condition=lambda metrics: metrics.get("cpu_percent", 0) > 80,
            severity="warning",
            message="High CPU usage detected: {cpu_percent}%"
        )
        
        self.add_rule(
            name="low_disk_space",
            condition=lambda metrics: metrics.get("disk_free_percent", 100) < 10,
            severity="critical",
            message="Low disk space: {disk_free_percent}% remaining"
        )
        
        self.add_rule(
            name="database_connection_failure",
            condition=lambda metrics: metrics.get("db_status") == "unhealthy",
            severity="critical",
            message="Database connection failure detected"
        )
        
        self.add_rule(
            name="high_error_rate",
            condition=lambda metrics: metrics.get("error_rate", 0) > 5,
            severity="warning",
            message="High error rate detected: {error_rate}%"
        )
    
    def add_rule(self, name: str, condition, severity: str, message: str):
        """Add an alert rule."""
        rule = {
            "name": name,
            "condition": condition,
            "severity": severity,
            "message": message,
            "created_at": datetime.utcnow()
        }
        self.alert_rules.append(rule)
        logger.info(f"Alert rule added: {name}")
    
    def evaluate_rules(self, metrics: Dict[str, Any]):
        """Evaluate all alert rules against current metrics."""
        for rule in self.alert_rules:
            try:
                if rule["condition"](metrics):
                    self._trigger_alert(rule, metrics)
                else:
                    self._resolve_alert(rule["name"])
            except Exception as e:
                logger.error(f"Error evaluating alert rule {rule['name']}: {e}")
    
    def _trigger_alert(self, rule: Dict[str, Any], metrics: Dict[str, Any]):
        """Trigger an alert."""
        alert_id = rule["name"]
        
        if alert_id in self.active_alerts:
            # Update existing alert
            self.active_alerts[alert_id]["last_triggered"] = datetime.utcnow()
            self.active_alerts[alert_id]["trigger_count"] += 1
        else:
            # Create new alert
            alert = {
                "id": alert_id,
                "rule": rule["name"],
                "severity": rule["severity"],
                "message": rule["message"].format(**metrics),
                "triggered_at": datetime.utcnow(),
                "last_triggered": datetime.utcnow(),
                "trigger_count": 1,
                "resolved": False,
                "metrics": metrics
            }
            
            self.active_alerts[alert_id] = alert
            self.alert_history.append(alert.copy())
            
            # Send notification
            self._send_alert_notification(alert)
            
            logger.warning(f"Alert triggered: {alert['message']}")
    
    def _resolve_alert(self, alert_id: str):
        """Resolve an active alert."""
        if alert_id in self.active_alerts:
            alert = self.active_alerts[alert_id]
            alert["resolved"] = True
            alert["resolved_at"] = datetime.utcnow()
            
            # Send resolution notification
            self._send_resolution_notification(alert)
            
            # Remove from active alerts
            del self.active_alerts[alert_id]
            
            logger.info(f"Alert resolved: {alert_id}")
    
    def _send_alert_notification(self, alert: Dict[str, Any]):
        """Send alert notification (implement based on requirements)."""
        # This could send emails, Slack messages, webhooks, etc.
        logger.warning(f"ALERT: {alert['message']}")
    
    def _send_resolution_notification(self, alert: Dict[str, Any]):
        """Send alert resolution notification."""
        logger.info(f"RESOLVED: Alert {alert['id']} has been resolved")
    
    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """Get all active alerts."""
        return list(self.active_alerts.values())
    
    def get_alert_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get alert history."""
        return self.alert_history[-limit:]


class MonitoringManager:
    """
    Central monitoring manager that coordinates all monitoring components.
    """
    
    def __init__(self):
        self.metrics_collector = MetricsCollector()
        self.distributed_tracing = DistributedTracing()
        self.health_checker = HealthChecker()
        self.alert_manager = AlertManager()
        self.monitoring_task = None
        self.is_running = False
    
    async def start_monitoring(self):
        """Start the monitoring system."""
        if self.is_running:
            return
        
        self.is_running = True
        
        # Start Prometheus metrics server
        if settings.enable_metrics:
            start_http_server(settings.metrics_port)
            logger.info(f"Prometheus metrics server started on port {settings.metrics_port}")
        
        # Start monitoring loop
        self.monitoring_task = asyncio.create_task(self._monitoring_loop())
        
        logger.info("Monitoring system started")
    
    async def stop_monitoring(self):
        """Stop the monitoring system."""
        self.is_running = False
        
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
        
        logger.info("Monitoring system stopped")
    
    async def _monitoring_loop(self):
        """Main monitoring loop."""
        while self.is_running:
            try:
                # Update system metrics
                self.metrics_collector.update_system_metrics()
                
                # Run health checks
                health_results = await self.health_checker.run_all_checks()
                
                # Prepare metrics for alert evaluation
                metrics = {
                    "cpu_percent": psutil.cpu_percent(),
                    "memory_percent": psutil.virtual_memory().percent,
                    "disk_free_percent": (psutil.disk_usage('/').free / psutil.disk_usage('/').total) * 100,
                    "db_status": health_results["checks"].get("database", {}).get("status", "unknown"),
                    "redis_status": health_results["checks"].get("redis", {}).get("status", "unknown")
                }
                
                # Evaluate alert rules
                self.alert_manager.evaluate_rules(metrics)
                
                # Wait before next iteration
                await asyncio.sleep(30)  # Run every 30 seconds
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(60)  # Wait longer on error
    
    def get_monitoring_status(self) -> Dict[str, Any]:
        """Get overall monitoring system status."""
        return {
            "is_running": self.is_running,
            "metrics_enabled": settings.enable_metrics,
            "tracing_enabled": settings.enable_tracing,
            "active_alerts": len(self.alert_manager.get_active_alerts()),
            "last_health_check": self.health_checker.get_last_results(),
            "uptime": time.time() - (getattr(self, 'start_time', time.time()))
        }


# Global monitoring manager instance
monitoring_manager = MonitoringManager()

# Convenience functions
def get_metrics_collector() -> MetricsCollector:
    """Get the global metrics collector."""
    return monitoring_manager.metrics_collector

def get_tracer():
    """Get the global tracer."""
    return monitoring_manager.distributed_tracing.tracer

def get_health_checker() -> HealthChecker:
    """Get the global health checker."""
    return monitoring_manager.health_checker

def get_alert_manager() -> AlertManager:
    """Get the global alert manager."""
    return monitoring_manager.alert_manager
