"""
CRM API routes for RentGuy Enterprise.
Integrates with existing API versioning and authentication systems.
"""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from ...core.database import get_db
from ...core.security import get_current_user, require_permissions
from ...models.models import User
from ...api.versioning import get_api_version
from ..models.crm_models import Lead, Opportunity, Campaign, LeadSource
from ..schemas.lead_schemas import (
    LeadCreate, LeadUpdate, LeadResponse, LeadListResponse,
    LeadConversionRequest, LeadConversionResponse,
    LeadSearchRequest, LeadBulkAction, LeadBulkActionResponse
)
from ..services.crm_service import CRMService, CRMEmailService

# Create router with prefix and tags
router = APIRouter(prefix="/crm", tags=["CRM"])


# Lead Management Endpoints

@router.post("/leads", response_model=LeadResponse, status_code=status.HTTP_201_CREATED)
async def create_lead(
    lead_data: LeadCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
    api_version: str = Depends(get_api_version)
):
    """
    Create a new lead.
    
    Requires: CRM_WRITE permission
    """
    # Check permissions
    if not current_user.has_permission("CRM_WRITE"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to create leads"
        )
    
    crm_service = CRMService(db)
    
    try:
        # Check for duplicate email
        existing_lead = db.query(Lead).filter(Lead.email == lead_data.email).first()
        if existing_lead:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Lead with email {lead_data.email} already exists"
            )
        
        # Create lead
        lead = crm_service.create_lead(lead_data, current_user.id)
        
        # Send welcome email if configured
        email_service = CRMEmailService(db)
        email_service.send_lead_welcome_email(lead)
        
        return LeadResponse.from_orm(lead)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create lead: {str(e)}"
        )


@router.get("/leads/{lead_id}", response_model=LeadResponse)
async def get_lead(
    lead_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get a specific lead by ID.
    
    Requires: CRM_READ permission
    """
    if not current_user.has_permission("CRM_READ"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to read leads"
        )
    
    lead = db.query(Lead).filter(Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Lead not found"
        )
    
    # Check if user can access this lead (assigned or admin)
    if (lead.assigned_to != current_user.id and 
        not current_user.has_permission("CRM_ADMIN")):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this lead"
        )
    
    return LeadResponse.from_orm(lead)


@router.put("/leads/{lead_id}", response_model=LeadResponse)
async def update_lead(
    lead_id: UUID,
    lead_data: LeadUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Update an existing lead.
    
    Requires: CRM_WRITE permission
    """
    if not current_user.has_permission("CRM_WRITE"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to update leads"
        )
    
    crm_service = CRMService(db)
    lead = crm_service.update_lead(lead_id, lead_data, current_user.id)
    
    if not lead:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Lead not found"
        )
    
    return LeadResponse.from_orm(lead)


@router.delete("/leads/{lead_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_lead(
    lead_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Delete a lead.
    
    Requires: CRM_ADMIN permission
    """
    if not current_user.has_permission("CRM_ADMIN"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to delete leads"
        )
    
    lead = db.query(Lead).filter(Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Lead not found"
        )
    
    db.delete(lead)
    db.commit()


@router.post("/leads/search", response_model=LeadListResponse)
async def search_leads(
    search_request: LeadSearchRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Advanced lead search with filtering and pagination.
    
    Requires: CRM_READ permission
    """
    if not current_user.has_permission("CRM_READ"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to search leads"
        )
    
    crm_service = CRMService(db)
    
    # Restrict to assigned leads if not admin
    if not current_user.has_permission("CRM_ADMIN"):
        if not search_request.assigned_to:
            search_request.assigned_to = [current_user.id]
        elif current_user.id not in search_request.assigned_to:
            search_request.assigned_to.append(current_user.id)
    
    leads, total = crm_service.search_leads(search_request)
    
    # Calculate pagination info
    pages = (total + search_request.per_page - 1) // search_request.per_page
    has_next = search_request.page < pages
    has_prev = search_request.page > 1
    
    return LeadListResponse(
        leads=[LeadResponse.from_orm(lead) for lead in leads],
        total=total,
        page=search_request.page,
        per_page=search_request.per_page,
        pages=pages,
        has_next=has_next,
        has_prev=has_prev
    )


@router.post("/leads/{lead_id}/convert", response_model=LeadConversionResponse)
async def convert_lead_to_user(
    lead_id: UUID,
    conversion_data: LeadConversionRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Convert a qualified lead to a registered user.
    
    Requires: CRM_WRITE permission
    """
    if not current_user.has_permission("CRM_WRITE"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to convert leads"
        )
    
    crm_service = CRMService(db)
    
    # Prepare user data
    user_data = conversion_data.dict()
    
    # Hash password
    from ...core.security import password_manager
    user_data['password_hash'] = password_manager.hash_password(user_data.pop('password'))
    
    user = crm_service.convert_lead_to_user(lead_id, user_data, current_user.id)
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Lead not found or not qualified for conversion"
        )
    
    return LeadConversionResponse(
        success=True,
        message="Lead successfully converted to user",
        user_id=user.id,
        lead_id=lead_id,
        converted_at=datetime.utcnow()
    )


@router.post("/leads/bulk-action", response_model=LeadBulkActionResponse)
async def bulk_lead_action(
    bulk_action: LeadBulkAction,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Perform bulk actions on multiple leads.
    
    Requires: CRM_WRITE permission (CRM_ADMIN for delete)
    """
    if not current_user.has_permission("CRM_WRITE"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions for bulk actions"
        )
    
    if bulk_action.action == "delete" and not current_user.has_permission("CRM_ADMIN"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to delete leads"
        )
    
    processed_count = 0
    failed_count = 0
    errors = []
    
    for lead_id in bulk_action.lead_ids:
        try:
            lead = db.query(Lead).filter(Lead.id == lead_id).first()
            if not lead:
                errors.append(f"Lead {lead_id} not found")
                failed_count += 1
                continue
            
            if bulk_action.action == "assign" and bulk_action.assigned_to:
                lead.assigned_to = bulk_action.assigned_to
            elif bulk_action.action == "status_change" and bulk_action.new_status:
                lead.lead_status = bulk_action.new_status
            elif bulk_action.action == "delete":
                db.delete(lead)
            elif bulk_action.action == "tag" and bulk_action.tag_ids:
                # Add tags to lead (implementation depends on tag relationship)
                pass
            
            processed_count += 1
            
        except Exception as e:
            errors.append(f"Failed to process lead {lead_id}: {str(e)}")
            failed_count += 1
    
    db.commit()
    
    return LeadBulkActionResponse(
        success=failed_count == 0,
        processed_count=processed_count,
        failed_count=failed_count,
        errors=errors
    )


# Lead Source Management

@router.get("/lead-sources", response_model=List[dict])
async def get_lead_sources(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get all lead sources.
    
    Requires: CRM_READ permission
    """
    if not current_user.has_permission("CRM_READ"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to read lead sources"
        )
    
    sources = db.query(LeadSource).filter(LeadSource.is_active == True).all()
    return [
        {
            "id": str(source.id),
            "name": source.name,
            "description": source.description,
            "total_leads": source.total_leads,
            "converted_leads": source.converted_leads,
            "conversion_rate": source.conversion_rate,
            "cost_per_lead": float(source.cost_per_lead),
            "cost_per_conversion": float(source.cost_per_conversion)
        }
        for source in sources
    ]


# CRM Dashboard and Analytics

@router.get("/dashboard", response_model=dict)
async def get_crm_dashboard(
    date_range: int = Query(default=30, ge=1, le=365, description="Date range in days"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get CRM dashboard metrics.
    
    Requires: CRM_READ permission
    """
    if not current_user.has_permission("CRM_READ"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to view CRM dashboard"
        )
    
    crm_service = CRMService(db)
    metrics = crm_service.get_crm_dashboard_metrics(date_range)
    
    return {
        "success": True,
        "data": metrics,
        "generated_at": datetime.utcnow().isoformat(),
        "user_id": str(current_user.id)
    }


# AI-Powered Features

@router.post("/leads/{lead_id}/ai-analysis")
async def trigger_ai_lead_analysis(
    lead_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Trigger AI analysis for lead qualification.
    
    Requires: CRM_WRITE permission
    """
    if not current_user.has_permission("CRM_WRITE"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to trigger AI analysis"
        )
    
    lead = db.query(Lead).filter(Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Lead not found"
        )
    
    crm_service = CRMService(db)
    
    try:
        # Trigger AI analysis
        crm_service._trigger_ai_lead_analysis(lead)
        
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "success": True,
                "message": "AI analysis triggered successfully",
                "lead_id": str(lead_id)
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to trigger AI analysis: {str(e)}"
        )


@router.get("/leads/{lead_id}/recommendations")
async def get_lead_recommendations(
    lead_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get AI-powered recommendations for lead engagement.
    
    Requires: CRM_READ permission
    """
    if not current_user.has_permission("CRM_READ"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to view recommendations"
        )
    
    lead = db.query(Lead).filter(Lead.id == lead_id).first()
    if not lead:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Lead not found"
        )
    
    try:
        # Import AI service
        from ...ai.customer_service import CustomerServiceAI
        
        ai_service = CustomerServiceAI()
        
        # Generate recommendations
        recommendations = ai_service.generate_lead_engagement_recommendations(
            lead_data={
                "lead_id": str(lead.id),
                "lead_status": lead.lead_status,
                "lead_score": lead.lead_score,
                "company_name": lead.company_name,
                "industry": lead.industry,
                "estimated_budget": float(lead.estimated_budget) if lead.estimated_budget else None,
                "rental_timeframe": lead.rental_timeframe,
                "days_since_first_contact": lead.days_since_first_contact
            }
        )
        
        return {
            "success": True,
            "lead_id": str(lead_id),
            "recommendations": recommendations,
            "generated_at": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "success": False,
                "error": f"Failed to generate recommendations: {str(e)}"
            }
        )


# Health Check

@router.get("/health")
async def crm_health_check():
    """CRM module health check."""
    return {
        "status": "healthy",
        "module": "CRM",
        "version": "1.0",
        "timestamp": datetime.utcnow().isoformat(),
        "features": [
            "lead_management",
            "opportunity_tracking", 
            "campaign_automation",
            "ai_integration",
            "email_automation"
        ]
    }
