"""
Enterprise CRM models for RentGuy.
Seamlessly integrates with existing User, Equipment, and Rental models.
"""

from datetime import datetime, date
from decimal import Decimal
from enum import Enum
from typing import List, Optional

from sqlalchemy import (
    Column, String, Text, Boolean, Integer, Numeric, Date, DateTime,
    ForeignKey, Table, Index, CheckConstraint, UniqueConstraint
)
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship, validates
from sqlalchemy.ext.hybrid import hybrid_property

from ...models.base import EnterpriseBaseModel, model_registry


# Association tables for many-to-many relationships
lead_tags_table = Table(
    'lead_tags',
    EnterpriseBaseModel.metadata,
    Column('lead_id', UUID(as_uuid=True), ForeignKey('crm_leads.id'), primary_key=True),
    Column('tag_id', UUID(as_uuid=True), ForeignKey('crm_tags.id'), primary_key=True),
    Column('tagged_at', DateTime, default=datetime.utcnow)
)

opportunity_tags_table = Table(
    'opportunity_tags',
    EnterpriseBaseModel.metadata,
    Column('opportunity_id', UUID(as_uuid=True), ForeignKey('crm_opportunities.id'), primary_key=True),
    Column('tag_id', UUID(as_uuid=True), ForeignKey('crm_tags.id'), primary_key=True),
    Column('tagged_at', DateTime, default=datetime.utcnow)
)


class LeadStatus(str, Enum):
    """Lead status enumeration."""
    NEW = "new"
    CONTACTED = "contacted"
    QUALIFIED = "qualified"
    UNQUALIFIED = "unqualified"
    CONVERTED = "converted"
    LOST = "lost"


class OpportunityStatus(str, Enum):
    """Opportunity status enumeration."""
    PROSPECTING = "prospecting"
    QUALIFICATION = "qualification"
    PROPOSAL = "proposal"
    NEGOTIATION = "negotiation"
    CLOSED_WON = "closed_won"
    CLOSED_LOST = "closed_lost"


class CampaignStatus(str, Enum):
    """Campaign status enumeration."""
    DRAFT = "draft"
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class ActivityType(str, Enum):
    """CRM activity type enumeration."""
    CALL = "call"
    EMAIL = "email"
    MEETING = "meeting"
    TASK = "task"
    NOTE = "note"
    QUOTE_SENT = "quote_sent"
    PROPOSAL_SENT = "proposal_sent"
    CONTRACT_SIGNED = "contract_signed"


class LeadSource(EnterpriseBaseModel):
    """Lead source tracking model."""
    
    __tablename__ = 'crm_lead_sources'
    
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    cost_per_lead = Column(Numeric(8, 2), default=0.00, nullable=False)
    
    # Tracking
    total_leads = Column(Integer, default=0, nullable=False)
    converted_leads = Column(Integer, default=0, nullable=False)
    
    # Relationships
    leads = relationship("Lead", back_populates="source")
    
    @hybrid_property
    def conversion_rate(self) -> float:
        """Calculate conversion rate percentage."""
        if self.total_leads == 0:
            return 0.0
        return (self.converted_leads / self.total_leads) * 100
    
    @hybrid_property
    def cost_per_conversion(self) -> Decimal:
        """Calculate cost per conversion."""
        if self.converted_leads == 0:
            return Decimal('0.00')
        return (self.cost_per_lead * self.total_leads) / self.converted_leads


class Lead(EnterpriseBaseModel):
    """
    Lead model that integrates with existing User model.
    Represents potential customers before they become registered users.
    """
    
    __tablename__ = 'crm_leads'
    
    # Basic information
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    email = Column(String(255), nullable=False, index=True)
    phone = Column(String(20), nullable=True)
    
    # Company information
    company_name = Column(String(255), nullable=True)
    job_title = Column(String(100), nullable=True)
    company_size = Column(String(50), nullable=True)  # 1-10, 11-50, 51-200, etc.
    industry = Column(String(100), nullable=True)
    
    # Address information
    address_line1 = Column(String(255), nullable=True)
    city = Column(String(100), nullable=True)
    country = Column(String(100), default="Netherlands", nullable=False)
    
    # Lead tracking
    lead_status = Column(String(50), default=LeadStatus.NEW, nullable=False)
    lead_score = Column(Integer, default=0, nullable=False)  # 0-100 scoring
    source_id = Column(UUID(as_uuid=True), ForeignKey('crm_lead_sources.id'), nullable=True)
    
    # Assignment and ownership
    assigned_to = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)
    converted_user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)
    
    # Interest and qualification
    interested_equipment = Column(ARRAY(String), nullable=True)
    estimated_budget = Column(Numeric(10, 2), nullable=True)
    rental_timeframe = Column(String(50), nullable=True)  # immediate, 1-3months, 3-6months, etc.
    
    # Tracking dates
    first_contact_date = Column(DateTime, nullable=True)
    last_contact_date = Column(DateTime, nullable=True)
    qualified_date = Column(DateTime, nullable=True)
    converted_date = Column(DateTime, nullable=True)
    
    # Additional information
    notes = Column(Text, nullable=True)
    custom_fields = Column(JSONB, nullable=True)
    
    # Relationships
    source = relationship("LeadSource", back_populates="leads")
    assigned_user = relationship("User", foreign_keys=[assigned_to])
    converted_user = relationship("User", foreign_keys=[converted_user_id])
    activities = relationship("CRMActivity", back_populates="lead", cascade="all, delete-orphan")
    opportunities = relationship("Opportunity", back_populates="lead")
    tags = relationship("CRMTag", secondary=lead_tags_table, back_populates="leads")
    
    # Indexes
    __table_args__ = (
        Index('idx_lead_email', 'email'),
        Index('idx_lead_status', 'lead_status'),
        Index('idx_lead_assigned', 'assigned_to'),
        Index('idx_lead_score', 'lead_score'),
        Index('idx_lead_company', 'company_name'),
        CheckConstraint('lead_score >= 0 AND lead_score <= 100', name='check_lead_score_range'),
    )
    
    @hybrid_property
    def full_name(self) -> str:
        """Get lead's full name."""
        return f"{self.first_name} {self.last_name}".strip()
    
    @hybrid_property
    def is_qualified(self) -> bool:
        """Check if lead is qualified."""
        return self.lead_status in [LeadStatus.QUALIFIED, LeadStatus.CONVERTED]
    
    @hybrid_property
    def days_since_first_contact(self) -> Optional[int]:
        """Calculate days since first contact."""
        if not self.first_contact_date:
            return None
        return (datetime.utcnow() - self.first_contact_date).days
    
    def convert_to_user(self, user_data: dict) -> "User":
        """Convert lead to registered user."""
        from ...models.models import User
        
        # Create new user with lead information
        user = User(
            email=self.email,
            first_name=self.first_name,
            last_name=self.last_name,
            phone=self.phone,
            company_name=self.company_name,
            address_line1=self.address_line1,
            city=self.city,
            country=self.country,
            **user_data
        )
        
        # Update lead status
        self.lead_status = LeadStatus.CONVERTED
        self.converted_user_id = user.id
        self.converted_date = datetime.utcnow()
        
        # Update source statistics
        if self.source:
            self.source.converted_leads += 1
        
        return user
    
    def update_score(self, score_delta: int):
        """Update lead score with bounds checking."""
        new_score = self.lead_score + score_delta
        self.lead_score = max(0, min(100, new_score))
    
    def qualify_lead(self, qualified_by: "User"):
        """Mark lead as qualified."""
        self.lead_status = LeadStatus.QUALIFIED
        self.qualified_date = datetime.utcnow()
        
        # Create qualification activity
        activity = CRMActivity(
            lead_id=self.id,
            activity_type=ActivityType.NOTE,
            subject="Lead Qualified",
            description=f"Lead qualified by {qualified_by.full_name}",
            performed_by=qualified_by.id
        )
        self.activities.append(activity)


class Opportunity(EnterpriseBaseModel):
    """
    Opportunity model for tracking potential deals.
    Links to existing User and Equipment models.
    """
    
    __tablename__ = 'crm_opportunities'
    
    # Basic information
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # References
    lead_id = Column(UUID(as_uuid=True), ForeignKey('crm_leads.id'), nullable=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)  # Existing customer
    assigned_to = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    
    # Opportunity details
    opportunity_status = Column(String(50), default=OpportunityStatus.PROSPECTING, nullable=False)
    stage_id = Column(UUID(as_uuid=True), ForeignKey('crm_opportunity_stages.id'), nullable=True)
    
    # Financial information
    estimated_value = Column(Numeric(12, 2), nullable=False)
    probability = Column(Integer, default=10, nullable=False)  # 0-100%
    expected_close_date = Column(Date, nullable=True)
    actual_close_date = Column(Date, nullable=True)
    
    # Equipment and rental details
    requested_equipment = Column(JSONB, nullable=True)  # List of equipment IDs and quantities
    rental_start_date = Column(Date, nullable=True)
    rental_end_date = Column(Date, nullable=True)
    rental_location = Column(String(255), nullable=True)
    
    # Tracking
    win_reason = Column(Text, nullable=True)
    loss_reason = Column(Text, nullable=True)
    competitor = Column(String(255), nullable=True)
    
    # Additional information
    custom_fields = Column(JSONB, nullable=True)
    
    # Relationships
    lead = relationship("Lead", back_populates="opportunities")
    user = relationship("User", foreign_keys=[user_id])
    assigned_user = relationship("User", foreign_keys=[assigned_to])
    stage = relationship("OpportunityStage", back_populates="opportunities")
    activities = relationship("CRMActivity", back_populates="opportunity", cascade="all, delete-orphan")
    tags = relationship("CRMTag", secondary=opportunity_tags_table, back_populates="opportunities")
    
    # Indexes
    __table_args__ = (
        Index('idx_opportunity_status', 'opportunity_status'),
        Index('idx_opportunity_assigned', 'assigned_to'),
        Index('idx_opportunity_value', 'estimated_value'),
        Index('idx_opportunity_close_date', 'expected_close_date'),
        CheckConstraint('probability >= 0 AND probability <= 100', name='check_probability_range'),
        CheckConstraint('estimated_value > 0', name='check_estimated_value_positive'),
    )
    
    @hybrid_property
    def weighted_value(self) -> Decimal:
        """Calculate weighted opportunity value."""
        return self.estimated_value * (Decimal(self.probability) / 100)
    
    @hybrid_property
    def is_closed(self) -> bool:
        """Check if opportunity is closed."""
        return self.opportunity_status in [OpportunityStatus.CLOSED_WON, OpportunityStatus.CLOSED_LOST]
    
    @hybrid_property
    def is_won(self) -> bool:
        """Check if opportunity is won."""
        return self.opportunity_status == OpportunityStatus.CLOSED_WON
    
    @hybrid_property
    def days_to_close(self) -> Optional[int]:
        """Calculate days until expected close."""
        if not self.expected_close_date:
            return None
        return (self.expected_close_date - date.today()).days
    
    def close_won(self, win_reason: str = None):
        """Mark opportunity as won."""
        self.opportunity_status = OpportunityStatus.CLOSED_WON
        self.actual_close_date = date.today()
        self.probability = 100
        self.win_reason = win_reason
    
    def close_lost(self, loss_reason: str = None, competitor: str = None):
        """Mark opportunity as lost."""
        self.opportunity_status = OpportunityStatus.CLOSED_LOST
        self.actual_close_date = date.today()
        self.probability = 0
        self.loss_reason = loss_reason
        self.competitor = competitor
    
    def create_rental_from_opportunity(self) -> Optional["Rental"]:
        """Create rental from won opportunity."""
        if not self.is_won or not self.user_id:
            return None
        
        from ...models.models import Rental, RentalStatus
        
        rental = Rental(
            user_id=self.user_id,
            start_date=self.rental_start_date,
            end_date=self.rental_end_date,
            rental_status=RentalStatus.PENDING,
            notes=f"Created from opportunity: {self.name}"
        )
        
        return rental


class OpportunityStage(EnterpriseBaseModel):
    """Opportunity stage configuration model."""
    
    __tablename__ = 'crm_opportunity_stages'
    
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    sort_order = Column(Integer, default=0, nullable=False)
    default_probability = Column(Integer, default=10, nullable=False)
    is_closed_stage = Column(Boolean, default=False, nullable=False)
    
    # Relationships
    opportunities = relationship("Opportunity", back_populates="stage")
    
    __table_args__ = (
        CheckConstraint('default_probability >= 0 AND default_probability <= 100', name='check_stage_probability_range'),
    )


class Campaign(EnterpriseBaseModel):
    """
    Marketing campaign model with AI-powered automation.
    Integrates with existing AI workflows.
    """
    
    __tablename__ = 'crm_campaigns'
    
    # Basic information
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    campaign_type = Column(String(50), nullable=False)  # email, sms, direct_mail, etc.
    
    # Campaign details
    campaign_status = Column(String(50), default=CampaignStatus.DRAFT, nullable=False)
    start_date = Column(DateTime, nullable=True)
    end_date = Column(DateTime, nullable=True)
    
    # Targeting
    target_audience = Column(JSONB, nullable=True)  # Criteria for targeting
    segment_criteria = Column(JSONB, nullable=True)
    
    # Content
    email_template_id = Column(UUID(as_uuid=True), ForeignKey('crm_email_templates.id'), nullable=True)
    subject_line = Column(String(255), nullable=True)
    content = Column(Text, nullable=True)
    
    # Budget and costs
    budget = Column(Numeric(10, 2), default=0.00, nullable=False)
    cost_per_contact = Column(Numeric(6, 4), default=0.00, nullable=False)
    
    # Performance tracking
    total_sent = Column(Integer, default=0, nullable=False)
    total_delivered = Column(Integer, default=0, nullable=False)
    total_opened = Column(Integer, default=0, nullable=False)
    total_clicked = Column(Integer, default=0, nullable=False)
    total_responses = Column(Integer, default=0, nullable=False)
    total_conversions = Column(Integer, default=0, nullable=False)
    
    # AI automation settings
    ai_optimization_enabled = Column(Boolean, default=False, nullable=False)
    ai_send_time_optimization = Column(Boolean, default=False, nullable=False)
    ai_subject_line_testing = Column(Boolean, default=False, nullable=False)
    
    # Relationships
    email_template = relationship("EmailTemplate", back_populates="campaigns")
    contacts = relationship("CampaignContact", back_populates="campaign", cascade="all, delete-orphan")
    activities = relationship("CRMActivity", back_populates="campaign")
    
    # Indexes
    __table_args__ = (
        Index('idx_campaign_status', 'campaign_status'),
        Index('idx_campaign_type', 'campaign_type'),
        Index('idx_campaign_dates', 'start_date', 'end_date'),
    )
    
    @hybrid_property
    def delivery_rate(self) -> float:
        """Calculate delivery rate percentage."""
        if self.total_sent == 0:
            return 0.0
        return (self.total_delivered / self.total_sent) * 100
    
    @hybrid_property
    def open_rate(self) -> float:
        """Calculate open rate percentage."""
        if self.total_delivered == 0:
            return 0.0
        return (self.total_opened / self.total_delivered) * 100
    
    @hybrid_property
    def click_rate(self) -> float:
        """Calculate click rate percentage."""
        if self.total_delivered == 0:
            return 0.0
        return (self.total_clicked / self.total_delivered) * 100
    
    @hybrid_property
    def conversion_rate(self) -> float:
        """Calculate conversion rate percentage."""
        if self.total_delivered == 0:
            return 0.0
        return (self.total_conversions / self.total_delivered) * 100
    
    @hybrid_property
    def roi(self) -> float:
        """Calculate return on investment."""
        if self.budget == 0:
            return 0.0
        
        # Estimate revenue from conversions (simplified)
        estimated_revenue = self.total_conversions * Decimal('500.00')  # Average deal value
        return float((estimated_revenue - self.budget) / self.budget * 100)


class CampaignContact(EnterpriseBaseModel):
    """Campaign contact tracking model."""
    
    __tablename__ = 'crm_campaign_contacts'
    
    # References
    campaign_id = Column(UUID(as_uuid=True), ForeignKey('crm_campaigns.id'), nullable=False)
    lead_id = Column(UUID(as_uuid=True), ForeignKey('crm_leads.id'), nullable=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)
    
    # Contact details (for non-lead/user contacts)
    email = Column(String(255), nullable=True)
    first_name = Column(String(100), nullable=True)
    last_name = Column(String(100), nullable=True)
    
    # Tracking
    sent_at = Column(DateTime, nullable=True)
    delivered_at = Column(DateTime, nullable=True)
    opened_at = Column(DateTime, nullable=True)
    clicked_at = Column(DateTime, nullable=True)
    responded_at = Column(DateTime, nullable=True)
    converted_at = Column(DateTime, nullable=True)
    
    # Status
    status = Column(String(50), default="pending", nullable=False)
    bounce_reason = Column(String(255), nullable=True)
    
    # Relationships
    campaign = relationship("Campaign", back_populates="contacts")
    lead = relationship("Lead")
    user = relationship("User")
    
    # Indexes
    __table_args__ = (
        Index('idx_campaign_contact_status', 'campaign_id', 'status'),
        Index('idx_campaign_contact_email', 'email'),
        UniqueConstraint('campaign_id', 'lead_id', name='uq_campaign_lead'),
        UniqueConstraint('campaign_id', 'user_id', name='uq_campaign_user'),
    )


class CRMActivity(EnterpriseBaseModel):
    """CRM activity tracking model."""
    
    __tablename__ = 'crm_activities'
    
    # References
    lead_id = Column(UUID(as_uuid=True), ForeignKey('crm_leads.id'), nullable=True)
    opportunity_id = Column(UUID(as_uuid=True), ForeignKey('crm_opportunities.id'), nullable=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)  # Customer
    campaign_id = Column(UUID(as_uuid=True), ForeignKey('crm_campaigns.id'), nullable=True)
    performed_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    
    # Activity details
    activity_type = Column(String(50), nullable=False)
    subject = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # Scheduling
    scheduled_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    due_date = Column(DateTime, nullable=True)
    
    # Status and priority
    is_completed = Column(Boolean, default=False, nullable=False)
    priority = Column(String(20), default="medium", nullable=False)  # low, medium, high, urgent
    
    # Additional data
    duration_minutes = Column(Integer, nullable=True)
    outcome = Column(Text, nullable=True)
    follow_up_required = Column(Boolean, default=False, nullable=False)
    follow_up_date = Column(DateTime, nullable=True)
    
    # Relationships
    lead = relationship("Lead", back_populates="activities")
    opportunity = relationship("Opportunity", back_populates="activities")
    customer = relationship("User", foreign_keys=[user_id])
    performer = relationship("User", foreign_keys=[performed_by])
    campaign = relationship("Campaign", back_populates="activities")
    
    # Indexes
    __table_args__ = (
        Index('idx_activity_type', 'activity_type'),
        Index('idx_activity_performer', 'performed_by'),
        Index('idx_activity_scheduled', 'scheduled_at'),
        Index('idx_activity_due', 'due_date'),
        Index('idx_activity_completed', 'is_completed'),
    )
    
    def complete_activity(self, outcome: str = None):
        """Mark activity as completed."""
        self.is_completed = True
        self.completed_at = datetime.utcnow()
        self.outcome = outcome


class CRMNote(EnterpriseBaseModel):
    """CRM note model for additional context."""
    
    __tablename__ = 'crm_notes'
    
    # References
    lead_id = Column(UUID(as_uuid=True), ForeignKey('crm_leads.id'), nullable=True)
    opportunity_id = Column(UUID(as_uuid=True), ForeignKey('crm_opportunities.id'), nullable=True)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    
    # Note content
    title = Column(String(255), nullable=True)
    content = Column(Text, nullable=False)
    is_private = Column(Boolean, default=False, nullable=False)
    
    # Relationships
    lead = relationship("Lead")
    opportunity = relationship("Opportunity")
    customer = relationship("User", foreign_keys=[user_id])
    author = relationship("User", foreign_keys=[created_by])


class CRMTag(EnterpriseBaseModel):
    """CRM tag model for categorization."""
    
    __tablename__ = 'crm_tags'
    
    name = Column(String(100), unique=True, nullable=False)
    color = Column(String(7), nullable=True)  # Hex color code
    description = Column(Text, nullable=True)
    
    # Relationships
    leads = relationship("Lead", secondary=lead_tags_table, back_populates="tags")
    opportunities = relationship("Opportunity", secondary=opportunity_tags_table, back_populates="tags")


class EmailTemplate(EnterpriseBaseModel):
    """Email template model for campaigns."""
    
    __tablename__ = 'crm_email_templates'
    
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    subject = Column(String(255), nullable=False)
    html_content = Column(Text, nullable=False)
    text_content = Column(Text, nullable=True)
    
    # Template variables
    variables = Column(ARRAY(String), nullable=True)  # Available template variables
    
    # Usage tracking
    times_used = Column(Integer, default=0, nullable=False)
    
    # Relationships
    campaigns = relationship("Campaign", back_populates="email_template")


class CRMMetrics(EnterpriseBaseModel):
    """CRM metrics and KPI tracking model."""
    
    __tablename__ = 'crm_metrics'
    
    # Time period
    metric_date = Column(Date, nullable=False)
    metric_type = Column(String(50), nullable=False)  # daily, weekly, monthly
    
    # Lead metrics
    new_leads = Column(Integer, default=0, nullable=False)
    qualified_leads = Column(Integer, default=0, nullable=False)
    converted_leads = Column(Integer, default=0, nullable=False)
    
    # Opportunity metrics
    new_opportunities = Column(Integer, default=0, nullable=False)
    won_opportunities = Column(Integer, default=0, nullable=False)
    lost_opportunities = Column(Integer, default=0, nullable=False)
    total_opportunity_value = Column(Numeric(15, 2), default=0.00, nullable=False)
    
    # Campaign metrics
    campaigns_sent = Column(Integer, default=0, nullable=False)
    campaign_responses = Column(Integer, default=0, nullable=False)
    campaign_conversions = Column(Integer, default=0, nullable=False)
    
    # Revenue metrics
    revenue_generated = Column(Numeric(15, 2), default=0.00, nullable=False)
    
    # Indexes
    __table_args__ = (
        Index('idx_metrics_date_type', 'metric_date', 'metric_type'),
        UniqueConstraint('metric_date', 'metric_type', name='uq_metrics_date_type'),
    )


# Register all CRM models
for model_class in [
    LeadSource, Lead, Opportunity, OpportunityStage, Campaign, CampaignContact,
    CRMActivity, CRMNote, CRMTag, EmailTemplate, CRMMetrics
]:
    model_registry.register_model(model_class)
