"""
CRM models for RentGuy Enterprise.
Integrates seamlessly with existing User, Equipment, and Rental models.
"""

from .crm_models import (
    Lead,
    Opportunity,
    Campaign,
    CampaignContact,
    CRMActivity,
    CRMNote,
    LeadSource,
    OpportunityStage,
    CRMTag,
    EmailTemplate,
    CRMMetrics
)

__all__ = [
    "Lead",
    "Opportunity", 
    "Campaign",
    "CampaignContact",
    "CRMActivity",
    "CRMNote",
    "LeadSource",
    "OpportunityStage",
    "CRMTag",
    "EmailTemplate",
    "CRMMetrics"
]
