"""
CRM service layer that integrates with existing RentGuy AI workflows.
Provides business logic for lead management, opportunity tracking, and campaign automation.
"""

from datetime import datetime, date, timedelta
from decimal import Decimal
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, desc, asc

from ...core.logging import get_logger
from ...models.models import User
from ..models.crm_models import (
    Lead, LeadStatus, Opportunity, OpportunityStatus, Campaign, CampaignStatus,
    CRMActivity, ActivityType, LeadSource, CRMTag, EmailTemplate
)
from ..schemas.lead_schemas import LeadCreate, LeadUpdate, LeadSearchRequest

logger = get_logger(__name__)


class CRMService:
    """
    Core CRM service that integrates with existing RentGuy architecture.
    Provides lead management, opportunity tracking, and AI-powered automation.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    # Lead Management
    
    def create_lead(self, lead_data: LeadCreate, created_by: UUID) -> Lead:
        """Create a new lead with automatic scoring and AI analysis."""
        # Create lead
        lead = Lead(**lead_data.dict())
        
        # Auto-assign lead score based on criteria
        lead.lead_score = self._calculate_initial_lead_score(lead)
        
        # Set first contact date
        lead.first_contact_date = datetime.utcnow()
        
        # Update source statistics
        if lead.source_id:
            source = self.db.query(LeadSource).filter(LeadSource.id == lead.source_id).first()
            if source:
                source.total_leads += 1
        
        self.db.add(lead)
        self.db.flush()  # Get the ID
        
        # Create initial activity
        activity = CRMActivity(
            lead_id=lead.id,
            activity_type=ActivityType.NOTE,
            subject="Lead Created",
            description=f"New lead created from {lead.source.name if lead.source else 'unknown source'}",
            performed_by=created_by,
            is_completed=True,
            completed_at=datetime.utcnow()
        )
        self.db.add(activity)
        
        # Trigger AI analysis for lead qualification
        self._trigger_ai_lead_analysis(lead)
        
        self.db.commit()
        
        logger.info(
            "Lead created successfully",
            lead_id=str(lead.id),
            email=lead.email,
            score=lead.lead_score,
            created_by=str(created_by)
        )
        
        return lead
    
    def update_lead(self, lead_id: UUID, lead_data: LeadUpdate, updated_by: UUID) -> Optional[Lead]:
        """Update an existing lead."""
        lead = self.db.query(Lead).filter(Lead.id == lead_id).first()
        if not lead:
            return None
        
        # Store original values for change tracking
        original_status = lead.lead_status
        original_score = lead.lead_score
        
        # Update lead fields
        for field, value in lead_data.dict(exclude_unset=True).items():
            setattr(lead, field, value)
        
        # Update last contact date if status changed
        if lead_data.lead_status and lead_data.lead_status != original_status:
            lead.last_contact_date = datetime.utcnow()
            
            # Create status change activity
            activity = CRMActivity(
                lead_id=lead.id,
                activity_type=ActivityType.NOTE,
                subject="Status Changed",
                description=f"Lead status changed from {original_status} to {lead.lead_status}",
                performed_by=updated_by,
                is_completed=True,
                completed_at=datetime.utcnow()
            )
            self.db.add(activity)
        
        # Recalculate score if relevant fields changed
        if any(field in lead_data.dict(exclude_unset=True) for field in 
               ['company_name', 'estimated_budget', 'rental_timeframe', 'interested_equipment']):
            new_score = self._calculate_initial_lead_score(lead)
            if new_score != original_score:
                lead.lead_score = new_score
                
                # Log score change
                activity = CRMActivity(
                    lead_id=lead.id,
                    activity_type=ActivityType.NOTE,
                    subject="Score Updated",
                    description=f"Lead score updated from {original_score} to {new_score}",
                    performed_by=updated_by,
                    is_completed=True,
                    completed_at=datetime.utcnow()
                )
                self.db.add(activity)
        
        self.db.commit()
        
        logger.info(
            "Lead updated successfully",
            lead_id=str(lead_id),
            updated_by=str(updated_by),
            status_changed=original_status != lead.lead_status
        )
        
        return lead
    
    def search_leads(self, search_request: LeadSearchRequest) -> Tuple[List[Lead], int]:
        """Advanced lead search with filtering and pagination."""
        query = self.db.query(Lead)
        
        # Text search
        if search_request.query:
            search_term = f"%{search_request.query}%"
            query = query.filter(
                or_(
                    Lead.first_name.ilike(search_term),
                    Lead.last_name.ilike(search_term),
                    Lead.email.ilike(search_term),
                    Lead.company_name.ilike(search_term)
                )
            )
        
        # Status filter
        if search_request.status:
            query = query.filter(Lead.lead_status.in_(search_request.status))
        
        # Source filter
        if search_request.source_ids:
            query = query.filter(Lead.source_id.in_(search_request.source_ids))
        
        # Assignment filter
        if search_request.assigned_to:
            query = query.filter(Lead.assigned_to.in_(search_request.assigned_to))
        
        # Score range filter
        if search_request.score_min is not None:
            query = query.filter(Lead.lead_score >= search_request.score_min)
        if search_request.score_max is not None:
            query = query.filter(Lead.lead_score <= search_request.score_max)
        
        # Date range filter
        if search_request.created_after:
            query = query.filter(Lead.created_at >= search_request.created_after)
        if search_request.created_before:
            query = query.filter(Lead.created_at <= search_request.created_before)
        
        # Company size filter
        if search_request.company_size:
            query = query.filter(Lead.company_size.in_(search_request.company_size))
        
        # Industry filter
        if search_request.industry:
            query = query.filter(Lead.industry.in_(search_request.industry))
        
        # Country filter
        if search_request.country:
            query = query.filter(Lead.country.in_(search_request.country))
        
        # Budget filter
        if search_request.has_budget is not None:
            if search_request.has_budget:
                query = query.filter(Lead.estimated_budget.isnot(None))
            else:
                query = query.filter(Lead.estimated_budget.is_(None))
        
        # Get total count before pagination
        total = query.count()
        
        # Sorting
        sort_column = getattr(Lead, search_request.sort_by)
        if search_request.sort_order == "desc":
            query = query.order_by(desc(sort_column))
        else:
            query = query.order_by(asc(sort_column))
        
        # Pagination
        offset = (search_request.page - 1) * search_request.per_page
        leads = query.offset(offset).limit(search_request.per_page).all()
        
        return leads, total
    
    def convert_lead_to_user(self, lead_id: UUID, user_data: Dict[str, Any], converted_by: UUID) -> Optional[User]:
        """Convert a qualified lead to a registered user."""
        lead = self.db.query(Lead).filter(Lead.id == lead_id).first()
        if not lead or lead.lead_status != LeadStatus.QUALIFIED:
            return None
        
        # Check if user with this email already exists
        existing_user = self.db.query(User).filter(User.email == lead.email).first()
        if existing_user:
            # Link existing user to lead
            lead.converted_user_id = existing_user.id
            lead.lead_status = LeadStatus.CONVERTED
            lead.converted_date = datetime.utcnow()
            self.db.commit()
            return existing_user
        
        # Create new user from lead data
        user = User(
            email=lead.email,
            first_name=lead.first_name,
            last_name=lead.last_name,
            phone=lead.phone,
            company_name=lead.company_name,
            address_line1=lead.address_line1,
            city=lead.city,
            country=lead.country,
            **user_data
        )
        
        self.db.add(user)
        self.db.flush()  # Get user ID
        
        # Update lead
        lead.converted_user_id = user.id
        lead.lead_status = LeadStatus.CONVERTED
        lead.converted_date = datetime.utcnow()
        
        # Update source statistics
        if lead.source:
            lead.source.converted_leads += 1
        
        # Create conversion activity
        activity = CRMActivity(
            lead_id=lead.id,
            user_id=user.id,
            activity_type=ActivityType.NOTE,
            subject="Lead Converted",
            description=f"Lead successfully converted to user account",
            performed_by=converted_by,
            is_completed=True,
            completed_at=datetime.utcnow()
        )
        self.db.add(activity)
        
        self.db.commit()
        
        logger.info(
            "Lead converted to user successfully",
            lead_id=str(lead_id),
            user_id=str(user.id),
            converted_by=str(converted_by)
        )
        
        return user
    
    # Opportunity Management
    
    def create_opportunity_from_lead(self, lead_id: UUID, opportunity_data: Dict[str, Any], created_by: UUID) -> Optional[Opportunity]:
        """Create an opportunity from a qualified lead."""
        lead = self.db.query(Lead).filter(Lead.id == lead_id).first()
        if not lead or not lead.is_qualified:
            return None
        
        # Create opportunity
        opportunity = Opportunity(
            lead_id=lead_id,
            user_id=lead.converted_user_id,
            assigned_to=created_by,
            **opportunity_data
        )
        
        self.db.add(opportunity)
        self.db.flush()
        
        # Create opportunity creation activity
        activity = CRMActivity(
            lead_id=lead_id,
            opportunity_id=opportunity.id,
            activity_type=ActivityType.NOTE,
            subject="Opportunity Created",
            description=f"Opportunity '{opportunity.name}' created from lead",
            performed_by=created_by,
            is_completed=True,
            completed_at=datetime.utcnow()
        )
        self.db.add(activity)
        
        self.db.commit()
        
        logger.info(
            "Opportunity created from lead",
            opportunity_id=str(opportunity.id),
            lead_id=str(lead_id),
            created_by=str(created_by)
        )
        
        return opportunity
    
    # AI Integration Methods
    
    def _calculate_initial_lead_score(self, lead: Lead) -> int:
        """Calculate initial lead score based on available information."""
        score = 0
        
        # Company information (30 points max)
        if lead.company_name:
            score += 10
        if lead.job_title:
            score += 5
        if lead.company_size in ['51-200', '201-500', '501-1000', '1000+']:
            score += 15
        
        # Budget information (25 points max)
        if lead.estimated_budget:
            if lead.estimated_budget >= 10000:
                score += 25
            elif lead.estimated_budget >= 5000:
                score += 20
            elif lead.estimated_budget >= 1000:
                score += 15
            else:
                score += 10
        
        # Timeframe (20 points max)
        timeframe_scores = {
            'immediate': 20,
            '1-3months': 15,
            '3-6months': 10,
            '6-12months': 5,
            '1year+': 2
        }
        if lead.rental_timeframe in timeframe_scores:
            score += timeframe_scores[lead.rental_timeframe]
        
        # Equipment interest (15 points max)
        if lead.interested_equipment:
            score += min(len(lead.interested_equipment) * 3, 15)
        
        # Contact completeness (10 points max)
        if lead.phone:
            score += 5
        if lead.address_line1:
            score += 5
        
        return min(score, 100)  # Cap at 100
    
    def _trigger_ai_lead_analysis(self, lead: Lead):
        """Trigger AI analysis for lead qualification using existing AI workflows."""
        try:
            # Import AI service (assuming it exists from Phase 18-19)
            from ...ai.customer_service import CustomerServiceAI
            
            ai_service = CustomerServiceAI()
            
            # Prepare lead data for AI analysis
            lead_context = {
                "lead_id": str(lead.id),
                "company_name": lead.company_name,
                "industry": lead.industry,
                "company_size": lead.company_size,
                "estimated_budget": float(lead.estimated_budget) if lead.estimated_budget else None,
                "rental_timeframe": lead.rental_timeframe,
                "interested_equipment": lead.interested_equipment,
                "notes": lead.notes
            }
            
            # Generate AI insights for lead qualification
            ai_insights = ai_service.analyze_lead_qualification(lead_context)
            
            # Create AI analysis activity
            activity = CRMActivity(
                lead_id=lead.id,
                activity_type=ActivityType.NOTE,
                subject="AI Analysis Completed",
                description=f"AI qualification analysis: {ai_insights.get('summary', 'Analysis completed')}",
                performed_by=None,  # System-generated
                is_completed=True,
                completed_at=datetime.utcnow()
            )
            self.db.add(activity)
            
            # Update lead score based on AI insights
            if ai_insights.get('recommended_score'):
                lead.lead_score = min(max(ai_insights['recommended_score'], 0), 100)
            
            logger.info(
                "AI lead analysis completed",
                lead_id=str(lead.id),
                ai_score=ai_insights.get('recommended_score'),
                ai_qualification=ai_insights.get('qualification_level')
            )
            
        except Exception as e:
            logger.error(
                "Failed to trigger AI lead analysis",
                lead_id=str(lead.id),
                error=str(e)
            )
    
    # Campaign and Email Integration
    
    def create_email_campaign(self, campaign_data: Dict[str, Any], created_by: UUID) -> Campaign:
        """Create an email campaign with AI optimization."""
        campaign = Campaign(
            **campaign_data,
            campaign_type="email"
        )
        
        self.db.add(campaign)
        self.db.flush()
        
        # If AI optimization is enabled, enhance the campaign
        if campaign.ai_optimization_enabled:
            self._optimize_campaign_with_ai(campaign)
        
        self.db.commit()
        
        logger.info(
            "Email campaign created",
            campaign_id=str(campaign.id),
            created_by=str(created_by),
            ai_optimized=campaign.ai_optimization_enabled
        )
        
        return campaign
    
    def _optimize_campaign_with_ai(self, campaign: Campaign):
        """Optimize campaign using AI insights."""
        try:
            from ...ai.customer_service import CustomerServiceAI
            
            ai_service = CustomerServiceAI()
            
            # Generate AI-optimized subject lines
            if campaign.ai_subject_line_testing and campaign.subject_line:
                optimized_subjects = ai_service.generate_subject_line_variants(
                    original_subject=campaign.subject_line,
                    campaign_type=campaign.campaign_type,
                    target_audience=campaign.target_audience
                )
                
                # Store variants in campaign custom fields
                if not campaign.target_audience:
                    campaign.target_audience = {}
                campaign.target_audience['ai_subject_variants'] = optimized_subjects
            
            # Optimize send time
            if campaign.ai_send_time_optimization:
                optimal_send_time = ai_service.calculate_optimal_send_time(
                    target_audience=campaign.target_audience,
                    campaign_type=campaign.campaign_type
                )
                
                if optimal_send_time:
                    campaign.start_date = optimal_send_time
            
            logger.info(
                "Campaign optimized with AI",
                campaign_id=str(campaign.id),
                subject_variants_generated=bool(campaign.ai_subject_line_testing),
                send_time_optimized=bool(campaign.ai_send_time_optimization)
            )
            
        except Exception as e:
            logger.error(
                "Failed to optimize campaign with AI",
                campaign_id=str(campaign.id),
                error=str(e)
            )
    
    # Analytics and Reporting
    
    def get_crm_dashboard_metrics(self, date_range: int = 30) -> Dict[str, Any]:
        """Get CRM dashboard metrics for the specified date range."""
        end_date = date.today()
        start_date = end_date - timedelta(days=date_range)
        
        # Lead metrics
        total_leads = self.db.query(Lead).count()
        new_leads = self.db.query(Lead).filter(
            Lead.created_at >= start_date
        ).count()
        
        qualified_leads = self.db.query(Lead).filter(
            and_(
                Lead.lead_status == LeadStatus.QUALIFIED,
                Lead.qualified_date >= start_date
            )
        ).count()
        
        converted_leads = self.db.query(Lead).filter(
            and_(
                Lead.lead_status == LeadStatus.CONVERTED,
                Lead.converted_date >= start_date
            )
        ).count()
        
        # Opportunity metrics
        total_opportunities = self.db.query(Opportunity).count()
        won_opportunities = self.db.query(Opportunity).filter(
            and_(
                Opportunity.opportunity_status == OpportunityStatus.CLOSED_WON,
                Opportunity.actual_close_date >= start_date
            )
        ).count()
        
        total_opportunity_value = self.db.query(
            func.sum(Opportunity.estimated_value)
        ).filter(
            Opportunity.created_at >= start_date
        ).scalar() or Decimal('0.00')
        
        won_opportunity_value = self.db.query(
            func.sum(Opportunity.estimated_value)
        ).filter(
            and_(
                Opportunity.opportunity_status == OpportunityStatus.CLOSED_WON,
                Opportunity.actual_close_date >= start_date
            )
        ).scalar() or Decimal('0.00')
        
        # Calculate conversion rates
        lead_conversion_rate = (converted_leads / new_leads * 100) if new_leads > 0 else 0
        opportunity_win_rate = (won_opportunities / total_opportunities * 100) if total_opportunities > 0 else 0
        
        return {
            "period_days": date_range,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "leads": {
                "total": total_leads,
                "new": new_leads,
                "qualified": qualified_leads,
                "converted": converted_leads,
                "conversion_rate": round(lead_conversion_rate, 2)
            },
            "opportunities": {
                "total": total_opportunities,
                "won": won_opportunities,
                "total_value": float(total_opportunity_value),
                "won_value": float(won_opportunity_value),
                "win_rate": round(opportunity_win_rate, 2)
            },
            "revenue": {
                "pipeline_value": float(total_opportunity_value),
                "closed_value": float(won_opportunity_value),
                "average_deal_size": float(won_opportunity_value / won_opportunities) if won_opportunities > 0 else 0
            }
        }


class CRMEmailService:
    """
    Email service for CRM that integrates with existing email infrastructure.
    Provides transactional email capabilities for lead nurturing and campaign management.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    def send_lead_welcome_email(self, lead: Lead) -> bool:
        """Send welcome email to new lead."""
        try:
            # Import existing email service (assuming it exists)
            from ...core.email import EmailService
            
            email_service = EmailService()
            
            # Get welcome email template
            template = self.db.query(EmailTemplate).filter(
                EmailTemplate.name == "lead_welcome"
            ).first()
            
            if not template:
                logger.warning("Lead welcome email template not found")
                return False
            
            # Prepare template variables
            variables = {
                "first_name": lead.first_name,
                "last_name": lead.last_name,
                "company_name": lead.company_name or "",
                "interested_equipment": ", ".join(lead.interested_equipment or [])
            }
            
            # Send email
            success = email_service.send_template_email(
                to_email=lead.email,
                template=template,
                variables=variables
            )
            
            if success:
                # Create email activity
                activity = CRMActivity(
                    lead_id=lead.id,
                    activity_type=ActivityType.EMAIL,
                    subject="Welcome Email Sent",
                    description=f"Welcome email sent to {lead.email}",
                    performed_by=None,  # System-generated
                    is_completed=True,
                    completed_at=datetime.utcnow()
                )
                self.db.add(activity)
                self.db.commit()
            
            return success
            
        except Exception as e:
            logger.error(
                "Failed to send lead welcome email",
                lead_id=str(lead.id),
                email=lead.email,
                error=str(e)
            )
            return False
    
    def send_follow_up_email(self, lead: Lead, template_name: str, custom_variables: Dict[str, Any] = None) -> bool:
        """Send follow-up email to lead."""
        try:
            from ...core.email import EmailService
            
            email_service = EmailService()
            
            # Get email template
            template = self.db.query(EmailTemplate).filter(
                EmailTemplate.name == template_name
            ).first()
            
            if not template:
                logger.warning(f"Email template '{template_name}' not found")
                return False
            
            # Prepare template variables
            variables = {
                "first_name": lead.first_name,
                "last_name": lead.last_name,
                "company_name": lead.company_name or "",
                **(custom_variables or {})
            }
            
            # Send email
            success = email_service.send_template_email(
                to_email=lead.email,
                template=template,
                variables=variables
            )
            
            if success:
                # Create email activity
                activity = CRMActivity(
                    lead_id=lead.id,
                    activity_type=ActivityType.EMAIL,
                    subject=f"Follow-up Email Sent: {template.subject}",
                    description=f"Follow-up email sent using template '{template_name}'",
                    performed_by=None,  # System-generated
                    is_completed=True,
                    completed_at=datetime.utcnow()
                )
                self.db.add(activity)
                self.db.commit()
            
            return success
            
        except Exception as e:
            logger.error(
                "Failed to send follow-up email",
                lead_id=str(lead.id),
                template_name=template_name,
                error=str(e)
            )
            return False
