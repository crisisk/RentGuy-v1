"""
CRM schemas for RentGuy Enterprise API.
Provides Pydantic models for request/response validation.
"""

from .lead_schemas import (
    LeadCreate,
    LeadUpdate,
    LeadResponse,
    LeadListResponse,
    LeadSourceCreate,
    LeadSourceResponse
)

from .opportunity_schemas import (
    OpportunityCreate,
    OpportunityUpdate,
    OpportunityResponse,
    OpportunityListResponse,
    OpportunityStageCreate,
    OpportunityStageResponse
)

from .campaign_schemas import (
    CampaignCreate,
    CampaignUpdate,
    CampaignResponse,
    CampaignListResponse,
    CampaignContactResponse,
    EmailTemplateCreate,
    EmailTemplateResponse
)

from .activity_schemas import (
    CRMActivityCreate,
    CRMActivityUpdate,
    CRMActivityResponse,
    CRMNoteCreate,
    CRMNoteResponse
)

from .common_schemas import (
    CRMTagCreate,
    CRMTagResponse,
    CRMMetricsResponse,
    CRMDashboardResponse
)

__all__ = [
    # Lead schemas
    "LeadCreate",
    "LeadUpdate", 
    "LeadResponse",
    "LeadListResponse",
    "LeadSourceCreate",
    "LeadSourceResponse",
    
    # Opportunity schemas
    "OpportunityCreate",
    "OpportunityUpdate",
    "OpportunityResponse", 
    "OpportunityListResponse",
    "OpportunityStageCreate",
    "OpportunityStageResponse",
    
    # Campaign schemas
    "CampaignCreate",
    "CampaignUpdate",
    "CampaignResponse",
    "CampaignListResponse",
    "CampaignContactResponse",
    "EmailTemplateCreate",
    "EmailTemplateResponse",
    
    # Activity schemas
    "CRMActivityCreate",
    "CRMActivityUpdate",
    "CRMActivityResponse",
    "CRMNoteCreate",
    "CRMNoteResponse",
    
    # Common schemas
    "CRMTagCreate",
    "CRMTagResponse",
    "CRMMetricsResponse",
    "CRMDashboardResponse"
]
