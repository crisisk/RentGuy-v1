"""
Lead-related Pydantic schemas for CRM API.
"""

from datetime import datetime, date
from decimal import Decimal
from typing import List, Optional, Dict, Any
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, validator

from ..models.crm_models import LeadStatus


class LeadSourceBase(BaseModel):
    """Base lead source schema."""
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    is_active: bool = True
    cost_per_lead: Decimal = Field(default=Decimal('0.00'), ge=0)


class LeadSourceCreate(LeadSourceBase):
    """Schema for creating a lead source."""
    pass


class LeadSourceUpdate(BaseModel):
    """Schema for updating a lead source."""
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = None
    is_active: Optional[bool] = None
    cost_per_lead: Optional[Decimal] = Field(None, ge=0)


class LeadSourceResponse(LeadSourceBase):
    """Schema for lead source response."""
    id: UUID
    total_leads: int
    converted_leads: int
    conversion_rate: float
    cost_per_conversion: Decimal
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True


class LeadBase(BaseModel):
    """Base lead schema."""
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    phone: Optional[str] = Field(None, max_length=20)
    
    # Company information
    company_name: Optional[str] = Field(None, max_length=255)
    job_title: Optional[str] = Field(None, max_length=100)
    company_size: Optional[str] = Field(None, max_length=50)
    industry: Optional[str] = Field(None, max_length=100)
    
    # Address information
    address_line1: Optional[str] = Field(None, max_length=255)
    city: Optional[str] = Field(None, max_length=100)
    country: str = Field(default="Netherlands", max_length=100)
    
    # Interest and qualification
    interested_equipment: Optional[List[str]] = None
    estimated_budget: Optional[Decimal] = Field(None, ge=0)
    rental_timeframe: Optional[str] = Field(None, max_length=50)
    
    # Additional information
    notes: Optional[str] = None
    custom_fields: Optional[Dict[str, Any]] = None

    @validator('phone')
    def validate_phone(cls, v):
        """Validate phone number format."""
        if v:
            # Remove all non-digit characters for validation
            digits_only = ''.join(filter(str.isdigit, v))
            if len(digits_only) < 10:
                raise ValueError('Phone number must have at least 10 digits')
        return v

    @validator('rental_timeframe')
    def validate_rental_timeframe(cls, v):
        """Validate rental timeframe options."""
        if v:
            valid_timeframes = [
                'immediate', '1-3months', '3-6months', 
                '6-12months', '1year+', 'unknown'
            ]
            if v not in valid_timeframes:
                raise ValueError(f'Invalid rental timeframe. Must be one of: {valid_timeframes}')
        return v

    @validator('company_size')
    def validate_company_size(cls, v):
        """Validate company size options."""
        if v:
            valid_sizes = [
                '1-10', '11-50', '51-200', '201-500', 
                '501-1000', '1000+', 'unknown'
            ]
            if v not in valid_sizes:
                raise ValueError(f'Invalid company size. Must be one of: {valid_sizes}')
        return v


class LeadCreate(LeadBase):
    """Schema for creating a lead."""
    source_id: Optional[UUID] = None
    assigned_to: Optional[UUID] = None
    lead_score: int = Field(default=0, ge=0, le=100)


class LeadUpdate(BaseModel):
    """Schema for updating a lead."""
    first_name: Optional[str] = Field(None, min_length=1, max_length=100)
    last_name: Optional[str] = Field(None, min_length=1, max_length=100)
    email: Optional[EmailStr] = None
    phone: Optional[str] = Field(None, max_length=20)
    
    # Company information
    company_name: Optional[str] = Field(None, max_length=255)
    job_title: Optional[str] = Field(None, max_length=100)
    company_size: Optional[str] = Field(None, max_length=50)
    industry: Optional[str] = Field(None, max_length=100)
    
    # Address information
    address_line1: Optional[str] = Field(None, max_length=255)
    city: Optional[str] = Field(None, max_length=100)
    country: Optional[str] = Field(None, max_length=100)
    
    # Lead tracking
    lead_status: Optional[LeadStatus] = None
    lead_score: Optional[int] = Field(None, ge=0, le=100)
    source_id: Optional[UUID] = None
    assigned_to: Optional[UUID] = None
    
    # Interest and qualification
    interested_equipment: Optional[List[str]] = None
    estimated_budget: Optional[Decimal] = Field(None, ge=0)
    rental_timeframe: Optional[str] = Field(None, max_length=50)
    
    # Additional information
    notes: Optional[str] = None
    custom_fields: Optional[Dict[str, Any]] = None


class LeadResponse(LeadBase):
    """Schema for lead response."""
    id: UUID
    lead_status: LeadStatus
    lead_score: int
    source_id: Optional[UUID]
    assigned_to: Optional[UUID]
    converted_user_id: Optional[UUID]
    
    # Tracking dates
    first_contact_date: Optional[datetime]
    last_contact_date: Optional[datetime]
    qualified_date: Optional[datetime]
    converted_date: Optional[datetime]
    
    # Computed properties
    full_name: str
    is_qualified: bool
    days_since_first_contact: Optional[int]
    
    # Metadata
    created_at: datetime
    updated_at: datetime
    
    # Related data
    source: Optional[LeadSourceResponse] = None
    assigned_user_name: Optional[str] = None
    converted_user_name: Optional[str] = None
    tags: List[str] = []
    activity_count: int = 0
    
    class Config:
        from_attributes = True


class LeadListResponse(BaseModel):
    """Schema for paginated lead list response."""
    leads: List[LeadResponse]
    total: int
    page: int
    per_page: int
    pages: int
    has_next: bool
    has_prev: bool


class LeadConversionRequest(BaseModel):
    """Schema for converting lead to user."""
    username: Optional[str] = Field(None, min_length=3, max_length=100)
    password: str = Field(..., min_length=8)
    credit_limit: Decimal = Field(default=Decimal('1000.00'), ge=0)
    payment_terms: int = Field(default=30, ge=1, le=365)
    
    # Additional user fields
    language: str = Field(default="nl", max_length=10)
    timezone: str = Field(default="Europe/Amsterdam", max_length=50)
    notification_preferences: Optional[Dict[str, Any]] = None


class LeadConversionResponse(BaseModel):
    """Schema for lead conversion response."""
    success: bool
    message: str
    user_id: Optional[UUID] = None
    lead_id: UUID
    converted_at: datetime


class LeadScoreUpdate(BaseModel):
    """Schema for updating lead score."""
    score_delta: int = Field(..., ge=-100, le=100)
    reason: Optional[str] = None


class LeadQualificationRequest(BaseModel):
    """Schema for qualifying a lead."""
    qualified: bool
    qualification_notes: Optional[str] = None
    next_action: Optional[str] = None
    follow_up_date: Optional[datetime] = None


class LeadBulkAction(BaseModel):
    """Schema for bulk lead actions."""
    lead_ids: List[UUID] = Field(..., min_items=1)
    action: str = Field(..., regex=r'^(assign|tag|status_change|delete)$')
    
    # Action-specific parameters
    assigned_to: Optional[UUID] = None
    new_status: Optional[LeadStatus] = None
    tag_ids: Optional[List[UUID]] = None


class LeadBulkActionResponse(BaseModel):
    """Schema for bulk action response."""
    success: bool
    processed_count: int
    failed_count: int
    errors: List[str] = []


class LeadImportRequest(BaseModel):
    """Schema for importing leads."""
    leads: List[LeadCreate] = Field(..., min_items=1, max_items=1000)
    source_id: Optional[UUID] = None
    assigned_to: Optional[UUID] = None
    skip_duplicates: bool = True


class LeadImportResponse(BaseModel):
    """Schema for lead import response."""
    success: bool
    imported_count: int
    skipped_count: int
    error_count: int
    errors: List[str] = []
    imported_lead_ids: List[UUID] = []


class LeadSearchRequest(BaseModel):
    """Schema for advanced lead search."""
    query: Optional[str] = None
    status: Optional[List[LeadStatus]] = None
    source_ids: Optional[List[UUID]] = None
    assigned_to: Optional[List[UUID]] = None
    score_min: Optional[int] = Field(None, ge=0, le=100)
    score_max: Optional[int] = Field(None, ge=0, le=100)
    created_after: Optional[date] = None
    created_before: Optional[date] = None
    company_size: Optional[List[str]] = None
    industry: Optional[List[str]] = None
    country: Optional[List[str]] = None
    has_budget: Optional[bool] = None
    tag_ids: Optional[List[UUID]] = None
    
    # Sorting
    sort_by: str = Field(default="created_at", regex=r'^(created_at|updated_at|lead_score|last_contact_date|company_name|full_name)$')
    sort_order: str = Field(default="desc", regex=r'^(asc|desc)$')
    
    # Pagination
    page: int = Field(default=1, ge=1)
    per_page: int = Field(default=20, ge=1, le=100)
