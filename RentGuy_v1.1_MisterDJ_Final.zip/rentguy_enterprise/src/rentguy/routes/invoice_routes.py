"""
Enhanced Invoice API routes for RentGuy Enterprise.
Provides PDF generation, bulk download, and advanced invoice management.
"""

from datetime import datetime, date
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import Response, StreamingResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field

from ..core.database import get_db
from ..core.security import get_current_user, require_permissions
from ..models.models import User, Invoice, PaymentStatus
from ..services.invoice_service import InvoiceService
from ..api.versioning import get_api_version

# Create router
router = APIRouter(prefix="/invoices", tags=["Invoices"])


# Pydantic models for request/response
class InvoiceDownloadRequest(BaseModel):
    """Request model for bulk invoice download."""
    invoice_ids: List[UUID] = Field(..., min_items=1, max_items=100)
    format: str = Field(default="zip", regex="^(pdf|zip)$")


class InvoiceFilterRequest(BaseModel):
    """Request model for filtering invoices."""
    user_id: Optional[UUID] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    payment_status: Optional[List[PaymentStatus]] = None
    invoice_numbers: Optional[List[str]] = None


class InvoiceDownloadSummary(BaseModel):
    """Response model for download summary."""
    count: int
    total_amount: float
    date_range: dict
    customers: List[str]
    payment_status_breakdown: dict
    invoice_numbers: List[str]


# Single Invoice PDF Download
@router.get("/{invoice_id}/pdf")
async def download_invoice_pdf(
    invoice_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Download a single invoice as PDF.
    
    Requires: INVOICE_READ permission or ownership of the invoice
    """
    # Get invoice
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not invoice:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Invoice not found"
        )
    
    # Check permissions
    if (invoice.user_id != current_user.id and 
        not current_user.has_permission("INVOICE_READ")):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this invoice"
        )
    
    try:
        # Generate PDF
        invoice_service = InvoiceService(db)
        pdf_content, filename = invoice_service.generate_invoice_pdf(invoice_id)
        
        # Return PDF response
        return Response(
            content=pdf_content,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f"attachment; filename=\"{filename}\"",
                "Content-Length": str(len(pdf_content))
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate PDF: {str(e)}"
        )


# Bulk Invoice Download
@router.post("/bulk-download")
async def bulk_download_invoices(
    download_request: InvoiceDownloadRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Download multiple invoices as ZIP file.
    
    Requires: INVOICE_READ permission or ownership of all invoices
    """
    # Validate invoice access
    invoices = db.query(Invoice).filter(
        Invoice.id.in_(download_request.invoice_ids)
    ).all()
    
    if not invoices:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No invoices found"
        )
    
    # Check permissions for each invoice
    if not current_user.has_permission("INVOICE_READ"):
        # Check if user owns all invoices
        user_invoice_ids = {invoice.user_id for invoice in invoices}
        if len(user_invoice_ids) > 1 or current_user.id not in user_invoice_ids:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to one or more invoices"
            )
    
    try:
        invoice_service = InvoiceService(db)
        
        if download_request.format == "pdf" and len(download_request.invoice_ids) == 1:
            # Single PDF download
            pdf_content, filename = invoice_service.generate_invoice_pdf(
                download_request.invoice_ids[0]
            )
            
            return Response(
                content=pdf_content,
                media_type="application/pdf",
                headers={
                    "Content-Disposition": f"attachment; filename=\"{filename}\"",
                    "Content-Length": str(len(pdf_content))
                }
            )
        else:
            # ZIP download (multiple invoices or explicitly requested)
            zip_content, filename = invoice_service.generate_bulk_invoice_zip(
                download_request.invoice_ids
            )
            
            return Response(
                content=zip_content,
                media_type="application/zip",
                headers={
                    "Content-Disposition": f"attachment; filename=\"{filename}\"",
                    "Content-Length": str(len(zip_content))
                }
            )
            
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate download: {str(e)}"
        )


# User's Invoice Download (for customer portal)
@router.get("/my-invoices/download")
async def download_my_invoices(
    start_date: Optional[date] = Query(None, description="Start date filter"),
    end_date: Optional[date] = Query(None, description="End date filter"),
    payment_status: Optional[List[PaymentStatus]] = Query(None, description="Payment status filter"),
    format: str = Query("zip", regex="^(pdf|zip)$", description="Download format"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Download all invoices for the current user.
    
    Available to all authenticated users for their own invoices.
    """
    try:
        invoice_service = InvoiceService(db)
        
        # Get user's invoices
        invoices = invoice_service.get_user_invoices_for_download(
            user_id=current_user.id,
            start_date=start_date,
            end_date=end_date,
            payment_status=payment_status
        )
        
        if not invoices:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No invoices found for the specified criteria"
            )
        
        invoice_ids = [invoice.id for invoice in invoices]
        
        if format == "pdf" and len(invoices) == 1:
            # Single PDF
            pdf_content, filename = invoice_service.generate_invoice_pdf(invoice_ids[0])
            
            return Response(
                content=pdf_content,
                media_type="application/pdf",
                headers={
                    "Content-Disposition": f"attachment; filename=\"{filename}\"",
                    "Content-Length": str(len(pdf_content))
                }
            )
        else:
            # ZIP file
            zip_content, filename = invoice_service.generate_bulk_invoice_zip(
                invoice_ids,
                user_id=current_user.id
            )
            
            return Response(
                content=zip_content,
                media_type="application/zip",
                headers={
                    "Content-Disposition": f"attachment; filename=\"{filename}\"",
                    "Content-Length": str(len(zip_content))
                }
            )
            
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate download: {str(e)}"
        )


# Download Summary (preview before download)
@router.post("/download-summary", response_model=InvoiceDownloadSummary)
async def get_download_summary(
    download_request: InvoiceDownloadRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get summary information for invoice download.
    
    Useful for showing preview before bulk download.
    """
    # Validate invoice access (same as bulk download)
    invoices = db.query(Invoice).filter(
        Invoice.id.in_(download_request.invoice_ids)
    ).all()
    
    if not invoices:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No invoices found"
        )
    
    # Check permissions
    if not current_user.has_permission("INVOICE_READ"):
        user_invoice_ids = {invoice.user_id for invoice in invoices}
        if len(user_invoice_ids) > 1 or current_user.id not in user_invoice_ids:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to one or more invoices"
            )
    
    try:
        invoice_service = InvoiceService(db)
        summary = invoice_service.get_invoice_download_summary(download_request.invoice_ids)
        
        return InvoiceDownloadSummary(**summary)
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to generate summary: {str(e)}"
        )


# Advanced Invoice Search for Download
@router.post("/search-for-download")
async def search_invoices_for_download(
    filter_request: InvoiceFilterRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Search invoices with filters and return IDs for download.
    
    Requires: INVOICE_READ permission or user can only search their own invoices
    """
    # Build query
    query = db.query(Invoice)
    
    # Apply user filter
    if filter_request.user_id:
        if (filter_request.user_id != current_user.id and 
            not current_user.has_permission("INVOICE_READ")):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to other users' invoices"
            )
        query = query.filter(Invoice.user_id == filter_request.user_id)
    elif not current_user.has_permission("INVOICE_READ"):
        # Restrict to user's own invoices if no admin permission
        query = query.filter(Invoice.user_id == current_user.id)
    
    # Apply date filters
    if filter_request.start_date:
        query = query.filter(Invoice.invoice_date >= filter_request.start_date)
    
    if filter_request.end_date:
        query = query.filter(Invoice.invoice_date <= filter_request.end_date)
    
    # Apply payment status filter
    if filter_request.payment_status:
        query = query.filter(Invoice.payment_status.in_(filter_request.payment_status))
    
    # Apply invoice number filter
    if filter_request.invoice_numbers:
        query = query.filter(Invoice.invoice_number.in_(filter_request.invoice_numbers))
    
    # Execute query
    invoices = query.order_by(Invoice.invoice_date.desc()).all()
    
    # Return invoice information for selection
    return {
        "success": True,
        "count": len(invoices),
        "invoices": [
            {
                "id": str(invoice.id),
                "invoice_number": invoice.invoice_number,
                "invoice_date": invoice.invoice_date.isoformat(),
                "due_date": invoice.due_date.isoformat(),
                "total_amount": float(invoice.total_amount),
                "payment_status": invoice.payment_status.value,
                "customer_name": invoice.user.company_name or invoice.user.full_name if invoice.user else "Unknown",
                "is_overdue": invoice.is_overdue
            }
            for invoice in invoices
        ]
    }


# Create Download Link (for email/sharing)
@router.post("/create-download-link")
async def create_invoice_download_link(
    download_request: InvoiceDownloadRequest,
    expires_in_hours: int = Query(24, ge=1, le=168, description="Link expiration in hours"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Create a temporary download link for invoices.
    
    Useful for sharing invoice downloads via email.
    Requires: INVOICE_READ permission or ownership
    """
    # Validate access (same as bulk download)
    invoices = db.query(Invoice).filter(
        Invoice.id.in_(download_request.invoice_ids)
    ).all()
    
    if not invoices:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No invoices found"
        )
    
    # Check permissions
    if not current_user.has_permission("INVOICE_READ"):
        user_invoice_ids = {invoice.user_id for invoice in invoices}
        if len(user_invoice_ids) > 1 or current_user.id not in user_invoice_ids:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to one or more invoices"
            )
    
    try:
        invoice_service = InvoiceService(db)
        download_token = invoice_service.create_invoice_download_link(
            download_request.invoice_ids,
            expires_in_hours
        )
        
        # Generate download URL
        download_url = f"/api/v1/invoices/download/{download_token}"
        
        return {
            "success": True,
            "download_token": download_token,
            "download_url": download_url,
            "expires_in_hours": expires_in_hours,
            "expires_at": (datetime.utcnow().replace(microsecond=0) + 
                          timedelta(hours=expires_in_hours)).isoformat(),
            "invoice_count": len(invoices)
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create download link: {str(e)}"
        )


# Download via Token (public endpoint)
@router.get("/download/{download_token}")
async def download_via_token(
    download_token: str,
    db: Session = Depends(get_db)
):
    """
    Download invoices using a temporary token.
    
    Public endpoint that doesn't require authentication.
    """
    # In production, retrieve download data from Redis/database using token
    # For now, return error as this requires proper token storage implementation
    
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Token-based downloads require Redis/database implementation for token storage"
    )


# Invoice Statistics for Dashboard
@router.get("/download-stats")
async def get_invoice_download_stats(
    days: int = Query(30, ge=1, le=365, description="Number of days to analyze"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get invoice download statistics.
    
    Requires: INVOICE_READ permission
    """
    if not current_user.has_permission("INVOICE_READ"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions to view invoice statistics"
        )
    
    from datetime import timedelta
    from sqlalchemy import func, and_
    
    # Calculate date range
    end_date = date.today()
    start_date = end_date - timedelta(days=days)
    
    # Get invoice statistics
    total_invoices = db.query(Invoice).filter(
        and_(
            Invoice.invoice_date >= start_date,
            Invoice.invoice_date <= end_date
        )
    ).count()
    
    # Payment status breakdown
    status_stats = db.query(
        Invoice.payment_status,
        func.count(Invoice.id).label('count'),
        func.sum(Invoice.total_amount).label('total_amount')
    ).filter(
        and_(
            Invoice.invoice_date >= start_date,
            Invoice.invoice_date <= end_date
        )
    ).group_by(Invoice.payment_status).all()
    
    # Monthly breakdown
    monthly_stats = db.query(
        func.date_trunc('month', Invoice.invoice_date).label('month'),
        func.count(Invoice.id).label('count'),
        func.sum(Invoice.total_amount).label('total_amount')
    ).filter(
        and_(
            Invoice.invoice_date >= start_date,
            Invoice.invoice_date <= end_date
        )
    ).group_by(func.date_trunc('month', Invoice.invoice_date)).all()
    
    return {
        "success": True,
        "period": {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "days": days
        },
        "total_invoices": total_invoices,
        "payment_status_breakdown": [
            {
                "status": stat.payment_status.value,
                "count": stat.count,
                "total_amount": float(stat.total_amount or 0)
            }
            for stat in status_stats
        ],
        "monthly_breakdown": [
            {
                "month": stat.month.strftime('%Y-%m'),
                "count": stat.count,
                "total_amount": float(stat.total_amount or 0)
            }
            for stat in monthly_stats
        ]
    }
