"""
Enterprise-grade models for RentGuy application.
Includes User, Equipment, Rental, and related models with advanced features.
"""

from datetime import datetime, date
from decimal import Decimal
from enum import Enum
from typing import List, Optional

from sqlalchemy import (
    Column, String, Text, Boolean, Integer, Numeric, Date, DateTime,
    ForeignKey, Table, Index, CheckConstraint, UniqueConstraint
)
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship, validates
from sqlalchemy.ext.hybrid import hybrid_property

from .base import EnterpriseBaseModel, model_registry


# Association tables for many-to-many relationships
user_roles_table = Table(
    'user_roles',
    EnterpriseBaseModel.metadata,
    Column('user_id', UUID(as_uuid=True), ForeignKey('users.id'), primary_key=True),
    Column('role_id', UUID(as_uuid=True), ForeignKey('roles.id'), primary_key=True),
    Column('assigned_at', DateTime, default=datetime.utcnow),
    Column('assigned_by', UUID(as_uuid=True), ForeignKey('users.id'))
)

equipment_categories_table = Table(
    'equipment_categories',
    EnterpriseBaseModel.metadata,
    Column('equipment_id', UUID(as_uuid=True), ForeignKey('equipment.id'), primary_key=True),
    Column('category_id', UUID(as_uuid=True), ForeignKey('categories.id'), primary_key=True)
)


class UserStatus(str, Enum):
    """User status enumeration."""
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    PENDING_VERIFICATION = "pending_verification"


class EquipmentStatus(str, Enum):
    """Equipment status enumeration."""
    AVAILABLE = "available"
    RENTED = "rented"
    MAINTENANCE = "maintenance"
    RETIRED = "retired"
    RESERVED = "reserved"


class RentalStatus(str, Enum):
    """Rental status enumeration."""
    PENDING = "pending"
    APPROVED = "approved"
    ACTIVE = "active"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    OVERDUE = "overdue"


class PaymentStatus(str, Enum):
    """Payment status enumeration."""
    PENDING = "pending"
    PAID = "paid"
    PARTIAL = "partial"
    OVERDUE = "overdue"
    REFUNDED = "refunded"


class User(EnterpriseBaseModel):
    """Enterprise user model with comprehensive features."""
    
    __tablename__ = 'users'
    
    # Basic information
    email = Column(String(255), unique=True, nullable=False, index=True)
    username = Column(String(100), unique=True, nullable=True, index=True)
    password_hash = Column(String(255), nullable=False)
    
    # Personal information
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=False)
    phone = Column(String(20), nullable=True)
    date_of_birth = Column(Date, nullable=True)
    
    # Address information
    address_line1 = Column(String(255), nullable=True)
    address_line2 = Column(String(255), nullable=True)
    city = Column(String(100), nullable=True)
    state = Column(String(100), nullable=True)
    postal_code = Column(String(20), nullable=True)
    country = Column(String(100), default="Netherlands", nullable=False)
    
    # Account status and settings
    user_status = Column(String(50), default=UserStatus.PENDING_VERIFICATION, nullable=False)
    is_email_verified = Column(Boolean, default=False, nullable=False)
    is_phone_verified = Column(Boolean, default=False, nullable=False)
    is_two_factor_enabled = Column(Boolean, default=False, nullable=False)
    
    # Authentication and security
    last_login_at = Column(DateTime, nullable=True)
    last_login_ip = Column(String(45), nullable=True)  # IPv6 support
    failed_login_attempts = Column(Integer, default=0, nullable=False)
    locked_until = Column(DateTime, nullable=True)
    password_changed_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Preferences and settings
    language = Column(String(10), default="nl", nullable=False)
    timezone = Column(String(50), default="Europe/Amsterdam", nullable=False)
    notification_preferences = Column(JSONB, nullable=True)
    
    # Business information (for business accounts)
    company_name = Column(String(255), nullable=True)
    vat_number = Column(String(50), nullable=True)
    business_type = Column(String(100), nullable=True)
    
    # Credit and financial information
    credit_limit = Column(Numeric(10, 2), default=0.00, nullable=False)
    current_balance = Column(Numeric(10, 2), default=0.00, nullable=False)
    payment_terms = Column(Integer, default=30, nullable=False)  # Days
    
    # Relationships
    roles = relationship("Role", secondary=user_roles_table, back_populates="users")
    rentals = relationship("Rental", back_populates="user", cascade="all, delete-orphan")
    invoices = relationship("Invoice", back_populates="user")
    user_sessions = relationship("UserSession", back_populates="user", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index('idx_user_email_status', 'email', 'user_status'),
        Index('idx_user_company', 'company_name'),
        Index('idx_user_location', 'city', 'country'),
        CheckConstraint('credit_limit >= 0', name='check_credit_limit_positive'),
        CheckConstraint('failed_login_attempts >= 0', name='check_failed_attempts_positive'),
    )
    
    @hybrid_property
    def full_name(self) -> str:
        """Get user's full name."""
        return f"{self.first_name} {self.last_name}".strip()
    
    @hybrid_property
    def is_business_account(self) -> bool:
        """Check if this is a business account."""
        return self.company_name is not None and len(self.company_name.strip()) > 0
    
    @hybrid_property
    def is_account_locked(self) -> bool:
        """Check if account is currently locked."""
        if not self.locked_until:
            return False
        return datetime.utcnow() < self.locked_until
    
    @validates('email')
    def validate_email(self, key, email):
        """Validate email format."""
        import re
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            raise ValueError("Invalid email format")
        return email.lower()
    
    @validates('phone')
    def validate_phone(self, key, phone):
        """Validate phone format."""
        if phone:
            # Remove all non-digit characters
            digits_only = ''.join(filter(str.isdigit, phone))
            if len(digits_only) < 10:
                raise ValueError("Phone number must have at least 10 digits")
        return phone
    
    def set_password(self, password: str):
        """Set user password with hashing."""
        from ..core.security import password_manager
        
        # Validate password strength
        validation = password_manager.validate_password_strength(password)
        if not validation["valid"]:
            raise ValueError(f"Password validation failed: {', '.join(validation['issues'])}")
        
        self.password_hash = password_manager.hash_password(password)
        self.password_changed_at = datetime.utcnow()
    
    def verify_password(self, password: str) -> bool:
        """Verify password against hash."""
        from ..core.security import password_manager
        return password_manager.verify_password(password, self.password_hash)
    
    def lock_account(self, duration_minutes: int = 15):
        """Lock user account for specified duration."""
        self.locked_until = datetime.utcnow() + timedelta(minutes=duration_minutes)
        self.failed_login_attempts += 1
    
    def unlock_account(self):
        """Unlock user account."""
        self.locked_until = None
        self.failed_login_attempts = 0
    
    def get_active_rentals(self):
        """Get user's active rentals."""
        return [rental for rental in self.rentals if rental.status == RentalStatus.ACTIVE]
    
    def get_total_rental_value(self) -> Decimal:
        """Get total value of active rentals."""
        active_rentals = self.get_active_rentals()
        return sum(rental.total_amount for rental in active_rentals)
    
    def can_rent(self, equipment_value: Decimal) -> bool:
        """Check if user can rent equipment based on credit limit."""
        current_rental_value = self.get_total_rental_value()
        return (current_rental_value + equipment_value) <= self.credit_limit


class Role(EnterpriseBaseModel):
    """Role model for RBAC system."""
    
    __tablename__ = 'roles'
    
    name = Column(String(100), unique=True, nullable=False)
    display_name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    permissions = Column(ARRAY(String), nullable=True)
    is_system_role = Column(Boolean, default=False, nullable=False)
    
    # Relationships
    users = relationship("User", secondary=user_roles_table, back_populates="roles")
    
    def has_permission(self, permission: str) -> bool:
        """Check if role has specific permission."""
        return permission in (self.permissions or [])


class Category(EnterpriseBaseModel):
    """Equipment category model."""
    
    __tablename__ = 'categories'
    
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text, nullable=True)
    parent_id = Column(UUID(as_uuid=True), ForeignKey('categories.id'), nullable=True)
    icon = Column(String(100), nullable=True)
    color = Column(String(7), nullable=True)  # Hex color code
    sort_order = Column(Integer, default=0, nullable=False)
    
    # Relationships
    parent = relationship("Category", remote_side="Category.id", back_populates="children")
    children = relationship("Category", back_populates="parent")
    equipment = relationship("Equipment", secondary=equipment_categories_table, back_populates="categories")
    
    @hybrid_property
    def full_path(self) -> str:
        """Get full category path."""
        if self.parent:
            return f"{self.parent.full_path} > {self.name}"
        return self.name


class Equipment(EnterpriseBaseModel):
    """Enterprise equipment model with comprehensive features."""
    
    __tablename__ = 'equipment'
    
    # Basic information
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    model = Column(String(100), nullable=True)
    brand = Column(String(100), nullable=True)
    serial_number = Column(String(100), unique=True, nullable=True)
    barcode = Column(String(100), unique=True, nullable=True)
    
    # Status and availability
    equipment_status = Column(String(50), default=EquipmentStatus.AVAILABLE, nullable=False)
    condition = Column(String(50), default="excellent", nullable=False)
    location = Column(String(255), nullable=True)
    
    # Financial information
    purchase_price = Column(Numeric(10, 2), nullable=True)
    current_value = Column(Numeric(10, 2), nullable=True)
    daily_rate = Column(Numeric(8, 2), nullable=False)
    weekly_rate = Column(Numeric(8, 2), nullable=True)
    monthly_rate = Column(Numeric(8, 2), nullable=True)
    deposit_amount = Column(Numeric(8, 2), default=0.00, nullable=False)
    
    # Technical specifications
    specifications = Column(JSONB, nullable=True)
    dimensions = Column(String(100), nullable=True)  # L x W x H
    weight = Column(Numeric(8, 2), nullable=True)  # in kg
    power_requirements = Column(String(100), nullable=True)
    
    # Maintenance and lifecycle
    purchase_date = Column(Date, nullable=True)
    warranty_expiry = Column(Date, nullable=True)
    last_maintenance_date = Column(Date, nullable=True)
    next_maintenance_date = Column(Date, nullable=True)
    maintenance_interval_days = Column(Integer, default=365, nullable=False)
    
    # Usage tracking
    total_rental_days = Column(Integer, default=0, nullable=False)
    total_revenue = Column(Numeric(12, 2), default=0.00, nullable=False)
    usage_hours = Column(Integer, default=0, nullable=True)
    
    # Media and documentation
    images = Column(ARRAY(String), nullable=True)
    documents = Column(ARRAY(String), nullable=True)
    manual_url = Column(String(500), nullable=True)
    
    # Relationships
    categories = relationship("Category", secondary=equipment_categories_table, back_populates="equipment")
    rentals = relationship("Rental", back_populates="equipment")
    maintenance_records = relationship("MaintenanceRecord", back_populates="equipment", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index('idx_equipment_status', 'equipment_status'),
        Index('idx_equipment_brand_model', 'brand', 'model'),
        Index('idx_equipment_location', 'location'),
        Index('idx_equipment_rates', 'daily_rate', 'weekly_rate'),
        CheckConstraint('daily_rate > 0', name='check_daily_rate_positive'),
        CheckConstraint('deposit_amount >= 0', name='check_deposit_positive'),
        CheckConstraint('total_rental_days >= 0', name='check_rental_days_positive'),
    )
    
    @hybrid_property
    def is_available(self) -> bool:
        """Check if equipment is available for rental."""
        return self.equipment_status == EquipmentStatus.AVAILABLE
    
    @hybrid_property
    def needs_maintenance(self) -> bool:
        """Check if equipment needs maintenance."""
        if not self.next_maintenance_date:
            return False
        return date.today() >= self.next_maintenance_date
    
    @validates('serial_number')
    def validate_serial_number(self, key, serial_number):
        """Validate serial number format."""
        if serial_number and len(serial_number.strip()) < 3:
            raise ValueError("Serial number must be at least 3 characters long")
        return serial_number
    
    def calculate_rental_cost(self, start_date: date, end_date: date) -> Decimal:
        """Calculate rental cost for given period."""
        if start_date >= end_date:
            raise ValueError("End date must be after start date")
        
        days = (end_date - start_date).days
        
        # Use monthly rate if available and rental is 30+ days
        if self.monthly_rate and days >= 30:
            months = days // 30
            remaining_days = days % 30
            cost = (months * self.monthly_rate) + (remaining_days * self.daily_rate)
        # Use weekly rate if available and rental is 7+ days
        elif self.weekly_rate and days >= 7:
            weeks = days // 7
            remaining_days = days % 7
            cost = (weeks * self.weekly_rate) + (remaining_days * self.daily_rate)
        else:
            cost = days * self.daily_rate
        
        return cost
    
    def schedule_maintenance(self, days_from_now: int = None):
        """Schedule next maintenance."""
        if days_from_now is None:
            days_from_now = self.maintenance_interval_days
        
        from datetime import timedelta
        self.next_maintenance_date = date.today() + timedelta(days=days_from_now)
    
    def update_usage_stats(self, rental_days: int, revenue: Decimal):
        """Update equipment usage statistics."""
        self.total_rental_days += rental_days
        self.total_revenue += revenue
    
    def get_utilization_rate(self, period_days: int = 365) -> float:
        """Calculate equipment utilization rate."""
        if period_days <= 0:
            return 0.0
        
        # Get rental days in the specified period
        from datetime import timedelta
        cutoff_date = date.today() - timedelta(days=period_days)
        
        recent_rental_days = sum(
            (rental.end_date - rental.start_date).days
            for rental in self.rentals
            if rental.start_date >= cutoff_date and rental.status == RentalStatus.COMPLETED
        )
        
        return (recent_rental_days / period_days) * 100


class Rental(EnterpriseBaseModel):
    """Enterprise rental model with comprehensive tracking."""
    
    __tablename__ = 'rentals'
    
    # References
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    equipment_id = Column(UUID(as_uuid=True), ForeignKey('equipment.id'), nullable=False)
    
    # Rental period
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    actual_return_date = Column(Date, nullable=True)
    
    # Status and tracking
    rental_status = Column(String(50), default=RentalStatus.PENDING, nullable=False)
    rental_type = Column(String(50), default="standard", nullable=False)  # standard, emergency, maintenance
    
    # Financial information
    daily_rate = Column(Numeric(8, 2), nullable=False)  # Rate at time of rental
    total_amount = Column(Numeric(10, 2), nullable=False)
    deposit_amount = Column(Numeric(8, 2), default=0.00, nullable=False)
    late_fee = Column(Numeric(8, 2), default=0.00, nullable=False)
    damage_fee = Column(Numeric(8, 2), default=0.00, nullable=False)
    
    # Delivery and pickup
    delivery_required = Column(Boolean, default=False, nullable=False)
    delivery_address = Column(Text, nullable=True)
    delivery_fee = Column(Numeric(6, 2), default=0.00, nullable=False)
    pickup_required = Column(Boolean, default=False, nullable=False)
    pickup_fee = Column(Numeric(6, 2), default=0.00, nullable=False)
    
    # Notes and documentation
    notes = Column(Text, nullable=True)
    special_instructions = Column(Text, nullable=True)
    condition_at_pickup = Column(Text, nullable=True)
    condition_at_return = Column(Text, nullable=True)
    
    # Approval workflow
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    rejection_reason = Column(Text, nullable=True)
    
    # Relationships
    user = relationship("User", foreign_keys=[user_id], back_populates="rentals")
    equipment = relationship("Equipment", back_populates="rentals")
    approver = relationship("User", foreign_keys=[approved_by])
    invoices = relationship("Invoice", back_populates="rental")
    
    # Indexes
    __table_args__ = (
        Index('idx_rental_dates', 'start_date', 'end_date'),
        Index('idx_rental_status', 'rental_status'),
        Index('idx_rental_user', 'user_id', 'rental_status'),
        Index('idx_rental_equipment', 'equipment_id', 'rental_status'),
        CheckConstraint('end_date > start_date', name='check_rental_dates'),
        CheckConstraint('total_amount >= 0', name='check_total_amount_positive'),
        CheckConstraint('deposit_amount >= 0', name='check_deposit_positive'),
    )
    
    @hybrid_property
    def duration_days(self) -> int:
        """Get rental duration in days."""
        return (self.end_date - self.start_date).days
    
    @hybrid_property
    def is_overdue(self) -> bool:
        """Check if rental is overdue."""
        if self.actual_return_date:
            return False
        return date.today() > self.end_date
    
    @hybrid_property
    def days_overdue(self) -> int:
        """Get number of days overdue."""
        if not self.is_overdue:
            return 0
        return (date.today() - self.end_date).days
    
    @validates('start_date', 'end_date')
    def validate_dates(self, key, value):
        """Validate rental dates."""
        if key == 'start_date' and value < date.today():
            raise ValueError("Start date cannot be in the past")
        if key == 'end_date' and hasattr(self, 'start_date') and self.start_date and value <= self.start_date:
            raise ValueError("End date must be after start date")
        return value
    
    def calculate_total_cost(self) -> Decimal:
        """Calculate total rental cost including fees."""
        base_cost = self.total_amount
        total_fees = self.delivery_fee + self.pickup_fee + self.late_fee + self.damage_fee
        return base_cost + total_fees
    
    def approve(self, approver_id: str):
        """Approve rental request."""
        self.rental_status = RentalStatus.APPROVED
        self.approved_by = approver_id
        self.approved_at = datetime.utcnow()
        
        # Update equipment status
        self.equipment.equipment_status = EquipmentStatus.RESERVED
    
    def start_rental(self):
        """Start the rental period."""
        self.rental_status = RentalStatus.ACTIVE
        self.equipment.equipment_status = EquipmentStatus.RENTED
    
    def complete_rental(self, return_condition: str = None):
        """Complete the rental."""
        self.rental_status = RentalStatus.COMPLETED
        self.actual_return_date = date.today()
        self.condition_at_return = return_condition
        
        # Update equipment status and stats
        self.equipment.equipment_status = EquipmentStatus.AVAILABLE
        self.equipment.update_usage_stats(self.duration_days, self.total_amount)
    
    def cancel_rental(self, reason: str = None):
        """Cancel the rental."""
        self.rental_status = RentalStatus.CANCELLED
        self.rejection_reason = reason
        
        # Free up equipment
        if self.equipment.equipment_status in [EquipmentStatus.RESERVED, EquipmentStatus.RENTED]:
            self.equipment.equipment_status = EquipmentStatus.AVAILABLE


class Invoice(EnterpriseBaseModel):
    """Enterprise invoice model."""
    
    __tablename__ = 'invoices'
    
    # References
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    rental_id = Column(UUID(as_uuid=True), ForeignKey('rentals.id'), nullable=True)
    
    # Invoice details
    invoice_number = Column(String(50), unique=True, nullable=False)
    invoice_date = Column(Date, default=date.today, nullable=False)
    due_date = Column(Date, nullable=False)
    
    # Financial information
    subtotal = Column(Numeric(10, 2), nullable=False)
    tax_rate = Column(Numeric(5, 4), default=0.21, nullable=False)  # 21% VAT
    tax_amount = Column(Numeric(10, 2), nullable=False)
    total_amount = Column(Numeric(10, 2), nullable=False)
    paid_amount = Column(Numeric(10, 2), default=0.00, nullable=False)
    
    # Status
    payment_status = Column(String(50), default=PaymentStatus.PENDING, nullable=False)
    payment_method = Column(String(50), nullable=True)
    payment_reference = Column(String(100), nullable=True)
    paid_at = Column(DateTime, nullable=True)
    
    # Additional information
    notes = Column(Text, nullable=True)
    terms_and_conditions = Column(Text, nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="invoices")
    rental = relationship("Rental", back_populates="invoices")
    
    # Indexes
    __table_args__ = (
        Index('idx_invoice_number', 'invoice_number'),
        Index('idx_invoice_status', 'payment_status'),
        Index('idx_invoice_dates', 'invoice_date', 'due_date'),
        CheckConstraint('total_amount > 0', name='check_invoice_total_positive'),
        CheckConstraint('paid_amount >= 0', name='check_paid_amount_positive'),
    )
    
    @hybrid_property
    def balance_due(self) -> Decimal:
        """Get remaining balance due."""
        return self.total_amount - self.paid_amount
    
    @hybrid_property
    def is_overdue(self) -> bool:
        """Check if invoice is overdue."""
        return date.today() > self.due_date and self.payment_status != PaymentStatus.PAID
    
    def calculate_totals(self):
        """Calculate tax and total amounts."""
        self.tax_amount = self.subtotal * self.tax_rate
        self.total_amount = self.subtotal + self.tax_amount
    
    def record_payment(self, amount: Decimal, method: str = None, reference: str = None):
        """Record a payment against this invoice."""
        self.paid_amount += amount
        self.payment_method = method
        self.payment_reference = reference
        
        if self.paid_amount >= self.total_amount:
            self.payment_status = PaymentStatus.PAID
            self.paid_at = datetime.utcnow()
        elif self.paid_amount > 0:
            self.payment_status = PaymentStatus.PARTIAL


class MaintenanceRecord(EnterpriseBaseModel):
    """Equipment maintenance record model."""
    
    __tablename__ = 'maintenance_records'
    
    # References
    equipment_id = Column(UUID(as_uuid=True), ForeignKey('equipment.id'), nullable=False)
    performed_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=True)
    
    # Maintenance details
    maintenance_type = Column(String(50), nullable=False)  # routine, repair, inspection
    description = Column(Text, nullable=False)
    maintenance_date = Column(Date, default=date.today, nullable=False)
    
    # Cost and parts
    labor_cost = Column(Numeric(8, 2), default=0.00, nullable=False)
    parts_cost = Column(Numeric(8, 2), default=0.00, nullable=False)
    total_cost = Column(Numeric(8, 2), nullable=False)
    
    # Status and completion
    is_completed = Column(Boolean, default=False, nullable=False)
    completion_date = Column(Date, nullable=True)
    next_maintenance_due = Column(Date, nullable=True)
    
    # Documentation
    work_performed = Column(Text, nullable=True)
    parts_replaced = Column(ARRAY(String), nullable=True)
    photos = Column(ARRAY(String), nullable=True)
    
    # Relationships
    equipment = relationship("Equipment", back_populates="maintenance_records")
    technician = relationship("User", foreign_keys=[performed_by])
    
    def complete_maintenance(self):
        """Mark maintenance as completed."""
        self.is_completed = True
        self.completion_date = date.today()
        self.total_cost = self.labor_cost + self.parts_cost
        
        # Update equipment maintenance date
        self.equipment.last_maintenance_date = self.completion_date
        if self.next_maintenance_due:
            self.equipment.next_maintenance_date = self.next_maintenance_due


class UserSession(EnterpriseBaseModel):
    """User session tracking model."""
    
    __tablename__ = 'user_sessions'
    
    # References
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    
    # Session information
    session_token = Column(String(255), unique=True, nullable=False)
    ip_address = Column(String(45), nullable=True)
    user_agent = Column(Text, nullable=True)
    
    # Timing
    login_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    last_activity = Column(DateTime, default=datetime.utcnow, nullable=False)
    logout_at = Column(DateTime, nullable=True)
    expires_at = Column(DateTime, nullable=False)
    
    # Status
    is_active = Column(Boolean, default=True, nullable=False)
    
    # Relationships
    user = relationship("User", back_populates="user_sessions")
    
    @hybrid_property
    def is_expired(self) -> bool:
        """Check if session is expired."""
        return datetime.utcnow() > self.expires_at
    
    def extend_session(self, minutes: int = 60):
        """Extend session expiry."""
        from datetime import timedelta
        self.expires_at = datetime.utcnow() + timedelta(minutes=minutes)
        self.last_activity = datetime.utcnow()
    
    def terminate_session(self):
        """Terminate the session."""
        self.is_active = False
        self.logout_at = datetime.utcnow()


# Register all models
for model_class in [User, Role, Category, Equipment, Rental, Invoice, MaintenanceRecord, UserSession]:
    model_registry.register_model(model_class)
