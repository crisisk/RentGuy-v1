"""
Enterprise-grade base models for RentGuy.
Provides common functionality, audit trails, and advanced features.
"""

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import Column, DateTime, String, Text, Boolean, event
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.orm import Session

from ..core.database import Base
from ..core.logging import audit_logger, get_logger

logger = get_logger(__name__)


class TimestampMixin:
    """Mixin for automatic timestamp management."""
    
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class UUIDMixin:
    """Mixin for UUID primary keys."""
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, nullable=False)


class SoftDeleteMixin:
    """Mixin for soft delete functionality."""
    
    deleted_at = Column(DateTime, nullable=True)
    is_deleted = Column(Boolean, default=False, nullable=False)
    
    def soft_delete(self):
        """Mark record as deleted without removing from database."""
        self.is_deleted = True
        self.deleted_at = datetime.utcnow()
    
    def restore(self):
        """Restore soft-deleted record."""
        self.is_deleted = False
        self.deleted_at = None


class AuditMixin:
    """Mixin for audit trail functionality."""
    
    created_by = Column(UUID(as_uuid=True), nullable=True)
    updated_by = Column(UUID(as_uuid=True), nullable=True)
    deleted_by = Column(UUID(as_uuid=True), nullable=True)
    
    version = Column(String(50), default="1.0", nullable=False)
    metadata_ = Column(Text, nullable=True)  # JSON metadata


class BaseModel(Base, UUIDMixin, TimestampMixin, SoftDeleteMixin, AuditMixin):
    """
    Enterprise base model with comprehensive functionality.
    """
    
    __abstract__ = True
    
    def __repr__(self):
        """String representation of model."""
        return f"<{self.__class__.__name__}(id={self.id})>"
    
    def to_dict(self, exclude: Optional[List[str]] = None) -> Dict[str, Any]:
        """Convert model to dictionary."""
        exclude = exclude or []
        result = {}
        
        for column in self.__table__.columns:
            if column.name not in exclude:
                value = getattr(self, column.name)
                if isinstance(value, datetime):
                    value = value.isoformat()
                elif isinstance(value, uuid.UUID):
                    value = str(value)
                result[column.name] = value
        
        return result
    
    def update_from_dict(self, data: Dict[str, Any], exclude: Optional[List[str]] = None):
        """Update model from dictionary."""
        exclude = exclude or ['id', 'created_at', 'updated_at']
        
        for key, value in data.items():
            if key not in exclude and hasattr(self, key):
                setattr(self, key, value)
    
    @classmethod
    def create(cls, session: Session, **kwargs):
        """Create new instance with audit logging."""
        instance = cls(**kwargs)
        session.add(instance)
        session.flush()  # Get ID without committing
        
        audit_logger.log_data_access(
            operation="create",
            table=cls.__tablename__,
            user_id=kwargs.get('created_by', 'system'),
            record_id=str(instance.id)
        )
        
        return instance
    
    def update(self, session: Session, **kwargs):
        """Update instance with audit logging."""
        old_values = self.to_dict()
        
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        
        self.updated_at = datetime.utcnow()
        
        audit_logger.log_data_access(
            operation="update",
            table=self.__tablename__,
            user_id=kwargs.get('updated_by', 'system'),
            record_id=str(self.id),
            fields=list(kwargs.keys())
        )
        
        return self
    
    def delete(self, session: Session, user_id: Optional[str] = None, hard_delete: bool = False):
        """Delete instance with audit logging."""
        if hard_delete:
            session.delete(self)
            operation = "hard_delete"
        else:
            self.soft_delete()
            self.deleted_by = user_id
            operation = "soft_delete"
        
        audit_logger.log_data_access(
            operation=operation,
            table=self.__tablename__,
            user_id=user_id or 'system',
            record_id=str(self.id)
        )


class VersionedMixin:
    """Mixin for optimistic locking with version control."""
    
    version_number = Column(String(20), default="1", nullable=False)
    
    def increment_version(self):
        """Increment version number."""
        try:
            current = int(self.version_number)
            self.version_number = str(current + 1)
        except ValueError:
            # Handle semantic versioning or custom formats
            parts = self.version_number.split('.')
            if len(parts) >= 1:
                try:
                    major = int(parts[0])
                    self.version_number = f"{major + 1}.0"
                except ValueError:
                    self.version_number = "2.0"


class MetadataMixin:
    """Mixin for flexible metadata storage."""
    
    metadata_json = Column(Text, nullable=True)
    tags = Column(Text, nullable=True)  # Comma-separated tags
    
    def set_metadata(self, key: str, value: Any):
        """Set metadata value."""
        import json
        
        metadata = {}
        if self.metadata_json:
            try:
                metadata = json.loads(self.metadata_json)
            except json.JSONDecodeError:
                metadata = {}
        
        metadata[key] = value
        self.metadata_json = json.dumps(metadata)
    
    def get_metadata(self, key: str, default: Any = None) -> Any:
        """Get metadata value."""
        import json
        
        if not self.metadata_json:
            return default
        
        try:
            metadata = json.loads(self.metadata_json)
            return metadata.get(key, default)
        except json.JSONDecodeError:
            return default
    
    def add_tag(self, tag: str):
        """Add tag to model."""
        tags = self.get_tags()
        if tag not in tags:
            tags.append(tag)
            self.tags = ','.join(tags)
    
    def remove_tag(self, tag: str):
        """Remove tag from model."""
        tags = self.get_tags()
        if tag in tags:
            tags.remove(tag)
            self.tags = ','.join(tags)
    
    def get_tags(self) -> List[str]:
        """Get list of tags."""
        if not self.tags:
            return []
        return [tag.strip() for tag in self.tags.split(',') if tag.strip()]


class SearchableMixin:
    """Mixin for full-text search functionality."""
    
    search_vector = Column(Text, nullable=True)  # For PostgreSQL full-text search
    
    @classmethod
    def search(cls, session: Session, query: str, limit: int = 50):
        """Perform full-text search."""
        # This would implement PostgreSQL full-text search
        # For now, simple LIKE search
        search_term = f"%{query}%"
        
        # Search in common text fields
        filters = []
        for column in cls.__table__.columns:
            if column.type.python_type == str:
                filters.append(getattr(cls, column.name).ilike(search_term))
        
        if filters:
            from sqlalchemy import or_
            return session.query(cls).filter(or_(*filters)).limit(limit).all()
        
        return []


class CacheableMixin:
    """Mixin for caching support."""
    
    cache_key_prefix = "model"
    cache_ttl = 3600  # 1 hour
    
    @property
    def cache_key(self) -> str:
        """Generate cache key for this instance."""
        return f"{self.cache_key_prefix}:{self.__class__.__name__.lower()}:{self.id}"
    
    def invalidate_cache(self):
        """Invalidate cache for this instance."""
        # This would integrate with Redis or other cache
        logger.info("Cache invalidated", model=self.__class__.__name__, id=str(self.id))


class ValidatedMixin:
    """Mixin for model validation."""
    
    def validate(self) -> List[str]:
        """Validate model and return list of errors."""
        errors = []
        
        # Basic validation - override in subclasses
        if hasattr(self, 'name') and not getattr(self, 'name'):
            errors.append("Name is required")
        
        if hasattr(self, 'email') and getattr(self, 'email'):
            email = getattr(self, 'email')
            if '@' not in email:
                errors.append("Invalid email format")
        
        return errors
    
    def is_valid(self) -> bool:
        """Check if model is valid."""
        return len(self.validate()) == 0


class EnterpriseBaseModel(BaseModel, VersionedMixin, MetadataMixin, SearchableMixin, CacheableMixin, ValidatedMixin):
    """
    Complete enterprise base model with all features.
    """
    
    __abstract__ = True
    
    # Additional enterprise features
    tenant_id = Column(UUID(as_uuid=True), nullable=True)  # Multi-tenancy support
    status = Column(String(50), default="active", nullable=False)
    priority = Column(String(20), default="normal", nullable=False)
    
    def __init__(self, **kwargs):
        """Initialize with validation."""
        super().__init__(**kwargs)
        
        # Set default tenant if not provided
        if not self.tenant_id and hasattr(self, '_current_tenant_id'):
            self.tenant_id = self._current_tenant_id
    
    @classmethod
    def set_current_tenant(cls, tenant_id: str):
        """Set current tenant for new instances."""
        cls._current_tenant_id = tenant_id
    
    def can_access(self, user_tenant_id: str) -> bool:
        """Check if user can access this record (multi-tenancy)."""
        return self.tenant_id is None or str(self.tenant_id) == user_tenant_id
    
    def archive(self, user_id: Optional[str] = None):
        """Archive record (different from soft delete)."""
        self.status = "archived"
        self.updated_by = user_id
        self.updated_at = datetime.utcnow()
        
        audit_logger.log_data_access(
            operation="archive",
            table=self.__tablename__,
            user_id=user_id or 'system',
            record_id=str(self.id)
        )
    
    def activate(self, user_id: Optional[str] = None):
        """Activate archived record."""
        self.status = "active"
        self.updated_by = user_id
        self.updated_at = datetime.utcnow()
        
        audit_logger.log_data_access(
            operation="activate",
            table=self.__tablename__,
            user_id=user_id or 'system',
            record_id=str(self.id)
        )


# Event listeners for automatic audit logging
@event.listens_for(BaseModel, 'before_insert', propagate=True)
def before_insert_listener(mapper, connection, target):
    """Log before insert events."""
    logger.debug(
        "Model insert",
        model=target.__class__.__name__,
        id=str(target.id) if hasattr(target, 'id') else None
    )


@event.listens_for(BaseModel, 'before_update', propagate=True)
def before_update_listener(mapper, connection, target):
    """Log before update events."""
    logger.debug(
        "Model update",
        model=target.__class__.__name__,
        id=str(target.id) if hasattr(target, 'id') else None
    )


@event.listens_for(BaseModel, 'before_delete', propagate=True)
def before_delete_listener(mapper, connection, target):
    """Log before delete events."""
    logger.debug(
        "Model delete",
        model=target.__class__.__name__,
        id=str(target.id) if hasattr(target, 'id') else None
    )


class ModelRegistry:
    """Registry for tracking all models and their relationships."""
    
    def __init__(self):
        self.models = {}
        self.relationships = {}
    
    def register_model(self, model_class):
        """Register a model class."""
        self.models[model_class.__name__] = model_class
        logger.info("Model registered", model=model_class.__name__)
    
    def get_model(self, name: str):
        """Get model class by name."""
        return self.models.get(name)
    
    def list_models(self) -> List[str]:
        """List all registered model names."""
        return list(self.models.keys())
    
    def get_model_info(self, name: str) -> Dict[str, Any]:
        """Get detailed information about a model."""
        model_class = self.get_model(name)
        if not model_class:
            return {}
        
        return {
            "name": name,
            "table_name": getattr(model_class, '__tablename__', None),
            "columns": [col.name for col in model_class.__table__.columns] if hasattr(model_class, '__table__') else [],
            "mixins": [base.__name__ for base in model_class.__bases__ if base != Base],
            "abstract": getattr(model_class, '__abstract__', False)
        }


# Global model registry
model_registry = ModelRegistry()
