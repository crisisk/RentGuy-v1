"""
AI-powered Customer Service and Automation for RentGuy Enterprise.
Provides intelligent customer support, automated responses, and service optimization.
"""

import asyncio
import json
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum

from .ensemble_architecture import (
    TaskType, TaskPriority, EnsembleStrategy,
    create_and_process_task, AITask, AIResponse
)
from ..core.logging import get_logger
from ..core.monitoring import get_metrics_collector

logger = get_logger(__name__)
metrics = get_metrics_collector()


class ConversationType(str, Enum):
    """Types of customer conversations."""
    INQUIRY = "inquiry"
    SUPPORT = "support"
    COMPLAINT = "complaint"
    BOOKING = "booking"
    MODIFICATION = "modification"
    CANCELLATION = "cancellation"
    TECHNICAL = "technical"
    BILLING = "billing"
    GENERAL = "general"


class SentimentType(str, Enum):
    """Customer sentiment types."""
    POSITIVE = "positive"
    NEUTRAL = "neutral"
    NEGATIVE = "negative"
    FRUSTRATED = "frustrated"
    SATISFIED = "satisfied"
    CONFUSED = "confused"


class UrgencyLevel(str, Enum):
    """Urgency levels for customer issues."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class CustomerMessage:
    """Represents a customer message."""
    id: str
    customer_id: str
    content: str
    channel: str  # email, chat, phone, etc.
    timestamp: datetime = field(default_factory=datetime.utcnow)
    conversation_type: Optional[ConversationType] = None
    sentiment: Optional[SentimentType] = None
    urgency: Optional[UrgencyLevel] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AIResponse_CS:
    """AI-generated customer service response."""
    id: str
    message_id: str
    content: str
    confidence: float
    response_type: str
    suggested_actions: List[str]
    escalation_needed: bool
    follow_up_required: bool
    created_at: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CustomerInsight:
    """Customer behavior insight."""
    customer_id: str
    insight_type: str
    description: str
    confidence: float
    recommendations: List[str]
    created_at: datetime = field(default_factory=datetime.utcnow)


class CustomerServiceAI:
    """AI-powered customer service engine."""
    
    def __init__(self):
        self.conversation_history = {}
        self.customer_profiles = {}
        self.response_templates = self._load_response_templates()
    
    async def analyze_customer_message(self, message: CustomerMessage) -> Dict[str, Any]:
        """Analyze customer message for type, sentiment, and urgency."""
        analysis_prompt = f"""
        Analyze the following customer message for RentGuy equipment rental service:
        
        Message: "{message.content}"
        Channel: {message.channel}
        Customer ID: {message.customer_id}
        
        Provide analysis in the following JSON format:
        {{
            "conversation_type": "inquiry|support|complaint|booking|modification|cancellation|technical|billing|general",
            "sentiment": "positive|neutral|negative|frustrated|satisfied|confused",
            "urgency": "low|medium|high|critical",
            "key_topics": ["topic1", "topic2"],
            "customer_intent": "brief description of what customer wants",
            "requires_human": true/false,
            "confidence": 0.0-1.0
        }}
        """
        
        response = await create_and_process_task(
            task_type=TaskType.CLASSIFICATION,
            prompt=analysis_prompt,
            priority=TaskPriority.HIGH,
            context={"message_id": message.id, "customer_id": message.customer_id},
            expected_format="json",
            strategy=EnsembleStrategy.CONSENSUS
        )
        
        try:
            analysis = json.loads(response.content)
            
            # Update message with analysis
            message.conversation_type = ConversationType(analysis.get("conversation_type", "general"))
            message.sentiment = SentimentType(analysis.get("sentiment", "neutral"))
            message.urgency = UrgencyLevel(analysis.get("urgency", "medium"))
            message.metadata.update({
                "key_topics": analysis.get("key_topics", []),
                "customer_intent": analysis.get("customer_intent", ""),
                "requires_human": analysis.get("requires_human", False),
                "analysis_confidence": analysis.get("confidence", 0.0)
            })
            
            return analysis
            
        except json.JSONDecodeError:
            logger.error(f"Failed to parse message analysis: {response.content}")
            return {
                "conversation_type": "general",
                "sentiment": "neutral",
                "urgency": "medium",
                "key_topics": [],
                "customer_intent": "Unable to analyze",
                "requires_human": True,
                "confidence": 0.0
            }
    
    async def generate_response(self, message: CustomerMessage, analysis: Dict[str, Any]) -> AIResponse_CS:
        """Generate AI response to customer message."""
        # Get customer context
        customer_context = await self._get_customer_context(message.customer_id)
        
        # Get conversation history
        conversation_history = self._get_conversation_history(message.customer_id)
        
        # Build response prompt
        response_prompt = f"""
        Generate a professional, helpful response to this customer message for RentGuy equipment rental service:
        
        Customer Message: "{message.content}"
        Message Analysis: {json.dumps(analysis, indent=2)}
        Customer Context: {json.dumps(customer_context, indent=2)}
        Conversation History: {json.dumps(conversation_history[-3:], indent=2) if conversation_history else "None"}
        
        Guidelines:
        1. Be professional, friendly, and helpful
        2. Address the customer's specific concern or question
        3. Provide relevant information about equipment, pricing, or policies
        4. Suggest next steps or actions when appropriate
        5. Use the customer's name if available
        6. Match the tone to the customer's sentiment
        7. Keep responses concise but complete
        
        Response should be ready to send directly to the customer.
        """
        
        response = await create_and_process_task(
            task_type=TaskType.GENERATION,
            prompt=response_prompt,
            priority=self._get_priority_from_urgency(message.urgency),
            context={
                "message_id": message.id,
                "customer_id": message.customer_id,
                "conversation_type": message.conversation_type.value if message.conversation_type else "general"
            },
            strategy=EnsembleStrategy.WEIGHTED_AVERAGE
        )
        
        # Generate suggested actions
        actions = await self._generate_suggested_actions(message, analysis)
        
        # Determine if escalation is needed
        escalation_needed = self._should_escalate(message, analysis)
        
        # Determine if follow-up is required
        follow_up_required = self._requires_follow_up(message, analysis)
        
        ai_response = AIResponse_CS(
            id=f"ai_response_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}",
            message_id=message.id,
            content=response.content,
            confidence=response.confidence,
            response_type=message.conversation_type.value if message.conversation_type else "general",
            suggested_actions=actions,
            escalation_needed=escalation_needed,
            follow_up_required=follow_up_required,
            metadata={
                "analysis": analysis,
                "customer_context": customer_context,
                "processing_time": response.processing_time
            }
        )
        
        # Store in conversation history
        self._add_to_conversation_history(message.customer_id, message, ai_response)
        
        return ai_response
    
    async def generate_proactive_outreach(self, customer_id: str, trigger_event: str) -> Optional[AIResponse_CS]:
        """Generate proactive customer outreach based on events."""
        customer_context = await self._get_customer_context(customer_id)
        
        outreach_prompt = f"""
        Generate a proactive customer outreach message for RentGuy based on the following trigger:
        
        Trigger Event: {trigger_event}
        Customer Context: {json.dumps(customer_context, indent=2)}
        
        Create a personalized, valuable message that:
        1. Acknowledges the trigger event
        2. Provides relevant information or assistance
        3. Offers specific value to the customer
        4. Includes a clear call-to-action
        5. Maintains a helpful, non-pushy tone
        
        Only generate outreach if it would genuinely benefit the customer.
        If no valuable outreach is appropriate, respond with "NO_OUTREACH".
        """
        
        response = await create_and_process_task(
            task_type=TaskType.GENERATION,
            prompt=outreach_prompt,
            priority=TaskPriority.NORMAL,
            context={
                "customer_id": customer_id,
                "trigger_event": trigger_event,
                "outreach_type": "proactive"
            },
            strategy=EnsembleStrategy.SINGLE_BEST
        )
        
        if "NO_OUTREACH" in response.content:
            return None
        
        return AIResponse_CS(
            id=f"proactive_outreach_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}",
            message_id=f"proactive_{customer_id}_{trigger_event}",
            content=response.content,
            confidence=response.confidence,
            response_type="proactive_outreach",
            suggested_actions=["Send proactive message", "Schedule follow-up"],
            escalation_needed=False,
            follow_up_required=True,
            metadata={
                "trigger_event": trigger_event,
                "customer_context": customer_context
            }
        )
    
    async def analyze_customer_satisfaction(self, customer_id: str, interaction_history: List[Dict]) -> CustomerInsight:
        """Analyze customer satisfaction and provide insights."""
        satisfaction_prompt = f"""
        Analyze customer satisfaction based on interaction history:
        
        Customer ID: {customer_id}
        Interaction History: {json.dumps(interaction_history, indent=2)}
        
        Provide analysis in JSON format:
        {{
            "satisfaction_score": 0.0-1.0,
            "satisfaction_trend": "improving|stable|declining",
            "key_satisfaction_drivers": ["driver1", "driver2"],
            "risk_factors": ["risk1", "risk2"],
            "recommendations": ["rec1", "rec2"],
            "churn_risk": "low|medium|high",
            "confidence": 0.0-1.0
        }}
        """
        
        response = await create_and_process_task(
            task_type=TaskType.ANALYSIS,
            prompt=satisfaction_prompt,
            priority=TaskPriority.NORMAL,
            context={"customer_id": customer_id, "analysis_type": "satisfaction"},
            expected_format="json",
            strategy=EnsembleStrategy.CONSENSUS
        )
        
        try:
            analysis = json.loads(response.content)
            
            return CustomerInsight(
                customer_id=customer_id,
                insight_type="satisfaction_analysis",
                description=f"Customer satisfaction score: {analysis.get('satisfaction_score', 0.0):.2f}, Trend: {analysis.get('satisfaction_trend', 'stable')}",
                confidence=analysis.get("confidence", 0.0),
                recommendations=analysis.get("recommendations", [])
            )
            
        except json.JSONDecodeError:
            logger.error(f"Failed to parse satisfaction analysis: {response.content}")
            return CustomerInsight(
                customer_id=customer_id,
                insight_type="satisfaction_analysis",
                description="Unable to analyze customer satisfaction",
                confidence=0.0,
                recommendations=[]
            )
    
    async def generate_personalized_recommendations(self, customer_id: str) -> List[str]:
        """Generate personalized equipment recommendations for customer."""
        customer_context = await self._get_customer_context(customer_id)
        
        recommendation_prompt = f"""
        Generate personalized equipment recommendations for this RentGuy customer:
        
        Customer Context: {json.dumps(customer_context, indent=2)}
        
        Based on their rental history, preferences, and business needs, recommend:
        1. Specific equipment they might need
        2. Seasonal equipment opportunities
        3. Complementary equipment for their projects
        4. Upgrade opportunities
        5. Cost-saving bundle options
        
        Provide 3-5 specific, actionable recommendations with brief explanations.
        Format as a JSON array of recommendation objects with "equipment", "reason", and "benefit" fields.
        """
        
        response = await create_and_process_task(
            task_type=TaskType.RECOMMENDATION,
            prompt=recommendation_prompt,
            priority=TaskPriority.NORMAL,
            context={"customer_id": customer_id, "recommendation_type": "equipment"},
            expected_format="json",
            strategy=EnsembleStrategy.WEIGHTED_AVERAGE
        )
        
        try:
            recommendations = json.loads(response.content)
            if isinstance(recommendations, list):
                return [f"{rec.get('equipment', 'Equipment')}: {rec.get('reason', 'Recommended')} - {rec.get('benefit', 'Beneficial')}" for rec in recommendations]
        except json.JSONDecodeError:
            pass
        
        # Fallback to simple text parsing
        lines = response.content.split('\n')
        recommendations = []
        for line in lines:
            line = line.strip()
            if line and not line.startswith('#') and len(line) > 20:
                recommendations.append(line)
        
        return recommendations[:5]
    
    async def handle_complaint_resolution(self, message: CustomerMessage) -> Dict[str, Any]:
        """Handle customer complaint with AI-powered resolution."""
        complaint_prompt = f"""
        Analyze this customer complaint and provide resolution strategy:
        
        Complaint: "{message.content}"
        Customer ID: {message.customer_id}
        
        Provide resolution strategy in JSON format:
        {{
            "complaint_category": "billing|service|equipment|delivery|other",
            "severity": "low|medium|high|critical",
            "root_cause_analysis": "brief analysis of likely cause",
            "immediate_actions": ["action1", "action2"],
            "resolution_steps": ["step1", "step2"],
            "compensation_suggested": "none|discount|refund|credit|other",
            "escalation_required": true/false,
            "follow_up_timeline": "24h|48h|1week|immediate",
            "confidence": 0.0-1.0
        }}
        """
        
        response = await create_and_process_task(
            task_type=TaskType.ANALYSIS,
            prompt=complaint_prompt,
            priority=TaskPriority.HIGH,
            context={"message_id": message.id, "customer_id": message.customer_id},
            expected_format="json",
            strategy=EnsembleStrategy.CONSENSUS
        )
        
        try:
            resolution_strategy = json.loads(response.content)
            
            # Generate empathetic response
            response_prompt = f"""
            Generate an empathetic, professional response to this customer complaint:
            
            Complaint: "{message.content}"
            Resolution Strategy: {json.dumps(resolution_strategy, indent=2)}
            
            The response should:
            1. Acknowledge the customer's frustration
            2. Apologize sincerely for the issue
            3. Explain what went wrong (if known)
            4. Outline specific steps to resolve the issue
            5. Provide timeline for resolution
            6. Offer appropriate compensation if suggested
            7. Ensure the customer feels heard and valued
            """
            
            response_gen = await create_and_process_task(
                task_type=TaskType.GENERATION,
                prompt=response_prompt,
                priority=TaskPriority.HIGH,
                context={"complaint_resolution": True},
                strategy=EnsembleStrategy.WEIGHTED_AVERAGE
            )
            
            resolution_strategy["ai_response"] = response_gen.content
            resolution_strategy["response_confidence"] = response_gen.confidence
            
            return resolution_strategy
            
        except json.JSONDecodeError:
            logger.error(f"Failed to parse complaint resolution: {response.content}")
            return {
                "complaint_category": "other",
                "severity": "medium",
                "root_cause_analysis": "Unable to analyze",
                "immediate_actions": ["Escalate to human agent"],
                "resolution_steps": ["Manual review required"],
                "compensation_suggested": "none",
                "escalation_required": True,
                "follow_up_timeline": "immediate",
                "confidence": 0.0,
                "ai_response": "I apologize for the issue you're experiencing. I'm escalating your concern to our customer service team who will contact you shortly to resolve this matter."
            }
    
    async def _get_customer_context(self, customer_id: str) -> Dict[str, Any]:
        """Get customer context for personalized responses."""
        # This would typically fetch from database
        # For now, return mock context
        return {
            "customer_id": customer_id,
            "name": "Customer",
            "rental_history": [],
            "preferences": {},
            "total_rentals": 0,
            "total_spent": 0.0,
            "last_rental_date": None,
            "customer_segment": "regular",
            "communication_preferences": ["email"]
        }
    
    def _get_conversation_history(self, customer_id: str) -> List[Dict]:
        """Get conversation history for customer."""
        return self.conversation_history.get(customer_id, [])
    
    def _add_to_conversation_history(self, customer_id: str, message: CustomerMessage, response: AIResponse_CS):
        """Add message and response to conversation history."""
        if customer_id not in self.conversation_history:
            self.conversation_history[customer_id] = []
        
        self.conversation_history[customer_id].append({
            "timestamp": message.timestamp.isoformat(),
            "customer_message": message.content,
            "ai_response": response.content,
            "conversation_type": message.conversation_type.value if message.conversation_type else "general",
            "sentiment": message.sentiment.value if message.sentiment else "neutral"
        })
        
        # Keep only last 20 interactions
        self.conversation_history[customer_id] = self.conversation_history[customer_id][-20:]
    
    async def _generate_suggested_actions(self, message: CustomerMessage, analysis: Dict[str, Any]) -> List[str]:
        """Generate suggested actions for customer service agent."""
        actions = []
        
        conversation_type = analysis.get("conversation_type", "general")
        urgency = analysis.get("urgency", "medium")
        
        # Base actions based on conversation type
        if conversation_type == "booking":
            actions.extend([
                "Check equipment availability",
                "Provide pricing quote",
                "Send booking confirmation"
            ])
        elif conversation_type == "support":
            actions.extend([
                "Review customer account",
                "Check recent rentals",
                "Provide technical assistance"
            ])
        elif conversation_type == "complaint":
            actions.extend([
                "Escalate to supervisor",
                "Review complaint history",
                "Offer compensation if appropriate"
            ])
        elif conversation_type == "billing":
            actions.extend([
                "Review billing history",
                "Check payment status",
                "Explain charges"
            ])
        
        # Add urgency-based actions
        if urgency in ["high", "critical"]:
            actions.insert(0, "Priority handling required")
            actions.append("Schedule immediate follow-up")
        
        return actions[:5]  # Limit to top 5 actions
    
    def _should_escalate(self, message: CustomerMessage, analysis: Dict[str, Any]) -> bool:
        """Determine if message should be escalated to human agent."""
        # Escalate if explicitly required by analysis
        if analysis.get("requires_human", False):
            return True
        
        # Escalate based on urgency
        if message.urgency in [UrgencyLevel.HIGH, UrgencyLevel.CRITICAL]:
            return True
        
        # Escalate based on sentiment
        if message.sentiment == SentimentType.FRUSTRATED:
            return True
        
        # Escalate based on conversation type
        if message.conversation_type in [ConversationType.COMPLAINT, ConversationType.TECHNICAL]:
            return True
        
        # Escalate if confidence is low
        if analysis.get("confidence", 1.0) < 0.6:
            return True
        
        return False
    
    def _requires_follow_up(self, message: CustomerMessage, analysis: Dict[str, Any]) -> bool:
        """Determine if follow-up is required."""
        # Follow-up for certain conversation types
        if message.conversation_type in [ConversationType.BOOKING, ConversationType.SUPPORT]:
            return True
        
        # Follow-up for high urgency
        if message.urgency in [UrgencyLevel.HIGH, UrgencyLevel.CRITICAL]:
            return True
        
        # Follow-up if customer intent suggests ongoing need
        customer_intent = analysis.get("customer_intent", "").lower()
        if any(keyword in customer_intent for keyword in ["quote", "booking", "schedule", "follow up"]):
            return True
        
        return False
    
    def _get_priority_from_urgency(self, urgency: Optional[UrgencyLevel]) -> TaskPriority:
        """Convert urgency level to task priority."""
        if urgency == UrgencyLevel.CRITICAL:
            return TaskPriority.CRITICAL
        elif urgency == UrgencyLevel.HIGH:
            return TaskPriority.HIGH
        elif urgency == UrgencyLevel.MEDIUM:
            return TaskPriority.NORMAL
        else:
            return TaskPriority.LOW
    
    def _load_response_templates(self) -> Dict[str, str]:
        """Load response templates for common scenarios."""
        return {
            "greeting": "Hello {customer_name}, thank you for contacting RentGuy. How can I assist you today?",
            "booking_confirmation": "Thank you for your booking request. I'll check availability and get back to you shortly.",
            "technical_support": "I understand you're experiencing technical difficulties. Let me help you resolve this issue.",
            "complaint_acknowledgment": "I sincerely apologize for the inconvenience you've experienced. Let me work on resolving this for you immediately.",
            "billing_inquiry": "I'll be happy to help you with your billing inquiry. Let me review your account details.",
            "general_inquiry": "Thank you for your inquiry. I'll provide you with the information you need."
        }


class AutomatedWorkflows:
    """Automated customer service workflows."""
    
    def __init__(self, cs_ai: CustomerServiceAI):
        self.cs_ai = cs_ai
    
    async def process_new_customer_onboarding(self, customer_id: str) -> List[str]:
        """Process new customer onboarding workflow."""
        onboarding_steps = []
        
        # Generate welcome message
        welcome_response = await self.cs_ai.generate_proactive_outreach(
            customer_id, "new_customer_registration"
        )
        
        if welcome_response:
            onboarding_steps.append("Send welcome message")
        
        # Schedule follow-up
        onboarding_steps.extend([
            "Send equipment catalog",
            "Schedule onboarding call",
            "Set up account preferences",
            "Provide tutorial resources"
        ])
        
        return onboarding_steps
    
    async def handle_rental_completion_workflow(self, customer_id: str, rental_id: str) -> List[str]:
        """Handle post-rental completion workflow."""
        workflow_steps = []
        
        # Generate feedback request
        feedback_response = await self.cs_ai.generate_proactive_outreach(
            customer_id, f"rental_completion_{rental_id}"
        )
        
        if feedback_response:
            workflow_steps.append("Send feedback request")
        
        # Additional steps
        workflow_steps.extend([
            "Process final billing",
            "Update equipment status",
            "Generate rental report",
            "Schedule equipment inspection"
        ])
        
        return workflow_steps
    
    async def monitor_customer_satisfaction(self, customer_id: str) -> Optional[Dict[str, Any]]:
        """Monitor and respond to customer satisfaction changes."""
        # Get recent interactions
        interaction_history = self.cs_ai._get_conversation_history(customer_id)
        
        if not interaction_history:
            return None
        
        # Analyze satisfaction
        satisfaction_insight = await self.cs_ai.analyze_customer_satisfaction(
            customer_id, interaction_history
        )
        
        # Generate proactive response if needed
        if satisfaction_insight.confidence > 0.7:
            if "declining" in satisfaction_insight.description or "low" in satisfaction_insight.description:
                proactive_response = await self.cs_ai.generate_proactive_outreach(
                    customer_id, "satisfaction_concern"
                )
                
                return {
                    "satisfaction_insight": satisfaction_insight,
                    "proactive_response": proactive_response,
                    "action_required": True
                }
        
        return {
            "satisfaction_insight": satisfaction_insight,
            "action_required": False
        }


# Global customer service AI instance
cs_ai = CustomerServiceAI()
automated_workflows = AutomatedWorkflows(cs_ai)

# Convenience functions
def get_customer_service_ai() -> CustomerServiceAI:
    """Get the global customer service AI."""
    return cs_ai

def get_automated_workflows() -> AutomatedWorkflows:
    """Get the automated workflows manager."""
    return automated_workflows

async def process_customer_message(
    customer_id: str,
    content: str,
    channel: str = "chat"
) -> Tuple[AIResponse_CS, Dict[str, Any]]:
    """Process a customer message and generate AI response."""
    import uuid
    
    # Create message
    message = CustomerMessage(
        id=str(uuid.uuid4()),
        customer_id=customer_id,
        content=content,
        channel=channel
    )
    
    # Analyze message
    analysis = await cs_ai.analyze_customer_message(message)
    
    # Generate response
    ai_response = await cs_ai.generate_response(message, analysis)
    
    # Record metrics
    metrics.record_business_metrics(
        {"customer_messages_processed": 1},
        {"ai_responses_generated": 1}
    )
    
    return ai_response, analysis

async def handle_customer_complaint(
    customer_id: str,
    complaint: str,
    channel: str = "email"
) -> Dict[str, Any]:
    """Handle customer complaint with AI-powered resolution."""
    import uuid
    
    # Create complaint message
    message = CustomerMessage(
        id=str(uuid.uuid4()),
        customer_id=customer_id,
        content=complaint,
        channel=channel,
        conversation_type=ConversationType.COMPLAINT,
        sentiment=SentimentType.NEGATIVE,
        urgency=UrgencyLevel.HIGH
    )
    
    # Handle complaint resolution
    resolution = await cs_ai.handle_complaint_resolution(message)
    
    # Record metrics
    metrics.record_business_metrics(
        {"customer_complaints_processed": 1}
    )
    
    return resolution

    # CRM Integration Methods
    
    def analyze_lead_qualification(self, lead_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        AI-powered lead qualification analysis.
        
        Args:
            lead_data: Dictionary containing lead information
            
        Returns:
            Dictionary with qualification analysis and recommendations
        """
        try:
            qualification_prompt = f"""
            Analyze this lead for qualification in the equipment rental industry:
            
            Lead Information:
            - Company: {lead_data.get('company_name', 'Unknown')}
            - Industry: {lead_data.get('industry', 'Unknown')}
            - Company Size: {lead_data.get('company_size', 'Unknown')}
            - Estimated Budget: {lead_data.get('estimated_budget', 'Unknown')}
            - Rental Timeframe: {lead_data.get('rental_timeframe', 'Unknown')}
            - Equipment Interest: {lead_data.get('interested_equipment', [])}
            - Notes: {lead_data.get('notes', 'None')}
            
            Provide a qualification analysis including:
            1. Qualification Level (High/Medium/Low) with reasoning
            2. Recommended Lead Score (0-100)
            3. Key Qualification Factors (positive and negative)
            4. Recommended Next Actions
            5. Potential Deal Value Estimate
            6. Timeline Assessment
            
            Format as structured analysis with clear recommendations.
            """
            
            # Create AI task for lead qualification
            task = AITask(
                id=f"lead_qual_{lead_data.get('lead_id', 'unknown')}",
                task_type=TaskType.ANALYSIS,
                priority=TaskPriority.HIGH,
                prompt=qualification_prompt,
                context={
                    "lead_data": lead_data,
                    "analysis_type": "lead_qualification"
                },
                max_tokens=500
            )
            
            # Process task synchronously
            response = asyncio.run(create_and_process_task(task, EnsembleStrategy.CONSENSUS))
            
            # Extract structured data from response
            analysis_content = response.content
            
            # Parse qualification level and score
            qualification_level = "Medium"  # Default
            recommended_score = 50  # Default
            
            if "High" in analysis_content and "qualification" in analysis_content.lower():
                qualification_level = "High"
                recommended_score = 75
            elif "Low" in analysis_content and "qualification" in analysis_content.lower():
                qualification_level = "Low"
                recommended_score = 25
            
            return {
                "success": True,
                "qualification_level": qualification_level,
                "recommended_score": recommended_score,
                "analysis": analysis_content,
                "summary": f"Lead qualified as {qualification_level} priority with score {recommended_score}",
                "confidence": response.confidence,
                "generated_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Lead qualification analysis failed: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "qualification_level": "Medium",
                "recommended_score": 50,
                "summary": "Analysis failed, using default qualification"
            }
    
    def generate_lead_engagement_recommendations(self, lead_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate AI-powered recommendations for lead engagement.
        
        Args:
            lead_data: Dictionary containing lead information and history
            
        Returns:
            Dictionary with engagement recommendations
        """
        try:
            engagement_prompt = f"""
            Generate engagement recommendations for this lead in equipment rental:
            
            Lead Profile:
            - Status: {lead_data.get('lead_status', 'Unknown')}
            - Score: {lead_data.get('lead_score', 0)}
            - Company: {lead_data.get('company_name', 'Unknown')}
            - Industry: {lead_data.get('industry', 'Unknown')}
            - Budget: {lead_data.get('estimated_budget', 'Unknown')}
            - Timeframe: {lead_data.get('rental_timeframe', 'Unknown')}
            - Days Since Contact: {lead_data.get('days_since_first_contact', 0)}
            
            Provide specific engagement recommendations:
            1. Immediate Next Action (call, email, meeting, etc.)
            2. Recommended Communication Channel
            3. Key Talking Points/Value Propositions
            4. Optimal Contact Timing
            5. Follow-up Strategy
            6. Risk Assessment (likelihood of losing lead)
            
            Focus on actionable, specific recommendations for sales team.
            """
            
            # Create AI task for engagement recommendations
            task = AITask(
                id=f"lead_engage_{lead_data.get('lead_id', 'unknown')}",
                task_type=TaskType.GENERATION,
                priority=TaskPriority.MEDIUM,
                prompt=engagement_prompt,
                context={
                    "lead_data": lead_data,
                    "analysis_type": "engagement_recommendations"
                },
                max_tokens=400
            )
            
            # Process task synchronously
            response = asyncio.run(create_and_process_task(task, EnsembleStrategy.BEST_OF_N))
            
            recommendations_content = response.content
            
            # Extract priority level based on lead data
            priority = "Medium"
            if lead_data.get('lead_score', 0) >= 75:
                priority = "High"
            elif lead_data.get('lead_score', 0) <= 25:
                priority = "Low"
            
            # Determine urgency based on days since contact
            days_since_contact = lead_data.get('days_since_first_contact', 0)
            urgency = "Normal"
            if days_since_contact > 14:
                urgency = "High"
            elif days_since_contact > 7:
                urgency = "Medium"
            
            return {
                "success": True,
                "priority": priority,
                "urgency": urgency,
                "recommendations": recommendations_content,
                "next_action_timeline": "Within 24 hours" if urgency == "High" else "Within 3 days",
                "confidence": response.confidence,
                "generated_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Lead engagement recommendations failed: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "priority": "Medium",
                "urgency": "Normal",
                "recommendations": "Contact lead to discuss equipment rental needs and provide personalized quote."
            }
    
    def generate_subject_line_variants(self, original_subject: str, campaign_type: str, target_audience: Dict[str, Any]) -> List[str]:
        """
        Generate AI-optimized email subject line variants for campaigns.
        
        Args:
            original_subject: Original subject line
            campaign_type: Type of campaign (email, follow_up, etc.)
            target_audience: Target audience information
            
        Returns:
            List of optimized subject line variants
        """
        try:
            subject_prompt = f"""
            Generate 5 optimized email subject line variants for equipment rental marketing:
            
            Original Subject: "{original_subject}"
            Campaign Type: {campaign_type}
            Target Audience: {target_audience.get('description', 'Equipment rental prospects')}
            Industry Focus: {target_audience.get('industry', 'General')}
            
            Create variants that:
            1. Increase open rates through urgency/curiosity
            2. Include relevant equipment rental keywords
            3. Personalize for the target industry
            4. Maintain professional tone
            5. Stay under 50 characters when possible
            
            Return as numbered list of 5 subject lines.
            """
            
            # Create AI task for subject line generation
            task = AITask(
                id=f"subject_gen_{hash(original_subject)}",
                task_type=TaskType.GENERATION,
                priority=TaskPriority.LOW,
                prompt=subject_prompt,
                context={
                    "original_subject": original_subject,
                    "campaign_type": campaign_type,
                    "target_audience": target_audience
                },
                max_tokens=300
            )
            
            # Process task synchronously
            response = asyncio.run(create_and_process_task(task, EnsembleStrategy.CREATIVE))
            
            variants_content = response.content
            
            # Parse the numbered list into individual subject lines
            variants = []
            for line in variants_content.split('\n'):
                line = line.strip()
                if line and (line[0].isdigit() or line.startswith('-')):
                    # Remove numbering and clean up
                    subject = line.split('.', 1)[-1].strip()
                    subject = subject.strip('"\'')
                    if subject:
                        variants.append(subject)
            
            # Ensure we have at least the original subject
            if not variants:
                variants = [original_subject]
            
            return variants[:5]  # Return max 5 variants
            
        except Exception as e:
            logger.error(f"Subject line generation failed: {str(e)}")
            return [original_subject]  # Return original as fallback
    
    def calculate_optimal_send_time(self, target_audience: Dict[str, Any], campaign_type: str) -> Optional[datetime]:
        """
        Calculate optimal send time for email campaigns using AI analysis.
        
        Args:
            target_audience: Target audience information
            campaign_type: Type of campaign
            
        Returns:
            Optimal datetime for sending, or None if cannot determine
        """
        try:
            timing_prompt = f"""
            Determine optimal email send time for equipment rental campaign:
            
            Target Audience:
            - Industry: {target_audience.get('industry', 'General')}
            - Company Size: {target_audience.get('company_size', 'Mixed')}
            - Geographic Region: {target_audience.get('region', 'Netherlands')}
            - Job Roles: {target_audience.get('job_roles', 'Decision makers')}
            
            Campaign Type: {campaign_type}
            Current Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}
            
            Recommend optimal send time considering:
            1. Industry work patterns
            2. B2B email best practices
            3. Time zone considerations
            4. Campaign type urgency
            
            Provide specific day of week and time (24h format) in Amsterdam timezone.
            Format: "YYYY-MM-DD HH:MM" with brief reasoning.
            """
            
            # Create AI task for send time optimization
            task = AITask(
                id=f"send_time_{hash(str(target_audience))}",
                task_type=TaskType.ANALYSIS,
                priority=TaskPriority.LOW,
                prompt=timing_prompt,
                context={
                    "target_audience": target_audience,
                    "campaign_type": campaign_type
                },
                max_tokens=200
            )
            
            # Process task synchronously
            response = asyncio.run(create_and_process_task(task, EnsembleStrategy.CONSENSUS))
            
            timing_content = response.content
            
            # Try to extract datetime from response
            import re
            datetime_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2})'
            match = re.search(datetime_pattern, timing_content)
            
            if match:
                try:
                    optimal_time = datetime.strptime(match.group(1), '%Y-%m-%d %H:%M')
                    # Ensure it's in the future
                    if optimal_time < datetime.utcnow():
                        # Add a week if the suggested time has passed
                        optimal_time += timedelta(weeks=1)
                    return optimal_time
                except ValueError:
                    pass
            
            # Fallback to business hours heuristic
            now = datetime.utcnow()
            # Tuesday 10:00 AM Amsterdam time (generally good for B2B)
            days_until_tuesday = (1 - now.weekday()) % 7
            if days_until_tuesday == 0 and now.hour >= 10:
                days_until_tuesday = 7  # Next Tuesday
            
            optimal_time = now + timedelta(days=days_until_tuesday)
            optimal_time = optimal_time.replace(hour=9, minute=0, second=0, microsecond=0)  # 9 AM UTC = 10 AM Amsterdam
            
            return optimal_time
            
        except Exception as e:
            logger.error(f"Optimal send time calculation failed: {str(e)}")
            return None
