"""
Multi-LLM Ensemble Architecture for RentGuy Enterprise.
Provides intelligent AI capabilities through coordinated LLM ensemble.
"""

import asyncio
import json
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Union, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed

import openai
from anthropic import Anthropic
import replicate

from ..core.config import settings
from ..core.logging import get_logger, audit_logger
from ..core.monitoring import get_metrics_collector
from ..core.performance import cached, timed

logger = get_logger(__name__)
metrics = get_metrics_collector()


class LLMProvider(str, Enum):
    """Supported LLM providers."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    REPLICATE = "replicate"
    LOCAL = "local"


class TaskType(str, Enum):
    """Types of AI tasks."""
    CLASSIFICATION = "classification"
    GENERATION = "generation"
    ANALYSIS = "analysis"
    TRANSLATION = "translation"
    SUMMARIZATION = "summarization"
    DECISION_SUPPORT = "decision_support"
    RECOMMENDATION = "recommendation"
    VALIDATION = "validation"
    EXTRACTION = "extraction"
    CONVERSATION = "conversation"


class TaskPriority(str, Enum):
    """Task priority levels."""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class LLMConfig:
    """Configuration for an LLM provider."""
    provider: LLMProvider
    model: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    max_tokens: int = 4000
    temperature: float = 0.7
    timeout: int = 30
    retry_attempts: int = 3
    cost_per_token: float = 0.0
    capabilities: List[TaskType] = field(default_factory=list)
    performance_score: float = 1.0
    availability_score: float = 1.0


@dataclass
class AITask:
    """Represents an AI task to be processed."""
    id: str
    task_type: TaskType
    priority: TaskPriority
    prompt: str
    context: Dict[str, Any] = field(default_factory=dict)
    constraints: Dict[str, Any] = field(default_factory=dict)
    expected_format: str = "text"
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    deadline: Optional[datetime] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None


@dataclass
class AIResponse:
    """Response from an AI task."""
    task_id: str
    provider: LLMProvider
    model: str
    content: str
    confidence: float
    processing_time: float
    token_usage: Dict[str, int]
    cost: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    error: Optional[str] = None


class LLMProvider_Base(ABC):
    """Abstract base class for LLM providers."""
    
    def __init__(self, config: LLMConfig):
        self.config = config
        self.client = None
        self._initialize_client()
    
    @abstractmethod
    def _initialize_client(self):
        """Initialize the provider client."""
        pass
    
    @abstractmethod
    async def generate_response(self, task: AITask) -> AIResponse:
        """Generate response for a task."""
        pass
    
    @abstractmethod
    def estimate_cost(self, task: AITask) -> float:
        """Estimate cost for a task."""
        pass
    
    def is_available(self) -> bool:
        """Check if provider is available."""
        return self.client is not None and self.config.availability_score > 0.5


class OpenAIProvider(LLMProvider_Base):
    """OpenAI LLM provider implementation."""
    
    def _initialize_client(self):
        """Initialize OpenAI client."""
        try:
            self.client = openai.OpenAI(
                api_key=self.config.api_key or settings.openai_api_key,
                base_url=self.config.base_url
            )
            logger.info(f"OpenAI provider initialized: {self.config.model}")
        except Exception as e:
            logger.error(f"Failed to initialize OpenAI provider: {e}")
            self.client = None
    
    async def generate_response(self, task: AITask) -> AIResponse:
        """Generate response using OpenAI."""
        start_time = time.time()
        
        try:
            # Prepare messages
            messages = [
                {"role": "system", "content": self._build_system_prompt(task)},
                {"role": "user", "content": task.prompt}
            ]
            
            # Add context if available
            if task.context:
                context_msg = f"Context: {json.dumps(task.context, indent=2)}"
                messages.insert(1, {"role": "system", "content": context_msg})
            
            # Make API call
            response = await asyncio.to_thread(
                self.client.chat.completions.create,
                model=self.config.model,
                messages=messages,
                max_tokens=task.max_tokens or self.config.max_tokens,
                temperature=task.temperature or self.config.temperature,
                timeout=self.config.timeout
            )
            
            processing_time = time.time() - start_time
            
            # Extract response data
            content = response.choices[0].message.content
            token_usage = {
                "prompt_tokens": response.usage.prompt_tokens,
                "completion_tokens": response.usage.completion_tokens,
                "total_tokens": response.usage.total_tokens
            }
            
            # Calculate cost and confidence
            cost = self._calculate_cost(token_usage)
            confidence = self._calculate_confidence(response, task)
            
            return AIResponse(
                task_id=task.id,
                provider=LLMProvider.OPENAI,
                model=self.config.model,
                content=content,
                confidence=confidence,
                processing_time=processing_time,
                token_usage=token_usage,
                cost=cost,
                metadata={
                    "finish_reason": response.choices[0].finish_reason,
                    "model_version": response.model
                }
            )
            
        except Exception as e:
            processing_time = time.time() - start_time
            logger.error(f"OpenAI generation failed: {e}")
            
            return AIResponse(
                task_id=task.id,
                provider=LLMProvider.OPENAI,
                model=self.config.model,
                content="",
                confidence=0.0,
                processing_time=processing_time,
                token_usage={},
                cost=0.0,
                error=str(e)
            )
    
    def _build_system_prompt(self, task: AITask) -> str:
        """Build system prompt based on task type."""
        base_prompt = "You are an AI assistant for RentGuy, an enterprise equipment rental management system."
        
        task_specific_prompts = {
            TaskType.CLASSIFICATION: "Classify the given input into appropriate categories.",
            TaskType.GENERATION: "Generate high-quality content based on the requirements.",
            TaskType.ANALYSIS: "Analyze the provided data and provide insights.",
            TaskType.TRANSLATION: "Translate the content accurately while preserving meaning.",
            TaskType.SUMMARIZATION: "Create a concise and comprehensive summary.",
            TaskType.DECISION_SUPPORT: "Provide decision recommendations with reasoning.",
            TaskType.RECOMMENDATION: "Generate personalized recommendations.",
            TaskType.VALIDATION: "Validate the input against specified criteria.",
            TaskType.EXTRACTION: "Extract specific information from the provided content.",
            TaskType.CONVERSATION: "Engage in helpful conversation while staying professional."
        }
        
        task_prompt = task_specific_prompts.get(task.task_type, "")
        
        # Add constraints if specified
        constraints_text = ""
        if task.constraints:
            constraints_text = f"\n\nConstraints: {json.dumps(task.constraints, indent=2)}"
        
        # Add format requirements
        format_text = f"\n\nResponse format: {task.expected_format}"
        
        return f"{base_prompt}\n\n{task_prompt}{constraints_text}{format_text}"
    
    def _calculate_cost(self, token_usage: Dict[str, int]) -> float:
        """Calculate cost based on token usage."""
        if not token_usage or self.config.cost_per_token == 0:
            return 0.0
        
        return token_usage.get("total_tokens", 0) * self.config.cost_per_token
    
    def _calculate_confidence(self, response: Any, task: AITask) -> float:
        """Calculate confidence score for the response."""
        # Basic confidence calculation based on response characteristics
        confidence = 0.8  # Base confidence
        
        # Adjust based on finish reason
        if hasattr(response.choices[0], 'finish_reason'):
            if response.choices[0].finish_reason == "stop":
                confidence += 0.1
            elif response.choices[0].finish_reason == "length":
                confidence -= 0.2
        
        # Adjust based on response length
        content_length = len(response.choices[0].message.content)
        if content_length < 10:
            confidence -= 0.3
        elif content_length > 100:
            confidence += 0.1
        
        return max(0.0, min(1.0, confidence))
    
    def estimate_cost(self, task: AITask) -> float:
        """Estimate cost for a task."""
        # Rough estimation based on prompt length
        estimated_tokens = len(task.prompt.split()) * 1.3  # Rough token estimation
        return estimated_tokens * self.config.cost_per_token


class AnthropicProvider(LLMProvider_Base):
    """Anthropic Claude LLM provider implementation."""
    
    def _initialize_client(self):
        """Initialize Anthropic client."""
        try:
            self.client = Anthropic(
                api_key=self.config.api_key or settings.anthropic_api_key
            )
            logger.info(f"Anthropic provider initialized: {self.config.model}")
        except Exception as e:
            logger.error(f"Failed to initialize Anthropic provider: {e}")
            self.client = None
    
    async def generate_response(self, task: AITask) -> AIResponse:
        """Generate response using Anthropic Claude."""
        start_time = time.time()
        
        try:
            # Build prompt
            system_prompt = self._build_system_prompt(task)
            user_prompt = task.prompt
            
            if task.context:
                user_prompt = f"Context: {json.dumps(task.context, indent=2)}\n\n{user_prompt}"
            
            # Make API call
            response = await asyncio.to_thread(
                self.client.messages.create,
                model=self.config.model,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
                max_tokens=task.max_tokens or self.config.max_tokens,
                temperature=task.temperature or self.config.temperature
            )
            
            processing_time = time.time() - start_time
            
            # Extract response data
            content = response.content[0].text
            token_usage = {
                "prompt_tokens": response.usage.input_tokens,
                "completion_tokens": response.usage.output_tokens,
                "total_tokens": response.usage.input_tokens + response.usage.output_tokens
            }
            
            # Calculate cost and confidence
            cost = self._calculate_cost(token_usage)
            confidence = self._calculate_confidence(response, task)
            
            return AIResponse(
                task_id=task.id,
                provider=LLMProvider.ANTHROPIC,
                model=self.config.model,
                content=content,
                confidence=confidence,
                processing_time=processing_time,
                token_usage=token_usage,
                cost=cost,
                metadata={
                    "stop_reason": response.stop_reason,
                    "model_version": response.model
                }
            )
            
        except Exception as e:
            processing_time = time.time() - start_time
            logger.error(f"Anthropic generation failed: {e}")
            
            return AIResponse(
                task_id=task.id,
                provider=LLMProvider.ANTHROPIC,
                model=self.config.model,
                content="",
                confidence=0.0,
                processing_time=processing_time,
                token_usage={},
                cost=0.0,
                error=str(e)
            )
    
    def _build_system_prompt(self, task: AITask) -> str:
        """Build system prompt for Anthropic."""
        return self._build_system_prompt_base(task)
    
    def _build_system_prompt_base(self, task: AITask) -> str:
        """Build base system prompt."""
        base_prompt = "You are Claude, an AI assistant integrated into RentGuy, an enterprise equipment rental management system. You provide helpful, accurate, and professional assistance."
        
        task_specific_prompts = {
            TaskType.CLASSIFICATION: "Your task is to classify the given input into appropriate categories with high accuracy.",
            TaskType.GENERATION: "Your task is to generate high-quality, relevant content based on the provided requirements.",
            TaskType.ANALYSIS: "Your task is to analyze the provided data thoroughly and provide actionable insights.",
            TaskType.TRANSLATION: "Your task is to translate content accurately while preserving meaning and context.",
            TaskType.SUMMARIZATION: "Your task is to create concise yet comprehensive summaries.",
            TaskType.DECISION_SUPPORT: "Your task is to provide well-reasoned decision recommendations.",
            TaskType.RECOMMENDATION: "Your task is to generate personalized, relevant recommendations.",
            TaskType.VALIDATION: "Your task is to validate input against specified criteria with detailed feedback.",
            TaskType.EXTRACTION: "Your task is to extract specific information accurately from the provided content.",
            TaskType.CONVERSATION: "Your task is to engage in helpful, professional conversation."
        }
        
        task_prompt = task_specific_prompts.get(task.task_type, "")
        
        constraints_text = ""
        if task.constraints:
            constraints_text = f"\n\nConstraints: {json.dumps(task.constraints, indent=2)}"
        
        format_text = f"\n\nPlease provide your response in the following format: {task.expected_format}"
        
        return f"{base_prompt}\n\n{task_prompt}{constraints_text}{format_text}"
    
    def _calculate_cost(self, token_usage: Dict[str, int]) -> float:
        """Calculate cost based on token usage."""
        if not token_usage or self.config.cost_per_token == 0:
            return 0.0
        
        return token_usage.get("total_tokens", 0) * self.config.cost_per_token
    
    def _calculate_confidence(self, response: Any, task: AITask) -> float:
        """Calculate confidence score."""
        confidence = 0.85  # Base confidence for Claude
        
        # Adjust based on stop reason
        if hasattr(response, 'stop_reason'):
            if response.stop_reason == "end_turn":
                confidence += 0.1
            elif response.stop_reason == "max_tokens":
                confidence -= 0.2
        
        # Adjust based on content quality indicators
        content = response.content[0].text if response.content else ""
        if len(content) < 10:
            confidence -= 0.3
        elif len(content) > 100:
            confidence += 0.05
        
        return max(0.0, min(1.0, confidence))
    
    def estimate_cost(self, task: AITask) -> float:
        """Estimate cost for a task."""
        estimated_tokens = len(task.prompt.split()) * 1.3
        return estimated_tokens * self.config.cost_per_token


class ReplicateProvider(LLMProvider_Base):
    """Replicate LLM provider implementation."""
    
    def _initialize_client(self):
        """Initialize Replicate client."""
        try:
            replicate.api_token = self.config.api_key or settings.replicate_api_token
            self.client = replicate
            logger.info(f"Replicate provider initialized: {self.config.model}")
        except Exception as e:
            logger.error(f"Failed to initialize Replicate provider: {e}")
            self.client = None
    
    async def generate_response(self, task: AITask) -> AIResponse:
        """Generate response using Replicate."""
        start_time = time.time()
        
        try:
            # Build input for Replicate
            input_data = {
                "prompt": self._build_full_prompt(task),
                "max_tokens": task.max_tokens or self.config.max_tokens,
                "temperature": task.temperature or self.config.temperature
            }
            
            # Make API call
            output = await asyncio.to_thread(
                self.client.run,
                self.config.model,
                input=input_data
            )
            
            processing_time = time.time() - start_time
            
            # Process output (format varies by model)
            if isinstance(output, list):
                content = "".join(output)
            elif isinstance(output, str):
                content = output
            else:
                content = str(output)
            
            # Estimate token usage (Replicate doesn't always provide this)
            estimated_tokens = len(content.split()) + len(task.prompt.split())
            token_usage = {
                "prompt_tokens": len(task.prompt.split()),
                "completion_tokens": len(content.split()),
                "total_tokens": estimated_tokens
            }
            
            # Calculate cost and confidence
            cost = self._calculate_cost(token_usage)
            confidence = self._calculate_confidence(content, task)
            
            return AIResponse(
                task_id=task.id,
                provider=LLMProvider.REPLICATE,
                model=self.config.model,
                content=content,
                confidence=confidence,
                processing_time=processing_time,
                token_usage=token_usage,
                cost=cost,
                metadata={
                    "model_version": self.config.model
                }
            )
            
        except Exception as e:
            processing_time = time.time() - start_time
            logger.error(f"Replicate generation failed: {e}")
            
            return AIResponse(
                task_id=task.id,
                provider=LLMProvider.REPLICATE,
                model=self.config.model,
                content="",
                confidence=0.0,
                processing_time=processing_time,
                token_usage={},
                cost=0.0,
                error=str(e)
            )
    
    def _build_full_prompt(self, task: AITask) -> str:
        """Build full prompt for Replicate models."""
        system_prompt = self._build_system_prompt_base(task)
        
        full_prompt = f"{system_prompt}\n\nUser: {task.prompt}\n\nAssistant:"
        
        if task.context:
            context_text = f"Context: {json.dumps(task.context, indent=2)}\n\n"
            full_prompt = f"{system_prompt}\n\n{context_text}User: {task.prompt}\n\nAssistant:"
        
        return full_prompt
    
    def _build_system_prompt_base(self, task: AITask) -> str:
        """Build base system prompt."""
        return "You are an AI assistant for RentGuy equipment rental management system. Provide helpful and accurate responses."
    
    def _calculate_cost(self, token_usage: Dict[str, int]) -> float:
        """Calculate cost based on token usage."""
        if not token_usage or self.config.cost_per_token == 0:
            return 0.0
        
        return token_usage.get("total_tokens", 0) * self.config.cost_per_token
    
    def _calculate_confidence(self, content: str, task: AITask) -> float:
        """Calculate confidence score."""
        confidence = 0.75  # Base confidence for Replicate models
        
        # Adjust based on content characteristics
        if len(content) < 10:
            confidence -= 0.3
        elif len(content) > 100:
            confidence += 0.1
        
        # Check for common error indicators
        error_indicators = ["error", "failed", "unable", "cannot", "sorry"]
        if any(indicator in content.lower() for indicator in error_indicators):
            confidence -= 0.2
        
        return max(0.0, min(1.0, confidence))
    
    def estimate_cost(self, task: AITask) -> float:
        """Estimate cost for a task."""
        estimated_tokens = len(task.prompt.split()) * 1.5
        return estimated_tokens * self.config.cost_per_token


class EnsembleStrategy(str, Enum):
    """Ensemble strategies for combining LLM responses."""
    SINGLE_BEST = "single_best"
    MAJORITY_VOTE = "majority_vote"
    WEIGHTED_AVERAGE = "weighted_average"
    CONSENSUS = "consensus"
    FALLBACK_CHAIN = "fallback_chain"
    PARALLEL_VALIDATION = "parallel_validation"


class LLMEnsemble:
    """Multi-LLM ensemble coordinator."""
    
    def __init__(self):
        self.providers: Dict[str, LLMProvider_Base] = {}
        self.task_queue = asyncio.Queue()
        self.response_cache = {}
        self.performance_metrics = {}
        self._initialize_providers()
    
    def _initialize_providers(self):
        """Initialize all LLM providers."""
        # OpenAI providers
        openai_configs = [
            LLMConfig(
                provider=LLMProvider.OPENAI,
                model="gpt-4-1106-preview",
                cost_per_token=0.00003,
                capabilities=[TaskType.ANALYSIS, TaskType.GENERATION, TaskType.DECISION_SUPPORT],
                performance_score=0.95
            ),
            LLMConfig(
                provider=LLMProvider.OPENAI,
                model="gpt-3.5-turbo",
                cost_per_token=0.000002,
                capabilities=[TaskType.CLASSIFICATION, TaskType.SUMMARIZATION, TaskType.CONVERSATION],
                performance_score=0.85
            )
        ]
        
        # Anthropic providers
        anthropic_configs = [
            LLMConfig(
                provider=LLMProvider.ANTHROPIC,
                model="claude-3-opus-20240229",
                cost_per_token=0.000075,
                capabilities=[TaskType.ANALYSIS, TaskType.GENERATION, TaskType.VALIDATION],
                performance_score=0.98
            ),
            LLMConfig(
                provider=LLMProvider.ANTHROPIC,
                model="claude-3-sonnet-20240229",
                cost_per_token=0.000015,
                capabilities=[TaskType.CLASSIFICATION, TaskType.TRANSLATION, TaskType.EXTRACTION],
                performance_score=0.90
            )
        ]
        
        # Replicate providers
        replicate_configs = [
            LLMConfig(
                provider=LLMProvider.REPLICATE,
                model="meta/llama-2-70b-chat",
                cost_per_token=0.000001,
                capabilities=[TaskType.CONVERSATION, TaskType.GENERATION, TaskType.SUMMARIZATION],
                performance_score=0.80
            )
        ]
        
        # Initialize providers
        all_configs = openai_configs + anthropic_configs + replicate_configs
        
        for config in all_configs:
            try:
                if config.provider == LLMProvider.OPENAI:
                    provider = OpenAIProvider(config)
                elif config.provider == LLMProvider.ANTHROPIC:
                    provider = AnthropicProvider(config)
                elif config.provider == LLMProvider.REPLICATE:
                    provider = ReplicateProvider(config)
                else:
                    continue
                
                if provider.is_available():
                    provider_key = f"{config.provider.value}_{config.model}"
                    self.providers[provider_key] = provider
                    logger.info(f"Initialized provider: {provider_key}")
                
            except Exception as e:
                logger.error(f"Failed to initialize provider {config.provider}_{config.model}: {e}")
    
    def get_suitable_providers(self, task: AITask) -> List[LLMProvider_Base]:
        """Get providers suitable for a task."""
        suitable_providers = []
        
        for provider in self.providers.values():
            # Check if provider supports the task type
            if task.task_type in provider.config.capabilities:
                suitable_providers.append(provider)
        
        # Sort by performance score and availability
        suitable_providers.sort(
            key=lambda p: (p.config.performance_score * p.config.availability_score),
            reverse=True
        )
        
        return suitable_providers
    
    async def process_task(self, task: AITask, strategy: EnsembleStrategy = EnsembleStrategy.SINGLE_BEST) -> AIResponse:
        """Process a task using the specified ensemble strategy."""
        start_time = time.time()
        
        try:
            # Get suitable providers
            providers = self.get_suitable_providers(task)
            
            if not providers:
                raise ValueError(f"No suitable providers found for task type: {task.task_type}")
            
            # Execute strategy
            if strategy == EnsembleStrategy.SINGLE_BEST:
                response = await self._single_best_strategy(task, providers)
            elif strategy == EnsembleStrategy.MAJORITY_VOTE:
                response = await self._majority_vote_strategy(task, providers)
            elif strategy == EnsembleStrategy.WEIGHTED_AVERAGE:
                response = await self._weighted_average_strategy(task, providers)
            elif strategy == EnsembleStrategy.CONSENSUS:
                response = await self._consensus_strategy(task, providers)
            elif strategy == EnsembleStrategy.FALLBACK_CHAIN:
                response = await self._fallback_chain_strategy(task, providers)
            elif strategy == EnsembleStrategy.PARALLEL_VALIDATION:
                response = await self._parallel_validation_strategy(task, providers)
            else:
                response = await self._single_best_strategy(task, providers)
            
            # Record metrics
            processing_time = time.time() - start_time
            self._record_task_metrics(task, response, processing_time)
            
            return response
            
        except Exception as e:
            logger.error(f"Task processing failed: {e}")
            
            # Return error response
            return AIResponse(
                task_id=task.id,
                provider=LLMProvider.OPENAI,  # Default
                model="error",
                content="",
                confidence=0.0,
                processing_time=time.time() - start_time,
                token_usage={},
                cost=0.0,
                error=str(e)
            )
    
    async def _single_best_strategy(self, task: AITask, providers: List[LLMProvider_Base]) -> AIResponse:
        """Use the single best provider for the task."""
        best_provider = providers[0]
        return await best_provider.generate_response(task)
    
    async def _majority_vote_strategy(self, task: AITask, providers: List[LLMProvider_Base]) -> AIResponse:
        """Use majority vote from multiple providers."""
        # Use top 3 providers for voting
        voting_providers = providers[:3]
        
        # Generate responses in parallel
        tasks = [provider.generate_response(task) for provider in voting_providers]
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter successful responses
        valid_responses = [r for r in responses if isinstance(r, AIResponse) and not r.error]
        
        if not valid_responses:
            return responses[0] if responses else AIResponse(
                task_id=task.id,
                provider=LLMProvider.OPENAI,
                model="error",
                content="",
                confidence=0.0,
                processing_time=0.0,
                token_usage={},
                cost=0.0,
                error="All providers failed"
            )
        
        # Simple majority vote (could be enhanced with semantic similarity)
        best_response = max(valid_responses, key=lambda r: r.confidence)
        
        # Combine metadata
        best_response.metadata["ensemble_strategy"] = "majority_vote"
        best_response.metadata["responses_count"] = len(valid_responses)
        
        return best_response
    
    async def _weighted_average_strategy(self, task: AITask, providers: List[LLMProvider_Base]) -> AIResponse:
        """Use weighted average of responses."""
        # Use top 3 providers
        selected_providers = providers[:3]
        
        # Generate responses in parallel
        tasks = [provider.generate_response(task) for provider in selected_providers]
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter successful responses
        valid_responses = [r for r in responses if isinstance(r, AIResponse) and not r.error]
        
        if not valid_responses:
            return AIResponse(
                task_id=task.id,
                provider=LLMProvider.OPENAI,
                model="ensemble",
                content="",
                confidence=0.0,
                processing_time=0.0,
                token_usage={},
                cost=0.0,
                error="All providers failed"
            )
        
        # Calculate weighted confidence
        total_weight = sum(r.confidence for r in valid_responses)
        if total_weight == 0:
            return valid_responses[0]
        
        # For text responses, select the highest confidence response
        # (true weighted averaging would require semantic analysis)
        best_response = max(valid_responses, key=lambda r: r.confidence)
        
        # Update metadata
        best_response.confidence = total_weight / len(valid_responses)
        best_response.metadata["ensemble_strategy"] = "weighted_average"
        best_response.metadata["responses_count"] = len(valid_responses)
        
        return best_response
    
    async def _consensus_strategy(self, task: AITask, providers: List[LLMProvider_Base]) -> AIResponse:
        """Require consensus from multiple providers."""
        # Use top 3 providers
        consensus_providers = providers[:3]
        
        # Generate responses in parallel
        tasks = [provider.generate_response(task) for provider in consensus_providers]
        responses = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter successful responses
        valid_responses = [r for r in responses if isinstance(r, AIResponse) and not r.error]
        
        if len(valid_responses) < 2:
            return valid_responses[0] if valid_responses else AIResponse(
                task_id=task.id,
                provider=LLMProvider.OPENAI,
                model="consensus",
                content="",
                confidence=0.0,
                processing_time=0.0,
                token_usage={},
                cost=0.0,
                error="Insufficient responses for consensus"
            )
        
        # Simple consensus check (could be enhanced with semantic similarity)
        avg_confidence = sum(r.confidence for r in valid_responses) / len(valid_responses)
        
        if avg_confidence > 0.8:  # High consensus threshold
            best_response = max(valid_responses, key=lambda r: r.confidence)
            best_response.metadata["ensemble_strategy"] = "consensus"
            best_response.metadata["consensus_score"] = avg_confidence
            return best_response
        else:
            # No consensus, return best individual response with lower confidence
            best_response = max(valid_responses, key=lambda r: r.confidence)
            best_response.confidence *= 0.7  # Reduce confidence due to lack of consensus
            best_response.metadata["ensemble_strategy"] = "consensus_failed"
            return best_response
    
    async def _fallback_chain_strategy(self, task: AITask, providers: List[LLMProvider_Base]) -> AIResponse:
        """Try providers in order until one succeeds."""
        for provider in providers:
            try:
                response = await provider.generate_response(task)
                if not response.error and response.confidence > 0.5:
                    response.metadata["ensemble_strategy"] = "fallback_chain"
                    response.metadata["provider_rank"] = providers.index(provider) + 1
                    return response
            except Exception as e:
                logger.warning(f"Provider {provider.config.model} failed: {e}")
                continue
        
        # All providers failed
        return AIResponse(
            task_id=task.id,
            provider=LLMProvider.OPENAI,
            model="fallback_chain",
            content="",
            confidence=0.0,
            processing_time=0.0,
            token_usage={},
            cost=0.0,
            error="All providers in fallback chain failed"
        )
    
    async def _parallel_validation_strategy(self, task: AITask, providers: List[LLMProvider_Base]) -> AIResponse:
        """Use one provider for generation, others for validation."""
        if len(providers) < 2:
            return await self._single_best_strategy(task, providers)
        
        # Use best provider for generation
        generator = providers[0]
        validators = providers[1:3]  # Use up to 2 validators
        
        # Generate initial response
        primary_response = await generator.generate_response(task)
        
        if primary_response.error:
            return primary_response
        
        # Create validation tasks
        validation_task = AITask(
            id=f"{task.id}_validation",
            task_type=TaskType.VALIDATION,
            priority=task.priority,
            prompt=f"Validate this response for accuracy and quality:\n\nOriginal task: {task.prompt}\n\nResponse to validate: {primary_response.content}",
            context=task.context,
            expected_format="json"
        )
        
        # Run validations in parallel
        validation_tasks = [validator.generate_response(validation_task) for validator in validators]
        validation_responses = await asyncio.gather(*validation_tasks, return_exceptions=True)
        
        # Process validation results
        valid_validations = [r for r in validation_responses if isinstance(r, AIResponse) and not r.error]
        
        if valid_validations:
            avg_validation_score = sum(r.confidence for r in valid_validations) / len(valid_validations)
            primary_response.confidence = (primary_response.confidence + avg_validation_score) / 2
            primary_response.metadata["ensemble_strategy"] = "parallel_validation"
            primary_response.metadata["validation_score"] = avg_validation_score
            primary_response.metadata["validators_count"] = len(valid_validations)
        
        return primary_response
    
    def _record_task_metrics(self, task: AITask, response: AIResponse, processing_time: float):
        """Record task processing metrics."""
        # Record metrics for monitoring
        metrics.record_business_metrics(
            {"ai_tasks_processed": 1},
            {"ai_responses_generated": 1}
        )
        
        # Log performance
        logger.info(f"Task {task.id} processed in {processing_time:.2f}s with confidence {response.confidence:.2f}")
        
        # Update provider performance metrics
        provider_key = f"{response.provider}_{response.model}"
        if provider_key not in self.performance_metrics:
            self.performance_metrics[provider_key] = {
                "total_tasks": 0,
                "total_time": 0,
                "total_cost": 0,
                "avg_confidence": 0,
                "error_count": 0
            }
        
        metrics_data = self.performance_metrics[provider_key]
        metrics_data["total_tasks"] += 1
        metrics_data["total_time"] += processing_time
        metrics_data["total_cost"] += response.cost
        
        if response.error:
            metrics_data["error_count"] += 1
        else:
            # Update average confidence
            current_avg = metrics_data["avg_confidence"]
            task_count = metrics_data["total_tasks"]
            metrics_data["avg_confidence"] = (current_avg * (task_count - 1) + response.confidence) / task_count
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Get performance report for all providers."""
        report = {
            "providers": {},
            "total_providers": len(self.providers),
            "available_providers": sum(1 for p in self.providers.values() if p.is_available()),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        for provider_key, metrics_data in self.performance_metrics.items():
            if metrics_data["total_tasks"] > 0:
                report["providers"][provider_key] = {
                    "total_tasks": metrics_data["total_tasks"],
                    "avg_processing_time": metrics_data["total_time"] / metrics_data["total_tasks"],
                    "total_cost": metrics_data["total_cost"],
                    "avg_confidence": metrics_data["avg_confidence"],
                    "error_rate": metrics_data["error_count"] / metrics_data["total_tasks"],
                    "availability": self.providers.get(provider_key, {}).is_available() if provider_key in self.providers else False
                }
        
        return report


# Global ensemble instance
llm_ensemble = LLMEnsemble()

# Convenience functions
def get_llm_ensemble() -> LLMEnsemble:
    """Get the global LLM ensemble."""
    return llm_ensemble

@cached(ttl=300, key_prefix="ai_task")
async def process_ai_task(task: AITask, strategy: EnsembleStrategy = EnsembleStrategy.SINGLE_BEST) -> AIResponse:
    """Process an AI task with caching."""
    return await llm_ensemble.process_task(task, strategy)

@timed("ai_task_processing")
async def create_and_process_task(
    task_type: TaskType,
    prompt: str,
    priority: TaskPriority = TaskPriority.NORMAL,
    context: Optional[Dict[str, Any]] = None,
    strategy: EnsembleStrategy = EnsembleStrategy.SINGLE_BEST,
    **kwargs
) -> AIResponse:
    """Create and process an AI task."""
    import uuid
    
    task = AITask(
        id=str(uuid.uuid4()),
        task_type=task_type,
        priority=priority,
        prompt=prompt,
        context=context or {},
        **kwargs
    )
    
    return await process_ai_task(task, strategy)
