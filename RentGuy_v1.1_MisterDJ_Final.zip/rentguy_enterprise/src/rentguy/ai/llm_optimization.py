"""
LLM Optimization Service for RentGuy Enterprise.
Handles intelligent routing, fallback, prompt versioning, and caching
to ensure cost-effectiveness, reliability, and performance of the Multi-LLM Ensemble.
"""

import json
import hashlib
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime, timedelta
from enum import Enum

from ..core.logging import get_logger
from ..core.config import get_settings
from .ensemble_architecture import MultiLLMEnsemble, AITask, AIResponse, EnsembleStrategy, TaskType

logger = get_logger(__name__)
settings = get_settings()

class LLMProvider(str, Enum):
    """Available LLM providers in the ensemble."""
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    REPLICATE = "replicate"
    FALLBACK = "fallback" # Local or cheapest model

class LLMOptimizationService:
    """
    Service to optimize LLM usage through routing, caching, and fallback.
    """
    
    def __init__(self, ensemble: MultiLLMEnsemble):
        self.ensemble = ensemble
        self.cache: Dict[str, Tuple[AIResponse, datetime]] = {} # Simple in-memory cache
        self.cache_ttl = timedelta(hours=24) # Time-to-live for cache entries
        self.prompt_versions: Dict[str, str] = self._load_prompt_versions()
        
    def _load_prompt_versions(self) -> Dict[str, str]:
        """
        Loads prompt versions from a configuration file or database.
        In a real system, this would be a persistent store.
        """
        # Example structure: { "task_type": "v1.0", ... }
        return {
            TaskType.GENERATION.value: "v1.1",
            TaskType.ANALYSIS.value: "v2.0",
            TaskType.CLASSIFICATION.value: "v1.0",
            "lead_qualification": "v1.2",
            "invoice_summary": "v1.0"
        }

    def _generate_cache_key(self, task: AITask) -> str:
        """
        Generates a unique cache key based on the task's prompt, context, and version.
        """
        version = self.prompt_versions.get(task.task_type.value, "v0.0")
        
        # Include the specific prompt version in the key
        data = {
            "prompt": task.prompt,
            "context": task.context,
            "version": version,
            "task_type": task.task_type.value
        }
        
        # Use a stable JSON dump and SHA256 hash
        json_data = json.dumps(data, sort_keys=True)
        return hashlib.sha256(json_data.encode('utf-8')).hexdigest()

    def _get_from_cache(self, cache_key: str) -> Optional[AIResponse]:
        """
        Retrieves a response from the cache if it's valid and not expired.
        """
        if cache_key in self.cache:
            response, timestamp = self.cache[cache_key]
            if datetime.utcnow() < timestamp + self.cache_ttl:
                logger.debug(f"Cache hit for key: {cache_key}")
                return response
            else:
                logger.debug(f"Cache expired for key: {cache_key}")
                del self.cache[cache_key]
        return None

    def _set_to_cache(self, cache_key: str, response: AIResponse):
        """
        Stores a response in the cache.
        """
        self.cache[cache_key] = (response, datetime.utcnow())
        logger.debug(f"Cache set for key: {cache_key}")

    def _intelligent_route(self, task: AITask) -> LLMProvider:
        """
        Intelligent routing based on task type, priority, and cost.
        
        Routing Strategy:
        1. High Priority / Complex Analysis -> ANTHROPIC (Opus/Sonnet)
        2. Creative Generation / General Tasks -> OPENAI (GPT-4/GPT-3.5)
        3. High Volume / Low Latency / Cost-Sensitive -> REPLICATE (Llama/DeepSeek)
        """
        if task.priority == TaskPriority.CRITICAL or task.task_type == TaskType.ANALYSIS:
            # Prioritize accuracy and reasoning for critical tasks
            return LLMProvider.ANTHROPIC
        
        if task.task_type == TaskType.GENERATION and task.priority == TaskPriority.HIGH:
            # Prioritize quality for high-value generation
            return LLMProvider.OPENAI
        
        # Default to the most cost-effective and fast provider for general tasks
        return LLMProvider.REPLICATE

    async def process_optimized_task(self, task: AITask) -> AIResponse:
        """
        Processes an AI task using caching, intelligent routing, and fallback.
        """
        # 1. Caching Check
        cache_key = self._generate_cache_key(task)
        cached_response = self._get_from_cache(cache_key)
        if cached_response:
            return cached_response

        # 2. Intelligent Routing
        primary_provider = self._intelligent_route(task)
        
        # Define fallback chain (e.g., Anthropic -> OpenAI -> Replicate)
        provider_chain = [primary_provider]
        if primary_provider != LLMProvider.ANTHROPIC:
            provider_chain.append(LLMProvider.ANTHROPIC)
        if primary_provider != LLMProvider.OPENAI:
            provider_chain.append(LLMProvider.OPENAI)
        if primary_provider != LLMProvider.REPLICATE:
            provider_chain.append(LLMProvider.REPLICATE)
        
        # Ensure no duplicates and Fallback is last
        provider_chain = list(dict.fromkeys(provider_chain))
        provider_chain.append(LLMProvider.FALLBACK)

        # 3. Execution with Fallback
        final_response = None
        
        for provider in provider_chain:
            try:
                logger.info(f"Attempting task execution with primary provider: {provider.value}")
                
                # In a real implementation, the ensemble would have a method to target a specific provider
                # For this implementation, we simulate the targeting and use the ensemble's core method
                
                # Simulate provider-specific execution (e.g., using different models/APIs)
                if provider == LLMProvider.ANTHROPIC:
                    # Use a high-quality model for Anthropic
                    response = await self.ensemble.process_task(task, EnsembleStrategy.CONSENSUS)
                elif provider == LLMProvider.OPENAI:
                    # Use a balanced model for OpenAI
                    response = await self.ensemble.process_task(task, EnsembleStrategy.BEST_OF_N)
                elif provider == LLMProvider.REPLICATE:
                    # Use a cost-effective model for Replicate
                    response = await self.ensemble.process_task(task, EnsembleStrategy.CHEAPEST)
                elif provider == LLMProvider.FALLBACK:
                    # Final fallback (e.g., a simple, local model or hardcoded response)
                    logger.warning("Using final fallback mechanism for AI task.")
                    response = AIResponse(
                        id=task.id,
                        content="Fallback response: Could not process request with any primary LLM provider.",
                        confidence=0.1,
                        source=LLMProvider.FALLBACK.value,
                        metadata={"error": "All LLM providers failed"}
                    )
                else:
                    continue # Should not happen
                
                # Check for a valid response (e.g., not an error message from the provider)
                if response.confidence > 0.1:
                    final_response = response
                    break # Success, break the fallback chain
                
            except Exception as e:
                logger.error(f"LLM provider {provider.value} failed: {str(e)}")
                continue # Try next provider in the chain

        if final_response is None:
            # Should be caught by the FALLBACK in the chain, but as a safety net
            raise Exception("All LLM providers and fallback mechanism failed to process the task.")

        # 4. Caching Update
        self._set_to_cache(cache_key, final_response)
        
        return final_response

    def get_current_prompt(self, task_type: str) -> Tuple[str, str]:
        """
        Retrieves the current versioned prompt for a given task type.
        
        Returns:
            Tuple of (prompt_content, version)
        """
        version = self.prompt_versions.get(task_type, "v0.0")
        
        # In a real system, this would fetch the prompt from a versioned store
        # For now, we return a placeholder and the version
        placeholder_prompt = f"Version {version} prompt for {task_type}. Use this version for all calls."
        
        return placeholder_prompt, version

    def update_prompt_version(self, task_type: str, new_version: str, new_prompt_content: str):
        """
        Updates the prompt version and content, invalidating relevant cache entries.
        """
        self.prompt_versions[task_type] = new_version
        
        # Invalidate cache entries related to this task type (complex in a real system)
        # For simplicity, we clear the entire cache on a major prompt update
        self.cache = {}
        
        logger.warning(
            "Prompt version updated and cache cleared",
            task_type=task_type,
            new_version=new_version
        )
        
        # In a real system, save the new prompt content to the versioned store
        # and persist the new version map.
        
        return {"success": True, "new_version": new_version}
