#!/usr/bin/env python3
"""
RentGuy Enterprise - Interactive Claude Code Review & Improvement Tool
Author: Manus AI
Date: October 2025
Purpose: Real-time code analysis and improvement with Claude API
"""

import os
import sys
import json
import time
import subprocess
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import anthropic

# Configuration
ANTHROPIC_API_KEY = "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"
PROJECT_ROOT = Path("/home/ubuntu/rentguy-enterprise-complete")
CLAUDE_MODEL = "claude-3-5-haiku-20241022"  # Best available model

class ClaudeCodeReviewer:
    def __init__(self):
        self.client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
        self.project_root = PROJECT_ROOT
        self.setup_logging()
        
    def setup_logging(self):
        """Setup logging for code review session"""
        log_dir = self.project_root / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_dir / "claude_code_review.log"),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def call_claude(self, prompt: str, max_tokens: int = 4000) -> Optional[str]:
        """Call Claude API for code analysis"""
        try:
            self.logger.info(f"🤖 Analyzing code with Claude...")
            
            response = self.client.messages.create(
                model=CLAUDE_MODEL,
                max_tokens=max_tokens,
                temperature=0.1,
                messages=[{"role": "user", "content": prompt}]
            )
            
            content = response.content[0].text
            self.logger.info(f"✅ Claude analysis complete ({len(content)} chars)")
            return content
            
        except Exception as e:
            self.logger.error(f"❌ Claude API error: {e}")
            return None
    
    def analyze_file(self, file_path: Path) -> Dict:
        """Analyze a single file with Claude"""
        if not file_path.exists():
            return {"error": "File not found"}
            
        try:
            content = file_path.read_text(encoding='utf-8')
        except Exception as e:
            return {"error": f"Cannot read file: {e}"}
        
        # Determine file type and create appropriate prompt
        file_ext = file_path.suffix.lower()
        file_type = self.get_file_type(file_ext)
        
        prompt = f"""
        Analyze this {file_type} file for the RentGuy Enterprise rental management platform.
        
        File: {file_path.name}
        Type: {file_type}
        
        Code:
        ```{file_ext[1:] if file_ext else 'text'}
        {content}
        ```
        
        Please provide:
        1. **Code Quality Assessment** (1-10 scale)
        2. **Security Issues** (if any)
        3. **Performance Improvements** 
        4. **Best Practices Violations**
        5. **Specific Improvements** with code examples
        6. **Enterprise-Grade Enhancements**
        
        Focus on:
        - TypeScript/JavaScript best practices
        - React performance optimization
        - Security vulnerabilities
        - Code maintainability
        - Enterprise scalability
        - Error handling
        
        Provide actionable, specific recommendations with code examples.
        """
        
        analysis = self.call_claude(prompt, 4000)
        
        if analysis:
            return {
                "file": str(file_path),
                "type": file_type,
                "size": len(content),
                "lines": len(content.splitlines()),
                "analysis": analysis,
                "timestamp": datetime.now().isoformat()
            }
        else:
            return {"error": "Claude analysis failed"}
    
    def get_file_type(self, extension: str) -> str:
        """Determine file type from extension"""
        type_map = {
            '.js': 'JavaScript',
            '.jsx': 'React JSX',
            '.ts': 'TypeScript', 
            '.tsx': 'React TypeScript',
            '.py': 'Python',
            '.css': 'CSS',
            '.scss': 'SCSS',
            '.html': 'HTML',
            '.json': 'JSON',
            '.md': 'Markdown',
            '.yml': 'YAML',
            '.yaml': 'YAML',
            '.sh': 'Shell Script',
            '.sql': 'SQL'
        }
        return type_map.get(extension, 'Text')
    
    def improve_file(self, file_path: Path, analysis: str) -> Optional[str]:
        """Generate improved version of file based on analysis"""
        try:
            original_content = file_path.read_text(encoding='utf-8')
        except Exception as e:
            self.logger.error(f"Cannot read file for improvement: {e}")
            return None
            
        prompt = f"""
        Based on the following analysis, create an improved version of this file:
        
        Original file: {file_path.name}
        
        Analysis:
        {analysis}
        
        Original code:
        ```
        {original_content}
        ```
        
        Please provide:
        1. **Improved Code** - Complete, production-ready version
        2. **Change Summary** - What was improved and why
        3. **Migration Notes** - Any breaking changes or considerations
        
        Requirements:
        - Maintain all existing functionality
        - Improve code quality, security, and performance
        - Add proper TypeScript types where applicable
        - Follow enterprise-grade best practices
        - Add comprehensive error handling
        - Include proper documentation/comments
        
        Respond with the complete improved file content.
        """
        
        improved_code = self.call_claude(prompt, 4000)
        return improved_code
    
    def scan_project(self) -> List[Path]:
        """Scan project for code files to analyze"""
        code_extensions = {'.js', '.jsx', '.ts', '.tsx', '.py', '.css', '.scss', '.html', '.json', '.yml', '.yaml'}
        
        code_files = []
        
        # Scan specific directories
        scan_dirs = [
            self.project_root / "mr-dj-onboarding-enhanced" / "src",
            self.project_root / "backend",
            self.project_root / "frontend", 
            self.project_root / "infrastructure",
            self.project_root / "scripts"
        ]
        
        for scan_dir in scan_dirs:
            if scan_dir.exists():
                for file_path in scan_dir.rglob("*"):
                    if (file_path.is_file() and 
                        file_path.suffix.lower() in code_extensions and
                        'node_modules' not in str(file_path) and
                        '.git' not in str(file_path)):
                        code_files.append(file_path)
        
        # Also check root level config files
        root_files = [
            'package.json', 'tsconfig.json', 'vite.config.js', 'docker-compose.yml',
            'README.md', '.gitignore', 'tailwind.config.js'
        ]
        
        for filename in root_files:
            file_path = self.project_root / filename
            if file_path.exists():
                code_files.append(file_path)
        
        return sorted(code_files)
    
    def interactive_review(self):
        """Interactive code review session"""
        print("🔍 RentGuy Enterprise - Interactive Claude Code Review")
        print("=" * 60)
        
        code_files = self.scan_project()
        print(f"📁 Found {len(code_files)} code files to analyze")
        
        if not code_files:
            print("❌ No code files found!")
            return
        
        # Show file list
        print("\n📋 Files to review:")
        for i, file_path in enumerate(code_files, 1):
            rel_path = file_path.relative_to(self.project_root)
            print(f"  {i:2d}. {rel_path}")
        
        print("\n🎯 Review Options:")
        print("  [A] Analyze all files")
        print("  [S] Select specific files")
        print("  [Q] Quick scan (critical files only)")
        print("  [I] Improve specific file")
        
        choice = input("\nChoose option [A/S/Q/I]: ").upper().strip()
        
        if choice == 'A':
            self.analyze_all_files(code_files)
        elif choice == 'S':
            self.select_and_analyze(code_files)
        elif choice == 'Q':
            self.quick_scan(code_files)
        elif choice == 'I':
            self.improve_specific_file(code_files)
        else:
            print("Invalid choice!")
    
    def analyze_all_files(self, code_files: List[Path]):
        """Analyze all code files"""
        print(f"\n🚀 Starting comprehensive analysis of {len(code_files)} files...")
        
        results = []
        
        for i, file_path in enumerate(code_files, 1):
            rel_path = file_path.relative_to(self.project_root)
            print(f"\n[{i}/{len(code_files)}] Analyzing {rel_path}...")
            
            result = self.analyze_file(file_path)
            results.append(result)
            
            if 'analysis' in result:
                print("✅ Analysis complete")
            else:
                print(f"❌ Analysis failed: {result.get('error', 'Unknown error')}")
        
        # Save comprehensive report
        self.save_analysis_report(results)
        self.generate_improvement_plan(results)
    
    def quick_scan(self, code_files: List[Path]):
        """Quick scan of critical files only"""
        critical_patterns = [
            'App.jsx', 'App.tsx', 'index.js', 'index.ts',
            'server.js', 'server.py', 'main.py',
            'docker-compose.yml', 'package.json',
            'OnboardingWizard', 'security', 'auth'
        ]
        
        critical_files = []
        for file_path in code_files:
            if any(pattern.lower() in file_path.name.lower() for pattern in critical_patterns):
                critical_files.append(file_path)
        
        print(f"\n⚡ Quick scan of {len(critical_files)} critical files...")
        self.analyze_all_files(critical_files)
    
    def select_and_analyze(self, code_files: List[Path]):
        """Let user select specific files to analyze"""
        print("\n📝 Enter file numbers to analyze (comma-separated, e.g., 1,3,5):")
        selection = input("Files: ").strip()
        
        try:
            indices = [int(x.strip()) - 1 for x in selection.split(',')]
            selected_files = [code_files[i] for i in indices if 0 <= i < len(code_files)]
            
            if selected_files:
                self.analyze_all_files(selected_files)
            else:
                print("❌ No valid files selected!")
                
        except ValueError:
            print("❌ Invalid input format!")
    
    def improve_specific_file(self, code_files: List[Path]):
        """Improve a specific file"""
        print("\n🔧 Select file to improve:")
        for i, file_path in enumerate(code_files, 1):
            rel_path = file_path.relative_to(self.project_root)
            print(f"  {i:2d}. {rel_path}")
        
        try:
            choice = int(input("\nFile number: ").strip()) - 1
            if 0 <= choice < len(code_files):
                file_path = code_files[choice]
                
                print(f"\n🔍 Analyzing {file_path.name}...")
                analysis_result = self.analyze_file(file_path)
                
                if 'analysis' in analysis_result:
                    print("✅ Analysis complete")
                    print("\n🔧 Generating improvements...")
                    
                    improved_code = self.improve_file(file_path, analysis_result['analysis'])
                    
                    if improved_code:
                        # Save improved version
                        backup_path = file_path.with_suffix(f'.backup{file_path.suffix}')
                        file_path.rename(backup_path)
                        
                        file_path.write_text(improved_code, encoding='utf-8')
                        
                        print(f"✅ File improved!")
                        print(f"📁 Original saved as: {backup_path.name}")
                        print(f"📁 Improved version: {file_path.name}")
                    else:
                        print("❌ Failed to generate improvements")
                else:
                    print(f"❌ Analysis failed: {analysis_result.get('error')}")
            else:
                print("❌ Invalid file number!")
                
        except ValueError:
            print("❌ Invalid input!")
    
    def save_analysis_report(self, results: List[Dict]):
        """Save comprehensive analysis report"""
        report_dir = self.project_root / "reports"
        report_dir.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = report_dir / f"claude_code_analysis_{timestamp}.json"
        
        # Create summary
        summary = {
            "timestamp": datetime.now().isoformat(),
            "total_files": len(results),
            "successful_analyses": len([r for r in results if 'analysis' in r]),
            "failed_analyses": len([r for r in results if 'error' in r]),
            "total_lines": sum(r.get('lines', 0) for r in results),
            "results": results
        }
        
        report_file.write_text(json.dumps(summary, indent=2), encoding='utf-8')
        
        print(f"\n📊 Analysis report saved: {report_file}")
        print(f"   • Total files: {summary['total_files']}")
        print(f"   • Successful: {summary['successful_analyses']}")
        print(f"   • Failed: {summary['failed_analyses']}")
        print(f"   • Total lines: {summary['total_lines']}")
    
    def generate_improvement_plan(self, results: List[Dict]):
        """Generate overall improvement plan"""
        successful_results = [r for r in results if 'analysis' in r]
        
        if not successful_results:
            print("❌ No successful analyses to generate improvement plan")
            return
        
        # Combine all analyses for overall assessment
        all_analyses = "\n\n".join([r['analysis'] for r in successful_results])
        
        prompt = f"""
        Based on the comprehensive code analysis of the RentGuy Enterprise platform, 
        create a prioritized improvement plan.
        
        Analysis Results:
        {all_analyses}
        
        Please provide:
        1. **Overall Code Quality Assessment** (1-10 scale)
        2. **Critical Issues** (security, performance, bugs)
        3. **Priority Improvements** (ranked by impact)
        4. **Implementation Roadmap** (phases and timeline)
        5. **Resource Requirements** (time, expertise needed)
        6. **Risk Assessment** (what could go wrong)
        
        Focus on enterprise-grade improvements that will make the biggest impact
        on security, performance, maintainability, and scalability.
        """
        
        improvement_plan = self.call_claude(prompt, 4000)
        
        if improvement_plan:
            plan_file = self.project_root / "reports" / "improvement_plan.md"
            plan_file.write_text(improvement_plan, encoding='utf-8')
            
            print(f"\n📋 Improvement plan generated: {plan_file}")
            print("\n" + "="*60)
            print("IMPROVEMENT PLAN PREVIEW")
            print("="*60)
            print(improvement_plan[:500] + "..." if len(improvement_plan) > 500 else improvement_plan)

def main():
    """Main execution function"""
    reviewer = ClaudeCodeReviewer()
    
    print("🚀 RentGuy Enterprise - Claude Code Reviewer")
    print("Real-time code analysis and improvement with Claude API")
    print("="*60)
    
    try:
        reviewer.interactive_review()
    except KeyboardInterrupt:
        print("\n\n👋 Code review session ended by user")
    except Exception as e:
        print(f"\n❌ Error during code review: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
