# RentGuy Enterprise Compliance Documentation: GDPR & ISO 27001 Preparation

Dit document dient als de basis voor de naleving van de Algemene Verordening Gegevensbescherming (AVG/GDPR) en de voorbereiding op ISO 27001-certificering (Informatiebeveiliging).

## 1. GDPR (AVG) Naleving

De GDPR vereist dat persoonsgegevens (PII) op een rechtmatige, eerlijke en transparante manier worden verwerkt. De volgende maatregelen zijn geïmplementeerd of voorbereid in de codebase:

### 1.1. Recht op Vergetelheid (Right to be Forgotten)

De **Data Anonymization Service** is geïmplementeerd om te voldoen aan artikel 17 van de GDPR.

| Component | Functie | Implementatie |
|:---|:---|:---|
| **Service** | `AnonymizationService` | Biedt methoden om PII in de database te anonimiseren of te pseudonimiseren. |
| **Techniek** | Pseudonimisering | Gebruik van salted SHA256-hashing voor PII (e-mail, telefoonnummer) om de data te behouden voor analytische doeleinden zonder directe identificatie. |
| **Techniek** | Vervanging (Faking) | Gebruik van de `Faker` bibliotheek om PII te vervangen door realistisch ogende, maar valse data (voor testomgevingen). |
| **Scope** | Gebruikersdata | Anonymiseert `User`, `Lead`, en `Contact` records op verzoek. |

### 1.2. Privacy by Design & Default

- **Minimale Gegevensverwerking:** De applicatie verzamelt alleen noodzakelijke PII voor de verhuurtransactie.
- **Audit Logging:** Gedetailleerde audit logs zijn geconfigureerd om te registreren wie, wanneer en welke PII heeft benaderd of gewijzigd.

### 1.3. Data Processing Agreement (DPA) Template

Een DPA is vereist wanneer RentGuy optreedt als verwerker van persoonsgegevens voor een klant.

**Actie:** Het template `DPA_TEMPLATE.md` is opgesteld en moet worden gebruikt voor alle enterprise-klanten.

## 2. ISO 27001 Voorbereiding

ISO 27001 is de internationale standaard voor Information Security Management Systems (ISMS). De voorbereiding richt zich op de volgende controlemaatregelen:

### 2.1. Audit Logging (A.12.4.1)

De gestructureerde logging-module is uitgebreid om te voldoen aan de vereisten voor audit trails.

| Vereiste | Implementatie in RentGuy |
|:---|:---|
| **Tijdssynchronisatie** | Alle logs gebruiken UTC en zijn gesynchroniseerd via het onderliggende OS/VPS. |
| **Gebeurtenisregistratie** | Registratie van inlogpogingen, toegangscontroles, en wijzigingen aan PII. |
| **PII Scrubbing** | De `AnonymizationService` bevat een methode om PII te hashen in log-entries voordat ze worden opgeslagen. |

### 2.2. Beveiliging van Systeembestanden (A.12.5.1)

- **Versiebeheer:** Alle configuratiebestanden en code staan onder strikt versiebeheer (Git).
- **Toegangscontrole:** Rollen en permissies (RBAC) zijn geïmplementeerd om de toegang tot de codebase en de database te beperken.

### 2.3. Beveiliging van Ontwikkelings- en Testomgevingen (A.14.2.1)

- **Omgevingsscheiding:** Productie, Staging en Ontwikkeling zijn strikt gescheiden via Docker/Docker Compose.
- **PII Gebruik:** De `AnonymizationService` moet worden gebruikt om PII te vervangen door fake data in de testomgevingen.

## 3. AI/LLM Optimalisatie (Betrouwbaarheid & Kosten)

De **LLM Optimization Service** is geïmplementeerd om de betrouwbaarheid en kosteneffectiviteit van de Multi-LLM Ensemble te garanderen, wat een cruciaal onderdeel is van de professionalisering.

| Component | Functie | Voordeel |
|:---|:---|:---|
| **Intelligent Routing** | `_intelligent_route()` | Stuurt taken naar de meest geschikte LLM (Anthropic voor analyse, Replicate voor kosten). |
| **Fallback Mechanisme** | `process_optimized_task()` | Zorgt ervoor dat een taak altijd wordt voltooid, zelfs als de primaire LLM faalt (valt terug op andere providers). |
| **Caching** | `_get_from_cache()` | Voorkomt onnodige API-calls voor herhaalde prompts, wat de kosten verlaagt en de latency verbetert. |
| **Prompt Versioning** | `_load_prompt_versions()` | Maakt het mogelijk om prompts te updaten zonder de cache te verliezen voor oudere versies, en zorgt voor auditability van AI-output. |

Deze maatregelen zorgen ervoor dat de AI-functionaliteit van RentGuy Enterprise zowel **betrouwbaar** (door fallback) als **kosteneffectief** (door routing en caching) is, wat essentieel is voor een enterprise-grade SaaS-oplossing.

---

**Volgende Stappen:**
1.  **Implementatie van de Audit Logging** in de kernservices.
2.  **Opstellen van de DPA en Privacy Policy templates.**
3.  **Integratie van de LLM Optimization Service** in de AI-workflows.
