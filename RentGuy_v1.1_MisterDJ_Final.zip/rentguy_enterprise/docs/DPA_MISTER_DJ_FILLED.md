# Data Processing Agreement (DPA) - Ingevuld voor Mister DJ

**Tussen:**

**RentGuy Enterprise B.V.**, gevestigd te [Adres RentGuy Enterprise B.V.], rechtsgeldig vertegenwoordigd door [Naam Vertegenwoordiger RentGuy], hierna te noemen **"Verwerker"**.

**En:**

**Mister DJ**, gevestigd te **Kapteijnlaan 17, 5505 AV Veldhoven**, rechtsgeldig vertegenwoordigd door **Bart van de Weijer** (Eigenaar), hierna te noemen **"Verwerkingsverantwoordelijke"**.

Gezamenlijk aangeduid als **"Partijen"**.

## Overwegingen

A. De Verwerkingsverantwoordelijke maakt gebruik van de diensten van de Verwerker (de "Diensten"), waarbij de Verwerker persoonsgegevens verwerkt namens de Verwerkingsverantwoordelijke.
B. De Verwerkingsverantwoordelijke is de Verwerkingsverantwoordelijke in de zin van de Algemene Verordening Gegevensbescherming (AVG/GDPR).
C. Partijen wensen de voorwaarden voor de verwerking van persoonsgegevens door de Verwerker vast te leggen, in overeenstemming met artikel 28 van de AVG.

## 1. Onderwerp en Duur van de Verwerking

| Criterium | Details |
|:---|:---|
| **Onderwerp** | De verwerking van persoonsgegevens in het kader van de levering van de RentGuy Enterprise software en gerelateerde diensten (verhuurbeheer, facturatie, CRM, AI-analyse). |
| **Duur** | Voor de duur van de hoofdovereenkomst tussen Partijen. |
| **Aard en Doel** | Het mogelijk maken van de verhuuractiviteiten van de Verwerkingsverantwoordelijke, inclusief het beheer van klanten, leads, verhuurcontracten en facturatie. |
| **Type Persoonsgegevens** | Naam, adres, woonplaats, e-mailadres, telefoonnummer, KvK-nummer, BTW-nummer, bankrekeningnummer, huurgeschiedenis, IP-adressen, logingegevens. |
| **Categorieën Betrokkenen** | Klanten, leads, contactpersonen, werknemers van de Verwerkingsverantwoordelijke. |

## 2. Verplichtingen van de Verwerker (RentGuy Enterprise B.V.)

De Verwerker verbindt zich ertoe:

2.1. De persoonsgegevens uitsluitend te verwerken in overeenstemming met de schriftelijke instructies van de Verwerkingsverantwoordelijke, tenzij de Verwerker wettelijk verplicht is anders te handelen.

2.2. De vertrouwelijkheid van de persoonsgegevens te waarborgen, inclusief het opleggen van geheimhoudingsplichten aan personeel dat toegang heeft tot de gegevens.

2.3. Passende technische en organisatorische maatregelen (T.O.M.) te treffen om de persoonsgegevens te beveiligen tegen verlies, onbevoegde toegang, wijziging of openbaarmaking. **(Verwijzing naar ISO 27001-voorbereiding)**

2.4. De Verwerkingsverantwoordelijke onverwijld te informeren na kennisname van een inbreuk in verband met persoonsgegevens (datalek).

2.5. De Verwerkingsverantwoordelijke bij te staan bij het voldoen aan diens verplichtingen onder de AVG, waaronder:
    a. Het behandelen van verzoeken van betrokkenen (bijv. recht op inzage, correctie, verwijdering). **(Ondersteund door de `AnonymizationService`)**
    b. Het uitvoeren van een Data Protection Impact Assessment (DPIA), indien nodig.

2.6. Na beëindiging van de Diensten, alle persoonsgegevens, naar keuze van de Verwerkingsverantwoordelijke, te verwijderen of terug te bezorgen, tenzij wettelijke bepalingen anders voorschrijven.

## 3. Subverwerkers

3.1. De Verwerker mag subverwerkers inschakelen voor de uitvoering van de Diensten, mits de Verwerker de Verwerkingsverantwoordelijke vooraf informeert over de voorgenomen inschakeling.

3.2. De Verwerker legt de subverwerkers dezelfde verplichtingen op als die welke in deze DPA zijn vastgelegd.

## 4. Audit en Inspectie

4.1. De Verwerkingsverantwoordelijke heeft het recht om audits uit te voeren, of door een onafhankelijke derde te laten uitvoeren, om de naleving van deze DPA te controleren.

4.2. De Verwerker zal de Verwerkingsverantwoordelijke alle noodzakelijke informatie ter beschikking stellen om de naleving van de verplichtingen in deze DPA aan te tonen.

## 5. Aansprakelijkheid

De aansprakelijkheid van Partijen voor schade voortvloeiend uit deze DPA wordt beheerst door de bepalingen van de hoofdovereenkomst.

---

**Aldus overeengekomen en ondertekend:**

| Voor RentGuy Enterprise B.V. (Verwerker) | Voor Mister DJ (Verwerkingsverantwoordelijke) |
|:---|:---|
| Naam: [Naam Vertegenwoordiger RentGuy] | Naam: Bart van de Weijer |
| Functie: [Functie Vertegenwoordiger RentGuy] | Functie: Eigenaar |
| Datum: | Datum: |
| Handtekening: | Handtekening: |

***
**Aanvullende Gegevens Mister DJ (Verwerkingsverantwoordelijke):**
*   **KvK-nummer:** 68906277
*   **BTW-nummer:** [BTW-nummer Mister DJ - **Nog in te vullen**]
*   **Contact E-mail:** info@mr-dj.nl
*   **Telefoon:** 0031 (0)40 8422594
***
