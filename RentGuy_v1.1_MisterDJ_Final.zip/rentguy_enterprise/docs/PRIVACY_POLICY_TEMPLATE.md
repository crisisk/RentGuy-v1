# Privacy Policy (Privacyverklaring)

**Laatst bijgewerkt:** [Datum]

Dit is de privacyverklaring van **RentGuy Enterprise B.V.**, gevestigd te [Adres RentGuy] (hierna: "RentGuy", "wij", "ons" of "onze").

RentGuy respecteert uw privacy en verwerkt persoonsgegevens in overeenstemming met de Algemene Verordening Gegevensbescherming (AVG/GDPR).

## 1. Welke Persoonsgegevens Verzamelen Wij?

Wij verwerken persoonsgegevens die u aan ons verstrekt in het kader van onze dienstverlening, waaronder:

| Categorie | Voorbeelden | Doel van Verwerking |
|:---|:---|:---|
| **Identificatiegegevens** | Naam, adres, e-mailadres, telefoonnummer. | Uitvoering van de verhuurovereenkomst, facturatie, communicatie. |
| **Financiële Gegevens** | Bankrekeningnummer, BTW-nummer, betalingsgeschiedenis. | Financiële administratie, voldoen aan wettelijke verplichtingen. |
| **Zakelijke Gegevens** | Bedrijfsnaam, KvK-nummer, functie. | Zakelijke communicatie, contractbeheer. |
| **Gebruiksgegevens** | IP-adres, browserinformatie, inlogtijden, acties in de applicatie (Audit Logs). | Beveiliging, optimalisatie van de dienst, foutopsporing. |
| **AI-Interactiegegevens** | Prompts, AI-gegenereerde antwoorden, feedback op AI-output. | Verbetering van de AI-modellen en de dienstverlening. |

## 2. Grondslagen voor de Verwerking

Wij verwerken uw persoonsgegevens op basis van de volgende grondslagen uit de AVG:

1.  **Uitvoering van de overeenkomst:** De verwerking is noodzakelijk voor de uitvoering van de verhuurovereenkomst.
2.  **Wettelijke verplichting:** De verwerking is noodzakelijk om te voldoen aan onze wettelijke verplichtingen (bijv. fiscale bewaarplicht).
3.  **Gerechtvaardigd belang:** De verwerking is noodzakelijk voor de behartiging van onze gerechtvaardigde belangen (bijv. beveiliging, fraudepreventie, productverbetering).

## 3. Delen van Persoonsgegevens

Wij delen uw gegevens alleen met derden indien dit noodzakelijk is voor de uitvoering van de overeenkomst of om te voldoen aan een wettelijke verplichting. Dit omvat:

*   **Subverwerkers:** Partijen die namens ons persoonsgegevens verwerken (bijv. hostingproviders, cloudopslagdiensten). Met deze partijen sluiten wij een **Data Processing Agreement (DPA)**.
*   **Wettelijke instanties:** Indien wij hiertoe wettelijk verplicht zijn.

## 4. Beveiliging van Persoonsgegevens

Wij nemen passende technische en organisatorische maatregelen om uw persoonsgegevens te beveiligen tegen verlies, onbevoegde toegang en onrechtmatige verwerking.

*   **ISO 27001 Voorbereiding:** Onze beveiligingsmaatregelen zijn gebaseerd op de internationale ISO 27001-standaard.
*   **Encryptie:** Gegevens worden versleuteld opgeslagen en verzonden.
*   **Toegangscontrole:** Toegang tot persoonsgegevens is beperkt tot geautoriseerd personeel op basis van de "need-to-know" principe.
*   **Pseudonimisering:** Voor analytische doeleinden gebruiken wij de **Data Anonymization Service** om PII te hashen.

## 5. Uw Rechten

U heeft de volgende rechten met betrekking tot uw persoonsgegevens:

| Recht | Beschrijving |
|:---|:---|
| **Recht op inzage** | U kunt een overzicht opvragen van de persoonsgegevens die wij van u verwerken. |
| **Recht op rectificatie** | U kunt onjuiste of onvolledige gegevens laten corrigeren. |
| **Recht op verwijdering** | U kunt ons vragen uw persoonsgegevens te verwijderen (Recht op Vergetelheid). **(Ondersteund door de `AnonymizationService`)** |
| **Recht op beperking** | U kunt ons vragen de verwerking van uw gegevens te beperken. |
| **Recht op bezwaar** | U kunt bezwaar maken tegen de verwerking van uw gegevens op basis van gerechtvaardigd belang. |
| **Recht op dataportabiliteit** | U kunt vragen om de gegevens die u aan ons heeft verstrekt in een gestructureerde, gangbare en machineleesbare vorm te ontvangen. |

U kunt uw rechten uitoefenen door contact op te nemen via [E-mailadres Functionaris Gegevensbescherming].

## 6. Contact

Voor vragen over deze privacyverklaring of de verwerking van uw persoonsgegevens kunt u contact opnemen met onze Functionaris Gegevensbescherming (FG):

**RentGuy Enterprise B.V.**
[Adres]
[Postcode en Plaats]
E-mail: [E-mailadres FG]
Telefoon: [Telefoonnummer]

---

**[Voetnoot: Dit is een template en moet worden aangevuld met specifieke bedrijfsgegevens en juridisch worden beoordeeld.]**
