#!/bin/bash

# RentGuy Enterprise Deployment Script
# Automated deployment for VPS infrastructure

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
DEPLOYMENT_ENV="${DEPLOYMENT_ENV:-production}"
BACKUP_BEFORE_DEPLOY="${BACKUP_BEFORE_DEPLOY:-true}"
RUN_MIGRATIONS="${RUN_MIGRATIONS:-true}"
HEALTH_CHECK_TIMEOUT="${HEALTH_CHECK_TIMEOUT:-300}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Error handling
error_exit() {
    log_error "$1"
    exit 1
}

# Cleanup function
cleanup() {
    log_info "Performing cleanup..."
    # Add cleanup tasks here
}

# Set up trap for cleanup
trap cleanup EXIT

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if running as root or with sudo
    if [[ $EUID -eq 0 ]]; then
        log_warning "Running as root. Consider using a dedicated user."
    fi
    
    # Check required commands
    local required_commands=("docker" "docker-compose" "curl" "jq")
    for cmd in "${required_commands[@]}"; do
        if ! command -v "$cmd" &> /dev/null; then
            error_exit "Required command '$cmd' not found. Please install it first."
        fi
    done
    
    # Check Docker daemon
    if ! docker info &> /dev/null; then
        error_exit "Docker daemon is not running or not accessible."
    fi
    
    # Check environment file
    if [[ ! -f "$PROJECT_ROOT/.env.production" ]]; then
        error_exit "Production environment file not found: $PROJECT_ROOT/.env.production"
    fi
    
    log_success "Prerequisites check passed"
}

# Create necessary directories
create_directories() {
    log_info "Creating necessary directories..."
    
    local directories=(
        "/opt/rentguy/secrets"
        "/opt/rentguy/config"
        "/opt/rentguy/data/postgres"
        "/opt/rentguy/data/redis"
        "/opt/rentguy/data/prometheus"
        "/opt/rentguy/data/grafana"
        "/opt/rentguy/data/elasticsearch"
        "/opt/rentguy/uploads"
        "/opt/rentguy/backups/postgres"
        "/opt/rentguy/backups/application"
        "/opt/rentguy/ssl"
        "/var/log/rentguy"
        "/var/log/nginx"
    )
    
    for dir in "${directories[@]}"; do
        if [[ ! -d "$dir" ]]; then
            sudo mkdir -p "$dir"
            log_info "Created directory: $dir"
        fi
    done
    
    # Set appropriate permissions
    sudo chmod 700 /opt/rentguy/secrets
    sudo chmod 755 /opt/rentguy/{config,data,uploads,backups}
    sudo chmod 755 /var/log/{rentguy,nginx}
    
    log_success "Directories created and permissions set"
}

# Setup secrets
setup_secrets() {
    log_info "Setting up secrets..."
    
    local secrets_dir="/opt/rentguy/secrets"
    
    # Generate secrets if they don't exist
    if [[ ! -f "$secrets_dir/app_secret_key.secret" ]]; then
        openssl rand -base64 32 | sudo tee "$secrets_dir/app_secret_key.secret" > /dev/null
        sudo chmod 600 "$secrets_dir/app_secret_key.secret"
        log_info "Generated application secret key"
    fi
    
    if [[ ! -f "$secrets_dir/postgres_password.secret" ]]; then
        openssl rand -base64 24 | sudo tee "$secrets_dir/postgres_password.secret" > /dev/null
        sudo chmod 600 "$secrets_dir/postgres_password.secret"
        log_info "Generated PostgreSQL password"
    fi
    
    if [[ ! -f "$secrets_dir/redis_password.secret" ]]; then
        openssl rand -base64 24 | sudo tee "$secrets_dir/redis_password.secret" > /dev/null
        sudo chmod 600 "$secrets_dir/redis_password.secret"
        log_info "Generated Redis password"
    fi
    
    if [[ ! -f "$secrets_dir/grafana_password.secret" ]]; then
        openssl rand -base64 16 | sudo tee "$secrets_dir/grafana_password.secret" > /dev/null
        sudo chmod 600 "$secrets_dir/grafana_password.secret"
        log_info "Generated Grafana password"
    fi
    
    log_success "Secrets setup completed"
}

# Create backup
create_backup() {
    if [[ "$BACKUP_BEFORE_DEPLOY" != "true" ]]; then
        log_info "Skipping backup (BACKUP_BEFORE_DEPLOY=false)"
        return
    fi
    
    log_info "Creating backup before deployment..."
    
    local backup_dir="/opt/rentguy/backups/application"
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local backup_file="$backup_dir/pre_deploy_backup_$timestamp.tar.gz"
    
    # Create application backup
    sudo tar -czf "$backup_file" \
        -C /opt/rentguy \
        --exclude='data' \
        --exclude='backups' \
        . || log_warning "Application backup failed"
    
    # Create database backup if PostgreSQL is running
    if docker ps | grep -q rentguy-postgres; then
        local db_backup_file="$backup_dir/database_backup_$timestamp.sql"
        docker exec rentguy-postgres pg_dump -U rentguy rentguy > "$db_backup_file" || log_warning "Database backup failed"
    fi
    
    log_success "Backup created: $backup_file"
}

# Build and deploy containers
deploy_containers() {
    log_info "Building and deploying containers..."
    
    cd "$PROJECT_ROOT"
    
    # Load environment variables
    export $(grep -v '^#' .env.production | xargs)
    
    # Load secrets into environment
    if [[ -f "/opt/rentguy/secrets/postgres_password.secret" ]]; then
        export POSTGRES_PASSWORD=$(sudo cat /opt/rentguy/secrets/postgres_password.secret)
    fi
    
    if [[ -f "/opt/rentguy/secrets/redis_password.secret" ]]; then
        export REDIS_PASSWORD=$(sudo cat /opt/rentguy/secrets/redis_password.secret)
    fi
    
    if [[ -f "/opt/rentguy/secrets/app_secret_key.secret" ]]; then
        export SECRET_KEY=$(sudo cat /opt/rentguy/secrets/app_secret_key.secret)
    fi
    
    if [[ -f "/opt/rentguy/secrets/grafana_password.secret" ]]; then
        export GRAFANA_PASSWORD=$(sudo cat /opt/rentguy/secrets/grafana_password.secret)
    fi
    
    # Pull latest images
    docker-compose -f infrastructure/docker-compose.production.yml pull
    
    # Build custom images
    docker-compose -f infrastructure/docker-compose.production.yml build --no-cache
    
    # Deploy with rolling update
    docker-compose -f infrastructure/docker-compose.production.yml up -d --remove-orphans
    
    log_success "Containers deployed"
}

# Run database migrations
run_migrations() {
    if [[ "$RUN_MIGRATIONS" != "true" ]]; then
        log_info "Skipping migrations (RUN_MIGRATIONS=false)"
        return
    fi
    
    log_info "Running database migrations..."
    
    # Wait for database to be ready
    local max_attempts=30
    local attempt=1
    
    while [[ $attempt -le $max_attempts ]]; do
        if docker exec rentguy-postgres pg_isready -U rentguy -d rentguy &> /dev/null; then
            break
        fi
        
        log_info "Waiting for database... (attempt $attempt/$max_attempts)"
        sleep 5
        ((attempt++))
    done
    
    if [[ $attempt -gt $max_attempts ]]; then
        error_exit "Database failed to become ready within timeout"
    fi
    
    # Run migrations
    docker exec rentguy-api alembic upgrade head || error_exit "Database migrations failed"
    
    log_success "Database migrations completed"
}

# Health checks
perform_health_checks() {
    log_info "Performing health checks..."
    
    local services=("rentguy-api" "rentguy-postgres" "rentguy-redis" "rentguy-nginx")
    local timeout=$HEALTH_CHECK_TIMEOUT
    local start_time=$(date +%s)
    
    for service in "${services[@]}"; do
        log_info "Checking health of $service..."
        
        local healthy=false
        while [[ $(($(date +%s) - start_time)) -lt $timeout ]]; do
            if docker ps --filter "name=$service" --filter "status=running" | grep -q "$service"; then
                # Additional health check for API service
                if [[ "$service" == "rentguy-api" ]]; then
                    if curl -f -s http://localhost:8000/health > /dev/null; then
                        healthy=true
                        break
                    fi
                else
                    healthy=true
                    break
                fi
            fi
            
            sleep 5
        done
        
        if [[ "$healthy" == "true" ]]; then
            log_success "$service is healthy"
        else
            error_exit "$service failed health check"
        fi
    done
    
    log_success "All health checks passed"
}

# Setup monitoring
setup_monitoring() {
    log_info "Setting up monitoring..."
    
    # Wait for Prometheus to be ready
    local max_attempts=20
    local attempt=1
    
    while [[ $attempt -le $max_attempts ]]; do
        if curl -f -s http://localhost:9090/-/ready > /dev/null; then
            break
        fi
        
        log_info "Waiting for Prometheus... (attempt $attempt/$max_attempts)"
        sleep 5
        ((attempt++))
    done
    
    # Import Grafana dashboards
    if curl -f -s http://localhost:3000/api/health > /dev/null; then
        log_info "Grafana is ready, importing dashboards..."
        # Dashboard import logic would go here
    fi
    
    log_success "Monitoring setup completed"
}

# Setup SSL certificates
setup_ssl() {
    log_info "Setting up SSL certificates..."
    
    local ssl_dir="/opt/rentguy/ssl"
    local domain="${DOMAIN:-localhost}"
    
    if [[ ! -f "$ssl_dir/cert.pem" ]] || [[ ! -f "$ssl_dir/key.pem" ]]; then
        log_info "Generating self-signed SSL certificate for $domain"
        
        sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
            -keyout "$ssl_dir/key.pem" \
            -out "$ssl_dir/cert.pem" \
            -subj "/C=US/ST=State/L=City/O=Organization/CN=$domain"
        
        sudo chmod 600 "$ssl_dir/key.pem"
        sudo chmod 644 "$ssl_dir/cert.pem"
        
        log_warning "Using self-signed certificate. Consider using Let's Encrypt for production."
    fi
    
    log_success "SSL certificates configured"
}

# Cleanup old resources
cleanup_old_resources() {
    log_info "Cleaning up old resources..."
    
    # Remove unused Docker images
    docker image prune -f
    
    # Remove old backups (keep last 30 days)
    find /opt/rentguy/backups -name "*.tar.gz" -mtime +30 -delete 2>/dev/null || true
    find /opt/rentguy/backups -name "*.sql" -mtime +30 -delete 2>/dev/null || true
    
    # Clean up old logs
    find /var/log/rentguy -name "*.log.*" -mtime +7 -delete 2>/dev/null || true
    
    log_success "Cleanup completed"
}

# Display deployment summary
display_summary() {
    log_success "Deployment completed successfully!"
    echo
    echo "=== Deployment Summary ==="
    echo "Environment: $DEPLOYMENT_ENV"
    echo "Timestamp: $(date)"
    echo
    echo "=== Service URLs ==="
    echo "Application: https://localhost (or your domain)"
    echo "API Health: http://localhost:8000/health"
    echo "Grafana: http://localhost:3000"
    echo "Prometheus: http://localhost:9090"
    echo "Kibana: http://localhost:5601"
    echo
    echo "=== Next Steps ==="
    echo "1. Configure your domain and SSL certificates"
    echo "2. Set up monitoring alerts"
    echo "3. Configure backup schedules"
    echo "4. Review security settings"
    echo
    echo "=== Useful Commands ==="
    echo "View logs: docker-compose -f infrastructure/docker-compose.production.yml logs -f"
    echo "Restart services: docker-compose -f infrastructure/docker-compose.production.yml restart"
    echo "Scale API: docker-compose -f infrastructure/docker-compose.production.yml up -d --scale rentguy-api=3"
}

# Main deployment function
main() {
    log_info "Starting RentGuy Enterprise deployment..."
    log_info "Environment: $DEPLOYMENT_ENV"
    
    check_prerequisites
    create_directories
    setup_secrets
    setup_ssl
    create_backup
    deploy_containers
    run_migrations
    perform_health_checks
    setup_monitoring
    cleanup_old_resources
    display_summary
    
    log_success "Deployment completed successfully!"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --env)
            DEPLOYMENT_ENV="$2"
            shift 2
            ;;
        --no-backup)
            BACKUP_BEFORE_DEPLOY="false"
            shift
            ;;
        --no-migrations)
            RUN_MIGRATIONS="false"
            shift
            ;;
        --timeout)
            HEALTH_CHECK_TIMEOUT="$2"
            shift 2
            ;;
        --help)
            echo "Usage: $0 [OPTIONS]"
            echo "Options:"
            echo "  --env ENV              Deployment environment (default: production)"
            echo "  --no-backup           Skip backup before deployment"
            echo "  --no-migrations       Skip database migrations"
            echo "  --timeout SECONDS     Health check timeout (default: 300)"
            echo "  --help                Show this help message"
            exit 0
            ;;
        *)
            error_exit "Unknown option: $1"
            ;;
    esac
done

# Run main function
main "$@"
