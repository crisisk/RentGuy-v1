/**
 * Invoice Download Manager Component
 * Provides comprehensive invoice download functionality with bulk operations
 */

import React, { useState, useEffect } from 'react';
import { 
  Download, 
  FileText, 
  Archive, 
  Calendar, 
  Filter,
  CheckCircle,
  AlertCircle,
  Clock,
  Euro,
  Users,
  Search,
  X
} from 'lucide-react';

interface Invoice {
  id: string;
  invoice_number: string;
  invoice_date: string;
  due_date: string;
  total_amount: number;
  payment_status: 'pending' | 'paid' | 'partial' | 'overdue' | 'refunded';
  customer_name: string;
  is_overdue: boolean;
}

interface DownloadSummary {
  count: number;
  total_amount: number;
  date_range: {
    start: string;
    end: string;
  };
  customers: string[];
  payment_status_breakdown: Record<string, number>;
  invoice_numbers: string[];
}

interface FilterOptions {
  start_date?: string;
  end_date?: string;
  payment_status?: string[];
  search_query?: string;
}

const InvoiceDownloadManager: React.FC = () => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [selectedInvoices, setSelectedInvoices] = useState<Set<string>>(new Set());
  const [downloadSummary, setDownloadSummary] = useState<DownloadSummary | null>(null);
  const [filters, setFilters] = useState<FilterOptions>({});
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(false);
  const [downloadFormat, setDownloadFormat] = useState<'pdf' | 'zip'>('zip');

  // Payment status options with colors
  const paymentStatusOptions = [
    { value: 'pending', label: 'In behandeling', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'paid', label: 'Betaald', color: 'bg-green-100 text-green-800' },
    { value: 'partial', label: 'Gedeeltelijk betaald', color: 'bg-blue-100 text-blue-800' },
    { value: 'overdue', label: 'Vervallen', color: 'bg-red-100 text-red-800' },
    { value: 'refunded', label: 'Terugbetaald', color: 'bg-gray-100 text-gray-800' }
  ];

  // Load invoices based on filters
  const loadInvoices = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/v1/invoices/search-for-download', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(filters)
      });

      if (response.ok) {
        const data = await response.json();
        setInvoices(data.invoices || []);
      }
    } catch (error) {
      console.error('Failed to load invoices:', error);
    } finally {
      setLoading(false);
    }
  };

  // Load download summary when selection changes
  const loadDownloadSummary = async () => {
    if (selectedInvoices.size === 0) {
      setDownloadSummary(null);
      return;
    }

    try {
      const response = await fetch('/api/v1/invoices/download-summary', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          invoice_ids: Array.from(selectedInvoices),
          format: downloadFormat
        })
      });

      if (response.ok) {
        const summary = await response.json();
        setDownloadSummary(summary);
      }
    } catch (error) {
      console.error('Failed to load download summary:', error);
    }
  };

  // Handle bulk download
  const handleBulkDownload = async () => {
    if (selectedInvoices.size === 0) return;

    setLoading(true);
    try {
      const response = await fetch('/api/v1/invoices/bulk-download', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({
          invoice_ids: Array.from(selectedInvoices),
          format: downloadFormat
        })
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        
        // Get filename from response headers
        const contentDisposition = response.headers.get('Content-Disposition');
        const filename = contentDisposition?.match(/filename="(.+)"/)?.[1] || 
                        `facturen_${new Date().toISOString().split('T')[0]}.${downloadFormat}`;
        
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Download failed:', error);
    } finally {
      setLoading(false);
    }
  };

  // Handle single invoice download
  const handleSingleDownload = async (invoiceId: string) => {
    try {
      const response = await fetch(`/api/v1/invoices/${invoiceId}/pdf`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        
        const contentDisposition = response.headers.get('Content-Disposition');
        const filename = contentDisposition?.match(/filename="(.+)"/)?.[1] || 
                        `factuur_${invoiceId}.pdf`;
        
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Download failed:', error);
    }
  };

  // Toggle invoice selection
  const toggleInvoiceSelection = (invoiceId: string) => {
    const newSelection = new Set(selectedInvoices);
    if (newSelection.has(invoiceId)) {
      newSelection.delete(invoiceId);
    } else {
      newSelection.add(invoiceId);
    }
    setSelectedInvoices(newSelection);
  };

  // Select all invoices
  const selectAllInvoices = () => {
    if (selectedInvoices.size === invoices.length) {
      setSelectedInvoices(new Set());
    } else {
      setSelectedInvoices(new Set(invoices.map(inv => inv.id)));
    }
  };

  // Get payment status display
  const getPaymentStatusDisplay = (status: string) => {
    const option = paymentStatusOptions.find(opt => opt.value === status);
    return option || { label: status, color: 'bg-gray-100 text-gray-800' };
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('nl-NL', {
      style: 'currency',
      currency: 'EUR'
    }).format(amount);
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('nl-NL');
  };

  // Load invoices on component mount and filter changes
  useEffect(() => {
    loadInvoices();
  }, [filters]);

  // Load summary when selection changes
  useEffect(() => {
    loadDownloadSummary();
  }, [selectedInvoices, downloadFormat]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Factuur Downloads</h2>
          <p className="text-gray-600">Beheer en download uw facturen individueel of in bulk</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </button>
          
          {selectedInvoices.size > 0 && (
            <button
              onClick={handleBulkDownload}
              disabled={loading}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
            >
              {downloadFormat === 'zip' ? (
                <Archive className="w-4 h-4 mr-2" />
              ) : (
                <FileText className="w-4 h-4 mr-2" />
              )}
              Download ({selectedInvoices.size})
            </button>
          )}
        </div>
      </div>

      {/* Filters Panel */}
      {showFilters && (
        <div className="bg-gray-50 p-4 rounded-lg border">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Van datum
              </label>
              <input
                type="date"
                value={filters.start_date || ''}
                onChange={(e) => setFilters({...filters, start_date: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Tot datum
              </label>
              <input
                type="date"
                value={filters.end_date || ''}
                onChange={(e) => setFilters({...filters, end_date: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Status
              </label>
              <select
                multiple
                value={filters.payment_status || []}
                onChange={(e) => setFilters({
                  ...filters, 
                  payment_status: Array.from(e.target.selectedOptions, option => option.value)
                })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
              >
                {paymentStatusOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Zoeken
              </label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Factuurnummer, klant..."
                  value={filters.search_query || ''}
                  onChange={(e) => setFilters({...filters, search_query: e.target.value})}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                />
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-4">
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium text-gray-700">Download formaat:</span>
              <div className="flex items-center space-x-2">
                <label className="flex items-center">
                  <input
                    type="radio"
                    value="pdf"
                    checked={downloadFormat === 'pdf'}
                    onChange={(e) => setDownloadFormat(e.target.value as 'pdf' | 'zip')}
                    className="mr-2"
                  />
                  <FileText className="w-4 h-4 mr-1" />
                  PDF
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    value="zip"
                    checked={downloadFormat === 'zip'}
                    onChange={(e) => setDownloadFormat(e.target.value as 'pdf' | 'zip')}
                    className="mr-2"
                  />
                  <Archive className="w-4 h-4 mr-1" />
                  ZIP
                </label>
              </div>
            </div>
            
            <button
              onClick={() => setFilters({})}
              className="flex items-center px-3 py-1 text-sm text-gray-600 hover:text-gray-800"
            >
              <X className="w-4 h-4 mr-1" />
              Wis filters
            </button>
          </div>
        </div>
      )}

      {/* Download Summary */}
      {downloadSummary && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="font-medium text-blue-900 mb-2">Download Overzicht</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center">
              <FileText className="w-4 h-4 mr-2 text-blue-600" />
              <span>{downloadSummary.count} facturen</span>
            </div>
            <div className="flex items-center">
              <Euro className="w-4 h-4 mr-2 text-blue-600" />
              <span>{formatCurrency(downloadSummary.total_amount)}</span>
            </div>
            <div className="flex items-center">
              <Calendar className="w-4 h-4 mr-2 text-blue-600" />
              <span>
                {formatDate(downloadSummary.date_range.start)} - {formatDate(downloadSummary.date_range.end)}
              </span>
            </div>
            <div className="flex items-center">
              <Users className="w-4 h-4 mr-2 text-blue-600" />
              <span>{downloadSummary.customers.length} klanten</span>
            </div>
          </div>
        </div>
      )}

      {/* Invoice List */}
      <div className="bg-white rounded-lg border">
        <div className="px-6 py-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <input
                type="checkbox"
                checked={invoices.length > 0 && selectedInvoices.size === invoices.length}
                onChange={selectAllInvoices}
                className="mr-3 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <span className="text-sm font-medium text-gray-700">
                {selectedInvoices.size > 0 
                  ? `${selectedInvoices.size} van ${invoices.length} geselecteerd`
                  : `${invoices.length} facturen`
                }
              </span>
            </div>
            
            {loading && (
              <div className="flex items-center text-sm text-gray-500">
                <Clock className="w-4 h-4 mr-2 animate-spin" />
                Laden...
              </div>
            )}
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {invoices.map((invoice) => {
            const statusDisplay = getPaymentStatusDisplay(invoice.payment_status);
            
            return (
              <div key={invoice.id} className="px-6 py-4 hover:bg-gray-50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <input
                      type="checkbox"
                      checked={selectedInvoices.has(invoice.id)}
                      onChange={() => toggleInvoiceSelection(invoice.id)}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <span className="font-medium text-gray-900">
                          {invoice.invoice_number}
                        </span>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusDisplay.color}`}>
                          {statusDisplay.label}
                        </span>
                        {invoice.is_overdue && (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Vervallen
                          </span>
                        )}
                      </div>
                      
                      <div className="mt-1 text-sm text-gray-500">
                        <span>{invoice.customer_name}</span>
                        <span className="mx-2">•</span>
                        <span>{formatDate(invoice.invoice_date)}</span>
                        <span className="mx-2">•</span>
                        <span className="font-medium">{formatCurrency(invoice.total_amount)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => handleSingleDownload(invoice.id)}
                    className="flex items-center px-3 py-1 text-sm text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded"
                  >
                    <Download className="w-4 h-4 mr-1" />
                    PDF
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {invoices.length === 0 && !loading && (
          <div className="px-6 py-12 text-center">
            <FileText className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Geen facturen gevonden</h3>
            <p className="text-gray-500">
              Pas uw filters aan om facturen te vinden die u kunt downloaden.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default InvoiceDownloadManager;
