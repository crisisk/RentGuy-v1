/**
 * Enterprise API client for RentGuy frontend.
 * Provides comprehensive API communication with authentication, caching, and error handling.
 */

import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios';
import { toast } from 'react-hot-toast';

// Types
export interface ApiResponse<T = any> {
  data: T;
  message?: string;
  success: boolean;
  errors?: string[];
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    totalPages?: number;
  };
}

export interface ApiError {
  message: string;
  status: number;
  code?: string;
  details?: any;
}

export interface PaginationParams {
  page?: number;
  limit?: number;
  sort?: string;
  order?: 'asc' | 'desc';
  search?: string;
  filters?: Record<string, any>;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  fullName: string;
  roles: string[];
  permissions: string[];
  status: string;
  isEmailVerified: boolean;
  lastLoginAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Equipment {
  id: string;
  name: string;
  description?: string;
  model?: string;
  brand?: string;
  serialNumber?: string;
  status: 'available' | 'rented' | 'maintenance' | 'retired';
  condition: string;
  dailyRate: number;
  weeklyRate?: number;
  monthlyRate?: number;
  depositAmount: number;
  categories: Category[];
  images?: string[];
  specifications?: Record<string, any>;
  location?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  parentId?: string;
  icon?: string;
  color?: string;
  children?: Category[];
}

export interface Rental {
  id: string;
  userId: string;
  equipmentId: string;
  user: User;
  equipment: Equipment;
  startDate: string;
  endDate: string;
  actualReturnDate?: string;
  status: 'pending' | 'approved' | 'active' | 'completed' | 'cancelled' | 'overdue';
  totalAmount: number;
  depositAmount: number;
  dailyRate: number;
  deliveryRequired: boolean;
  deliveryAddress?: string;
  deliveryFee: number;
  notes?: string;
  approvedBy?: string;
  approvedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface LoginRequest {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface LoginResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface RegisterRequest {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone?: string;
  companyName?: string;
}

// API Configuration
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api';
const API_VERSION = import.meta.env.VITE_API_VERSION || 'v1';
const API_TIMEOUT = 30000; // 30 seconds

class ApiClient {
  private client: AxiosInstance;
  private accessToken: string | null = null;
  private refreshToken: string | null = null;
  private isRefreshing = false;
  private failedQueue: Array<{
    resolve: (value?: any) => void;
    reject: (error?: any) => void;
  }> = [];

  constructor() {
    this.client = axios.create({
      baseURL: `${API_BASE_URL}/${API_VERSION}`,
      timeout: API_TIMEOUT,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    });

    this.setupInterceptors();
    this.loadTokensFromStorage();
  }

  private setupInterceptors() {
    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        // Add authentication token
        if (this.accessToken) {
          config.headers.Authorization = `Bearer ${this.accessToken}`;
        }

        // Add API version header
        config.headers['Accept-Version'] = `application/vnd.rentguy.${API_VERSION}+json`;

        // Add request ID for tracking
        config.headers['X-Request-ID'] = this.generateRequestId();

        // Add timestamp
        config.headers['X-Request-Time'] = new Date().toISOString();

        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response) => {
        // Log successful requests in development
        if (import.meta.env.DEV) {
          console.log(`✅ ${response.config.method?.toUpperCase()} ${response.config.url}`, {
            status: response.status,
            data: response.data,
          });
        }

        return response;
      },
      async (error: AxiosError) => {
        const originalRequest = error.config as AxiosRequestConfig & { _retry?: boolean };

        // Handle token refresh
        if (error.response?.status === 401 && !originalRequest._retry) {
          if (this.isRefreshing) {
            // Queue the request
            return new Promise((resolve, reject) => {
              this.failedQueue.push({ resolve, reject });
            }).then((token) => {
              if (originalRequest.headers) {
                originalRequest.headers.Authorization = `Bearer ${token}`;
              }
              return this.client(originalRequest);
            });
          }

          originalRequest._retry = true;
          this.isRefreshing = true;

          try {
            const newToken = await this.refreshAccessToken();
            this.processQueue(null, newToken);
            
            if (originalRequest.headers) {
              originalRequest.headers.Authorization = `Bearer ${newToken}`;
            }
            
            return this.client(originalRequest);
          } catch (refreshError) {
            this.processQueue(refreshError, null);
            this.logout();
            return Promise.reject(refreshError);
          } finally {
            this.isRefreshing = false;
          }
        }

        // Handle other errors
        this.handleApiError(error);
        return Promise.reject(error);
      }
    );
  }

  private processQueue(error: any, token: string | null) {
    this.failedQueue.forEach(({ resolve, reject }) => {
      if (error) {
        reject(error);
      } else {
        resolve(token);
      }
    });

    this.failedQueue = [];
  }

  private generateRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private handleApiError(error: AxiosError) {
    const apiError: ApiError = {
      message: 'An unexpected error occurred',
      status: error.response?.status || 0,
    };

    if (error.response?.data) {
      const errorData = error.response.data as any;
      apiError.message = errorData.message || errorData.detail || apiError.message;
      apiError.code = errorData.code;
      apiError.details = errorData.details;
    } else if (error.request) {
      apiError.message = 'Network error - please check your connection';
    }

    // Show toast notification for user-facing errors
    if (error.response?.status !== 401) {
      toast.error(apiError.message);
    }

    // Log error in development
    if (import.meta.env.DEV) {
      console.error(`❌ API Error:`, {
        url: error.config?.url,
        method: error.config?.method,
        status: error.response?.status,
        message: apiError.message,
        details: apiError.details,
      });
    }
  }

  private loadTokensFromStorage() {
    this.accessToken = localStorage.getItem('accessToken');
    this.refreshToken = localStorage.getItem('refreshToken');
  }

  private saveTokensToStorage(accessToken: string, refreshToken: string) {
    this.accessToken = accessToken;
    this.refreshToken = refreshToken;
    localStorage.setItem('accessToken', accessToken);
    localStorage.setItem('refreshToken', refreshToken);
  }

  private clearTokensFromStorage() {
    this.accessToken = null;
    this.refreshToken = null;
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
  }

  private async refreshAccessToken(): Promise<string> {
    if (!this.refreshToken) {
      throw new Error('No refresh token available');
    }

    const response = await axios.post(`${API_BASE_URL}/${API_VERSION}/auth/refresh`, {
      refreshToken: this.refreshToken,
    });

    const { accessToken, refreshToken } = response.data.data;
    this.saveTokensToStorage(accessToken, refreshToken);
    
    return accessToken;
  }

  // Authentication methods
  async login(credentials: LoginRequest): Promise<LoginResponse> {
    const response = await this.client.post<ApiResponse<LoginResponse>>('/auth/login', credentials);
    const { user, accessToken, refreshToken } = response.data.data;
    
    this.saveTokensToStorage(accessToken, refreshToken);
    
    return response.data.data;
  }

  async register(userData: RegisterRequest): Promise<User> {
    const response = await this.client.post<ApiResponse<User>>('/auth/register', userData);
    return response.data.data;
  }

  async logout(): Promise<void> {
    try {
      await this.client.post('/auth/logout');
    } catch (error) {
      // Ignore logout errors
    } finally {
      this.clearTokensFromStorage();
    }
  }

  async getCurrentUser(): Promise<User> {
    const response = await this.client.get<ApiResponse<User>>('/auth/me');
    return response.data.data;
  }

  async changePassword(currentPassword: string, newPassword: string): Promise<void> {
    await this.client.post('/auth/change-password', {
      currentPassword,
      newPassword,
    });
  }

  async requestPasswordReset(email: string): Promise<void> {
    await this.client.post('/auth/forgot-password', { email });
  }

  async resetPassword(token: string, newPassword: string): Promise<void> {
    await this.client.post('/auth/reset-password', {
      token,
      newPassword,
    });
  }

  // User management methods
  async getUsers(params?: PaginationParams): Promise<ApiResponse<User[]>> {
    const response = await this.client.get<ApiResponse<User[]>>('/users', { params });
    return response.data;
  }

  async getUser(id: string): Promise<User> {
    const response = await this.client.get<ApiResponse<User>>(`/users/${id}`);
    return response.data.data;
  }

  async updateUser(id: string, userData: Partial<User>): Promise<User> {
    const response = await this.client.put<ApiResponse<User>>(`/users/${id}`, userData);
    return response.data.data;
  }

  async deleteUser(id: string): Promise<void> {
    await this.client.delete(`/users/${id}`);
  }

  // Equipment management methods
  async getEquipment(params?: PaginationParams): Promise<ApiResponse<Equipment[]>> {
    const response = await this.client.get<ApiResponse<Equipment[]>>('/equipment', { params });
    return response.data;
  }

  async getEquipmentItem(id: string): Promise<Equipment> {
    const response = await this.client.get<ApiResponse<Equipment>>(`/equipment/${id}`);
    return response.data.data;
  }

  async createEquipment(equipmentData: Partial<Equipment>): Promise<Equipment> {
    const response = await this.client.post<ApiResponse<Equipment>>('/equipment', equipmentData);
    return response.data.data;
  }

  async updateEquipment(id: string, equipmentData: Partial<Equipment>): Promise<Equipment> {
    const response = await this.client.put<ApiResponse<Equipment>>(`/equipment/${id}`, equipmentData);
    return response.data.data;
  }

  async deleteEquipment(id: string): Promise<void> {
    await this.client.delete(`/equipment/${id}`);
  }

  async uploadEquipmentImages(id: string, files: File[]): Promise<string[]> {
    const formData = new FormData();
    files.forEach((file) => {
      formData.append('images', file);
    });

    const response = await this.client.post<ApiResponse<string[]>>(
      `/equipment/${id}/images`,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );

    return response.data.data;
  }

  // Category management methods
  async getCategories(): Promise<Category[]> {
    const response = await this.client.get<ApiResponse<Category[]>>('/categories');
    return response.data.data;
  }

  async createCategory(categoryData: Partial<Category>): Promise<Category> {
    const response = await this.client.post<ApiResponse<Category>>('/categories', categoryData);
    return response.data.data;
  }

  async updateCategory(id: string, categoryData: Partial<Category>): Promise<Category> {
    const response = await this.client.put<ApiResponse<Category>>(`/categories/${id}`, categoryData);
    return response.data.data;
  }

  async deleteCategory(id: string): Promise<void> {
    await this.client.delete(`/categories/${id}`);
  }

  // Rental management methods
  async getRentals(params?: PaginationParams): Promise<ApiResponse<Rental[]>> {
    const response = await this.client.get<ApiResponse<Rental[]>>('/rentals', { params });
    return response.data;
  }

  async getRental(id: string): Promise<Rental> {
    const response = await this.client.get<ApiResponse<Rental>>(`/rentals/${id}`);
    return response.data.data;
  }

  async createRental(rentalData: Partial<Rental>): Promise<Rental> {
    const response = await this.client.post<ApiResponse<Rental>>('/rentals', rentalData);
    return response.data.data;
  }

  async updateRental(id: string, rentalData: Partial<Rental>): Promise<Rental> {
    const response = await this.client.put<ApiResponse<Rental>>(`/rentals/${id}`, rentalData);
    return response.data.data;
  }

  async approveRental(id: string): Promise<Rental> {
    const response = await this.client.post<ApiResponse<Rental>>(`/rentals/${id}/approve`);
    return response.data.data;
  }

  async cancelRental(id: string, reason?: string): Promise<Rental> {
    const response = await this.client.post<ApiResponse<Rental>>(`/rentals/${id}/cancel`, { reason });
    return response.data.data;
  }

  async completeRental(id: string, returnCondition?: string): Promise<Rental> {
    const response = await this.client.post<ApiResponse<Rental>>(`/rentals/${id}/complete`, {
      returnCondition,
    });
    return response.data.data;
  }

  // Dashboard and analytics methods
  async getDashboardStats(): Promise<any> {
    const response = await this.client.get<ApiResponse<any>>('/dashboard/stats');
    return response.data.data;
  }

  async getRevenueChart(period: string = '30d'): Promise<any> {
    const response = await this.client.get<ApiResponse<any>>(`/dashboard/revenue?period=${period}`);
    return response.data.data;
  }

  async getEquipmentUtilization(): Promise<any> {
    const response = await this.client.get<ApiResponse<any>>('/dashboard/utilization');
    return response.data.data;
  }

  // File upload methods
  async uploadFile(file: File, type: string = 'general'): Promise<string> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', type);

    const response = await this.client.post<ApiResponse<{ url: string }>>(
      '/files/upload',
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );

    return response.data.data.url;
  }

  // Health check
  async healthCheck(): Promise<any> {
    const response = await this.client.get('/health');
    return response.data;
  }

  // Utility methods
  isAuthenticated(): boolean {
    return !!this.accessToken;
  }

  getAccessToken(): string | null {
    return this.accessToken;
  }

  // Generic request method for custom endpoints
  async request<T = any>(config: AxiosRequestConfig): Promise<T> {
    const response = await this.client.request<T>(config);
    return response.data;
  }
}

// Create and export singleton instance
export const apiClient = new ApiClient();

// Export default
export default apiClient;
