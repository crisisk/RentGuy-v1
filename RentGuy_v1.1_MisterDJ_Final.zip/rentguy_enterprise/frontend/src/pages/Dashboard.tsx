import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '../../../design-system/components/Card';
import { Button } from '../../../design-system/components/Button';
import { Badge } from '../../../design-system/components/Badge';
import { Icon } from '../../../design-system/components/Icon';
import { cn } from '../../../design-system/utils/cn';

// Mock data - in real app this would come from API
const mockDashboardData = {
  revenue: {
    current: 24580,
    previous: 22340,
    trend: 'up',
    percentage: 10.0
  },
  equipment: {
    total: 45,
    available: 24,
    rented: 18,
    maintenance: 3,
    damaged: 0
  },
  rentals: {
    active: 18,
    pending: 5,
    completed: 142,
    overdue: 2
  },
  customers: {
    total: 89,
    active: 34,
    new: 7
  },
  aiInsights: [
    {
      id: 1,
      type: 'revenue',
      title: 'Verhoog camera prijzen met 8%',
      description: 'Gebaseerd op vraag analyse kan een prijsverhoging van 8% voor camera\'s de maandelijkse omzet met €2,100 verhogen.',
      confidence: 92,
      impact: 'high',
      category: 'pricing'
    },
    {
      id: 2,
      type: 'maintenance',
      title: 'Preventief onderhoud aanbevolen',
      description: 'Projector PJ-003 toont tekenen van slijtage. Plan onderhoud binnen 2 weken om uitval te voorkomen.',
      confidence: 87,
      impact: 'medium',
      category: 'maintenance'
    },
    {
      id: 3,
      type: 'customer',
      title: 'VIP klant retentie kans',
      description: 'Demo Klant B.V. heeft 3 maanden geen verhuur gedaan. Persoonlijk contact kan €5,000 omzet behouden.',
      confidence: 78,
      impact: 'high',
      category: 'retention'
    }
  ],
  recentActivity: [
    {
      id: 1,
      type: 'rental_created',
      title: 'Nieuwe verhuur aangemaakt',
      description: 'Camera Set voor Eventbureau XYZ - 3 dagen',
      timestamp: '2 minuten geleden',
      user: 'Sarah van der Berg',
      amount: 450
    },
    {
      id: 2,
      type: 'equipment_returned',
      title: 'Apparatuur geretourneerd',
      description: 'Geluidssysteem GS-012 terug van verhuur',
      timestamp: '15 minuten geleden',
      user: 'Mark Janssen',
      status: 'good'
    },
    {
      id: 3,
      type: 'maintenance_completed',
      title: 'Onderhoud voltooid',
      description: 'Projector PJ-001 gereed voor verhuur',
      timestamp: '1 uur geleden',
      user: 'Technische Dienst',
      status: 'completed'
    }
  ]
};

export const Dashboard: React.FC = () => {
  const [timeRange, setTimeRange] = useState<'today' | 'week' | 'month' | 'quarter'>('month');
  const [data, setData] = useState(mockDashboardData);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate small data changes
      setData(prev => ({
        ...prev,
        revenue: {
          ...prev.revenue,
          current: prev.revenue.current + Math.floor(Math.random() * 100)
        }
      }));
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'text-green-600';
      case 'rented': return 'text-sevensa-teal';
      case 'maintenance': return 'text-yellow-600';
      case 'damaged': return 'text-red-600';
      default: return 'text-secondary-600';
    }
  };

  const getImpactBadge = (impact: string) => {
    switch (impact) {
      case 'high': return 'danger';
      case 'medium': return 'warning';
      case 'low': return 'available';
      default: return 'default';
    }
  };

  return (
    <div className="min-h-screen bg-secondary-50">
      {/* Header */}
      <div className="bg-white border-b border-secondary-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-sevensa-dark">Dashboard</h1>
            <p className="text-secondary-600">Welkom terug! Hier is uw overzicht van vandaag.</p>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Time Range Selector */}
            <div className="flex bg-secondary-100 rounded-lg p-1">
              {(['today', 'week', 'month', 'quarter'] as const).map((range) => (
                <Button
                  key={range}
                  variant={timeRange === range ? 'primary' : 'ghost'}
                  size="sm"
                  onClick={() => setTimeRange(range)}
                  className="text-xs"
                >
                  {range === 'today' ? 'Vandaag' : 
                   range === 'week' ? 'Week' :
                   range === 'month' ? 'Maand' : 'Kwartaal'}
                </Button>
              ))}
            </div>
            
            <Button>
              <Icon name="add" size="sm" className="mr-2" />
              Nieuwe Verhuur
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Revenue Card */}
          <Card className="revenue-widget">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-secondary-600">Omzet Deze Maand</p>
                  <p className="text-2xl font-bold text-sevensa-dark">
                    €{data.revenue.current.toLocaleString()}
                  </p>
                  <div className="flex items-center mt-2">
                    <Icon 
                      name={data.revenue.trend === 'up' ? 'analytics' : 'analytics'} 
                      size="sm" 
                      className={data.revenue.trend === 'up' ? 'text-green-600' : 'text-red-600'} 
                    />
                    <span className={cn(
                      'text-sm font-medium ml-1',
                      data.revenue.trend === 'up' ? 'text-green-600' : 'text-red-600'
                    )}>
                      +{data.revenue.percentage}%
                    </span>
                    <span className="text-sm text-secondary-500 ml-1">vs vorige maand</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-sevensa-teal/10 rounded-lg flex items-center justify-center">
                  <Icon name="revenue" className="text-sevensa-teal" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Equipment Status Card */}
          <Card className="equipment-status">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm font-medium text-secondary-600">Equipment Status</p>
                <div className="w-12 h-12 bg-sevensa-teal/10 rounded-lg flex items-center justify-center">
                  <Icon name="inventory" className="text-sevensa-teal" />
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                    <span className="text-sm text-secondary-700">Beschikbaar</span>
                  </div>
                  <Badge variant="available">{data.equipment.available}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-sevensa-teal rounded-full mr-2"></div>
                    <span className="text-sm text-secondary-700">Verhuurd</span>
                  </div>
                  <Badge variant="rented">{data.equipment.rented}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                    <span className="text-sm text-secondary-700">Onderhoud</span>
                  </div>
                  <Badge variant="maintenance">{data.equipment.maintenance}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Active Rentals Card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-secondary-600">Actieve Verhuur</p>
                  <p className="text-2xl font-bold text-sevensa-dark">{data.rentals.active}</p>
                  <div className="flex items-center mt-2 space-x-4">
                    <div className="flex items-center">
                      <span className="text-xs text-secondary-500">Pending:</span>
                      <Badge variant="secondary" className="ml-1 text-xs">{data.rentals.pending}</Badge>
                    </div>
                    {data.rentals.overdue > 0 && (
                      <div className="flex items-center">
                        <span className="text-xs text-red-500">Overdue:</span>
                        <Badge variant="danger" className="ml-1 text-xs">{data.rentals.overdue}</Badge>
                      </div>
                    )}
                  </div>
                </div>
                <div className="w-12 h-12 bg-sevensa-teal/10 rounded-lg flex items-center justify-center">
                  <Icon name="rentals" className="text-sevensa-teal" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Customers Card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-secondary-600">Klanten</p>
                  <p className="text-2xl font-bold text-sevensa-dark">{data.customers.total}</p>
                  <div className="flex items-center mt-2">
                    <Icon name="add" size="sm" className="text-green-600" />
                    <span className="text-sm font-medium text-green-600 ml-1">
                      +{data.customers.new}
                    </span>
                    <span className="text-sm text-secondary-500 ml-1">deze maand</span>
                  </div>
                </div>
                <div className="w-12 h-12 bg-sevensa-teal/10 rounded-lg flex items-center justify-center">
                  <Icon name="customers" className="text-sevensa-teal" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* AI Insights Panel */}
          <Card className="lg:col-span-2 ai-insights-panel">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Icon name="ai-insight" className="mr-2 text-sevensa-teal" />
                AI Business Intelligence
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {data.aiInsights.map((insight) => (
                <div key={insight.id} className="p-4 bg-sevensa-teal/5 rounded-lg border border-sevensa-teal/10">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Icon name="ai-insight" size="sm" className="text-sevensa-teal" />
                      <h4 className="font-semibold text-sevensa-dark">{insight.title}</h4>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={getImpactBadge(insight.impact)} className="text-xs">
                        {insight.impact === 'high' ? 'Hoge Impact' : 
                         insight.impact === 'medium' ? 'Gemiddelde Impact' : 'Lage Impact'}
                      </Badge>
                      <span className="text-xs text-secondary-500">{insight.confidence}% zeker</span>
                    </div>
                  </div>
                  <p className="text-sm text-secondary-700 mb-3">{insight.description}</p>
                  <div className="flex items-center justify-between">
                    <Badge variant="ai" className="text-xs">
                      <Icon name="brain" size="xs" className="mr-1" />
                      {insight.category}
                    </Badge>
                    <Button size="sm" variant="ghost">
                      <Icon name="view" size="sm" className="mr-1" />
                      Details
                    </Button>
                  </div>
                </div>
              ))}
              
              <div className="text-center pt-4">
                <Button variant="ai">
                  <Icon name="analytics" size="sm" className="mr-2" />
                  Alle AI Inzichten Bekijken
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Icon name="clock" className="mr-2 text-sevensa-teal" />
                Recente Activiteit
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {data.recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3 pb-3 border-b border-secondary-100 last:border-b-0">
                  <div className="w-8 h-8 bg-sevensa-teal/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon 
                      name={activity.type === 'rental_created' ? 'add' :
                            activity.type === 'equipment_returned' ? 'inventory' : 'maintenance'} 
                      size="sm" 
                      className="text-sevensa-teal" 
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-sevensa-dark">{activity.title}</p>
                    <p className="text-xs text-secondary-600">{activity.description}</p>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-xs text-secondary-500">{activity.timestamp}</span>
                      {activity.amount && (
                        <span className="text-xs font-medium text-sevensa-teal">€{activity.amount}</span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              
              <div className="text-center pt-2">
                <Button variant="ghost" size="sm">
                  <Icon name="view" size="sm" className="mr-1" />
                  Alle Activiteit
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Snelle Acties</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {[
                { icon: 'add', label: 'Nieuwe Verhuur', action: 'create-rental' },
                { icon: 'customers', label: 'Klant Toevoegen', action: 'add-customer' },
                { icon: 'inventory', label: 'Equipment Scan', action: 'scan-equipment' },
                { icon: 'maintenance', label: 'Onderhoud Plannen', action: 'schedule-maintenance' },
                { icon: 'reports', label: 'Rapport Genereren', action: 'generate-report' },
                { icon: 'settings', label: 'Instellingen', action: 'settings' }
              ].map((action) => (
                <Button
                  key={action.action}
                  variant="ghost"
                  className="h-auto p-4 flex flex-col items-center space-y-2 hover:bg-sevensa-teal/5"
                >
                  <div className="w-10 h-10 bg-sevensa-teal/10 rounded-lg flex items-center justify-center">
                    <Icon name={action.icon} className="text-sevensa-teal" />
                  </div>
                  <span className="text-xs font-medium text-center">{action.label}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
