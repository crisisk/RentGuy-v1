import React, { useState, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '../../../design-system/components/Card';
import { Button } from '../../../design-system/components/Button';
import { Badge } from '../../../design-system/components/Badge';
import { Icon } from '../../../design-system/components/Icon';
import { cn } from '../../../design-system/utils/cn';

// Mock customer data
const mockCustomers = [
  {
    id: 'CUST-001',
    name: 'Demo Klant B.V.',
    type: 'business',
    email: 'contact@demoklant.nl',
    phone: '+31 20 123 4567',
    address: {
      street: 'Hoofdstraat 123',
      city: 'Amsterdam',
      postalCode: '1012 AB',
      country: 'Nederland'
    },
    contactPerson: 'Jan van der Berg',
    status: 'active',
    tier: 'vip',
    registrationDate: '2024-03-15',
    lastRental: '2025-09-28',
    totalRentals: 24,
    totalRevenue: 12450,
    averageRentalValue: 518,
    paymentTerms: 30,
    creditLimit: 5000,
    outstandingBalance: 0,
    preferredCategories: ['camera', 'lighting'],
    notes: 'Vaste klant voor evenementen. Altijd op tijd met betalingen.',
    tags: ['VIP', 'Evenementen', 'Betrouwbaar'],
    aiInsights: {
      riskScore: 15,
      loyaltyScore: 92,
      growthPotential: 'high',
      recommendations: [
        'Bied exclusieve kortingen aan voor camera equipment',
        'Stel voor om een jaarcontract af te sluiten'
      ]
    }
  },
  {
    id: 'CUST-002',
    name: 'Eventbureau XYZ',
    type: 'business',
    email: 'info@eventbureauXYZ.nl',
    phone: '+31 30 987 6543',
    address: {
      street: 'Eventlaan 45',
      city: 'Utrecht',
      postalCode: '3511 AB',
      country: 'Nederland'
    },
    contactPerson: 'Sarah Jansen',
    status: 'active',
    tier: 'premium',
    registrationDate: '2024-01-20',
    lastRental: '2025-10-05',
    totalRentals: 18,
    totalRevenue: 8920,
    averageRentalValue: 495,
    paymentTerms: 14,
    creditLimit: 3000,
    outstandingBalance: 450,
    preferredCategories: ['speaker', 'microphone', 'lighting'],
    notes: 'Gespecialiseerd in corporate events. Regelmatige klant.',
    tags: ['Corporate', 'Audio', 'Regelmatig'],
    aiInsights: {
      riskScore: 25,
      loyaltyScore: 78,
      growthPotential: 'medium',
      recommendations: [
        'Verhoog creditlimit voor grotere projecten',
        'Introduceer audio equipment bundels'
      ]
    }
  },
  {
    id: 'CUST-003',
    name: 'Lisa van Dijk',
    type: 'individual',
    email: 'lisa.vandijk@email.com',
    phone: '+31 6 1234 5678',
    address: {
      street: 'Kerkstraat 78',
      city: 'Haarlem',
      postalCode: '2011 AB',
      country: 'Nederland'
    },
    contactPerson: 'Lisa van Dijk',
    status: 'active',
    tier: 'standard',
    registrationDate: '2024-06-10',
    lastRental: '2025-08-15',
    totalRentals: 6,
    totalRevenue: 1280,
    averageRentalValue: 213,
    paymentTerms: 7,
    creditLimit: 500,
    outstandingBalance: 0,
    preferredCategories: ['camera'],
    notes: 'Freelance fotograaf. Huurt vooral camera equipment voor bruiloften.',
    tags: ['Freelancer', 'Fotografie', 'Bruiloften'],
    aiInsights: {
      riskScore: 10,
      loyaltyScore: 65,
      growthPotential: 'medium',
      recommendations: [
        'Bied fotografie packages aan',
        'Stuur seizoensgebonden aanbiedingen'
      ]
    }
  },
  {
    id: 'CUST-004',
    name: 'TechStart Solutions',
    type: 'business',
    email: 'hello@techstart.nl',
    phone: '+31 20 555 0123',
    address: {
      street: 'Innovation Square 12',
      city: 'Eindhoven',
      postalCode: '5612 AB',
      country: 'Nederland'
    },
    contactPerson: 'Mark de Vries',
    status: 'inactive',
    tier: 'standard',
    registrationDate: '2024-02-28',
    lastRental: '2025-05-20',
    totalRentals: 3,
    totalRevenue: 890,
    averageRentalValue: 297,
    paymentTerms: 30,
    creditLimit: 1000,
    outstandingBalance: 0,
    preferredCategories: ['projector'],
    notes: 'Startup bedrijf. Laatste verhuur was 4 maanden geleden.',
    tags: ['Startup', 'Inactief', 'Presentaties'],
    aiInsights: {
      riskScore: 45,
      loyaltyScore: 35,
      growthPotential: 'low',
      recommendations: [
        'Stuur reactivatie email met speciale aanbieding',
        'Bel voor persoonlijk contact'
      ]
    }
  },
  {
    id: 'CUST-005',
    name: 'Creative Agency Pro',
    type: 'business',
    email: 'projects@creativeagency.nl',
    phone: '+31 10 777 8899',
    address: {
      street: 'Designpark 88',
      city: 'Rotterdam',
      postalCode: '3011 AB',
      country: 'Nederland'
    },
    contactPerson: 'Emma Bakker',
    status: 'active',
    tier: 'vip',
    registrationDate: '2023-11-05',
    lastRental: '2025-10-07',
    totalRentals: 31,
    totalRevenue: 18750,
    averageRentalValue: 605,
    paymentTerms: 14,
    creditLimit: 7500,
    outstandingBalance: 1200,
    preferredCategories: ['camera', 'lighting', 'projector'],
    notes: 'Grote creative agency. Onze beste klant qua omzet.',
    tags: ['VIP', 'Creative', 'Hoge Omzet', 'Multimedia'],
    aiInsights: {
      riskScore: 20,
      loyaltyScore: 95,
      growthPotential: 'high',
      recommendations: [
        'Bied dedicated account manager aan',
        'Ontwikkel custom packages voor video productie'
      ]
    }
  }
];

const customerTiers = [
  { id: 'all', name: 'Alle Klanten', count: mockCustomers.length },
  { id: 'vip', name: 'VIP', count: mockCustomers.filter(c => c.tier === 'vip').length },
  { id: 'premium', name: 'Premium', count: mockCustomers.filter(c => c.tier === 'premium').length },
  { id: 'standard', name: 'Standaard', count: mockCustomers.filter(c => c.tier === 'standard').length }
];

const customerStatuses = [
  { id: 'all', name: 'Alle Status', count: mockCustomers.length },
  { id: 'active', name: 'Actief', count: mockCustomers.filter(c => c.status === 'active').length },
  { id: 'inactive', name: 'Inactief', count: mockCustomers.filter(c => c.status === 'inactive').length }
];

export const CustomerManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTier, setSelectedTier] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [sortBy, setSortBy] = useState<'name' | 'totalRevenue' | 'lastRental' | 'totalRentals'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null);

  // Filter and sort customers
  const filteredCustomers = useMemo(() => {
    let filtered = mockCustomers.filter(customer => {
      const matchesSearch = customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           customer.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesTier = selectedTier === 'all' || customer.tier === selectedTier;
      const matchesStatus = selectedStatus === 'all' || customer.status === selectedStatus;
      
      return matchesSearch && matchesTier && matchesStatus;
    });

    // Sort
    filtered.sort((a, b) => {
      let aValue: any = a[sortBy];
      let bValue: any = b[sortBy];
      
      if (sortBy === 'lastRental') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }
      
      if (sortOrder === 'asc') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

    return filtered;
  }, [searchTerm, selectedTier, selectedStatus, sortBy, sortOrder]);

  const getTierBadgeVariant = (tier: string) => {
    switch (tier) {
      case 'vip': return 'ai';
      case 'premium': return 'rented';
      case 'standard': return 'available';
      default: return 'default';
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'active': return 'available';
      case 'inactive': return 'maintenance';
      default: return 'default';
    }
  };

  const getRiskScoreColor = (score: number) => {
    if (score <= 20) return 'text-green-600';
    if (score <= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getLoyaltyScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-sevensa-teal';
    return 'text-yellow-600';
  };

  const CustomerCard: React.FC<{ customer: typeof mockCustomers[0] }> = ({ customer }) => (
    <Card className={cn(
      'hover:shadow-lg transition-all duration-200 cursor-pointer',
      selectedCustomer === customer.id && 'ring-2 ring-sevensa-teal'
    )}
    onClick={() => setSelectedCustomer(selectedCustomer === customer.id ? null : customer.id)}>
      <CardContent className="p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start space-x-3">
            <div className="w-12 h-12 bg-sevensa-teal/10 rounded-full flex items-center justify-center">
              <Icon name="customers" className="text-sevensa-teal" />
            </div>
            <div>
              <h3 className="font-semibold text-sevensa-dark">{customer.name}</h3>
              <p className="text-sm text-secondary-600">{customer.contactPerson}</p>
              <p className="text-xs text-secondary-500">{customer.id}</p>
            </div>
          </div>
          <div className="flex flex-col items-end space-y-1">
            <Badge variant={getTierBadgeVariant(customer.tier)}>
              {customer.tier.toUpperCase()}
            </Badge>
            <Badge variant={getStatusBadgeVariant(customer.status)}>
              {customer.status === 'active' ? 'Actief' : 'Inactief'}
            </Badge>
          </div>
        </div>

        {/* Contact Info */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-sm text-secondary-600">
            <Icon name="customers" size="sm" className="mr-2" />
            {customer.email}
          </div>
          <div className="flex items-center text-sm text-secondary-600">
            <Icon name="location" size="sm" className="mr-2" />
            {customer.address.city}, {customer.address.country}
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="text-center p-3 bg-secondary-50 rounded-lg">
            <div className="text-lg font-bold text-sevensa-dark">€{customer.totalRevenue.toLocaleString()}</div>
            <div className="text-xs text-secondary-600">Totale Omzet</div>
          </div>
          <div className="text-center p-3 bg-secondary-50 rounded-lg">
            <div className="text-lg font-bold text-sevensa-dark">{customer.totalRentals}</div>
            <div className="text-xs text-secondary-600">Verhuurcontracten</div>
          </div>
        </div>

        {/* AI Insights */}
        <div className="space-y-3 mb-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-secondary-700">AI Risk Score</span>
            <span className={cn('text-sm font-bold', getRiskScoreColor(customer.aiInsights.riskScore))}>
              {customer.aiInsights.riskScore}%
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-secondary-700">Loyalty Score</span>
            <span className={cn('text-sm font-bold', getLoyaltyScoreColor(customer.aiInsights.loyaltyScore))}>
              {customer.aiInsights.loyaltyScore}%
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-secondary-700">Growth Potential</span>
            <Badge variant={
              customer.aiInsights.growthPotential === 'high' ? 'available' :
              customer.aiInsights.growthPotential === 'medium' ? 'maintenance' : 'danger'
            } className="text-xs">
              {customer.aiInsights.growthPotential === 'high' ? 'Hoog' :
               customer.aiInsights.growthPotential === 'medium' ? 'Gemiddeld' : 'Laag'}
            </Badge>
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-4">
          {customer.tags.map((tag, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>

        {/* AI Recommendations */}
        {customer.aiInsights.recommendations.length > 0 && (
          <div className="p-3 bg-sevensa-teal/5 rounded-lg border border-sevensa-teal/20 mb-4">
            <div className="flex items-center mb-2">
              <Icon name="ai-insight" size="sm" className="text-sevensa-teal mr-2" />
              <span className="text-sm font-medium text-sevensa-dark">AI Aanbevelingen</span>
            </div>
            <ul className="space-y-1">
              {customer.aiInsights.recommendations.slice(0, 2).map((rec, index) => (
                <li key={index} className="text-xs text-secondary-700 flex items-start">
                  <span className="w-1 h-1 bg-sevensa-teal rounded-full mt-2 mr-2 flex-shrink-0"></span>
                  {rec}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Outstanding Balance Warning */}
        {customer.outstandingBalance > 0 && (
          <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200 mb-4">
            <div className="flex items-center">
              <Icon name="notification" size="sm" className="text-yellow-600 mr-2" />
              <span className="text-sm font-medium text-yellow-800">
                Openstaand bedrag: €{customer.outstandingBalance}
              </span>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex space-x-2">
          <Button size="sm" variant="ghost" className="flex-1">
            <Icon name="view" size="sm" className="mr-1" />
            Profiel
          </Button>
          <Button size="sm" variant="ghost">
            <Icon name="add" size="sm" className="mr-1" />
            Verhuur
          </Button>
          <Button size="sm" variant="ghost">
            <Icon name="customers" size="sm" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-secondary-50">
      {/* Header */}
      <div className="bg-white border-b border-secondary-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-sevensa-dark">Customer Management</h1>
            <p className="text-secondary-600">Beheer klantrelaties met AI-powered insights</p>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="secondary">
              <Icon name="analytics" size="sm" className="mr-2" />
              Customer Analytics
            </Button>
            <Button>
              <Icon name="add" size="sm" className="mr-2" />
              Nieuwe Klant
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-secondary-600">Totale Klanten</p>
                  <p className="text-2xl font-bold text-sevensa-dark">{mockCustomers.length}</p>
                </div>
                <Icon name="customers" className="text-sevensa-teal" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-secondary-600">Actieve Klanten</p>
                  <p className="text-2xl font-bold text-sevensa-dark">
                    {mockCustomers.filter(c => c.status === 'active').length}
                  </p>
                </div>
                <Icon name="available" className="text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-secondary-600">Totale Omzet</p>
                  <p className="text-2xl font-bold text-sevensa-dark">
                    €{mockCustomers.reduce((sum, c) => sum + c.totalRevenue, 0).toLocaleString()}
                  </p>
                </div>
                <Icon name="revenue" className="text-sevensa-teal" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-secondary-600">Gem. Waarde</p>
                  <p className="text-2xl font-bold text-sevensa-dark">
                    €{Math.round(mockCustomers.reduce((sum, c) => sum + c.averageRentalValue, 0) / mockCustomers.length)}
                  </p>
                </div>
                <Icon name="analytics" className="text-sevensa-teal" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <div className="mb-6 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Icon name="search" className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400" />
            <input
              type="text"
              placeholder="Zoek klanten op naam, email of ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-sevensa-teal focus:border-transparent"
            />
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap gap-4">
            {/* Tier Filter */}
            <div className="flex bg-white rounded-lg border border-secondary-200 p-1">
              {customerTiers.map((tier) => (
                <Button
                  key={tier.id}
                  variant={selectedTier === tier.id ? 'primary' : 'ghost'}
                  size="sm"
                  onClick={() => setSelectedTier(tier.id)}
                  className="text-xs"
                >
                  {tier.name}
                  <Badge variant="secondary" className="ml-1 text-xs">
                    {tier.count}
                  </Badge>
                </Button>
              ))}
            </div>

            {/* Status Filter */}
            <div className="flex bg-white rounded-lg border border-secondary-200 p-1">
              {customerStatuses.map((status) => (
                <Button
                  key={status.id}
                  variant={selectedStatus === status.id ? 'primary' : 'ghost'}
                  size="sm"
                  onClick={() => setSelectedStatus(status.id)}
                  className="text-xs"
                >
                  {status.name}
                  <Badge variant="secondary" className="ml-1 text-xs">
                    {status.count}
                  </Badge>
                </Button>
              ))}
            </div>
          </div>

          {/* Sort Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-secondary-600">Sorteer op:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="text-sm border border-secondary-300 rounded px-2 py-1"
                >
                  <option value="name">Naam</option>
                  <option value="totalRevenue">Omzet</option>
                  <option value="totalRentals">Aantal Verhuur</option>
                  <option value="lastRental">Laatste Verhuur</option>
                </select>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                >
                  <Icon name={sortOrder === 'asc' ? 'sort' : 'sort'} size="sm" />
                </Button>
              </div>
              
              <div className="text-sm text-secondary-600">
                {filteredCustomers.length} van {mockCustomers.length} klanten
              </div>
            </div>
          </div>
        </div>

        {/* Customer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCustomers.map((customer) => (
            <CustomerCard key={customer.id} customer={customer} />
          ))}
        </div>

        {/* Empty State */}
        {filteredCustomers.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="customers" size="lg" className="text-secondary-400" />
            </div>
            <h3 className="text-lg font-medium text-secondary-900 mb-2">Geen klanten gevonden</h3>
            <p className="text-secondary-600 mb-4">
              Probeer uw zoekterm of filters aan te passen
            </p>
            <Button variant="secondary" onClick={() => {
              setSearchTerm('');
              setSelectedTier('all');
              setSelectedStatus('all');
            }}>
              Filters Wissen
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomerManagement;
