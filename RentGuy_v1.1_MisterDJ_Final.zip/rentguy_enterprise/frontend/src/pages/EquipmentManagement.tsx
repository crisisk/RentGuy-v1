import React, { useState, useMemo } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '../../../design-system/components/Card';
import { Button } from '../../../design-system/components/Button';
import { Badge } from '../../../design-system/components/Badge';
import { Icon } from '../../../design-system/components/Icon';
import { cn } from '../../../design-system/utils/cn';

// Mock equipment data
const mockEquipment = [
  {
    id: 'CAM-001',
    name: 'Canon EOS R5 Camera Set',
    category: 'camera',
    status: 'available',
    location: 'Magazijn A-12',
    dailyRate: 85,
    weeklyRate: 450,
    condition: 'excellent',
    lastMaintenance: '2025-09-15',
    nextMaintenance: '2025-12-15',
    totalRentals: 24,
    revenue: 2040,
    utilization: 68,
    specifications: {
      brand: 'Canon',
      model: 'EOS R5',
      year: 2023,
      weight: '1.2kg',
      accessories: ['Battery', 'Charger', '24-70mm Lens', 'Memory Card']
    },
    images: ['/api/placeholder/300/200'],
    qrCode: 'RG-CAM-001'
  },
  {
    id: 'MIC-002',
    name: 'Shure SM7B Microphone',
    category: 'microphone',
    status: 'rented',
    location: 'Klant: Eventbureau XYZ',
    dailyRate: 35,
    weeklyRate: 180,
    condition: 'good',
    lastMaintenance: '2025-08-20',
    nextMaintenance: '2025-11-20',
    totalRentals: 18,
    revenue: 630,
    utilization: 45,
    currentRental: {
      customer: 'Eventbureau XYZ',
      startDate: '2025-10-06',
      endDate: '2025-10-09',
      value: 105
    },
    specifications: {
      brand: 'Shure',
      model: 'SM7B',
      year: 2022,
      weight: '0.8kg',
      accessories: ['Windscreen', 'XLR Cable']
    },
    images: ['/api/placeholder/300/200'],
    qrCode: 'RG-MIC-002'
  },
  {
    id: 'PROJ-003',
    name: 'Epson PowerLite Projector',
    category: 'projector',
    status: 'maintenance',
    location: 'Technische Dienst',
    dailyRate: 120,
    weeklyRate: 650,
    condition: 'fair',
    lastMaintenance: '2025-10-01',
    nextMaintenance: '2025-10-15',
    totalRentals: 31,
    revenue: 3720,
    utilization: 72,
    maintenanceNote: 'Lamp vervangen, lens reiniging',
    specifications: {
      brand: 'Epson',
      model: 'PowerLite Pro L1755U',
      year: 2021,
      weight: '11.2kg',
      accessories: ['Remote', 'Power Cable', 'VGA Cable', 'HDMI Cable']
    },
    images: ['/api/placeholder/300/200'],
    qrCode: 'RG-PROJ-003'
  },
  {
    id: 'LIGHT-004',
    name: 'LED Panel Light Kit',
    category: 'lighting',
    status: 'available',
    location: 'Magazijn B-05',
    dailyRate: 65,
    weeklyRate: 350,
    condition: 'excellent',
    lastMaintenance: '2025-09-30',
    nextMaintenance: '2026-01-30',
    totalRentals: 15,
    revenue: 975,
    utilization: 38,
    specifications: {
      brand: 'Aputure',
      model: 'AL-M9 Kit',
      year: 2023,
      weight: '2.1kg',
      accessories: ['Diffusers', 'Color Gels', 'Stands', 'Carrying Case']
    },
    images: ['/api/placeholder/300/200'],
    qrCode: 'RG-LIGHT-004'
  },
  {
    id: 'SOUND-005',
    name: 'Portable PA System',
    category: 'speaker',
    status: 'reserved',
    location: 'Magazijn A-08',
    dailyRate: 95,
    weeklyRate: 500,
    condition: 'good',
    lastMaintenance: '2025-09-10',
    nextMaintenance: '2025-12-10',
    totalRentals: 22,
    revenue: 2090,
    utilization: 55,
    reservation: {
      customer: 'Demo Klant B.V.',
      startDate: '2025-10-12',
      endDate: '2025-10-14',
      value: 285
    },
    specifications: {
      brand: 'JBL',
      model: 'EON615',
      year: 2022,
      weight: '18.6kg',
      accessories: ['Microphones', 'Cables', 'Stand']
    },
    images: ['/api/placeholder/300/200'],
    qrCode: 'RG-SOUND-005'
  }
];

const categories = [
  { id: 'all', name: 'Alle Categorieën', icon: 'inventory' },
  { id: 'camera', name: 'Camera\'s', icon: 'camera' },
  { id: 'microphone', name: 'Microfoons', icon: 'microphone' },
  { id: 'speaker', name: 'Speakers', icon: 'speaker' },
  { id: 'lighting', name: 'Verlichting', icon: 'lighting' },
  { id: 'projector', name: 'Projectoren', icon: 'projector' }
];

const statusFilters = [
  { id: 'all', name: 'Alle Status', count: mockEquipment.length },
  { id: 'available', name: 'Beschikbaar', count: mockEquipment.filter(e => e.status === 'available').length },
  { id: 'rented', name: 'Verhuurd', count: mockEquipment.filter(e => e.status === 'rented').length },
  { id: 'maintenance', name: 'Onderhoud', count: mockEquipment.filter(e => e.status === 'maintenance').length },
  { id: 'reserved', name: 'Gereserveerd', count: mockEquipment.filter(e => e.status === 'reserved').length }
];

export const EquipmentManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [sortBy, setSortBy] = useState<'name' | 'utilization' | 'revenue' | 'lastMaintenance'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedEquipment, setSelectedEquipment] = useState<string | null>(null);

  // Filter and sort equipment
  const filteredEquipment = useMemo(() => {
    let filtered = mockEquipment.filter(equipment => {
      const matchesSearch = equipment.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           equipment.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || equipment.category === selectedCategory;
      const matchesStatus = selectedStatus === 'all' || equipment.status === selectedStatus;
      
      return matchesSearch && matchesCategory && matchesStatus;
    });

    // Sort
    filtered.sort((a, b) => {
      let aValue: any = a[sortBy];
      let bValue: any = b[sortBy];
      
      if (sortBy === 'lastMaintenance') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }
      
      if (sortOrder === 'asc') {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

    return filtered;
  }, [searchTerm, selectedCategory, selectedStatus, sortBy, sortOrder]);

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'available': return 'available';
      case 'rented': return 'rented';
      case 'maintenance': return 'maintenance';
      case 'reserved': return 'reserved';
      default: return 'default';
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case 'excellent': return 'text-green-600';
      case 'good': return 'text-sevensa-teal';
      case 'fair': return 'text-yellow-600';
      case 'poor': return 'text-red-600';
      default: return 'text-secondary-600';
    }
  };

  const EquipmentCard: React.FC<{ equipment: typeof mockEquipment[0] }> = ({ equipment }) => (
    <Card className={cn(
      'hover:shadow-lg transition-all duration-200 cursor-pointer',
      selectedEquipment === equipment.id && 'ring-2 ring-sevensa-teal'
    )}
    onClick={() => setSelectedEquipment(selectedEquipment === equipment.id ? null : equipment.id)}>
      <CardContent className="p-4">
        {/* Equipment Image */}
        <div className="relative mb-4">
          <div className="w-full h-32 bg-secondary-100 rounded-lg flex items-center justify-center">
            <Icon name={equipment.category} size="xl" className="text-secondary-400" />
          </div>
          <div className="absolute top-2 right-2">
            <Badge variant={getStatusBadgeVariant(equipment.status)}>
              {equipment.status === 'available' ? 'Beschikbaar' :
               equipment.status === 'rented' ? 'Verhuurd' :
               equipment.status === 'maintenance' ? 'Onderhoud' :
               equipment.status === 'reserved' ? 'Gereserveerd' : equipment.status}
            </Badge>
          </div>
          <div className="absolute top-2 left-2">
            <Badge variant="secondary" className="text-xs">
              {equipment.id}
            </Badge>
          </div>
        </div>

        {/* Equipment Info */}
        <div className="space-y-3">
          <div>
            <h3 className="font-semibold text-sevensa-dark">{equipment.name}</h3>
            <p className="text-sm text-secondary-600">{equipment.location}</p>
          </div>

          {/* Pricing */}
          <div className="flex justify-between items-center">
            <div>
              <span className="text-lg font-bold text-sevensa-dark">€{equipment.dailyRate}</span>
              <span className="text-sm text-secondary-600">/dag</span>
            </div>
            <div className="text-right">
              <span className="text-sm text-secondary-600">€{equipment.weeklyRate}/week</span>
            </div>
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="text-sm font-medium text-sevensa-dark">{equipment.utilization}%</div>
              <div className="text-xs text-secondary-500">Benutting</div>
            </div>
            <div>
              <div className="text-sm font-medium text-sevensa-dark">€{equipment.revenue}</div>
              <div className="text-xs text-secondary-500">Omzet</div>
            </div>
            <div>
              <div className={cn('text-sm font-medium', getConditionColor(equipment.condition))}>
                {equipment.condition === 'excellent' ? 'Uitstekend' :
                 equipment.condition === 'good' ? 'Goed' :
                 equipment.condition === 'fair' ? 'Redelijk' : 'Slecht'}
              </div>
              <div className="text-xs text-secondary-500">Conditie</div>
            </div>
          </div>

          {/* Current Status Details */}
          {equipment.status === 'rented' && equipment.currentRental && (
            <div className="p-2 bg-sevensa-teal/5 rounded border border-sevensa-teal/20">
              <div className="text-xs text-sevensa-dark font-medium">
                Verhuurd aan: {equipment.currentRental.customer}
              </div>
              <div className="text-xs text-secondary-600">
                Tot: {new Date(equipment.currentRental.endDate).toLocaleDateString('nl-NL')}
              </div>
            </div>
          )}

          {equipment.status === 'maintenance' && equipment.maintenanceNote && (
            <div className="p-2 bg-yellow-50 rounded border border-yellow-200">
              <div className="text-xs text-yellow-800 font-medium">Onderhoud</div>
              <div className="text-xs text-yellow-700">{equipment.maintenanceNote}</div>
            </div>
          )}

          {equipment.status === 'reserved' && equipment.reservation && (
            <div className="p-2 bg-purple-50 rounded border border-purple-200">
              <div className="text-xs text-purple-800 font-medium">
                Gereserveerd: {equipment.reservation.customer}
              </div>
              <div className="text-xs text-purple-700">
                Start: {new Date(equipment.reservation.startDate).toLocaleDateString('nl-NL')}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex space-x-2 pt-2">
            <Button size="sm" variant="ghost" className="flex-1">
              <Icon name="view" size="sm" className="mr-1" />
              Details
            </Button>
            <Button size="sm" variant="ghost">
              <Icon name="edit" size="sm" />
            </Button>
            <Button size="sm" variant="ghost">
              <Icon name="view" size="sm" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-secondary-50">
      {/* Header */}
      <div className="bg-white border-b border-secondary-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-sevensa-dark">Equipment Management</h1>
            <p className="text-secondary-600">Beheer uw volledige inventaris met real-time tracking</p>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button variant="secondary">
              <Icon name="view" size="sm" className="mr-2" />
              QR Scanner
            </Button>
            <Button>
              <Icon name="add" size="sm" className="mr-2" />
              Equipment Toevoegen
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Filters and Search */}
        <div className="mb-6 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Icon name="search" className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400" />
            <input
              type="text"
              placeholder="Zoek equipment op naam of ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-secondary-300 rounded-lg focus:ring-2 focus:ring-sevensa-teal focus:border-transparent"
            />
          </div>

          {/* Filter Tabs */}
          <div className="flex flex-wrap gap-4">
            {/* Category Filter */}
            <div className="flex bg-white rounded-lg border border-secondary-200 p-1">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? 'primary' : 'ghost'}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className="text-xs"
                >
                  <Icon name={category.icon} size="sm" className="mr-1" />
                  {category.name}
                </Button>
              ))}
            </div>

            {/* Status Filter */}
            <div className="flex bg-white rounded-lg border border-secondary-200 p-1">
              {statusFilters.map((status) => (
                <Button
                  key={status.id}
                  variant={selectedStatus === status.id ? 'primary' : 'ghost'}
                  size="sm"
                  onClick={() => setSelectedStatus(status.id)}
                  className="text-xs"
                >
                  {status.name}
                  <Badge variant="secondary" className="ml-1 text-xs">
                    {status.count}
                  </Badge>
                </Button>
              ))}
            </div>
          </div>

          {/* Sort and View Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-secondary-600">Sorteer op:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="text-sm border border-secondary-300 rounded px-2 py-1"
                >
                  <option value="name">Naam</option>
                  <option value="utilization">Benutting</option>
                  <option value="revenue">Omzet</option>
                  <option value="lastMaintenance">Laatste Onderhoud</option>
                </select>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                >
                  <Icon name={sortOrder === 'asc' ? 'sort' : 'sort'} size="sm" />
                </Button>
              </div>
              
              <div className="text-sm text-secondary-600">
                {filteredEquipment.length} van {mockEquipment.length} items
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Button
                variant={viewMode === 'grid' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                <Icon name="inventory" size="sm" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
              >
                <Icon name="view" size="sm" />
              </Button>
            </div>
          </div>
        </div>

        {/* Equipment Grid */}
        <div className={cn(
          'grid gap-6',
          viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'
        )}>
          {filteredEquipment.map((equipment) => (
            <EquipmentCard key={equipment.id} equipment={equipment} />
          ))}
        </div>

        {/* Empty State */}
        {filteredEquipment.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="search" size="lg" className="text-secondary-400" />
            </div>
            <h3 className="text-lg font-medium text-secondary-900 mb-2">Geen equipment gevonden</h3>
            <p className="text-secondary-600 mb-4">
              Probeer uw zoekterm of filters aan te passen
            </p>
            <Button variant="secondary" onClick={() => {
              setSearchTerm('');
              setSelectedCategory('all');
              setSelectedStatus('all');
            }}>
              Filters Wissen
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default EquipmentManagement;
