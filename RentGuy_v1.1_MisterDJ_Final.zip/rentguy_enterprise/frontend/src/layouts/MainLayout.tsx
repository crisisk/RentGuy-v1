import React, { useState, useEffect } from 'react';
import { Button } from '../../../design-system/components/Button';
import { Badge } from '../../../design-system/components/Badge';
import { Icon, NavigationIcon } from '../../../design-system/components/Icon';
import { cn } from '../../../design-system/utils/cn';
import { OnboardingOrchestrator, useOnboardingStatus } from '../../../src/rentguy/onboarding';

interface MainLayoutProps {
  children: React.ReactNode;
  currentPage: string;
  userRole: 'manager' | 'warehouse' | 'sales';
  onNavigate: (page: string) => void;
}

const navigationItems = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: 'dashboard',
    roles: ['manager', 'warehouse', 'sales']
  },
  {
    id: 'equipment',
    label: 'Equipment',
    icon: 'inventory',
    roles: ['manager', 'warehouse', 'sales']
  },
  {
    id: 'rentals',
    label: 'Verhuur',
    icon: 'rentals',
    roles: ['manager', 'sales']
  },
  {
    id: 'customers',
    label: 'Klanten',
    icon: 'customers',
    roles: ['manager', 'sales']
  },
  {
    id: 'reports',
    label: 'Rapportage',
    icon: 'reports',
    roles: ['manager']
  },
  {
    id: 'maintenance',
    label: 'Onderhoud',
    icon: 'maintenance',
    roles: ['manager', 'warehouse']
  },
  {
    id: 'settings',
    label: 'Instellingen',
    icon: 'settings',
    roles: ['manager']
  }
];

const quickActions = {
  manager: [
    { id: 'new-rental', label: 'Nieuwe Verhuur', icon: 'add' },
    { id: 'ai-insights', label: 'AI Inzichten', icon: 'ai-insight' },
    { id: 'reports', label: 'Rapporten', icon: 'reports' }
  ],
  warehouse: [
    { id: 'scan-equipment', label: 'Equipment Scannen', icon: 'view' },
    { id: 'maintenance', label: 'Onderhoud', icon: 'maintenance' },
    { id: 'inventory', label: 'Inventaris', icon: 'inventory' }
  ],
  sales: [
    { id: 'new-rental', label: 'Nieuwe Verhuur', icon: 'add' },
    { id: 'new-customer', label: 'Nieuwe Klant', icon: 'customers' },
    { id: 'quotes', label: 'Offertes', icon: 'revenue' }
  ]
};

export const MainLayout: React.FC<MainLayoutProps> = ({
  children,
  currentPage,
  userRole,
  onNavigate
}) => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const { shouldShowOnboarding } = useOnboardingStatus(userRole);

  // Mock notifications
  const notifications = [
    {
      id: 1,
      type: 'rental_overdue',
      title: 'Verhuur verlopen',
      message: 'Camera Set bij Demo Klant B.V. is 2 dagen verlopen',
      timestamp: '5 minuten geleden',
      urgent: true
    },
    {
      id: 2,
      type: 'maintenance_due',
      title: 'Onderhoud gepland',
      message: 'Projector PJ-003 heeft onderhoud nodig binnen 3 dagen',
      timestamp: '1 uur geleden',
      urgent: false
    },
    {
      id: 3,
      type: 'ai_insight',
      title: 'AI Aanbeveling',
      message: 'Nieuwe pricing optimalisatie beschikbaar',
      timestamp: '2 uur geleden',
      urgent: false
    }
  ];

  // Filter navigation items based on user role
  const filteredNavigation = navigationItems.filter(item => 
    item.roles.includes(userRole)
  );

  // Auto-show onboarding for new users
  useEffect(() => {
    if (shouldShowOnboarding) {
      const timer = setTimeout(() => {
        setShowOnboarding(true);
      }, 2000); // Show after 2 seconds
      
      return () => clearTimeout(timer);
    }
  }, [shouldShowOnboarding]);

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
  };

  const handleOnboardingSkip = () => {
    setShowOnboarding(false);
  };

  return (
    <div className="min-h-screen bg-secondary-50 flex">
      {/* Sidebar */}
      <div className={cn(
        'bg-white border-r border-secondary-200 transition-all duration-300 flex flex-col',
        sidebarCollapsed ? 'w-16' : 'w-64'
      )}>
        {/* Logo */}
        <div className="p-4 border-b border-secondary-200">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-sevensa-teal to-sevensa-dark rounded-lg flex items-center justify-center">
              <Icon name="inventory" size="sm" className="text-white" />
            </div>
            {!sidebarCollapsed && (
              <div>
                <h1 className="font-bold text-sevensa-dark">RentGuy</h1>
                <p className="text-xs text-secondary-600">Enterprise</p>
              </div>
            )}
          </div>
        </div>

        {/* User Info */}
        <div className="p-4 border-b border-secondary-200">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-sevensa-teal/10 rounded-full flex items-center justify-center">
              <Icon name="customers" className="text-sevensa-teal" />
            </div>
            {!sidebarCollapsed && (
              <div className="flex-1">
                <p className="font-medium text-sevensa-dark">John Doe</p>
                <p className="text-xs text-secondary-600 capitalize">{userRole}</p>
                <Badge variant="available" className="text-xs mt-1">
                  Online
                </Badge>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <div className="space-y-2">
            {filteredNavigation.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={cn(
                  'w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left transition-colors',
                  currentPage === item.id
                    ? 'bg-sevensa-teal text-white'
                    : 'text-secondary-700 hover:bg-secondary-100'
                )}
              >
                <NavigationIcon type={item.icon as any} className={cn(
                  'flex-shrink-0',
                  currentPage === item.id ? 'text-white' : 'text-secondary-600'
                )} />
                {!sidebarCollapsed && (
                  <span className="font-medium">{item.label}</span>
                )}
              </button>
            ))}
          </div>

          {/* Quick Actions */}
          {!sidebarCollapsed && (
            <div className="mt-8">
              <h3 className="text-xs font-semibold text-secondary-500 uppercase tracking-wider mb-3">
                Snelle Acties
              </h3>
              <div className="space-y-2">
                {quickActions[userRole].map((action) => (
                  <button
                    key={action.id}
                    className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left text-secondary-700 hover:bg-secondary-100 transition-colors"
                  >
                    <Icon name={action.icon} size="sm" className="text-secondary-600" />
                    <span className="text-sm">{action.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </nav>

        {/* Onboarding Trigger */}
        {!sidebarCollapsed && shouldShowOnboarding && (
          <div className="p-4 border-t border-secondary-200">
            <div className="p-3 bg-sevensa-teal/5 rounded-lg border border-sevensa-teal/20">
              <div className="flex items-center mb-2">
                <Icon name="tour-start" size="sm" className="text-sevensa-teal mr-2" />
                <span className="text-sm font-medium text-sevensa-dark">Nieuwe gebruiker?</span>
              </div>
              <p className="text-xs text-secondary-600 mb-3">
                Start de interactieve tour om RentGuy te leren kennen
              </p>
              <Button
                size="sm"
                onClick={() => setShowOnboarding(true)}
                className="w-full"
              >
                <Icon name="tour-start" size="sm" className="mr-1" />
                Start Tour
              </Button>
            </div>
          </div>
        )}

        {/* Sidebar Toggle */}
        <div className="p-4 border-t border-secondary-200">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="w-full"
          >
            <Icon name={sidebarCollapsed ? 'tour-next' : 'tour-previous'} size="sm" />
            {!sidebarCollapsed && <span className="ml-2">Inklappen</span>}
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Bar */}
        <header className="bg-white border-b border-secondary-200 px-6 py-3">
          <div className="flex items-center justify-between">
            {/* Search */}
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Icon name="search" className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-400" size="sm" />
                <input
                  type="text"
                  placeholder="Zoek equipment, klanten, verhuur..."
                  className="w-full pl-10 pr-4 py-2 border border-secondary-300 rounded-lg text-sm focus:ring-2 focus:ring-sevensa-teal focus:border-transparent"
                />
              </div>
            </div>

            {/* Right Side Actions */}
            <div className="flex items-center space-x-4">
              {/* AI Insights Button */}
              <Button variant="ai" size="sm">
                <Icon name="ai-insight" size="sm" className="mr-2" />
                AI Inzichten
              </Button>

              {/* Notifications */}
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="relative"
                >
                  <Icon name="notification" size="sm" />
                  {notifications.filter(n => n.urgent).length > 0 && (
                    <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                      {notifications.filter(n => n.urgent).length}
                    </span>
                  )}
                </Button>

                {/* Notifications Dropdown */}
                {showNotifications && (
                  <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-lg shadow-lg border border-secondary-200 z-50">
                    <div className="p-4 border-b border-secondary-200">
                      <h3 className="font-semibold text-sevensa-dark">Meldingen</h3>
                    </div>
                    <div className="max-h-64 overflow-y-auto">
                      {notifications.map((notification) => (
                        <div key={notification.id} className="p-4 border-b border-secondary-100 hover:bg-secondary-50">
                          <div className="flex items-start space-x-3">
                            <div className={cn(
                              'w-8 h-8 rounded-full flex items-center justify-center',
                              notification.urgent ? 'bg-red-100' : 'bg-sevensa-teal/10'
                            )}>
                              <Icon 
                                name={notification.type === 'ai_insight' ? 'ai-insight' : 'notification'} 
                                size="sm" 
                                className={notification.urgent ? 'text-red-600' : 'text-sevensa-teal'} 
                              />
                            </div>
                            <div className="flex-1">
                              <h4 className="font-medium text-sevensa-dark text-sm">{notification.title}</h4>
                              <p className="text-xs text-secondary-600">{notification.message}</p>
                              <p className="text-xs text-secondary-500 mt-1">{notification.timestamp}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="p-4 text-center">
                      <Button variant="ghost" size="sm">
                        Alle meldingen bekijken
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              {/* User Menu */}
              <div className="relative">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2"
                >
                  <div className="w-8 h-8 bg-sevensa-teal/10 rounded-full flex items-center justify-center">
                    <Icon name="customers" size="sm" className="text-sevensa-teal" />
                  </div>
                  <Icon name="tour-next" size="sm" className="text-secondary-400" />
                </Button>

                {/* User Menu Dropdown */}
                {showUserMenu && (
                  <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-secondary-200 z-50">
                    <div className="p-4 border-b border-secondary-200">
                      <p className="font-medium text-sevensa-dark">John Doe</p>
                      <p className="text-sm text-secondary-600 capitalize">{userRole}</p>
                    </div>
                    <div className="p-2">
                      <button className="w-full text-left px-3 py-2 text-sm text-secondary-700 hover:bg-secondary-100 rounded">
                        Profiel
                      </button>
                      <button className="w-full text-left px-3 py-2 text-sm text-secondary-700 hover:bg-secondary-100 rounded">
                        Instellingen
                      </button>
                      <button 
                        className="w-full text-left px-3 py-2 text-sm text-secondary-700 hover:bg-secondary-100 rounded"
                        onClick={() => setShowOnboarding(true)}
                      >
                        Tour Herhalen
                      </button>
                      <hr className="my-2" />
                      <button className="w-full text-left px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded">
                        Uitloggen
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>

      {/* Onboarding Overlay */}
      {showOnboarding && (
        <OnboardingOrchestrator
          userRole={userRole}
          onComplete={handleOnboardingComplete}
          onSkip={handleOnboardingSkip}
        />
      )}

      {/* Click outside handlers */}
      {(showNotifications || showUserMenu) && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => {
            setShowNotifications(false);
            setShowUserMenu(false);
          }}
        />
      )}
    </div>
  );
};

export default MainLayout;
