import React, { useState, useEffect } from 'react';
import { MainLayout } from './layouts/MainLayout';
import { Dashboard } from './pages/Dashboard';
import { EquipmentManagement } from './pages/EquipmentManagement';
import { CustomerManagement } from './pages/CustomerManagement';
import { OnboardingProvider } from '../../src/rentguy/onboarding';
import './App.css';

// Mock authentication and user data
const mockUser = {
  id: 'user-001',
  name: 'John Doe',
  email: 'john.doe@company.com',
  role: 'manager' as const,
  permissions: ['read', 'write', 'admin'],
  preferences: {
    theme: 'light',
    language: 'nl',
    notifications: true
  }
};

// Page components mapping
const pageComponents = {
  dashboard: Dashboard,
  equipment: EquipmentManagement,
  customers: CustomerManagement,
  rentals: () => <div className="p-6">Verhuur pagina - Coming Soon</div>,
  reports: () => <div className="p-6">Rapportage pagina - Coming Soon</div>,
  maintenance: () => <div className="p-6">Onderhoud pagina - Coming Soon</div>,
  settings: () => <div className="p-6">Instellingen pagina - Coming Soon</div>
};

function App() {
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [user, setUser] = useState(mockUser);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate app initialization
  useEffect(() => {
    const initializeApp = async () => {
      // Simulate loading time
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Load user preferences, check authentication, etc.
      const savedPage = localStorage.getItem('rentguy-current-page');
      if (savedPage && pageComponents[savedPage as keyof typeof pageComponents]) {
        setCurrentPage(savedPage);
      }
      
      setIsLoading(false);
    };

    initializeApp();
  }, []);

  // Save current page to localStorage
  useEffect(() => {
    localStorage.setItem('rentguy-current-page', currentPage);
  }, [currentPage]);

  const handleNavigation = (page: string) => {
    if (pageComponents[page as keyof typeof pageComponents]) {
      setCurrentPage(page);
    }
  };

  // Loading screen
  if (isLoading) {
    return (
      <div className="min-h-screen bg-secondary-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-sevensa-teal to-sevensa-dark rounded-full flex items-center justify-center mx-auto mb-4">
            <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          </div>
          <h2 className="text-xl font-semibold text-sevensa-dark mb-2">RentGuy Enterprise</h2>
          <p className="text-secondary-600">Laden...</p>
        </div>
      </div>
    );
  }

  // Get current page component
  const CurrentPageComponent = pageComponents[currentPage as keyof typeof pageComponents] || Dashboard;

  return (
    <OnboardingProvider userRole={user.role} autoStart={false}>
      <div className="App">
        <MainLayout
          currentPage={currentPage}
          userRole={user.role}
          onNavigate={handleNavigation}
        >
          <CurrentPageComponent />
        </MainLayout>
      </div>
    </OnboardingProvider>
  );
}

export default App;
