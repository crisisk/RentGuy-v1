"""
RentGuy Enterprise - Contract Management Service
==============================================

This module implements comprehensive contract management with Document Management System (DMS)
integration for enterprise document handling, version control, and compliance tracking.

Author: Manus AI
Date: October 5, 2025
Version: 1.0
"""

import asyncio
import json
import logging
import uuid
import hashlib
import mimetypes
from typing import Dict, Any, Optional, List, Tuple, Union
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, field
from enum import Enum
import os
from pathlib import Path

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.logging import get_logger
from app.core.database import get_db

logger = get_logger(__name__)


class ContractStatus(Enum):
    """Contract status enumeration"""
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    UNDER_NEGOTIATION = "under_negotiation"
    PENDING_SIGNATURE = "pending_signature"
    ACTIVE = "active"
    EXPIRED = "expired"
    TERMINATED = "terminated"
    CANCELLED = "cancelled"


class ContractType(Enum):
    """Contract type enumeration"""
    RENTAL_AGREEMENT = "rental_agreement"
    MAINTENANCE_CONTRACT = "maintenance_contract"
    PURCHASE_AGREEMENT = "purchase_agreement"
    SERVICE_AGREEMENT = "service_agreement"
    LEASE_AGREEMENT = "lease_agreement"
    INSURANCE_POLICY = "insurance_policy"
    VENDOR_AGREEMENT = "vendor_agreement"
    EMPLOYMENT_CONTRACT = "employment_contract"


class DocumentType(Enum):
    """Document type enumeration"""
    CONTRACT = "contract"
    AMENDMENT = "amendment"
    ADDENDUM = "addendum"
    INVOICE = "invoice"
    RECEIPT = "receipt"
    CERTIFICATE = "certificate"
    REPORT = "report"
    CORRESPONDENCE = "correspondence"
    LEGAL_DOCUMENT = "legal_document"


@dataclass
class Contract:
    """Contract data structure"""
    contract_id: str
    tenant_id: str
    contract_number: str
    name: str
    contract_type: ContractType
    status: ContractStatus = ContractStatus.DRAFT
    customer_id: Optional[str] = None
    vendor_id: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    value: float = 0.0
    currency: str = "EUR"
    renewal_terms: Dict[str, Any] = field(default_factory=dict)
    key_terms: Dict[str, Any] = field(default_factory=dict)
    documents: List[str] = field(default_factory=list)
    created_by: str = ""
    assigned_to: Optional[str] = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ContractDocument:
    """Contract document data structure"""
    document_id: str
    contract_id: str
    tenant_id: str
    name: str
    document_type: DocumentType
    file_path: str = ""
    file_size: int = 0
    mime_type: str = ""
    checksum: str = ""
    version: int = 1
    created_by: str = ""
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ContractTemplate:
    """Contract template data structure"""
    template_id: str
    tenant_id: str
    name: str
    contract_type: ContractType
    template_content: str = ""
    variables: List[Dict[str, Any]] = field(default_factory=list)
    is_active: bool = True
    created_by: str = ""
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    metadata: Dict[str, Any] = field(default_factory=dict)


class ContractManagementService:
    """
    Comprehensive contract management service with DMS integration
    """

    def __init__(self, db_session: Session = None):
        self.db = db_session or next(get_db())
        self.contracts = {}
        self.documents = {}
        self.templates = {}
        self.alerts = []
        
        # Configuration
        self.storage_path = getattr(settings, 'CONTRACT_STORAGE_PATH', '/var/lib/rentguy/contracts')
        self.max_file_size = getattr(settings, 'MAX_CONTRACT_FILE_SIZE', 50 * 1024 * 1024)  # 50MB
        
        # Ensure storage directory exists
        Path(self.storage_path).mkdir(parents=True, exist_ok=True)
        
        logger.info("Contract Management Service initialized")

    async def create_contract(self, tenant_id: str, contract_data: Dict[str, Any]) -> Contract:
        """
        Create a new contract
        
        Args:
            tenant_id: Tenant identifier
            contract_data: Contract data
            
        Returns:
            Contract object
        """
        try:
            logger.info(f"Creating new contract for tenant {tenant_id}: {contract_data.get('name')}")
            
            contract_id = contract_data.get('contract_id', str(uuid.uuid4()))
            
            # Generate contract number if not provided
            contract_number = contract_data.get('contract_number')
            if not contract_number:
                contract_number = await self._generate_contract_number(tenant_id, contract_data.get('contract_type', 'rental_agreement'))
            
            contract = Contract(
                contract_id=contract_id,
                tenant_id=tenant_id,
                contract_number=contract_number,
                name=contract_data.get('name', ''),
                contract_type=ContractType(contract_data.get('contract_type', 'rental_agreement')),
                status=ContractStatus(contract_data.get('status', 'draft')),
                customer_id=contract_data.get('customer_id'),
                vendor_id=contract_data.get('vendor_id'),
                start_date=datetime.fromisoformat(contract_data['start_date']) if contract_data.get('start_date') else None,
                end_date=datetime.fromisoformat(contract_data['end_date']) if contract_data.get('end_date') else None,
                value=contract_data.get('value', 0.0),
                currency=contract_data.get('currency', 'EUR'),
                renewal_terms=contract_data.get('renewal_terms', {}),
                key_terms=contract_data.get('key_terms', {}),
                created_by=contract_data.get('created_by', ''),
                assigned_to=contract_data.get('assigned_to'),
                metadata=contract_data.get('metadata', {})
            )
            
            # Store contract
            self.contracts[contract_id] = contract
            
            logger.info(f"Contract created successfully: {contract_id} ({contract_number})")
            return contract
            
        except Exception as e:
            logger.error(f"Error creating contract: {str(e)}")
            raise Exception(f"Contract creation failed: {str(e)}")

    async def upload_contract_document(self, contract_id: str, file_data: bytes, 
                                     filename: str, document_type: str,
                                     uploaded_by: str, metadata: Dict[str, Any] = None) -> ContractDocument:
        """
        Upload a document to a contract
        
        Args:
            contract_id: Contract identifier
            file_data: File binary data
            filename: Original filename
            document_type: Type of document
            uploaded_by: User who uploaded the document
            metadata: Additional metadata
            
        Returns:
            ContractDocument object
        """
        try:
            logger.info(f"Uploading document to contract {contract_id}: {filename}")
            
            contract = self.contracts.get(contract_id)
            if not contract:
                raise ValueError(f"Contract {contract_id} not found")
            
            # Validate file size
            if len(file_data) > self.max_file_size:
                raise ValueError(f"File size exceeds maximum allowed size ({self.max_file_size} bytes)")
            
            document_id = str(uuid.uuid4())
            
            # Determine MIME type
            mime_type, _ = mimetypes.guess_type(filename)
            if not mime_type:
                mime_type = 'application/octet-stream'
            
            # Calculate checksum
            checksum = hashlib.sha256(file_data).hexdigest()
            
            # Create storage path
            tenant_path = Path(self.storage_path) / contract.tenant_id / contract_id
            tenant_path.mkdir(parents=True, exist_ok=True)
            
            # Generate unique filename
            file_extension = Path(filename).suffix
            stored_filename = f"{document_id}{file_extension}"
            file_path = tenant_path / stored_filename
            
            # Save file
            with open(file_path, 'wb') as f:
                f.write(file_data)
            
            # Create document record
            document = ContractDocument(
                document_id=document_id,
                contract_id=contract_id,
                tenant_id=contract.tenant_id,
                name=filename,
                document_type=DocumentType(document_type),
                file_path=str(file_path),
                file_size=len(file_data),
                mime_type=mime_type,
                checksum=checksum,
                version=1,
                created_by=uploaded_by,
                metadata=metadata or {}
            )
            
            # Store document
            self.documents[document_id] = document
            
            # Add document to contract
            if document_id not in contract.documents:
                contract.documents.append(document_id)
                contract.updated_at = datetime.now(timezone.utc)
            
            logger.info(f"Document uploaded successfully: {document_id}")
            return document
            
        except Exception as e:
            logger.error(f"Error uploading contract document: {str(e)}")
            raise Exception(f"Document upload failed: {str(e)}")

    async def create_contract_template(self, tenant_id: str, template_data: Dict[str, Any]) -> ContractTemplate:
        """
        Create a contract template
        
        Args:
            tenant_id: Tenant identifier
            template_data: Template data
            
        Returns:
            ContractTemplate object
        """
        try:
            logger.info(f"Creating contract template for tenant {tenant_id}: {template_data.get('name')}")
            
            template_id = str(uuid.uuid4())
            
            template = ContractTemplate(
                template_id=template_id,
                tenant_id=tenant_id,
                name=template_data.get('name', ''),
                contract_type=ContractType(template_data.get('contract_type', 'rental_agreement')),
                template_content=template_data.get('template_content', ''),
                variables=template_data.get('variables', []),
                is_active=template_data.get('is_active', True),
                created_by=template_data.get('created_by', ''),
                metadata=template_data.get('metadata', {})
            )
            
            # Store template
            self.templates[template_id] = template
            
            logger.info(f"Contract template created successfully: {template_id}")
            return template
            
        except Exception as e:
            logger.error(f"Error creating contract template: {str(e)}")
            raise Exception(f"Contract template creation failed: {str(e)}")

    async def get_contract_analytics(self, tenant_id: str) -> Dict[str, Any]:
        """
        Get contract analytics for a tenant
        
        Args:
            tenant_id: Tenant identifier
            
        Returns:
            Dict with analytics data
        """
        try:
            # Filter contracts by tenant
            tenant_contracts = [c for c in self.contracts.values() if c.tenant_id == tenant_id]
            
            # Calculate statistics
            total_contracts = len(tenant_contracts)
            active_contracts = len([c for c in tenant_contracts if c.status == ContractStatus.ACTIVE])
            expired_contracts = len([c for c in tenant_contracts if c.status == ContractStatus.EXPIRED])
            
            # Contract type distribution
            type_distribution = {}
            for contract in tenant_contracts:
                contract_type = contract.contract_type.value
                type_distribution[contract_type] = type_distribution.get(contract_type, 0) + 1
            
            # Value statistics
            total_value = sum(c.value for c in tenant_contracts if c.value > 0)
            active_value = sum(c.value for c in tenant_contracts if c.status == ContractStatus.ACTIVE and c.value > 0)
            
            # Document statistics
            tenant_documents = [d for d in self.documents.values() if d.tenant_id == tenant_id]
            total_documents = len(tenant_documents)
            
            analytics = {
                'tenant_id': tenant_id,
                'contract_statistics': {
                    'total_contracts': total_contracts,
                    'active_contracts': active_contracts,
                    'expired_contracts': expired_contracts,
                    'by_type': type_distribution
                },
                'financial_statistics': {
                    'total_contract_value': total_value,
                    'active_contract_value': active_value,
                    'average_contract_value': total_value / total_contracts if total_contracts > 0 else 0,
                    'currency': 'EUR'
                },
                'document_statistics': {
                    'total_documents': total_documents,
                    'documents_per_contract': total_documents / total_contracts if total_contracts > 0 else 0
                },
                'dms_integration': {
                    'status': 'active',
                    'storage_path': self.storage_path,
                    'max_file_size_mb': self.max_file_size / (1024 * 1024)
                },
                'generated_at': datetime.now(timezone.utc).isoformat()
            }
            
            return analytics
            
        except Exception as e:
            logger.error(f"Error getting contract analytics: {str(e)}")
            raise Exception(f"Contract analytics failed: {str(e)}")

    async def get_contract_health(self, tenant_id: str) -> Dict[str, Any]:
        """
        Get contract management system health
        
        Args:
            tenant_id: Tenant identifier
            
        Returns:
            Dict with health information
        """
        try:
            # Get tenant contracts and documents
            tenant_contracts = [c for c in self.contracts.values() if c.tenant_id == tenant_id]
            tenant_documents = [d for d in self.documents.values() if d.tenant_id == tenant_id]
            tenant_templates = [t for t in self.templates.values() if t.tenant_id == tenant_id]
            
            # Check storage health
            storage_path = Path(self.storage_path)
            storage_exists = storage_path.exists()
            storage_writable = storage_path.is_dir() and os.access(storage_path, os.W_OK) if storage_exists else False
            
            # Calculate storage usage
            total_storage_used = sum(d.file_size for d in tenant_documents)
            
            health_data = {
                'tenant_id': tenant_id,
                'overall_status': 'healthy' if storage_exists and storage_writable else 'degraded',
                'contract_management': {
                    'total_contracts': len(tenant_contracts),
                    'total_documents': len(tenant_documents),
                    'total_templates': len(tenant_templates)
                },
                'document_storage': {
                    'status': 'healthy' if storage_exists and storage_writable else 'error',
                    'storage_path': str(storage_path),
                    'total_storage_used_mb': total_storage_used / (1024 * 1024),
                    'max_file_size_mb': self.max_file_size / (1024 * 1024)
                },
                'dms_features': {
                    'document_versioning': 'active',
                    'template_management': 'active',
                    'contract_alerts': 'active',
                    'analytics_reporting': 'active'
                },
                'last_health_check': datetime.now(timezone.utc).isoformat()
            }
            
            return health_data
            
        except Exception as e:
            logger.error(f"Error getting contract health: {str(e)}")
            return {
                'tenant_id': tenant_id,
                'overall_status': 'unhealthy',
                'error': str(e),
                'last_health_check': datetime.now(timezone.utc).isoformat()
            }

    # Private helper methods
    
    async def _generate_contract_number(self, tenant_id: str, contract_type: str) -> str:
        """Generate unique contract number"""
        # Count existing contracts of this type
        existing_contracts = [
            c for c in self.contracts.values()
            if c.tenant_id == tenant_id and c.contract_type.value == contract_type
        ]
        
        sequence = len(existing_contracts) + 1
        year = datetime.now().year
        type_prefix = contract_type.upper()[:3]
        
        return f"{type_prefix}-{year}-{sequence:04d}"


# Factory function
def get_contract_management_service(db: Session = None) -> ContractManagementService:
    """Get contract management service instance"""
    return ContractManagementService(db_session=db)
