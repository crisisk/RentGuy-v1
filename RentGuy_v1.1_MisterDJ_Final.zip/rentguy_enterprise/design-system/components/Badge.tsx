import React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../utils/cn';

const badgeVariants = cva(
  "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
  {
    variants: {
      variant: {
        available: "border-green-200 bg-green-100 text-green-800 hover:bg-green-200",
        rented: "border-sevensa-teal/20 bg-sevensa-teal/10 text-sevensa-dark hover:bg-sevensa-teal/20",
        maintenance: "border-yellow-200 bg-yellow-100 text-yellow-800 hover:bg-yellow-200",
        damaged: "border-red-200 bg-red-100 text-red-800 hover:bg-red-200",
        reserved: "border-purple-200 bg-purple-100 text-purple-800 hover:bg-purple-200",
        ai: "border-sevensa-teal/30 bg-gradient-to-r from-sevensa-teal/20 to-sevensa-dark/20 text-sevensa-dark hover:from-sevensa-teal/30 hover:to-sevensa-dark/30",
        default: "border-secondary-200 bg-secondary-100 text-secondary-800 hover:bg-secondary-200",
        secondary: "border-transparent bg-secondary-100 text-secondary-900 hover:bg-secondary-200",
        destructive: "border-transparent bg-red-500 text-white hover:bg-red-600",
        outline: "text-secondary-950 border-secondary-300"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props} />
  );
}

export { Badge, badgeVariants };
