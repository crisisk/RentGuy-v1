import React from 'react';
import { cn } from '../utils/cn';

export interface IconProps extends React.SVGAttributes<SVGElement> {
  name: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const iconSizes = {
  xs: 'w-3 h-3',
  sm: 'w-4 h-4',
  md: 'w-5 h-5',
  lg: 'w-6 h-6',
  xl: 'w-8 h-8'
};

const Icon = React.forwardRef<SVGSVGElement, IconProps>(
  ({ name, size = 'md', className, ...props }, ref) => {
    return (
      <svg
        ref={ref}
        className={cn(iconSizes[size], 'inline-block', className)}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
        {...props}
      >
        <use href={`#${name}`} />
      </svg>
    );
  }
);

Icon.displayName = "Icon";

// Equipment Status Icons
export const EquipmentStatusIcon: React.FC<{ status: string; className?: string }> = ({ 
  status, 
  className 
}) => {
  const statusIconMap = {
    available: 'available',
    rented: 'rented',
    maintenance: 'maintenance',
    damaged: 'damaged',
    reserved: 'reserved'
  };

  const statusColorMap = {
    available: 'text-green-600',
    rented: 'text-sevensa-teal',
    maintenance: 'text-yellow-600',
    damaged: 'text-red-600',
    reserved: 'text-purple-600'
  };

  const iconName = statusIconMap[status as keyof typeof statusIconMap] || 'help';
  const colorClass = statusColorMap[status as keyof typeof statusColorMap] || 'text-secondary-500';

  return (
    <Icon 
      name={iconName} 
      className={cn(colorClass, className)} 
      aria-label={`Status: ${status}`}
    />
  );
};

// AI Insight Icon with special styling
export const AIInsightIcon: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <Icon 
      name="ai-insight" 
      className={cn('text-sevensa-teal animate-pulse', className)}
      aria-label="AI Insight"
    />
  );
};

// Navigation Icons
export const NavigationIcon: React.FC<{ 
  type: 'dashboard' | 'inventory' | 'rentals' | 'customers' | 'reports' | 'settings';
  className?: string;
}> = ({ type, className }) => {
  return (
    <Icon 
      name={type} 
      className={cn('text-secondary-600', className)}
      aria-label={`Navigate to ${type}`}
    />
  );
};

export { Icon };
