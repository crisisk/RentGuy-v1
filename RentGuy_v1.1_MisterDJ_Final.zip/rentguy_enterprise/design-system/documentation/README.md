# RentGuy Design System (RDGS) v1.0

**Een moderne, Sevensa-geïnspireerde design system voor RentGuy Enterprise**

## Overzicht

Het RentGuy Design System (RDGS) is een uitgebreide collectie van design tokens, componenten en richtlijnen die zorgen voor een consistente, professionele en toegankelijke gebruikerservaring in de RentGuy Enterprise applicatie. Het design system is gebaseerd op de Sevensa Brand Identity Guide en geoptimaliseerd voor equipment rental management.

## Kernprincipes

### 1. **Sevensa Brand Alignment**
- **Primaire Kleur:** Sevensa Teal (#00A896) voor acties, links en AI-gerelateerde elementen
- **Secundaire Kleur:** Sevensa Dark (#2D3A45) voor tekst, navigatie en structurele elementen
- **Typografie:** Montserrat als primair lettertype voor professionele uitstraling

### 2. **AI-First Design**
- Speciale styling voor AI-insights en aanbevelingen
- Duidelijke visuele hiërarchie voor machine-gegenereerde content
- Intuïtieve iconografie voor intelligente functies

### 3. **Equipment-Centric UX**
- Status-specifieke kleuren en icons voor apparatuur
- Contextuele badges voor verhuurstatus
- Visuele prioritering van kritieke informatie

## Design Tokens

### Kleurenpalet

```css
/* Primaire Kleuren (Sevensa Teal) */
--primary-50: #f0fdfc;
--primary-500: #00A896;  /* Sevensa Teal */
--primary-700: #006B5F;

/* Secundaire Kleuren (Sevensa Dark) */
--secondary-500: #6b7885;
--secondary-700: #2D3A45;  /* Sevensa Dark */
--secondary-900: #151E25;

/* Semantische Kleuren */
--available: #4CAF50;      /* Sevensa Success Green */
--rented: #00A896;         /* Sevensa Teal */
--maintenance: #f59e0b;    /* Warning Yellow */
--damaged: #F44336;        /* Sevensa Error Red */
--ai-insight: #00A896;     /* Sevensa Teal voor AI */
```

### Typografie

```css
/* Font Familie */
font-family: 'Montserrat', 'Inter', system-ui, sans-serif;

/* Typografische Hiërarchie */
--text-h1: 36px / Bold (700)     /* Pagina Titels */
--text-h2: 24px / Semi-Bold (600) /* Sectie Titels */
--text-body: 16px / Regular (400) /* Body Text */
--text-small: 14px / Regular (400) /* Labels, Captions */
```

## Componenten

### 1. Button Component

```tsx
import { Button } from '@/design-system/components/Button';

// Primaire actie (Sevensa Teal)
<Button variant="primary">Nieuwe Verhuur</Button>

// AI-gerelateerde actie (Gradient)
<Button variant="ai">AI Analyse Starten</Button>

// Secundaire actie
<Button variant="secondary">Annuleren</Button>
```

**Varianten:**
- `primary`: Sevensa Teal voor hoofdacties
- `secondary`: Neutrale styling voor secundaire acties
- `ai`: Gradient styling voor AI-functies
- `danger`: Rood voor destructieve acties
- `ghost`: Transparant voor subtiele acties

### 2. Badge Component

```tsx
import { Badge } from '@/design-system/components/Badge';

// Equipment status badges
<Badge variant="available">Beschikbaar</Badge>
<Badge variant="rented">Verhuurd</Badge>
<Badge variant="maintenance">Onderhoud</Badge>
<Badge variant="damaged">Beschadigd</Badge>

// AI-gerelateerde badge
<Badge variant="ai">AI Aanbeveling</Badge>
```

### 3. Icon Component

```tsx
import { Icon, EquipmentStatusIcon, AIInsightIcon } from '@/design-system/components/Icon';

// Basis icon
<Icon name="camera" size="md" />

// Equipment status icon (automatische kleuring)
<EquipmentStatusIcon status="available" />

// AI insight icon (met animatie)
<AIInsightIcon />
```

**Beschikbare Icons:**
- **Equipment:** `camera`, `microphone`, `speaker`, `lighting`, `projector`
- **Status:** `available`, `rented`, `maintenance`, `damaged`, `reserved`
- **Actions:** `add`, `edit`, `delete`, `view`, `search`, `filter`
- **Navigation:** `dashboard`, `inventory`, `rentals`, `customers`, `reports`
- **AI:** `ai-insight`, `brain`, `analytics`

### 4. Card Component

```tsx
import { Card, CardHeader, CardTitle, CardContent } from '@/design-system/components/Card';

<Card>
  <CardHeader>
    <CardTitle>Equipment Overzicht</CardTitle>
  </CardHeader>
  <CardContent>
    <p>Inhoud van de card...</p>
  </CardContent>
</Card>
```

## Iconografie Richtlijnen

### Stijl
- **Type:** Lijnicons (outline) met 2px lijndikte
- **Stijl:** Minimalistisch, consistent, professioneel
- **Kleuren:** Gebruik semantische kleuren voor status-gerelateerde icons

### Gebruik
- **Status Icons:** Automatische kleuring op basis van equipment status
- **AI Icons:** Sevensa Teal met optionele pulse-animatie
- **Navigation Icons:** Neutrale kleuring met hover states

## Layout & Grid

### Grid Systeem
- **Basis:** 12-koloms grid systeem (Sevensa standaard)
- **Breakpoints:** sm (640px), md (768px), lg (1024px), xl (1280px)
- **Spacing:** 8px basis unit (0.5rem)

### Witruimte
- **Minimale marge:** 16px (1rem) voor leesbaarheid
- **Sectie spacing:** 32px (2rem) tussen hoofdsecties
- **Component spacing:** 16px (1rem) tussen gerelateerde elementen

## Toegankelijkheid

### Kleurcontrast
- **Tekst op wit:** Minimaal 4.5:1 contrast ratio
- **Sevensa Teal (#00A896):** WCAG AA compliant op witte achtergrond
- **Sevensa Dark (#2D3A45):** WCAG AAA compliant voor body text

### Keyboard Navigation
- **Focus indicators:** 2px Sevensa Teal outline
- **Tab order:** Logische volgorde door interface
- **Skip links:** Voor hoofdnavigatie

### Screen Readers
- **Alt text:** Voor alle informatieve images en icons
- **ARIA labels:** Voor complexe UI componenten
- **Semantic HTML:** Gebruik van juiste HTML elementen

## Implementatie

### Installatie

```bash
# Installeer dependencies
npm install clsx tailwind-merge class-variance-authority

# Installeer Tailwind CSS plugins
npm install @tailwindcss/forms @tailwindcss/typography @tailwindcss/aspect-ratio
```

### Setup

1. **Tailwind Config:** Gebruik `design-system/tailwind.config.js`
2. **Font Loading:** Voeg Montserrat toe via Google Fonts
3. **Icon Sprite:** Includeer `design-system/icons/rentguy-icons.svg`

```html
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

<!-- Icon Sprite -->
<svg style="display: none;">
  <!-- Inhoud van rentguy-icons.svg -->
</svg>
```

## Best Practices

### Do's
✅ Gebruik Sevensa Teal voor primaire acties en AI-elementen  
✅ Gebruik consistente spacing (8px units)  
✅ Gebruik semantische kleuren voor equipment status  
✅ Gebruik Montserrat voor alle tekst  
✅ Gebruik lijnicons met 2px dikte  

### Don'ts
❌ Gebruik geen andere primaire kleuren dan Sevensa Teal  
❌ Gebruik geen gevulde icons (alleen outline)  
❌ Gebruik geen inconsistente spacing  
❌ Gebruik geen andere fonts dan Montserrat/Inter  
❌ Gebruik geen clichématige AI-imagery (robots, binaire code)  

## Versioning

**Huidige Versie:** 1.0.0  
**Laatste Update:** Oktober 2025  
**Compatibiliteit:** React 18+, Tailwind CSS 3.0+

## Support

Voor vragen over het design system:
- **Documentatie:** `/design-system/documentation/`
- **Componenten:** `/design-system/components/`
- **Tokens:** `/design-system/tokens/design-tokens.json`

---

*Dit design system is ontwikkeld door Manus AI en gebaseerd op de Sevensa Brand Identity Guide voor optimale merkherkenning en professionele uitstraling.*
