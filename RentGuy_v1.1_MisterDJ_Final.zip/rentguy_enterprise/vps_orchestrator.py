#!/usr/bin/env python3
"""
RentGuy Enterprise VPS Orchestrator
Advanced multi-LLM orchestration system for enterprise development tasks

@author Manus AI
@version 2.1.0
@date October 2025
"""

import os
import sys
import json
import time
import asyncio
import logging
import subprocess
from datetime import datetime
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from pathlib import Path

# Third-party imports
try:
    import paramiko
    import anthropic
    import openai
    import requests
except ImportError as e:
    print(f"Missing required packages. Install with: pip install paramiko anthropic openai requests")
    sys.exit(1)

# Configuration
VPS_HOST = "147.93.57.40"
VPS_USER = "root"
VPS_PASSWORD = "MP@admin69741414"
CLAUDE_API_KEY = "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"
OPENAI_API_KEY = "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"
OPENROUTER_API_KEY = "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"

@dataclass
class TaskResult:
    """Result of a task execution"""
    success: bool
    output: str
    error: Optional[str] = None
    execution_time: float = 0.0
    model_used: Optional[str] = None
    tokens_used: int = 0

@dataclass
class LLMConfig:
    """LLM configuration"""
    name: str
    api_key: str
    base_url: Optional[str] = None
    model: str = ""
    max_tokens: int = 4000
    temperature: float = 0.1

class VPSConnection:
    """Secure VPS connection manager"""

    def __init__(self, host: str, username: str, password: str):
        self.host = host
        self.username = username
        self.password = password
        self.client = None
        self.sftp = None

    def connect(self) -> bool:
        """Establish SSH connection"""
        try:
            self.client = paramiko.SSHClient()
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            self.client.connect(
                hostname=self.host,
                username=self.username,
                password=self.password,
                timeout=30
            )
            self.sftp = self.client.open_sftp()
            logging.info(f"Connected to VPS: {self.host}")
            return True
        except Exception as e:
            logging.error(f"VPS connection failed: {e}")
            return False

    def execute_command(self, command: str, timeout: int = 300) -> TaskResult:
        """Execute command on VPS"""
        start_time = time.time()
        try:
            stdin, stdout, stderr = self.client.exec_command(command, timeout=timeout)

            # Wait for command completion
            exit_status = stdout.channel.recv_exit_status()

            output = stdout.read().decode("utf-8")
            error = stderr.read().decode("utf-8")

            execution_time = time.time() - start_time

            return TaskResult(
                success=exit_status == 0,
                output=output,
                error=error if error else None,
                execution_time=execution_time
            )
        except Exception as e:
            return TaskResult(
                success=False,
                output="",
                error=str(e),
                execution_time=time.time() - start_time
            )

    def upload_file(self, local_path: str, remote_path: str) -> bool:
        """Upload file to VPS"""
        try:
            self.sftp.put(local_path, remote_path)
            logging.info(f"Uploaded {local_path} to {remote_path}")
            return True
        except Exception as e:
            logging.error(f"File upload failed: {e}")
            return False

    def download_file(self, remote_path: str, local_path: str) -> bool:
        """Download file from VPS"""
        try:
            self.sftp.get(remote_path, local_path)
            logging.info(f"Downloaded {remote_path} to {local_path}")
            return True
        except Exception as e:
            logging.error(f"File download failed: {e}")
            return False

    def disconnect(self):
        """Close VPS connection"""
        if self.sftp:
            self.sftp.close()
        if self.client:
            self.client.close()
        logging.info("VPS connection closed")

class LLMOrchestrator:
    """Multi-LLM orchestration system"""

    def __init__(self):
        self.llms = self._initialize_llms()
        self.task_history = []

    def _initialize_llms(self) -> Dict[str, Any]:
        """Initialize all available LLMs"""
        llms = {}

        # Claude (Anthropic)
        try:
            claude_client = anthropic.Anthropic(api_key=CLAUDE_API_KEY)
            # Only initialize Haiku models as they are proven to be available
            llms["claude-haiku-latest"] = {
                "client": claude_client,
                "model": "claude-3-5-haiku-20241022", # Use the latest Haiku version
                "config": LLMConfig("claude-haiku-latest", CLAUDE_API_KEY, model="claude-3-5-haiku-20241022", max_tokens=4000),
                "strengths": ["speed", "simple_tasks", "code_review", "documentation", "balanced_performance"]
            }
            llms["claude-haiku-old"] = {
                "client": claude_client,
                "model": "claude-3-haiku-20240307", # Fallback Haiku
                "config": LLMConfig("claude-haiku-old", CLAUDE_API_KEY, model="claude-3-haiku-20240307", max_tokens=4000),
                "strengths": ["speed", "simple_tasks", "code_review", "documentation"]
            }
        except Exception as e:
            logging.warning(f"Claude initialization failed: {e}")

        # OpenAI
        try:
            openai_client = openai.OpenAI(api_key=OPENAI_API_KEY, base_url="https://api.openai.com/v1/")
            llms["gpt-4"] = {
                "client": openai_client,
                "model": "gpt-4-turbo", # Use a more recent GPT-4 model if available
                "config": LLMConfig("gpt-4", OPENAI_API_KEY, model="gpt-4-turbo", max_tokens=4000),
                "strengths": ["general_purpose", "creative_solutions", "problem_solving", "integration"]
            }
            llms["gpt-3.5-turbo"] = {
                "client": openai_client,
                "model": "gpt-3.5-turbo",
                "config": LLMConfig("gpt-3.5-turbo", OPENAI_API_KEY, model="gpt-3.5-turbo", max_tokens=4000),
                "strengths": ["speed", "cost_effective", "simple_coding", "scripting"]
            }
        except Exception as e:
            logging.warning(f"OpenAI initialization failed: {e}")

        # OpenRouter (Multiple models)
        try:
            llms["openrouter-claude-haiku"] = {
                "client": "openrouter",
                "model": "anthropic/claude-3-haiku", # Use Haiku via OpenRouter as well
                "config": LLMConfig("openrouter-claude-haiku", OPENROUTER_API_KEY,
                                  base_url="https://openrouter.ai/api/v1",
                                  model="anthropic/claude-3-haiku", max_tokens=4000),
                "strengths": ["alternative_access", "backup_option", "specialized_models"]
            }
        except Exception as e:
            logging.warning(f"OpenRouter initialization failed: {e}")

        logging.info(f"Initialized {len(llms)} LLM providers")
        return llms

    def select_best_llm(self, task_type: str, complexity: str = "medium") -> str:
        """Select the best LLM for a specific task"""

        # Prioritize available Haiku models for Claude tasks
        if task_type in ["architecture", "system_design", "complex_debugging"]:
            return "claude-haiku-latest" if "claude-haiku-latest" in self.llms else "gpt-4"
        elif task_type in ["code_generation", "optimization", "refactoring"]:
            return "claude-haiku-latest" if "claude-haiku-latest" in self.llms else "gpt-4"
        elif task_type in ["documentation", "simple_scripts", "code_review"]:
            return "claude-haiku-latest" if "claude-haiku-latest" in self.llms else "gpt-3.5-turbo"
        elif task_type in ["integration", "problem_solving", "creative_solutions"]:
            return "gpt-4" if "gpt-4" in self.llms else "claude-haiku-latest"
        else:
            # Default fallback
            available_models = list(self.llms.keys())
            return available_models[0] if available_models else None

    async def execute_llm_task(self, prompt: str, task_type: str = "general",
                              model_preference: Optional[str] = None) -> TaskResult:
        """Execute task using selected LLM"""

        # Select LLM
        model_name = model_preference or self.select_best_llm(task_type)
        if not model_name or model_name not in self.llms:
            return TaskResult(False, "", "No suitable LLM available")

        llm_info = self.llms[model_name]
        start_time = time.time()

        try:
            if "claude" in model_name:
                # Claude API call
                response = llm_info["client"].messages.create(
                    model=llm_info["model"],
                    max_tokens=llm_info["config"].max_tokens,
                    temperature=llm_info["config"].temperature,
                    messages=[{"role": "user", "content": prompt}]
                )
                output = response.content[0].text
                tokens_used = response.usage.input_tokens + response.usage.output_tokens

            elif "gpt" in model_name:
                # OpenAI API call
                response = llm_info["client"].chat.completions.create(
                    model=llm_info["model"],
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=llm_info["config"].max_tokens,
                    temperature=llm_info["config"].temperature
                )
                output = response.choices[0].message.content
                tokens_used = response.usage.total_tokens

            elif "openrouter" in model_name:
                # OpenRouter API call
                headers = {
                    "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                    "Content-Type": "application/json"
                }
                data = {
                    "model": llm_info["model"],
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": llm_info["config"].max_tokens,
                    "temperature": llm_info["config"].temperature
                }

                response = requests.post(
                    "https://openrouter.ai/api/v1/chat/completions",
                    headers=headers,
                    json=data,
                    timeout=60
                )
                response.raise_for_status()
                result = response.json()
                output = result["choices"][0]["message"]["content"]
                tokens_used = result.get("usage", {}).get("total_tokens", 0)

            execution_time = time.time() - start_time

            # Log task execution
            task_record = {
                "timestamp": datetime.now().isoformat(),
                "model": model_name,
                "task_type": task_type,
                "execution_time": execution_time,
                "tokens_used": tokens_used,
                "success": True
            }
            self.task_history.append(task_record)

            return TaskResult(
                success=True,
                output=output,
                execution_time=execution_time,
                model_used=model_name,
                tokens_used=tokens_used
            )

        except Exception as e:
            execution_time = time.time() - start_time
            logging.error(f"LLM task execution failed with {model_name}: {e}")

            # Log failed task
            task_record = {
                "timestamp": datetime.now().isoformat(),
                "model": model_name,
                "task_type": task_type,
                "execution_time": execution_time,
                "error": str(e),
                "success": False
            }
            self.task_history.append(task_record)

            return TaskResult(
                success=False,
                output="",
                error=str(e),
                execution_time=execution_time,
                model_used=model_name
            )

class RentGuyOrchestrator:
    """Main orchestrator for RentGuy Enterprise development"""

    def __init__(self):
        self.vps = VPSConnection(VPS_HOST, VPS_USER, VPS_PASSWORD)
        self.llm_orchestrator = LLMOrchestrator()
        self.setup_logging()

    def setup_logging(self):
        """Setup comprehensive logging"""
        log_filename = f"orchestrator_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            handlers=[
                logging.FileHandler(log_filename),
                logging.StreamHandler(sys.stdout)
            ]
        )

    async def execute_development_task(self, task_description: str,
                                     task_type: str = "general",
                                     execute_on_vps: bool = False) -> TaskResult:
        """Execute a complete development task"""

        logging.info(f"Executing development task: {task_description}")

        # Step 1: Generate solution using LLM
        solution_prompt = f'''
        Task: {task_description}
        Task Type: {task_type}

        Please provide a complete solution including:
        1. Analysis of the requirements
        2. Implementation approach
        3. Code/scripts needed
        4. Deployment steps
        5. Testing procedures

        Focus on enterprise-grade quality and RentGuy platform integration.
        '''

        llm_result = await self.llm_orchestrator.execute_llm_task(
            solution_prompt, task_type
        )

        # Save the LLM's generated solution to a file
        with open("/home/ubuntu/rentguy-enterprise-final/integration_plan.md", "a") as f: # Changed 'w' to 'a' for append mode
            f.write(llm_result.output)

        if not llm_result.success:
            return llm_result

        # Step 2: Execute on VPS if requested
        if execute_on_vps:
            if not self.vps.connect():
                return TaskResult(False, llm_result.output, "VPS connection failed")

            # Extract commands from LLM response (simplified)
            commands = self.extract_commands_from_response(llm_result.output)

            vps_results = []
            for command in commands:
                vps_result = self.vps.execute_command(command)
                vps_results.append(vps_result)

                if not vps_result.success:
                    logging.warning(f"VPS command failed: {command}")

            self.vps.disconnect()

            # Combine results
            combined_output = llm_result.output + "\n\nVPS Execution Results:\n"
            for i, result in enumerate(vps_results):
                status = 'SUCCESS' if result.success else 'FAILED'
                combined_output += f"Command {i+1}: {status}\n"
                combined_output += f"Output: {result.output}\n"
                if result.error:
                    combined_output += f"Error: {result.error}\n"
                combined_output += "\n"

            return TaskResult(
                success=all(r.success for r in vps_results),
                output=combined_output,
                execution_time=llm_result.execution_time + sum(r.execution_time for r in vps_results),
                model_used=llm_result.model_used
            )

        return llm_result

    def extract_commands_from_response(self, response: str) -> List[str]:
        """Extract executable commands from LLM response"""
        commands = []
        lines = response.split("\n")

        in_code_block = False
        for line in lines:
            if line.strip().startswith("```"):
                in_code_block = not in_code_block
                continue
            if in_code_block:
                commands.append(line)
        return commands

    async def implement_phase_3_tasks(self) -> Dict[str, TaskResult]:
        """Implement all Phase 3 scalability tasks"""

        tasks = {
            "database_optimization": {
                "description": "Analyze and optimize database queries, add necessary indexes, and implement connection pooling.",
                "task_type": "optimization"
            },
            "caching_strategy": {
                "description": "Implement a multi-level caching strategy (in-memory, Redis) for frequently accessed data.",
                "task_type": "architecture"
            },
            "load_balancing": {
                "description": "Configure a load balancer (e.g., Traefik) to distribute traffic across multiple application instances.",
                "task_type": "system_design"
            },
            "async_workers": {
                "description": "Set up asynchronous task queues (e.g., Celery with RabbitMQ/Redis) for long-running background jobs.",
                "task_type": "architecture"
            },
            "logging_system": {
                "description": "Implement a centralized logging system (e.g., ELK stack) for better monitoring and debugging.",
                "task_type": "system_design"
            },
            "alerting_system": {
                "description": "Configure an alerting system (e.g., Grafana alerting) for critical system events and performance metrics.",
                "task_type": "system_design"
            },
            "performance_dashboard": {
                "description": "Create a comprehensive performance dashboard in Grafana to monitor key application and system metrics.",
                "task_type": "documentation"
            },
            "health_checks": {
                "description": "Implement detailed health check endpoints for all services to ensure they are running correctly.",
                "task_type": "code_generation"
            }
        }

        results = {}
        for task_name, task_info in tasks.items():
            result = await self.execute_development_task(
                task_info["description"], task_info["task_type"], execute_on_vps=False
            )
            results[task_name] = result
        return results

    def generate_report(self, results: Dict[str, TaskResult]):
        """Generate a summary report of the development cycle"""

        report = f"""
# RentGuy Enterprise Development Report
Generated: {datetime.now().isoformat()}

## Executive Summary
Total tasks executed: {len(results)}
Successful tasks: {sum(1 for r in results.values() if r.success)}
Failed tasks: {sum(1 for r in results.values() if not r.success)}

## Task Details
"""

        for task_name, result in results.items():
            report += f"### {task_name.replace('_', ' ').title()}\n"
            report += f"- Status: {'✅ SUCCESS' if result.success else '❌ FAILED'}\n"
            report += f"- Execution Time: {result.execution_time:.2f}s\n"
            report += f"- Model Used: {result.model_used}\n"
            report += f"- Tokens Used: {result.tokens_used}\n"
            if result.error:
                report += f"- Error: {result.error}\n"

        report += f"""
## LLM Usage Statistics
Total tasks in history: {len(self.llm_orchestrator.task_history)}
"""
        print(report)

async def main():
    orchestrator = RentGuyOrchestrator()

    if len(sys.argv) > 1:
        task_description = sys.argv[1]
        results = await orchestrator.implement_phase_3_tasks()
        orchestrator.generate_report(results)
    else:
        print("Usage: python vps_orchestrator.py \"<task_description>\"")

if __name__ == "__main__":
    print("🚀 RentGuy Enterprise VPS Orchestrator v2.1.0")
    print("=" * 60)
    asyncio.run(main())
    print("=" * 60)
    print("📊 DEVELOPMENT CYCLE COMPLETED")
    print("=" * 60)

