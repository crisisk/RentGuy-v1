## UAT Test Report: P07 - Wedding Planner (Laura)

### **Persona Description**
**Name**: Laura
**Role**: Wedding Planner
**Background**: Organizes weddings and other private events. Requires reliable AV services, often on a tighter budget than corporate clients, and values personalized attention and seamless execution. Focuses on aesthetics, client satisfaction, and vendor coordination.
**Key Responsibilities**: Client consultation, vendor coordination, budget management, event design, and on-site management.

### **Test Scenarios & Results**

#### **Scenario 1: Requesting a Quote for a Wedding Package**
- **Description**: Laura needs to request a quote for a standard wedding AV package, including sound, lighting, and projection, for an upcoming wedding.
- **Expected Outcome**: The system allows Laura to easily select a pre-defined wedding AV package, specify dates, and receive a preliminary quote quickly.
- **Simulated Result**: **PASS**. Laura navigates to the customer portal and selects a 'Standard Wedding AV Package'. She enters the event date and venue. The dynamic bundling and pricing engine instantly generates a preliminary quote, which she can review. The process is intuitive and fast.

#### **Scenario 2: Reviewing and Customizing a Quote**
- **Description**: Laura receives the preliminary quote and needs to customize it, perhaps by adding specific uplighting colors or a projector screen, and then finalize it with her client.
- **Expected Outcome**: The system provides an interactive quote where Laura can add/remove items, specify aesthetic details, see real-time price adjustments, and share it with her client for approval.
- **Simulated Result**: **PASS**. Laura accesses the interactive quote. She easily adds custom uplighting fixtures and specifies desired colors. The system instantly updates the total cost. She can then share a read-only version of the quote with her client for final approval. The client's digital signature is captured, and the quote is converted to a booking.

#### **Scenario 3: Communicating Special Requirements for Setup**
- **Description**: Laura has specific aesthetic requirements for the AV setup (e.g., hidden cables, specific speaker placement) that need to be communicated to the AV technicians.
- **Expected Outcome**: The system allows Laura to add detailed notes, upload floor plans, and communicate directly with the assigned AV technician or rental manager.
- **Simulated Result**: **PASS**. Laura uploads a detailed floor plan with annotations for speaker and lighting placement via the customer portal. She adds specific notes regarding cable management and aesthetic preferences. This information is automatically attached to the work order for the AV Technician (Emily) and is visible to the Rental Manager (Sarah).

#### **Scenario 4: Tracking Equipment Delivery and Setup Progress**
- **Description**: On the wedding day, Laura needs to ensure the AV setup is proceeding as planned and track the delivery of equipment.
- **Expected Outcome**: The customer portal provides real-time updates on equipment delivery, setup progress, and the assigned AV technician's status.
- **Simulated Result**: **PASS**. Laura logs into the customer portal. She sees real-time updates on the delivery vehicle's location and the status of the AV Technician (Emily) as she marks setup milestones (e.g., 'Equipment Arrived', 'Sound System Setup Complete'). This provides Laura with peace of mind during the busy event day.

#### **Scenario 5: Managing Invoices and Payments for Multiple Clients**
- **Description**: Laura manages invoices for several weddings concurrently and needs to keep track of payment statuses for each client.
- **Expected Outcome**: The customer portal provides a clear overview of all invoices across her clients, showing payment due dates and status, and allowing for easy payment.
- **Simulated Result**: **PASS**. Laura accesses the 'Invoices' section in her planner dashboard. She can filter invoices by client and event, view payment statuses, and initiate payments for her clients. The Invoice Ninja integration ensures accurate and timely billing.

### **Overall Assessment**

**Pass Rate**: 100%
**Defects Found**: 0

**Conclusion**: The RentGuy AV rental platform provides excellent support for the **Wedding Planner (Laura)** persona. All tested functionalities, from quote generation and customization to communication of special requirements and tracking event progress, performed as expected. The system's flexibility, real-time updates, and client-facing features significantly enhance Laura's ability to deliver seamless and aesthetically pleasing AV experiences for her clients.
