#!/usr/bin/env bash
set -euo pipefail
MAX_FILES=${MAX_FILES:-30}
MAX_KB=${MAX_KB:-300}
ADDED_LINES_LIMIT=${ADDED_LINES_LIMIT:-800}
files=$(git diff --cached --name-only | wc -l | tr -d ' ')
kb=$(git diff --cached | wc -c)
added=$(git diff --cached --numstat | awk '{s+=$1} END {print s+0}')
if [ "$files" -gt "$MAX_FILES" ] || [ "$kb" -gt $((MAX_KB*1024)) ] || [ "$added" -gt "$ADDED_LINES_LIMIT" ]; then
  echo "Size guard failed: files=$files, KB=$((kb/1024)), added_lines=$added"; exit 1
fi
echo "Size guard passed."
