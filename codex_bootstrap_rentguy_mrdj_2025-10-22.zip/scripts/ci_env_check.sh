#!/usr/bin/env bash
set -euo pipefail
echo "[ci_env_check] Checking required environment..."
command -v node >/dev/null || (echo "Node missing" && exit 1)
command -v npx >/dev/null || (echo "npx missing" && exit 1)
if [ ! -f ".env" ]; then echo "WARN: .env not found (continuing for CI)"; fi
echo "[ci_env_check] OK"
