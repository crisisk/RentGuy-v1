// Minimal Lighthouse runner placeholder
console.log('[lighthouse] Run placeholder — implement real checks in CI.');