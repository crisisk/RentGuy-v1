# Mr-DJ ↔ RentGuy Connector Instructions
Place these files into the **mr-djv1** repository at the same paths.
- `lib/connectors/rentguy.ts`
- `lib/analytics/rentguySink.ts`
- `app/api/proxy/rentguy/route.ts` (optional server-side proxy)

Env vars to set in mr-djv1:
- NEXT_PUBLIC_RENTGUY_URL
- NEXT_PUBLIC_TENANT_ID
- RENTGUY_HMAC_SECRET
- RENTGUY_BASE_URL (if using the server proxy)
