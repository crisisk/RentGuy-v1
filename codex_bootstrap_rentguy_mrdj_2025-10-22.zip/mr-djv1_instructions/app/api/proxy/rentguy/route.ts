// mr-djv1/app/api/proxy/rentguy/route.ts (optional)
// Wraps client calls on the server to keep secrets server-side
import { NextRequest, NextResponse } from 'next/server';
import { postLead, sendEvents } from '@/lib/connectors/rentguy';

export async function POST(req: NextRequest) {
  const body = await req.json();
  const baseUrl = process.env.RENTGUY_BASE_URL || '';
  const secret = process.env.RENTGUY_HMAC_SECRET || '';
  const kind = body.kind;
  try {
    if (kind === 'lead') {
      const res = await postLead(baseUrl, body.payload, secret);
      return NextResponse.json(res, { status: 202 });
    }
    if (kind === 'events') {
      const res = await sendEvents(baseUrl, body.payload, secret);
      return NextResponse.json(res, { status: 202 });
    }
    return NextResponse.json({ error: 'invalid kind' }, { status: 400 });
  } catch (e:any) {
    return NextResponse.json({ error: e.message || 'proxy error' }, { status: 500 });
  }
}
