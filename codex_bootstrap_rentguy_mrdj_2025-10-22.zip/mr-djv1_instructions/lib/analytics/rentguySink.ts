// mr-djv1/lib/analytics/rentguySink.ts
import { sendEvents } from '../connectors/rentguy';

let buffer: any[] = [];
let timer: any = null;

export function track(evt: any) {
  buffer.push(evt);
  if (!timer) {
    timer = setTimeout(flush, 2000);
  }
}

export async function flush() {
  if (buffer.length === 0) return;
  const events = buffer.slice();
  buffer = [];
  clearTimeout(timer);
  timer = null;
  try {
    const baseUrl = process.env.NEXT_PUBLIC_RENTGUY_URL || '';
    const secret = process.env.RENTGUY_HMAC_SECRET || '';
    const batch = {
      tenantId: process.env.NEXT_PUBLIC_TENANT_ID || 'default',
      events,
      idempotencyKey: cryptoRandom(),
      timestamp: new Date().toISOString()
    };
    await sendEvents(baseUrl, batch as any, secret);
  } catch (e) {
    console.error('[rentguySink] flush failed', e);
  }
}

function cryptoRandom() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}
