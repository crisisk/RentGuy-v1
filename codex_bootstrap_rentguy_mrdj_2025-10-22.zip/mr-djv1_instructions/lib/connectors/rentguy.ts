// mr-djv1/lib/connectors/rentguy.ts
// Minimal client for RentGuy public API (HMAC + idempotency)
import crypto from 'crypto';

type LeadPayload = Record<string, any>;
type EventBatch = { tenantId: string; events: any[]; idempotencyKey: string; timestamp: string };

function hmac(body: string, secret: string) {
  return crypto.createHmac('sha256', secret).update(body).digest('hex');
}

export async function postLead(baseUrl: string, payload: LeadPayload, secret: string) {
  const body = JSON.stringify(payload);
  const sig = hmac(body, secret);
  const r = await fetch(`${baseUrl}/api/public/v1/mrdj/leads`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'X-MRDJ-Signature': `sha256=${sig}`, 'X-Idempotency-Key': payload.idempotencyKey || '' },
    body
  });
  if (!r.ok) throw new Error(`RentGuy lead error: ${r.status}`);
  return r.json().catch(() => ({}));
}

export async function sendEvents(baseUrl: string, batch: EventBatch, secret: string) {
  const body = JSON.stringify(batch);
  const sig = hmac(body, secret);
  const r = await fetch(`${baseUrl}/api/public/v1/mrdj/events`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'X-MRDJ-Signature': `sha256=${sig}`, 'X-Idempotency-Key': batch.idempotencyKey || '' },
    body
  });
  if (!r.ok) throw new Error(`RentGuy events error: ${r.status}`);
  return r.json().catch(() => ({}));
}
