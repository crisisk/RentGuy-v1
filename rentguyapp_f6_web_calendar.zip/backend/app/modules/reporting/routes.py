from fastapi import APIRouter
router = APIRouter()
# TODO: implement reporting routes
