from fastapi import APIRouter
router = APIRouter()
# TODO: implement warehouse routes
