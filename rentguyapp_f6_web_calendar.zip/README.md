# Rentguyapp – Modular Monolith (Phases 1–2)

## Quick start (Docker)
```bash
cd ops
cp env/.env.example .env
# set POSTGRES_PASSWORD and JWT_SECRET
docker compose up --build
# Backend on http://localhost:8000
# Swagger on http://localhost:8000/docs
```

## Migrations
Alembic runs automatically at container start (baseline creates `auth_users`).

## Auth
- POST `/api/v1/auth/login` (form fields `email`, `password`)
- GET `/api/v1/auth/me` (Bearer token)

## Next
Implement modules in `backend/app/modules/*` following ports/adapters.
