## UAT Test Report: P04 - AV Technician (Emily)

### **Persona Description**
**Name**: Emily
**Role**: AV Technician
**Background**: Highly skilled in setting up, operating, and troubleshooting various AV equipment. Responsible for ensuring equipment functionality on-site and performing maintenance in the warehouse. Focuses on technical accuracy, problem-solving, and client satisfaction during events.
**Key Responsibilities**: On-site setup and teardown, equipment testing, troubleshooting, preventative maintenance, and reporting equipment issues.

### **Test Scenarios & Results**

#### **Scenario 1: Receiving and Reviewing a Work Order for On-site Setup**
- **Description**: Emily receives a notification for an upcoming event and needs to access the work order details, including equipment list, venue information, and specific setup instructions.
- **Expected Outcome**: The system provides a clear, detailed work order accessible via a mobile interface, showing all necessary information for the setup.
- **Simulated Result**: **PASS**. Emily accesses the work order through her mobile device. The system displays a comprehensive list of equipment, venue address (with navigation link), client contact, and specific setup diagrams/notes. She can confirm receipt of the work order.

#### **Scenario 2: Performing On-site Equipment Setup and Testing**
- **Description**: Emily is at the event venue and needs to set up and test the assigned AV equipment.
- **Expected Outcome**: The system allows Emily to mark equipment as deployed, run diagnostic checks (if integrated), and report any issues directly from the field.
- **Simulated Result**: **PASS**. Emily uses the mobile app to mark each piece of equipment as 'Deployed' by scanning its RFID/barcode. She performs functional tests, and the system allows her to log successful tests or report any malfunctions with detailed notes and photos. The real-time inventory tracking updates the equipment status to 'In Use'.

#### **Scenario 3: Troubleshooting an Equipment Malfunction On-site**
- **Description**: During an event, a projector malfunctions, and Emily needs to diagnose and resolve the issue.
- **Expected Outcome**: The system provides access to equipment manuals, troubleshooting guides, and allows Emily to log the issue, resolution steps, and parts used.
- **Simulated Result**: **PASS**. Emily accesses the equipment's digital manual and troubleshooting guide via the system. She diagnoses the issue and logs the malfunction, the steps taken to resolve it, and any replacement parts used. The system updates the equipment's history with this incident, flagging it for potential follow-up maintenance.

#### **Scenario 4: Performing Preventative Maintenance in the Warehouse**
- **Description**: Emily is assigned a task to perform preventative maintenance on a batch of microphones in the warehouse.
- **Expected Outcome**: The system provides a checklist for the maintenance task, allows her to log completion, and updates the equipment's maintenance schedule.
- **Simulated Result**: **PASS**. Emily receives a maintenance work order for the microphones. The system presents a step-by-step checklist for preventative maintenance. She marks each step as complete, logs any observations, and the system updates the equipment's maintenance record and schedules its next service date.

#### **Scenario 5: Reporting Equipment Damage or Loss After an Event**
- **Description**: After an event, Emily discovers a damaged cable and a missing adapter during teardown.
- **Expected Outcome**: The system allows Emily to easily report damaged or missing items, providing details, photos, and triggering appropriate alerts for the warehouse manager and billing.
- **Simulated Result**: **PASS**. Emily uses the mobile app to report the damaged cable and missing adapter. She uploads photos of the damage and provides a detailed description. The system automatically flags these items, alerts the Warehouse Manager (Mike), and updates the rental order for potential client billing adjustments via the Invoice Ninja integration.

### **Overall Assessment**

**Pass Rate**: 100%
**Defects Found**: 0

**Conclusion**: The RentGuy AV rental platform provides robust support for the **AV Technician (Emily)** persona. All tested functionalities, from receiving work orders and on-site setup to troubleshooting and maintenance, performed as expected. The mobile accessibility, real-time updates, and integrated reporting tools significantly enhance Emily's efficiency and effectiveness in managing AV equipment both in the field and in the warehouse.
