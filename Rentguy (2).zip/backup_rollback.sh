#!/bin/bash
# RentGuy Enterprise - Automated Backup and Rollback System
# Author: Manus AI
# Date: October 2025
# Phase: 1-2 Infrastructure and Repository Management

set -euo pipefail

# Configuration
BACKUP_DIR="/opt/rentguy/backups"
LOG_FILE="/var/log/rentguy/backup.log"
RETENTION_DAYS=30
ENCRYPTION_KEY="/secure/keys/backup.key"
NOTIFICATION_EMAIL="admin@sevensa.nl"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Error handling
error_exit() {
    echo -e "${RED}ERROR: $1${NC}" >&2
    log "ERROR: $1"
    send_notification "BACKUP ERROR" "$1"
    exit 1
}

# Success notification
success_msg() {
    echo -e "${GREEN}SUCCESS: $1${NC}"
    log "SUCCESS: $1"
}

# Warning notification
warning_msg() {
    echo -e "${YELLOW}WARNING: $1${NC}"
    log "WARNING: $1"
}

# Send notification
send_notification() {
    local subject="$1"
    local message="$2"
    echo "$message" | mail -s "RentGuy Enterprise - $subject" "$NOTIFICATION_EMAIL" 2>/dev/null || true
}

# Create backup directory structure
setup_backup_dirs() {
    mkdir -p "$BACKUP_DIR"/{database,application,config,logs}
    mkdir -p "$(dirname "$LOG_FILE")"
    chmod 700 "$BACKUP_DIR"
}

# Database backup
backup_database() {
    local backup_file="$BACKUP_DIR/database/postgres_$(date +%Y%m%d_%H%M%S).sql"
    local encrypted_file="${backup_file}.gpg"
    
    log "Starting database backup..."
    
    # Create database dump
    docker exec rentguy_postgres pg_dump -U rentguy rentguy_production > "$backup_file" || \
        error_exit "Failed to create database dump"
    
    # Encrypt backup
    gpg --cipher-algo AES256 --compress-algo 1 --symmetric --batch --yes \
        --passphrase-file "$ENCRYPTION_KEY" --output "$encrypted_file" "$backup_file" || \
        error_exit "Failed to encrypt database backup"
    
    # Remove unencrypted file
    rm "$backup_file"
    
    # Verify backup integrity
    gpg --decrypt --batch --yes --passphrase-file "$ENCRYPTION_KEY" "$encrypted_file" | head -n 1 > /dev/null || \
        error_exit "Backup integrity verification failed"
    
    success_msg "Database backup completed: $encrypted_file"
    echo "$encrypted_file"
}

# Application backup
backup_application() {
    local backup_file="$BACKUP_DIR/application/app_$(date +%Y%m%d_%H%M%S).tar.gz"
    local encrypted_file="${backup_file}.gpg"
    
    log "Starting application backup..."
    
    # Create application archive
    tar -czf "$backup_file" -C /opt/rentguy \
        --exclude='backups' \
        --exclude='logs' \
        --exclude='node_modules' \
        --exclude='.git' \
        . || error_exit "Failed to create application backup"
    
    # Encrypt backup
    gpg --cipher-algo AES256 --compress-algo 1 --symmetric --batch --yes \
        --passphrase-file "$ENCRYPTION_KEY" --output "$encrypted_file" "$backup_file" || \
        error_exit "Failed to encrypt application backup"
    
    # Remove unencrypted file
    rm "$backup_file"
    
    success_msg "Application backup completed: $encrypted_file"
    echo "$encrypted_file"
}

# Configuration backup
backup_configuration() {
    local backup_file="$BACKUP_DIR/config/config_$(date +%Y%m%d_%H%M%S).tar.gz"
    local encrypted_file="${backup_file}.gpg"
    
    log "Starting configuration backup..."
    
    # Create configuration archive
    tar -czf "$backup_file" \
        /etc/traefik/ \
        /etc/nginx/ \
        /etc/ssl/ \
        /opt/rentguy/docker-compose*.yml \
        /opt/rentguy/.env* \
        2>/dev/null || warning_msg "Some configuration files may not exist"
    
    # Encrypt backup
    gpg --cipher-algo AES256 --compress-algo 1 --symmetric --batch --yes \
        --passphrase-file "$ENCRYPTION_KEY" --output "$encrypted_file" "$backup_file" || \
        error_exit "Failed to encrypt configuration backup"
    
    # Remove unencrypted file
    rm "$backup_file"
    
    success_msg "Configuration backup completed: $encrypted_file"
    echo "$encrypted_file"
}

# Docker volumes backup
backup_volumes() {
    local backup_file="$BACKUP_DIR/application/volumes_$(date +%Y%m%d_%H%M%S).tar.gz"
    local encrypted_file="${backup_file}.gpg"
    
    log "Starting Docker volumes backup..."
    
    # Stop services temporarily for consistent backup
    docker-compose -f /opt/rentguy/docker-compose.production.yml stop || \
        warning_msg "Failed to stop services for backup"
    
    # Backup Docker volumes
    docker run --rm -v rentguy_postgres_data:/backup-source -v "$BACKUP_DIR/application":/backup-dest \
        alpine tar -czf /backup-dest/volumes_temp.tar.gz -C /backup-source . || \
        error_exit "Failed to backup Docker volumes"
    
    # Restart services
    docker-compose -f /opt/rentguy/docker-compose.production.yml up -d || \
        error_exit "Failed to restart services after backup"
    
    # Encrypt backup
    gpg --cipher-algo AES256 --compress-algo 1 --symmetric --batch --yes \
        --passphrase-file "$ENCRYPTION_KEY" --output "$encrypted_file" \
        "$BACKUP_DIR/application/volumes_temp.tar.gz" || \
        error_exit "Failed to encrypt volumes backup"
    
    # Remove temporary file
    rm "$BACKUP_DIR/application/volumes_temp.tar.gz"
    
    success_msg "Docker volumes backup completed: $encrypted_file"
    echo "$encrypted_file"
}

# Full system backup
full_backup() {
    log "Starting full system backup..."
    
    setup_backup_dirs
    
    local db_backup=$(backup_database)
    local app_backup=$(backup_application)
    local config_backup=$(backup_configuration)
    local volumes_backup=$(backup_volumes)
    
    # Create backup manifest
    local manifest_file="$BACKUP_DIR/backup_manifest_$(date +%Y%m%d_%H%M%S).json"
    cat > "$manifest_file" << EOF
{
    "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
    "version": "$(git -C /opt/rentguy rev-parse HEAD 2>/dev/null || echo 'unknown')",
    "backups": {
        "database": "$(basename "$db_backup")",
        "application": "$(basename "$app_backup")",
        "configuration": "$(basename "$config_backup")",
        "volumes": "$(basename "$volumes_backup")"
    },
    "system_info": {
        "hostname": "$(hostname)",
        "docker_version": "$(docker --version)",
        "compose_version": "$(docker-compose --version)"
    }
}
EOF
    
    success_msg "Full backup completed successfully"
    send_notification "BACKUP SUCCESS" "Full system backup completed at $(date)"
    
    # Cleanup old backups
    cleanup_old_backups
}

# Cleanup old backups
cleanup_old_backups() {
    log "Cleaning up backups older than $RETENTION_DAYS days..."
    
    find "$BACKUP_DIR" -type f -name "*.gpg" -mtime +$RETENTION_DAYS -delete
    find "$BACKUP_DIR" -type f -name "*.json" -mtime +$RETENTION_DAYS -delete
    
    success_msg "Backup cleanup completed"
}

# List available backups
list_backups() {
    echo "Available backups:"
    echo "=================="
    
    for manifest in "$BACKUP_DIR"/backup_manifest_*.json; do
        if [[ -f "$manifest" ]]; then
            local timestamp=$(jq -r '.timestamp' "$manifest" 2>/dev/null || echo "unknown")
            local version=$(jq -r '.version' "$manifest" 2>/dev/null || echo "unknown")
            echo "Backup: $(basename "$manifest" .json)"
            echo "  Timestamp: $timestamp"
            echo "  Version: $version"
            echo ""
        fi
    done
}

# Restore from backup
restore_backup() {
    local manifest_file="$1"
    
    if [[ ! -f "$manifest_file" ]]; then
        error_exit "Backup manifest not found: $manifest_file"
    fi
    
    log "Starting restore from backup: $manifest_file"
    
    # Parse manifest
    local db_backup=$(jq -r '.backups.database' "$manifest_file")
    local app_backup=$(jq -r '.backups.application' "$manifest_file")
    local config_backup=$(jq -r '.backups.configuration' "$manifest_file")
    local volumes_backup=$(jq -r '.backups.volumes' "$manifest_file")
    
    # Confirm restore operation
    echo -e "${YELLOW}WARNING: This will restore the system to a previous state.${NC}"
    echo "Backup timestamp: $(jq -r '.timestamp' "$manifest_file")"
    echo "Are you sure you want to continue? (yes/no)"
    read -r confirmation
    
    if [[ "$confirmation" != "yes" ]]; then
        log "Restore operation cancelled by user"
        exit 0
    fi
    
    # Stop services
    log "Stopping services..."
    docker-compose -f /opt/rentguy/docker-compose.production.yml down || \
        warning_msg "Failed to stop some services"
    
    # Restore database
    if [[ "$db_backup" != "null" && -f "$BACKUP_DIR/database/$db_backup" ]]; then
        log "Restoring database..."
        
        # Decrypt and restore database
        gpg --decrypt --batch --yes --passphrase-file "$ENCRYPTION_KEY" \
            "$BACKUP_DIR/database/$db_backup" | \
            docker exec -i rentguy_postgres psql -U rentguy -d rentguy_production || \
            error_exit "Failed to restore database"
        
        success_msg "Database restored successfully"
    fi
    
    # Restore application
    if [[ "$app_backup" != "null" && -f "$BACKUP_DIR/application/$app_backup" ]]; then
        log "Restoring application..."
        
        # Create temporary directory
        local temp_dir=$(mktemp -d)
        
        # Decrypt and extract application
        gpg --decrypt --batch --yes --passphrase-file "$ENCRYPTION_KEY" \
            "$BACKUP_DIR/application/$app_backup" | \
            tar -xzf - -C "$temp_dir" || \
            error_exit "Failed to decrypt/extract application backup"
        
        # Replace application files
        rsync -av --delete "$temp_dir/" /opt/rentguy/ || \
            error_exit "Failed to restore application files"
        
        # Cleanup
        rm -rf "$temp_dir"
        
        success_msg "Application restored successfully"
    fi
    
    # Restore configuration
    if [[ "$config_backup" != "null" && -f "$BACKUP_DIR/config/$config_backup" ]]; then
        log "Restoring configuration..."
        
        # Decrypt and extract configuration
        gpg --decrypt --batch --yes --passphrase-file "$ENCRYPTION_KEY" \
            "$BACKUP_DIR/config/$config_backup" | \
            tar -xzf - -C / || \
            warning_msg "Some configuration files may not have been restored"
        
        success_msg "Configuration restored successfully"
    fi
    
    # Start services
    log "Starting services..."
    docker-compose -f /opt/rentguy/docker-compose.production.yml up -d || \
        error_exit "Failed to start services after restore"
    
    # Wait for services to be healthy
    sleep 30
    
    # Verify services
    if docker-compose -f /opt/rentguy/docker-compose.production.yml ps | grep -q "Up"; then
        success_msg "Restore completed successfully"
        send_notification "RESTORE SUCCESS" "System restored from backup: $manifest_file"
    else
        error_exit "Services failed to start after restore"
    fi
}

# Health check
health_check() {
    log "Performing system health check..."
    
    local issues=0
    
    # Check Docker services
    if ! docker-compose -f /opt/rentguy/docker-compose.production.yml ps | grep -q "Up"; then
        warning_msg "Some Docker services are not running"
        ((issues++))
    fi
    
    # Check disk space
    local disk_usage=$(df /opt/rentguy | awk 'NR==2 {print $5}' | sed 's/%//')
    if [[ $disk_usage -gt 80 ]]; then
        warning_msg "Disk usage is high: ${disk_usage}%"
        ((issues++))
    fi
    
    # Check backup directory
    if [[ ! -d "$BACKUP_DIR" ]]; then
        warning_msg "Backup directory does not exist"
        ((issues++))
    fi
    
    # Check encryption key
    if [[ ! -f "$ENCRYPTION_KEY" ]]; then
        warning_msg "Encryption key not found"
        ((issues++))
    fi
    
    if [[ $issues -eq 0 ]]; then
        success_msg "System health check passed"
    else
        warning_msg "Health check completed with $issues issues"
    fi
    
    return $issues
}

# Main function
main() {
    case "${1:-}" in
        "backup")
            full_backup
            ;;
        "restore")
            if [[ -z "${2:-}" ]]; then
                echo "Usage: $0 restore <manifest_file>"
                list_backups
                exit 1
            fi
            restore_backup "$2"
            ;;
        "list")
            list_backups
            ;;
        "cleanup")
            cleanup_old_backups
            ;;
        "health")
            health_check
            ;;
        *)
            echo "RentGuy Enterprise Backup & Rollback System"
            echo "Usage: $0 {backup|restore|list|cleanup|health}"
            echo ""
            echo "Commands:"
            echo "  backup          - Create full system backup"
            echo "  restore <file>  - Restore from backup manifest"
            echo "  list           - List available backups"
            echo "  cleanup        - Remove old backups"
            echo "  health         - Perform system health check"
            exit 1
            ;;
    esac
}

# Run main function
main "$@"
