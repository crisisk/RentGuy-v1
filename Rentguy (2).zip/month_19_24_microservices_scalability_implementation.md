# Month 19-24 Implementation: Microservices & Scalability for RentGuy AV Rental Platform

## Overview
This document provides comprehensive implementations for the Month 19-24 roadmap tasks focusing on Microservices Architecture and Scalability features specifically designed for the RentGuy AV rental platform. These implementations enable distributed system architecture, auto-scaling capabilities, service resilience, and enterprise-grade scalability for AV rental operations.

## 1. Service Decomposition & Microservices Architecture

### Core Service Definitions

```python
# services/service_registry.py
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum
import asyncio
import aiohttp
import json

class ServiceStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    OFFLINE = "offline"

@dataclass
class ServiceInstance:
    service_id: str
    service_name: str
    version: str
    host: str
    port: int
    health_endpoint: str
    status: ServiceStatus
    last_heartbeat: datetime
    metadata: Dict[str, Any]
    load_factor: float = 0.0
    response_time: float = 0.0

@dataclass
class ServiceDependency:
    service_name: str
    dependency_name: str
    dependency_type: str  # required, optional, fallback
    timeout_ms: int
    retry_count: int
    circuit_breaker_enabled: bool

class ServiceRegistry:
    def __init__(self):
        self.services = {}
        self.dependencies = {}
        self.health_checks = {}
        self.load_balancer = LoadBalancer()
        self.circuit_breakers = {}
    
    async def register_service(self, service: ServiceInstance) -> bool:
        """Register a new service instance"""
        try:
            service_key = f"{service.service_name}:{service.service_id}"
            
            # Validate service health
            health_status = await self._check_service_health(service)
            service.status = health_status
            service.last_heartbeat = datetime.utcnow()
            
            # Store service
            if service.service_name not in self.services:
                self.services[service.service_name] = []
            
            # Remove existing instance if re-registering
            self.services[service.service_name] = [
                s for s in self.services[service.service_name] 
                if s.service_id != service.service_id
            ]
            
            self.services[service.service_name].append(service)
            
            print(f"Service registered: {service.service_name} ({service.service_id})")
            return True
            
        except Exception as e:
            print(f"Failed to register service {service.service_name}: {e}")
            return False
    
    async def deregister_service(self, service_name: str, service_id: str) -> bool:
        """Deregister a service instance"""
        try:
            if service_name in self.services:
                self.services[service_name] = [
                    s for s in self.services[service_name] 
                    if s.service_id != service_id
                ]
                
                if not self.services[service_name]:
                    del self.services[service_name]
                
                print(f"Service deregistered: {service_name} ({service_id})")
                return True
            
            return False
            
        except Exception as e:
            print(f"Failed to deregister service {service_name}: {e}")
            return False
    
    async def discover_service(self, service_name: str) -> Optional[ServiceInstance]:
        """Discover and return a healthy service instance"""
        if service_name not in self.services:
            return None
        
        healthy_services = [
            s for s in self.services[service_name] 
            if s.status == ServiceStatus.HEALTHY
        ]
        
        if not healthy_services:
            # Try degraded services as fallback
            healthy_services = [
                s for s in self.services[service_name] 
                if s.status == ServiceStatus.DEGRADED
            ]
        
        if not healthy_services:
            return None
        
        # Use load balancer to select instance
        return self.load_balancer.select_instance(healthy_services)
    
    async def _check_service_health(self, service: ServiceInstance) -> ServiceStatus:
        """Check health of a service instance"""
        try:
            health_url = f"http://{service.host}:{service.port}{service.health_endpoint}"
            
            async with aiohttp.ClientSession() as session:
                async with session.get(health_url, timeout=aiohttp.ClientTimeout(total=5)) as response:
                    if response.status == 200:
                        health_data = await response.json()
                        
                        if health_data.get("status") == "healthy":
                            return ServiceStatus.HEALTHY
                        elif health_data.get("status") == "degraded":
                            return ServiceStatus.DEGRADED
                        else:
                            return ServiceStatus.UNHEALTHY
                    else:
                        return ServiceStatus.UNHEALTHY
                        
        except Exception as e:
            print(f"Health check failed for {service.service_name}: {e}")
            return ServiceStatus.OFFLINE
    
    async def start_health_monitoring(self, interval_seconds: int = 30):
        """Start continuous health monitoring of all services"""
        while True:
            try:
                for service_name, instances in self.services.items():
                    for service in instances:
                        # Check health
                        old_status = service.status
                        service.status = await self._check_service_health(service)
                        service.last_heartbeat = datetime.utcnow()
                        
                        # Log status changes
                        if old_status != service.status:
                            print(f"Service {service_name} ({service.service_id}) status changed: {old_status.value} -> {service.status.value}")
                
                await asyncio.sleep(interval_seconds)
                
            except Exception as e:
                print(f"Error in health monitoring: {e}")
                await asyncio.sleep(interval_seconds)
    
    def get_service_topology(self) -> Dict[str, Any]:
        """Get complete service topology and dependencies"""
        topology = {
            "services": {},
            "dependencies": self.dependencies,
            "health_summary": {
                "total_services": 0,
                "healthy_services": 0,
                "degraded_services": 0,
                "unhealthy_services": 0,
                "offline_services": 0
            }
        }
        
        for service_name, instances in self.services.items():
            topology["services"][service_name] = {
                "instances": [asdict(instance) for instance in instances],
                "instance_count": len(instances),
                "healthy_instances": len([s for s in instances if s.status == ServiceStatus.HEALTHY])
            }
            
            # Update health summary
            topology["health_summary"]["total_services"] += len(instances)
            for instance in instances:
                if instance.status == ServiceStatus.HEALTHY:
                    topology["health_summary"]["healthy_services"] += 1
                elif instance.status == ServiceStatus.DEGRADED:
                    topology["health_summary"]["degraded_services"] += 1
                elif instance.status == ServiceStatus.UNHEALTHY:
                    topology["health_summary"]["unhealthy_services"] += 1
                else:
                    topology["health_summary"]["offline_services"] += 1
        
        return topology

class LoadBalancer:
    def __init__(self, strategy: str = "round_robin"):
        self.strategy = strategy
        self.round_robin_counters = {}
    
    def select_instance(self, instances: List[ServiceInstance]) -> Optional[ServiceInstance]:
        """Select service instance based on load balancing strategy"""
        if not instances:
            return None
        
        if self.strategy == "round_robin":
            return self._round_robin_selection(instances)
        elif self.strategy == "least_connections":
            return self._least_connections_selection(instances)
        elif self.strategy == "weighted_response_time":
            return self._weighted_response_time_selection(instances)
        else:
            return instances[0]  # Default to first instance
    
    def _round_robin_selection(self, instances: List[ServiceInstance]) -> ServiceInstance:
        """Round-robin load balancing"""
        service_name = instances[0].service_name
        
        if service_name not in self.round_robin_counters:
            self.round_robin_counters[service_name] = 0
        
        selected_index = self.round_robin_counters[service_name] % len(instances)
        self.round_robin_counters[service_name] += 1
        
        return instances[selected_index]
    
    def _least_connections_selection(self, instances: List[ServiceInstance]) -> ServiceInstance:
        """Select instance with least connections (using load_factor as proxy)"""
        return min(instances, key=lambda x: x.load_factor)
    
    def _weighted_response_time_selection(self, instances: List[ServiceInstance]) -> ServiceInstance:
        """Select instance with best response time"""
        return min(instances, key=lambda x: x.response_time)
```

### AV Rental Microservices Definition

```python
# services/av_rental_services.py
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import asyncio
import aiohttp
import json

# Define AV Rental specific microservices
AV_RENTAL_SERVICES = {
    "equipment-catalog-service": {
        "description": "Manages AV equipment catalog, specifications, and availability",
        "endpoints": [
            "/api/v1/equipment",
            "/api/v1/equipment/{id}",
            "/api/v1/equipment/search",
            "/api/v1/categories"
        ],
        "dependencies": ["inventory-service", "pricing-service"],
        "database": "equipment_catalog_db",
        "cache_layer": True
    },
    
    "inventory-service": {
        "description": "Real-time inventory tracking and management",
        "endpoints": [
            "/api/v1/inventory",
            "/api/v1/inventory/{equipment_id}",
            "/api/v1/inventory/availability",
            "/api/v1/inventory/reservations"
        ],
        "dependencies": ["equipment-catalog-service", "warehouse-service"],
        "database": "inventory_db",
        "real_time": True
    },
    
    "booking-service": {
        "description": "Handles rental bookings, reservations, and scheduling",
        "endpoints": [
            "/api/v1/bookings",
            "/api/v1/bookings/{id}",
            "/api/v1/bookings/calendar",
            "/api/v1/bookings/conflicts"
        ],
        "dependencies": ["inventory-service", "customer-service", "pricing-service"],
        "database": "bookings_db",
        "event_driven": True
    },
    
    "customer-service": {
        "description": "Customer management, profiles, and preferences",
        "endpoints": [
            "/api/v1/customers",
            "/api/v1/customers/{id}",
            "/api/v1/customers/{id}/history",
            "/api/v1/customers/{id}/preferences"
        ],
        "dependencies": ["auth-service"],
        "database": "customers_db",
        "gdpr_compliant": True
    },
    
    "pricing-service": {
        "description": "Dynamic pricing, packages, and discount management",
        "endpoints": [
            "/api/v1/pricing/calculate",
            "/api/v1/pricing/packages",
            "/api/v1/pricing/discounts",
            "/api/v1/pricing/quotes"
        ],
        "dependencies": ["equipment-catalog-service", "booking-service"],
        "database": "pricing_db",
        "cache_layer": True
    },
    
    "warehouse-service": {
        "description": "Warehouse operations, logistics, and equipment tracking",
        "endpoints": [
            "/api/v1/warehouse/locations",
            "/api/v1/warehouse/movements",
            "/api/v1/warehouse/picking",
            "/api/v1/warehouse/returns"
        ],
        "dependencies": ["inventory-service", "booking-service"],
        "database": "warehouse_db",
        "iot_integration": True
    },
    
    "delivery-service": {
        "description": "Delivery scheduling, route optimization, and tracking",
        "endpoints": [
            "/api/v1/deliveries",
            "/api/v1/deliveries/{id}/track",
            "/api/v1/deliveries/routes",
            "/api/v1/deliveries/schedule"
        ],
        "dependencies": ["booking-service", "warehouse-service"],
        "database": "deliveries_db",
        "gps_tracking": True
    },
    
    "billing-service": {
        "description": "Invoice generation, payment processing, and financial tracking",
        "endpoints": [
            "/api/v1/invoices",
            "/api/v1/payments",
            "/api/v1/billing/statements",
            "/api/v1/billing/reconciliation"
        ],
        "dependencies": ["booking-service", "customer-service", "pricing-service"],
        "database": "billing_db",
        "payment_integration": True
    },
    
    "maintenance-service": {
        "description": "Equipment maintenance scheduling and tracking",
        "endpoints": [
            "/api/v1/maintenance/schedules",
            "/api/v1/maintenance/work-orders",
            "/api/v1/maintenance/history",
            "/api/v1/maintenance/alerts"
        ],
        "dependencies": ["equipment-catalog-service", "inventory-service"],
        "database": "maintenance_db",
        "predictive_analytics": True
    },
    
    "notification-service": {
        "description": "Multi-channel notifications and communication",
        "endpoints": [
            "/api/v1/notifications/send",
            "/api/v1/notifications/templates",
            "/api/v1/notifications/preferences",
            "/api/v1/notifications/history"
        ],
        "dependencies": ["customer-service"],
        "database": "notifications_db",
        "multi_channel": True
    },
    
    "analytics-service": {
        "description": "Business intelligence, reporting, and analytics",
        "endpoints": [
            "/api/v1/analytics/dashboards",
            "/api/v1/analytics/reports",
            "/api/v1/analytics/metrics",
            "/api/v1/analytics/forecasts"
        ],
        "dependencies": ["booking-service", "inventory-service", "billing-service"],
        "database": "analytics_db",
        "big_data": True
    },
    
    "auth-service": {
        "description": "Authentication, authorization, and user management",
        "endpoints": [
            "/api/v1/auth/login",
            "/api/v1/auth/logout",
            "/api/v1/auth/refresh",
            "/api/v1/users"
        ],
        "dependencies": [],
        "database": "auth_db",
        "security_critical": True
    }
}

class MicroserviceOrchestrator:
    def __init__(self, service_registry: ServiceRegistry):
        self.service_registry = service_registry
        self.service_mesh = ServiceMesh()
        self.deployment_manager = DeploymentManager()
    
    async def deploy_av_rental_services(self) -> Dict[str, Any]:
        """Deploy all AV rental microservices"""
        deployment_results = {}
        
        for service_name, config in AV_RENTAL_SERVICES.items():
            try:
                # Create service instance
                service_instance = ServiceInstance(
                    service_id=f"{service_name}-001",
                    service_name=service_name,
                    version="1.0.0",
                    host="localhost",
                    port=8000 + len(deployment_results),  # Dynamic port assignment
                    health_endpoint="/health",
                    status=ServiceStatus.OFFLINE,
                    last_heartbeat=datetime.utcnow(),
                    metadata=config
                )
                
                # Deploy service (mock deployment)
                deployment_result = await self.deployment_manager.deploy_service(
                    service_instance, config
                )
                
                if deployment_result["success"]:
                    # Register with service registry
                    await self.service_registry.register_service(service_instance)
                    deployment_results[service_name] = {
                        "status": "deployed",
                        "instance_id": service_instance.service_id,
                        "port": service_instance.port,
                        "endpoints": config.get("endpoints", [])
                    }
                else:
                    deployment_results[service_name] = {
                        "status": "failed",
                        "error": deployment_result.get("error", "Unknown error")
                    }
                    
            except Exception as e:
                deployment_results[service_name] = {
                    "status": "failed",
                    "error": str(e)
                }
        
        return {
            "deployment_summary": {
                "total_services": len(AV_RENTAL_SERVICES),
                "successful_deployments": len([r for r in deployment_results.values() if r["status"] == "deployed"]),
                "failed_deployments": len([r for r in deployment_results.values() if r["status"] == "failed"])
            },
            "service_details": deployment_results,
            "deployed_at": datetime.utcnow().isoformat()
        }
    
    async def create_service_dependencies(self) -> Dict[str, Any]:
        """Create and configure service dependencies"""
        dependencies = {}
        
        for service_name, config in AV_RENTAL_SERVICES.items():
            service_deps = []
            
            for dep_name in config.get("dependencies", []):
                dependency = ServiceDependency(
                    service_name=service_name,
                    dependency_name=dep_name,
                    dependency_type="required",
                    timeout_ms=5000,
                    retry_count=3,
                    circuit_breaker_enabled=True
                )
                service_deps.append(dependency)
            
            dependencies[service_name] = service_deps
        
        # Store dependencies in registry
        self.service_registry.dependencies = dependencies
        
        return {
            "dependencies_created": len(dependencies),
            "total_dependency_relationships": sum(len(deps) for deps in dependencies.values()),
            "dependency_graph": dependencies
        }

class ServiceMesh:
    def __init__(self):
        self.traffic_policies = {}
        self.security_policies = {}
        self.observability_config = {}
    
    async def configure_traffic_management(self) -> Dict[str, Any]:
        """Configure traffic management policies"""
        
        # Load balancing policies
        load_balancing_policies = {
            "equipment-catalog-service": {
                "algorithm": "round_robin",
                "health_check": {"interval": "30s", "timeout": "5s"},
                "circuit_breaker": {"failure_threshold": 5, "recovery_time": "30s"}
            },
            "inventory-service": {
                "algorithm": "least_connections",
                "health_check": {"interval": "10s", "timeout": "3s"},
                "circuit_breaker": {"failure_threshold": 3, "recovery_time": "15s"}
            },
            "booking-service": {
                "algorithm": "weighted_response_time",
                "health_check": {"interval": "15s", "timeout": "5s"},
                "circuit_breaker": {"failure_threshold": 5, "recovery_time": "30s"}
            }
        }
        
        # Rate limiting policies
        rate_limiting_policies = {
            "global": {"requests_per_minute": 1000, "burst_size": 100},
            "per_service": {
                "booking-service": {"requests_per_minute": 200, "burst_size": 20},
                "pricing-service": {"requests_per_minute": 500, "burst_size": 50},
                "auth-service": {"requests_per_minute": 100, "burst_size": 10}
            }
        }
        
        # Timeout policies
        timeout_policies = {
            "default": {"request_timeout": "30s", "idle_timeout": "60s"},
            "critical_services": {
                "auth-service": {"request_timeout": "10s", "idle_timeout": "30s"},
                "inventory-service": {"request_timeout": "15s", "idle_timeout": "45s"}
            }
        }
        
        self.traffic_policies = {
            "load_balancing": load_balancing_policies,
            "rate_limiting": rate_limiting_policies,
            "timeouts": timeout_policies
        }
        
        return {
            "traffic_management_configured": True,
            "policies": self.traffic_policies,
            "configured_at": datetime.utcnow().isoformat()
        }
    
    async def configure_security_policies(self) -> Dict[str, Any]:
        """Configure service mesh security policies"""
        
        # mTLS policies
        mtls_policies = {
            "mode": "strict",
            "certificate_rotation": "24h",
            "allowed_services": {
                "auth-service": ["customer-service", "booking-service"],
                "inventory-service": ["booking-service", "warehouse-service"],
                "billing-service": ["booking-service", "customer-service"]
            }
        }
        
        # Authorization policies
        authorization_policies = {
            "rbac_enabled": True,
            "service_permissions": {
                "booking-service": {
                    "can_access": ["inventory-service", "customer-service", "pricing-service"],
                    "methods": ["GET", "POST", "PUT"],
                    "rate_limit": "100/min"
                },
                "analytics-service": {
                    "can_access": ["booking-service", "inventory-service", "billing-service"],
                    "methods": ["GET"],
                    "rate_limit": "50/min"
                }
            }
        }
        
        self.security_policies = {
            "mtls": mtls_policies,
            "authorization": authorization_policies
        }
        
        return {
            "security_policies_configured": True,
            "policies": self.security_policies,
            "configured_at": datetime.utcnow().isoformat()
        }

class DeploymentManager:
    def __init__(self):
        self.deployment_strategies = {
            "blue_green": BlueGreenDeployment(),
            "canary": CanaryDeployment(),
            "rolling": RollingDeployment()
        }
    
    async def deploy_service(
        self, 
        service: ServiceInstance, 
        config: Dict[str, Any],
        strategy: str = "rolling"
    ) -> Dict[str, Any]:
        """Deploy a service using specified strategy"""
        
        try:
            if strategy not in self.deployment_strategies:
                strategy = "rolling"
            
            deployment_strategy = self.deployment_strategies[strategy]
            
            # Mock deployment process
            deployment_steps = [
                "Validating service configuration",
                "Building service container",
                "Running health checks",
                "Deploying to target environment",
                "Verifying deployment",
                "Updating service registry"
            ]
            
            for step in deployment_steps:
                print(f"[{service.service_name}] {step}...")
                await asyncio.sleep(0.1)  # Simulate deployment time
            
            # Simulate deployment success/failure
            success_rate = 0.95  # 95% success rate
            import random
            success = random.random() < success_rate
            
            if success:
                return {
                    "success": True,
                    "service_id": service.service_id,
                    "deployment_strategy": strategy,
                    "deployed_at": datetime.utcnow().isoformat(),
                    "health_status": "healthy"
                }
            else:
                return {
                    "success": False,
                    "error": "Deployment failed during health check validation",
                    "service_id": service.service_id
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "service_id": service.service_id
            }
```

## 2. Event-Driven Architecture

### Event Bus Implementation

```python
# services/event_bus.py
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
from enum import Enum
import asyncio
import json
import uuid
from abc import ABC, abstractmethod

class EventType(Enum):
    EQUIPMENT_RESERVED = "equipment.reserved"
    EQUIPMENT_RETURNED = "equipment.returned"
    BOOKING_CREATED = "booking.created"
    BOOKING_CANCELLED = "booking.cancelled"
    PAYMENT_PROCESSED = "payment.processed"
    DELIVERY_SCHEDULED = "delivery.scheduled"
    MAINTENANCE_REQUIRED = "maintenance.required"
    CUSTOMER_REGISTERED = "customer.registered"
    INVENTORY_UPDATED = "inventory.updated"
    NOTIFICATION_SENT = "notification.sent"

@dataclass
class Event:
    event_id: str
    event_type: EventType
    source_service: str
    timestamp: datetime
    data: Dict[str, Any]
    correlation_id: Optional[str] = None
    causation_id: Optional[str] = None
    version: str = "1.0"
    metadata: Optional[Dict[str, Any]] = None

@dataclass
class EventSubscription:
    subscription_id: str
    service_name: str
    event_types: List[EventType]
    callback_url: str
    filter_conditions: Optional[Dict[str, Any]] = None
    retry_policy: Optional[Dict[str, Any]] = None
    dead_letter_queue: bool = True

class EventBus:
    def __init__(self):
        self.subscriptions = {}
        self.event_store = EventStore()
        self.message_broker = MessageBroker()
        self.event_handlers = {}
        self.dead_letter_queue = []
    
    async def publish_event(self, event: Event) -> bool:
        """Publish an event to all subscribers"""
        try:
            # Store event
            await self.event_store.store_event(event)
            
            # Find subscribers
            subscribers = self._find_subscribers(event.event_type)
            
            # Publish to message broker
            await self.message_broker.publish(event, subscribers)
            
            # Process local handlers
            await self._process_local_handlers(event)
            
            print(f"Event published: {event.event_type.value} from {event.source_service}")
            return True
            
        except Exception as e:
            print(f"Failed to publish event {event.event_id}: {e}")
            return False
    
    async def subscribe(self, subscription: EventSubscription) -> bool:
        """Subscribe a service to specific event types"""
        try:
            subscription_key = f"{subscription.service_name}:{subscription.subscription_id}"
            self.subscriptions[subscription_key] = subscription
            
            # Register with message broker
            await self.message_broker.subscribe(subscription)
            
            print(f"Service {subscription.service_name} subscribed to {len(subscription.event_types)} event types")
            return True
            
        except Exception as e:
            print(f"Failed to create subscription for {subscription.service_name}: {e}")
            return False
    
    async def unsubscribe(self, service_name: str, subscription_id: str) -> bool:
        """Unsubscribe a service from events"""
        try:
            subscription_key = f"{service_name}:{subscription_id}"
            
            if subscription_key in self.subscriptions:
                subscription = self.subscriptions[subscription_key]
                
                # Unregister from message broker
                await self.message_broker.unsubscribe(subscription)
                
                # Remove subscription
                del self.subscriptions[subscription_key]
                
                print(f"Service {service_name} unsubscribed")
                return True
            
            return False
            
        except Exception as e:
            print(f"Failed to unsubscribe {service_name}: {e}")
            return False
    
    def _find_subscribers(self, event_type: EventType) -> List[EventSubscription]:
        """Find all subscribers for a specific event type"""
        subscribers = []
        
        for subscription in self.subscriptions.values():
            if event_type in subscription.event_types:
                subscribers.append(subscription)
        
        return subscribers
    
    async def _process_local_handlers(self, event: Event):
        """Process local event handlers"""
        if event.event_type in self.event_handlers:
            handlers = self.event_handlers[event.event_type]
            
            for handler in handlers:
                try:
                    await handler(event)
                except Exception as e:
                    print(f"Error in event handler: {e}")
    
    def register_handler(self, event_type: EventType, handler: Callable):
        """Register a local event handler"""
        if event_type not in self.event_handlers:
            self.event_handlers[event_type] = []
        
        self.event_handlers[event_type].append(handler)
    
    async def replay_events(
        self, 
        service_name: str, 
        from_timestamp: datetime,
        event_types: Optional[List[EventType]] = None
    ) -> List[Event]:
        """Replay events for a service from a specific timestamp"""
        
        events = await self.event_store.get_events(
            from_timestamp=from_timestamp,
            event_types=event_types
        )
        
        # Find service subscriptions
        service_subscriptions = [
            sub for sub in self.subscriptions.values() 
            if sub.service_name == service_name
        ]
        
        replayed_events = []
        
        for event in events:
            # Check if service should receive this event
            for subscription in service_subscriptions:
                if event.event_type in subscription.event_types:
                    # Send event to service
                    await self.message_broker.send_to_service(event, subscription)
                    replayed_events.append(event)
                    break
        
        return replayed_events

class EventStore:
    def __init__(self):
        self.events = []
        self.event_index = {}
    
    async def store_event(self, event: Event):
        """Store an event in the event store"""
        self.events.append(event)
        
        # Index by event type
        if event.event_type not in self.event_index:
            self.event_index[event.event_type] = []
        
        self.event_index[event.event_type].append(event)
        
        # Keep only last 10000 events (in production, use persistent storage)
        if len(self.events) > 10000:
            self.events = self.events[-10000:]
    
    async def get_events(
        self, 
        from_timestamp: datetime,
        to_timestamp: Optional[datetime] = None,
        event_types: Optional[List[EventType]] = None
    ) -> List[Event]:
        """Retrieve events based on criteria"""
        
        filtered_events = []
        
        for event in self.events:
            # Time filter
            if event.timestamp < from_timestamp:
                continue
            
            if to_timestamp and event.timestamp > to_timestamp:
                continue
            
            # Event type filter
            if event_types and event.event_type not in event_types:
                continue
            
            filtered_events.append(event)
        
        return sorted(filtered_events, key=lambda x: x.timestamp)
    
    async def get_event_stream(self, correlation_id: str) -> List[Event]:
        """Get all events for a specific correlation ID"""
        return [
            event for event in self.events 
            if event.correlation_id == correlation_id
        ]

class MessageBroker:
    def __init__(self):
        self.queues = {}
        self.subscribers = {}
    
    async def publish(self, event: Event, subscribers: List[EventSubscription]):
        """Publish event to subscribers"""
        for subscriber in subscribers:
            try:
                # Apply filters if any
                if self._passes_filter(event, subscriber.filter_conditions):
                    await self._deliver_event(event, subscriber)
                    
            except Exception as e:
                print(f"Failed to deliver event to {subscriber.service_name}: {e}")
                await self._handle_delivery_failure(event, subscriber, str(e))
    
    async def subscribe(self, subscription: EventSubscription):
        """Subscribe to events"""
        for event_type in subscription.event_types:
            if event_type not in self.subscribers:
                self.subscribers[event_type] = []
            
            self.subscribers[event_type].append(subscription)
    
    async def unsubscribe(self, subscription: EventSubscription):
        """Unsubscribe from events"""
        for event_type in subscription.event_types:
            if event_type in self.subscribers:
                self.subscribers[event_type] = [
                    sub for sub in self.subscribers[event_type]
                    if sub.subscription_id != subscription.subscription_id
                ]
    
    def _passes_filter(self, event: Event, filter_conditions: Optional[Dict[str, Any]]) -> bool:
        """Check if event passes filter conditions"""
        if not filter_conditions:
            return True
        
        # Simple filter implementation
        for key, expected_value in filter_conditions.items():
            if key in event.data:
                if event.data[key] != expected_value:
                    return False
            elif key in event.metadata:
                if event.metadata[key] != expected_value:
                    return False
        
        return True
    
    async def _deliver_event(self, event: Event, subscriber: EventSubscription):
        """Deliver event to subscriber"""
        # In real implementation, this would make HTTP call to callback_url
        # For now, we'll simulate delivery
        
        delivery_payload = {
            "event": asdict(event),
            "subscription_id": subscriber.subscription_id,
            "delivered_at": datetime.utcnow().isoformat()
        }
        
        print(f"Delivering event {event.event_type.value} to {subscriber.service_name}")
        
        # Simulate delivery success/failure
        import random
        if random.random() < 0.95:  # 95% success rate
            return True
        else:
            raise Exception("Simulated delivery failure")
    
    async def _handle_delivery_failure(
        self, 
        event: Event, 
        subscriber: EventSubscription, 
        error: str
    ):
        """Handle event delivery failure"""
        
        retry_policy = subscriber.retry_policy or {
            "max_retries": 3,
            "retry_delay": 5,
            "exponential_backoff": True
        }
        
        # In real implementation, implement retry logic
        print(f"Event delivery failed for {subscriber.service_name}: {error}")
        
        if subscriber.dead_letter_queue:
            # Add to dead letter queue
            dead_letter_event = {
                "original_event": asdict(event),
                "subscriber": asdict(subscriber),
                "error": error,
                "failed_at": datetime.utcnow().isoformat()
            }
            # Store in dead letter queue (implementation depends on message broker)
    
    async def send_to_service(self, event: Event, subscription: EventSubscription):
        """Send event directly to a specific service"""
        await self._deliver_event(event, subscription)

# AV Rental Event Handlers
class AVRentalEventHandlers:
    def __init__(self, event_bus: EventBus):
        self.event_bus = event_bus
        self._register_handlers()
    
    def _register_handlers(self):
        """Register all AV rental event handlers"""
        
        # Equipment events
        self.event_bus.register_handler(EventType.EQUIPMENT_RESERVED, self.handle_equipment_reserved)
        self.event_bus.register_handler(EventType.EQUIPMENT_RETURNED, self.handle_equipment_returned)
        
        # Booking events
        self.event_bus.register_handler(EventType.BOOKING_CREATED, self.handle_booking_created)
        self.event_bus.register_handler(EventType.BOOKING_CANCELLED, self.handle_booking_cancelled)
        
        # Payment events
        self.event_bus.register_handler(EventType.PAYMENT_PROCESSED, self.handle_payment_processed)
        
        # Inventory events
        self.event_bus.register_handler(EventType.INVENTORY_UPDATED, self.handle_inventory_updated)
    
    async def handle_equipment_reserved(self, event: Event):
        """Handle equipment reservation event"""
        equipment_id = event.data.get("equipment_id")
        booking_id = event.data.get("booking_id")
        
        print(f"Equipment {equipment_id} reserved for booking {booking_id}")
        
        # Update inventory
        inventory_event = Event(
            event_id=str(uuid.uuid4()),
            event_type=EventType.INVENTORY_UPDATED,
            source_service="inventory-service",
            timestamp=datetime.utcnow(),
            data={
                "equipment_id": equipment_id,
                "status": "reserved",
                "booking_id": booking_id
            },
            correlation_id=event.correlation_id
        )
        
        await self.event_bus.publish_event(inventory_event)
    
    async def handle_equipment_returned(self, event: Event):
        """Handle equipment return event"""
        equipment_id = event.data.get("equipment_id")
        booking_id = event.data.get("booking_id")
        condition = event.data.get("condition", "good")
        
        print(f"Equipment {equipment_id} returned from booking {booking_id} in {condition} condition")
        
        # Check if maintenance is required
        if condition in ["damaged", "needs_maintenance"]:
            maintenance_event = Event(
                event_id=str(uuid.uuid4()),
                event_type=EventType.MAINTENANCE_REQUIRED,
                source_service="maintenance-service",
                timestamp=datetime.utcnow(),
                data={
                    "equipment_id": equipment_id,
                    "reason": f"Equipment returned in {condition} condition",
                    "priority": "high" if condition == "damaged" else "medium"
                },
                correlation_id=event.correlation_id
            )
            
            await self.event_bus.publish_event(maintenance_event)
        
        # Update inventory
        inventory_event = Event(
            event_id=str(uuid.uuid4()),
            event_type=EventType.INVENTORY_UPDATED,
            source_service="inventory-service",
            timestamp=datetime.utcnow(),
            data={
                "equipment_id": equipment_id,
                "status": "available" if condition == "good" else "maintenance",
                "booking_id": booking_id
            },
            correlation_id=event.correlation_id
        )
        
        await self.event_bus.publish_event(inventory_event)
    
    async def handle_booking_created(self, event: Event):
        """Handle booking creation event"""
        booking_id = event.data.get("booking_id")
        customer_id = event.data.get("customer_id")
        equipment_list = event.data.get("equipment", [])
        
        print(f"New booking {booking_id} created for customer {customer_id}")
        
        # Schedule delivery
        delivery_event = Event(
            event_id=str(uuid.uuid4()),
            event_type=EventType.DELIVERY_SCHEDULED,
            source_service="delivery-service",
            timestamp=datetime.utcnow(),
            data={
                "booking_id": booking_id,
                "customer_id": customer_id,
                "equipment_list": equipment_list,
                "delivery_date": event.data.get("start_date"),
                "delivery_address": event.data.get("delivery_address")
            },
            correlation_id=event.correlation_id
        )
        
        await self.event_bus.publish_event(delivery_event)
        
        # Send confirmation notification
        notification_event = Event(
            event_id=str(uuid.uuid4()),
            event_type=EventType.NOTIFICATION_SENT,
            source_service="notification-service",
            timestamp=datetime.utcnow(),
            data={
                "recipient_id": customer_id,
                "notification_type": "booking_confirmation",
                "booking_id": booking_id,
                "channel": "email"
            },
            correlation_id=event.correlation_id
        )
        
        await self.event_bus.publish_event(notification_event)
    
    async def handle_booking_cancelled(self, event: Event):
        """Handle booking cancellation event"""
        booking_id = event.data.get("booking_id")
        customer_id = event.data.get("customer_id")
        equipment_list = event.data.get("equipment", [])
        
        print(f"Booking {booking_id} cancelled for customer {customer_id}")
        
        # Release reserved equipment
        for equipment_id in equipment_list:
            inventory_event = Event(
                event_id=str(uuid.uuid4()),
                event_type=EventType.INVENTORY_UPDATED,
                source_service="inventory-service",
                timestamp=datetime.utcnow(),
                data={
                    "equipment_id": equipment_id,
                    "status": "available",
                    "booking_id": None
                },
                correlation_id=event.correlation_id
            )
            
            await self.event_bus.publish_event(inventory_event)
    
    async def handle_payment_processed(self, event: Event):
        """Handle payment processing event"""
        booking_id = event.data.get("booking_id")
        amount = event.data.get("amount")
        payment_status = event.data.get("status")
        
        print(f"Payment of €{amount} {payment_status} for booking {booking_id}")
        
        if payment_status == "completed":
            # Confirm booking
            print(f"Booking {booking_id} confirmed after successful payment")
        elif payment_status == "failed":
            # Handle payment failure
            print(f"Payment failed for booking {booking_id} - initiating cancellation")
    
    async def handle_inventory_updated(self, event: Event):
        """Handle inventory update event"""
        equipment_id = event.data.get("equipment_id")
        status = event.data.get("status")
        
        print(f"Inventory updated: Equipment {equipment_id} status changed to {status}")
```

## 3. Auto-scaling Implementation

### Auto-scaling Service

```python
# services/auto_scaling_service.py
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import statistics

class ScalingDirection(Enum):
    UP = "up"
    DOWN = "down"
    NONE = "none"

class ScalingTrigger(Enum):
    CPU_UTILIZATION = "cpu_utilization"
    MEMORY_UTILIZATION = "memory_utilization"
    REQUEST_RATE = "request_rate"
    RESPONSE_TIME = "response_time"
    QUEUE_LENGTH = "queue_length"
    CUSTOM_METRIC = "custom_metric"

@dataclass
class ScalingPolicy:
    policy_id: str
    service_name: str
    min_instances: int
    max_instances: int
    target_cpu_utilization: float
    target_memory_utilization: float
    target_request_rate: float
    target_response_time: float
    scale_up_cooldown: int  # seconds
    scale_down_cooldown: int  # seconds
    scale_up_threshold: float
    scale_down_threshold: float
    enabled: bool = True

@dataclass
class ScalingMetric:
    metric_name: str
    value: float
    timestamp: datetime
    service_name: str
    instance_id: Optional[str] = None

@dataclass
class ScalingAction:
    action_id: str
    service_name: str
    direction: ScalingDirection
    from_instances: int
    to_instances: int
    trigger: ScalingTrigger
    trigger_value: float
    timestamp: datetime
    status: str = "pending"
    error_message: Optional[str] = None

class AutoScalingService:
    def __init__(self, service_registry: ServiceRegistry):
        self.service_registry = service_registry
        self.scaling_policies = {}
        self.metrics_history = {}
        self.scaling_actions = []
        self.last_scaling_action = {}
        self.is_monitoring = False
    
    async def create_scaling_policy(self, policy: ScalingPolicy) -> bool:
        """Create a new auto-scaling policy"""
        try:
            self.scaling_policies[policy.service_name] = policy
            print(f"Scaling policy created for {policy.service_name}")
            return True
        except Exception as e:
            print(f"Failed to create scaling policy for {policy.service_name}: {e}")
            return False
    
    async def update_scaling_policy(self, service_name: str, updates: Dict[str, Any]) -> bool:
        """Update an existing scaling policy"""
        try:
            if service_name not in self.scaling_policies:
                return False
            
            policy = self.scaling_policies[service_name]
            
            for key, value in updates.items():
                if hasattr(policy, key):
                    setattr(policy, key, value)
            
            print(f"Scaling policy updated for {service_name}")
            return True
        except Exception as e:
            print(f"Failed to update scaling policy for {service_name}: {e}")
            return False
    
    async def start_auto_scaling(self, monitoring_interval: int = 30):
        """Start auto-scaling monitoring and execution"""
        self.is_monitoring = True
        
        while self.is_monitoring:
            try:
                # Collect metrics for all services
                await self.collect_scaling_metrics()
                
                # Evaluate scaling decisions
                await self.evaluate_scaling_decisions()
                
                # Execute scaling actions
                await self.execute_scaling_actions()
                
                await asyncio.sleep(monitoring_interval)
                
            except Exception as e:
                print(f"Error in auto-scaling loop: {e}")
                await asyncio.sleep(monitoring_interval)
    
    def stop_auto_scaling(self):
        """Stop auto-scaling monitoring"""
        self.is_monitoring = False
    
    async def collect_scaling_metrics(self):
        """Collect metrics for scaling decisions"""
        current_time = datetime.utcnow()
        
        for service_name in self.scaling_policies.keys():
            # Get service instances
            service_instances = self.service_registry.services.get(service_name, [])
            
            if not service_instances:
                continue
            
            # Collect metrics for each instance
            service_metrics = []
            
            for instance in service_instances:
                # Mock metric collection - in real implementation, collect from monitoring system
                metrics = await self._collect_instance_metrics(instance)
                service_metrics.extend(metrics)
            
            # Store metrics history
            if service_name not in self.metrics_history:
                self.metrics_history[service_name] = []
            
            self.metrics_history[service_name].extend(service_metrics)
            
            # Keep only last 1000 metrics per service
            if len(self.metrics_history[service_name]) > 1000:
                self.metrics_history[service_name] = self.metrics_history[service_name][-1000:]
    
    async def _collect_instance_metrics(self, instance: ServiceInstance) -> List[ScalingMetric]:
        """Collect metrics from a service instance"""
        current_time = datetime.utcnow()
        
        # Mock metrics - in real implementation, collect from actual monitoring
        import random
        
        base_cpu = 50 + random.uniform(-20, 30)
        base_memory = 60 + random.uniform(-15, 25)
        base_requests = 100 + random.uniform(-30, 50)
        base_response_time = 200 + random.uniform(-50, 100)
        
        # Add some load patterns
        hour = current_time.hour
        if 9 <= hour <= 17:  # Business hours
            base_cpu *= 1.3
            base_memory *= 1.2
            base_requests *= 1.5
            base_response_time *= 1.2
        
        metrics = [
            ScalingMetric(
                metric_name="cpu_utilization",
                value=max(0, min(100, base_cpu)),
                timestamp=current_time,
                service_name=instance.service_name,
                instance_id=instance.service_id
            ),
            ScalingMetric(
                metric_name="memory_utilization",
                value=max(0, min(100, base_memory)),
                timestamp=current_time,
                service_name=instance.service_name,
                instance_id=instance.service_id
            ),
            ScalingMetric(
                metric_name="request_rate",
                value=max(0, base_requests),
                timestamp=current_time,
                service_name=instance.service_name,
                instance_id=instance.service_id
            ),
            ScalingMetric(
                metric_name="response_time",
                value=max(0, base_response_time),
                timestamp=current_time,
                service_name=instance.service_name,
                instance_id=instance.service_id
            )
        ]
        
        return metrics
    
    async def evaluate_scaling_decisions(self):
        """Evaluate whether scaling actions are needed"""
        current_time = datetime.utcnow()
        
        for service_name, policy in self.scaling_policies.items():
            if not policy.enabled:
                continue
            
            # Check cooldown period
            if self._is_in_cooldown(service_name, current_time):
                continue
            
            # Get recent metrics
            recent_metrics = self._get_recent_metrics(service_name, minutes=5)
            
            if not recent_metrics:
                continue
            
            # Calculate average metrics
            avg_metrics = self._calculate_average_metrics(recent_metrics)
            
            # Determine scaling decision
            scaling_decision = self._determine_scaling_decision(policy, avg_metrics)
            
            if scaling_decision["direction"] != ScalingDirection.NONE:
                # Create scaling action
                action = ScalingAction(
                    action_id=f"{service_name}_{int(current_time.timestamp())}",
                    service_name=service_name,
                    direction=scaling_decision["direction"],
                    from_instances=scaling_decision["current_instances"],
                    to_instances=scaling_decision["target_instances"],
                    trigger=scaling_decision["trigger"],
                    trigger_value=scaling_decision["trigger_value"],
                    timestamp=current_time
                )
                
                self.scaling_actions.append(action)
                print(f"Scaling action queued: {service_name} {scaling_decision['direction'].value} from {scaling_decision['current_instances']} to {scaling_decision['target_instances']}")
    
    def _is_in_cooldown(self, service_name: str, current_time: datetime) -> bool:
        """Check if service is in cooldown period"""
        if service_name not in self.last_scaling_action:
            return False
        
        last_action = self.last_scaling_action[service_name]
        policy = self.scaling_policies[service_name]
        
        if last_action["direction"] == ScalingDirection.UP:
            cooldown_period = policy.scale_up_cooldown
        else:
            cooldown_period = policy.scale_down_cooldown
        
        time_since_last_action = (current_time - last_action["timestamp"]).total_seconds()
        
        return time_since_last_action < cooldown_period
    
    def _get_recent_metrics(self, service_name: str, minutes: int = 5) -> List[ScalingMetric]:
        """Get recent metrics for a service"""
        if service_name not in self.metrics_history:
            return []
        
        cutoff_time = datetime.utcnow() - timedelta(minutes=minutes)
        
        return [
            metric for metric in self.metrics_history[service_name]
            if metric.timestamp >= cutoff_time
        ]
    
    def _calculate_average_metrics(self, metrics: List[ScalingMetric]) -> Dict[str, float]:
        """Calculate average values for metrics"""
        metric_groups = {}
        
        for metric in metrics:
            if metric.metric_name not in metric_groups:
                metric_groups[metric.metric_name] = []
            metric_groups[metric.metric_name].append(metric.value)
        
        avg_metrics = {}
        for metric_name, values in metric_groups.items():
            avg_metrics[metric_name] = statistics.mean(values)
        
        return avg_metrics
    
    def _determine_scaling_decision(self, policy: ScalingPolicy, avg_metrics: Dict[str, float]) -> Dict[str, Any]:
        """Determine if scaling is needed based on policy and metrics"""
        
        # Get current instance count
        current_instances = len(self.service_registry.services.get(policy.service_name, []))
        
        # Check each metric against thresholds
        scale_up_triggers = []
        scale_down_triggers = []
        
        # CPU utilization
        cpu_util = avg_metrics.get("cpu_utilization", 0)
        if cpu_util > policy.target_cpu_utilization * (1 + policy.scale_up_threshold):
            scale_up_triggers.append(("cpu_utilization", cpu_util))
        elif cpu_util < policy.target_cpu_utilization * (1 - policy.scale_down_threshold):
            scale_down_triggers.append(("cpu_utilization", cpu_util))
        
        # Memory utilization
        memory_util = avg_metrics.get("memory_utilization", 0)
        if memory_util > policy.target_memory_utilization * (1 + policy.scale_up_threshold):
            scale_up_triggers.append(("memory_utilization", memory_util))
        elif memory_util < policy.target_memory_utilization * (1 - policy.scale_down_threshold):
            scale_down_triggers.append(("memory_utilization", memory_util))
        
        # Request rate
        request_rate = avg_metrics.get("request_rate", 0)
        if request_rate > policy.target_request_rate * (1 + policy.scale_up_threshold):
            scale_up_triggers.append(("request_rate", request_rate))
        elif request_rate < policy.target_request_rate * (1 - policy.scale_down_threshold):
            scale_down_triggers.append(("request_rate", request_rate))
        
        # Response time
        response_time = avg_metrics.get("response_time", 0)
        if response_time > policy.target_response_time * (1 + policy.scale_up_threshold):
            scale_up_triggers.append(("response_time", response_time))
        elif response_time < policy.target_response_time * (1 - policy.scale_down_threshold):
            scale_down_triggers.append(("response_time", response_time))
        
        # Determine scaling direction
        if scale_up_triggers and current_instances < policy.max_instances:
            # Scale up
            target_instances = min(current_instances + 1, policy.max_instances)
            primary_trigger = scale_up_triggers[0]
            
            return {
                "direction": ScalingDirection.UP,
                "current_instances": current_instances,
                "target_instances": target_instances,
                "trigger": ScalingTrigger(primary_trigger[0]),
                "trigger_value": primary_trigger[1]
            }
        
        elif scale_down_triggers and current_instances > policy.min_instances:
            # Scale down
            target_instances = max(current_instances - 1, policy.min_instances)
            primary_trigger = scale_down_triggers[0]
            
            return {
                "direction": ScalingDirection.DOWN,
                "current_instances": current_instances,
                "target_instances": target_instances,
                "trigger": ScalingTrigger(primary_trigger[0]),
                "trigger_value": primary_trigger[1]
            }
        
        else:
            # No scaling needed
            return {
                "direction": ScalingDirection.NONE,
                "current_instances": current_instances,
                "target_instances": current_instances,
                "trigger": None,
                "trigger_value": 0
            }
    
    async def execute_scaling_actions(self):
        """Execute pending scaling actions"""
        pending_actions = [action for action in self.scaling_actions if action.status == "pending"]
        
        for action in pending_actions:
            try:
                success = await self._execute_scaling_action(action)
                
                if success:
                    action.status = "completed"
                    
                    # Update last scaling action
                    self.last_scaling_action[action.service_name] = {
                        "direction": action.direction,
                        "timestamp": action.timestamp
                    }
                    
                    print(f"Scaling action completed: {action.service_name} scaled {action.direction.value} to {action.to_instances} instances")
                else:
                    action.status = "failed"
                    action.error_message = "Scaling execution failed"
                    print(f"Scaling action failed: {action.service_name}")
                    
            except Exception as e:
                action.status = "failed"
                action.error_message = str(e)
                print(f"Error executing scaling action for {action.service_name}: {e}")
    
    async def _execute_scaling_action(self, action: ScalingAction) -> bool:
        """Execute a specific scaling action"""
        try:
            if action.direction == ScalingDirection.UP:
                # Scale up - add new instances
                for i in range(action.to_instances - action.from_instances):
                    new_instance = ServiceInstance(
                        service_id=f"{action.service_name}-{int(datetime.utcnow().timestamp())}-{i}",
                        service_name=action.service_name,
                        version="1.0.0",
                        host="localhost",
                        port=8000 + len(self.service_registry.services.get(action.service_name, [])),
                        health_endpoint="/health",
                        status=ServiceStatus.HEALTHY,
                        last_heartbeat=datetime.utcnow(),
                        metadata={}
                    )
                    
                    await self.service_registry.register_service(new_instance)
            
            elif action.direction == ScalingDirection.DOWN:
                # Scale down - remove instances
                service_instances = self.service_registry.services.get(action.service_name, [])
                instances_to_remove = action.from_instances - action.to_instances
                
                for i in range(instances_to_remove):
                    if service_instances:
                        instance_to_remove = service_instances[-1]  # Remove last instance
                        await self.service_registry.deregister_service(
                            action.service_name, 
                            instance_to_remove.service_id
                        )
                        service_instances.pop()
            
            return True
            
        except Exception as e:
            print(f"Failed to execute scaling action: {e}")
            return False
    
    async def get_scaling_status(self, service_name: Optional[str] = None) -> Dict[str, Any]:
        """Get current scaling status"""
        
        if service_name:
            services = {service_name: self.scaling_policies.get(service_name)}
        else:
            services = self.scaling_policies
        
        status = {
            "services": {},
            "recent_actions": [],
            "monitoring_active": self.is_monitoring
        }
        
        for svc_name, policy in services.items():
            if not policy:
                continue
            
            current_instances = len(self.service_registry.services.get(svc_name, []))
            recent_metrics = self._get_recent_metrics(svc_name, minutes=5)
            avg_metrics = self._calculate_average_metrics(recent_metrics) if recent_metrics else {}
            
            status["services"][svc_name] = {
                "current_instances": current_instances,
                "min_instances": policy.min_instances,
                "max_instances": policy.max_instances,
                "policy_enabled": policy.enabled,
                "recent_metrics": avg_metrics,
                "last_scaling_action": self.last_scaling_action.get(svc_name),
                "in_cooldown": self._is_in_cooldown(svc_name, datetime.utcnow())
            }
        
        # Get recent scaling actions
        recent_actions = [
            {
                "action_id": action.action_id,
                "service_name": action.service_name,
                "direction": action.direction.value,
                "from_instances": action.from_instances,
                "to_instances": action.to_instances,
                "trigger": action.trigger.value if action.trigger else None,
                "trigger_value": action.trigger_value,
                "timestamp": action.timestamp.isoformat(),
                "status": action.status,
                "error_message": action.error_message
            }
            for action in self.scaling_actions[-10:]  # Last 10 actions
        ]
        
        status["recent_actions"] = recent_actions
        
        return status

# AV Rental Auto-scaling Policies
class AVRentalAutoScalingPolicies:
    @staticmethod
    def get_default_policies() -> List[ScalingPolicy]:
        """Get default auto-scaling policies for AV rental services"""
        
        return [
            # Booking Service - High priority, needs to scale quickly
            ScalingPolicy(
                policy_id="booking-service-policy",
                service_name="booking-service",
                min_instances=2,
                max_instances=10,
                target_cpu_utilization=60.0,
                target_memory_utilization=70.0,
                target_request_rate=100.0,
                target_response_time=500.0,
                scale_up_cooldown=60,  # 1 minute
                scale_down_cooldown=300,  # 5 minutes
                scale_up_threshold=0.2,  # 20% above target
                scale_down_threshold=0.3,  # 30% below target
                enabled=True
            ),
            
            # Inventory Service - Critical for availability checks
            ScalingPolicy(
                policy_id="inventory-service-policy",
                service_name="inventory-service",
                min_instances=2,
                max_instances=8,
                target_cpu_utilization=50.0,
                target_memory_utilization=60.0,
                target_request_rate=200.0,
                target_response_time=300.0,
                scale_up_cooldown=90,
                scale_down_cooldown=300,
                scale_up_threshold=0.25,
                scale_down_threshold=0.4,
                enabled=True
            ),
            
            # Equipment Catalog Service - Read-heavy, can handle more load
            ScalingPolicy(
                policy_id="equipment-catalog-policy",
                service_name="equipment-catalog-service",
                min_instances=1,
                max_instances=6,
                target_cpu_utilization=70.0,
                target_memory_utilization=75.0,
                target_request_rate=300.0,
                target_response_time=400.0,
                scale_up_cooldown=120,
                scale_down_cooldown=600,
                scale_up_threshold=0.3,
                scale_down_threshold=0.5,
                enabled=True
            ),
            
            # Pricing Service - Computation intensive
            ScalingPolicy(
                policy_id="pricing-service-policy",
                service_name="pricing-service",
                min_instances=1,
                max_instances=5,
                target_cpu_utilization=65.0,
                target_memory_utilization=70.0,
                target_request_rate=80.0,
                target_response_time=800.0,
                scale_up_cooldown=90,
                scale_down_cooldown=300,
                scale_up_threshold=0.25,
                scale_down_threshold=0.4,
                enabled=True
            ),
            
            # Analytics Service - Can tolerate higher latency
            ScalingPolicy(
                policy_id="analytics-service-policy",
                service_name="analytics-service",
                min_instances=1,
                max_instances=4,
                target_cpu_utilization=80.0,
                target_memory_utilization=85.0,
                target_request_rate=50.0,
                target_response_time=2000.0,
                scale_up_cooldown=300,
                scale_down_cooldown=900,
                scale_up_threshold=0.4,
                scale_down_threshold=0.6,
                enabled=True
            )
        ]
```

## 4. Circuit Breaker Pattern

### Circuit Breaker Implementation

```python
# services/circuit_breaker.py
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import asyncio
import time
import statistics

class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

@dataclass
class CircuitBreakerConfig:
    failure_threshold: int = 5
    recovery_timeout: int = 60  # seconds
    request_timeout: int = 30  # seconds
    half_open_max_calls: int = 3
    minimum_throughput: int = 10
    error_percentage_threshold: float = 50.0
    sliding_window_size: int = 100

@dataclass
class CallResult:
    success: bool
    response_time: float
    timestamp: datetime
    error_message: Optional[str] = None

class CircuitBreaker:
    def __init__(self, name: str, config: CircuitBreakerConfig):
        self.name = name
        self.config = config
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.last_failure_time = None
        self.half_open_calls = 0
        self.call_history = []
        self.state_change_listeners = []
    
    async def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute a function call through the circuit breaker"""
        
        # Check if circuit is open
        if self.state == CircuitState.OPEN:
            if self._should_attempt_reset():
                self._transition_to_half_open()
            else:
                raise CircuitBreakerOpenException(f"Circuit breaker {self.name} is OPEN")
        
        # Check if we're in half-open state and have exceeded max calls
        if self.state == CircuitState.HALF_OPEN and self.half_open_calls >= self.config.half_open_max_calls:
            raise CircuitBreakerOpenException(f"Circuit breaker {self.name} is HALF_OPEN with max calls exceeded")
        
        # Execute the call
        start_time = time.time()
        
        try:
            # Set timeout for the call
            result = await asyncio.wait_for(
                func(*args, **kwargs),
                timeout=self.config.request_timeout
            )
            
            # Record successful call
            response_time = time.time() - start_time
            self._record_success(response_time)
            
            return result
            
        except asyncio.TimeoutError:
            # Record timeout as failure
            response_time = time.time() - start_time
            self._record_failure(response_time, "Request timeout")
            raise CircuitBreakerTimeoutException(f"Request timeout in circuit breaker {self.name}")
            
        except Exception as e:
            # Record failure
            response_time = time.time() - start_time
            self._record_failure(response_time, str(e))
            raise
    
    def _record_success(self, response_time: float):
        """Record a successful call"""
        call_result = CallResult(
            success=True,
            response_time=response_time,
            timestamp=datetime.utcnow()
        )
        
        self._add_call_result(call_result)
        
        if self.state == CircuitState.HALF_OPEN:
            self.half_open_calls += 1
            
            # If we've had enough successful calls in half-open, close the circuit
            if self.half_open_calls >= self.config.half_open_max_calls:
                self._transition_to_closed()
        
        elif self.state == CircuitState.CLOSED:
            # Reset failure count on success
            self.failure_count = 0
    
    def _record_failure(self, response_time: float, error_message: str):
        """Record a failed call"""
        call_result = CallResult(
            success=False,
            response_time=response_time,
            timestamp=datetime.utcnow(),
            error_message=error_message
        )
        
        self._add_call_result(call_result)
        
        self.failure_count += 1
        self.last_failure_time = datetime.utcnow()
        
        if self.state == CircuitState.HALF_OPEN:
            # Any failure in half-open state opens the circuit
            self._transition_to_open()
        
        elif self.state == CircuitState.CLOSED:
            # Check if we should open the circuit
            if self._should_open_circuit():
                self._transition_to_open()
    
    def _add_call_result(self, call_result: CallResult):
        """Add call result to history"""
        self.call_history.append(call_result)
        
        # Keep only the last N calls based on sliding window size
        if len(self.call_history) > self.config.sliding_window_size:
            self.call_history = self.call_history[-self.config.sliding_window_size:]
    
    def _should_open_circuit(self) -> bool:
        """Determine if circuit should be opened"""
        
        # Check failure threshold
        if self.failure_count >= self.config.failure_threshold:
            return True
        
        # Check error percentage in sliding window
        if len(self.call_history) >= self.config.minimum_throughput:
            recent_calls = self.call_history[-self.config.minimum_throughput:]
            failed_calls = [call for call in recent_calls if not call.success]
            error_percentage = (len(failed_calls) / len(recent_calls)) * 100
            
            if error_percentage >= self.config.error_percentage_threshold:
                return True
        
        return False
    
    def _should_attempt_reset(self) -> bool:
        """Determine if we should attempt to reset from open state"""
        if not self.last_failure_time:
            return True
        
        time_since_failure = datetime.utcnow() - self.last_failure_time
        return time_since_failure.total_seconds() >= self.config.recovery_timeout
    
    def _transition_to_open(self):
        """Transition circuit breaker to OPEN state"""
        old_state = self.state
        self.state = CircuitState.OPEN
        self.half_open_calls = 0
        
        print(f"Circuit breaker {self.name} transitioned from {old_state.value} to OPEN")
        self._notify_state_change(old_state, self.state)
    
    def _transition_to_half_open(self):
        """Transition circuit breaker to HALF_OPEN state"""
        old_state = self.state
        self.state = CircuitState.HALF_OPEN
        self.half_open_calls = 0
        
        print(f"Circuit breaker {self.name} transitioned from {old_state.value} to HALF_OPEN")
        self._notify_state_change(old_state, self.state)
    
    def _transition_to_closed(self):
        """Transition circuit breaker to CLOSED state"""
        old_state = self.state
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.half_open_calls = 0
        
        print(f"Circuit breaker {self.name} transitioned from {old_state.value} to CLOSED")
        self._notify_state_change(old_state, self.state)
    
    def _notify_state_change(self, old_state: CircuitState, new_state: CircuitState):
        """Notify listeners of state change"""
        for listener in self.state_change_listeners:
            try:
                listener(self.name, old_state, new_state)
            except Exception as e:
                print(f"Error notifying circuit breaker state change listener: {e}")
    
    def add_state_change_listener(self, listener: Callable):
        """Add a state change listener"""
        self.state_change_listeners.append(listener)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get circuit breaker metrics"""
        
        # Calculate metrics from call history
        if not self.call_history:
            return {
                "name": self.name,
                "state": self.state.value,
                "total_calls": 0,
                "successful_calls": 0,
                "failed_calls": 0,
                "error_percentage": 0.0,
                "average_response_time": 0.0
            }
        
        total_calls = len(self.call_history)
        successful_calls = len([call for call in self.call_history if call.success])
        failed_calls = total_calls - successful_calls
        error_percentage = (failed_calls / total_calls) * 100 if total_calls > 0 else 0
        
        response_times = [call.response_time for call in self.call_history]
        avg_response_time = statistics.mean(response_times) if response_times else 0
        
        return {
            "name": self.name,
            "state": self.state.value,
            "total_calls": total_calls,
            "successful_calls": successful_calls,
            "failed_calls": failed_calls,
            "error_percentage": round(error_percentage, 2),
            "average_response_time": round(avg_response_time * 1000, 2),  # Convert to ms
            "failure_count": self.failure_count,
            "last_failure_time": self.last_failure_time.isoformat() if self.last_failure_time else None
        }

class CircuitBreakerOpenException(Exception):
    """Exception raised when circuit breaker is open"""
    pass

class CircuitBreakerTimeoutException(Exception):
    """Exception raised when request times out"""
    pass

class CircuitBreakerManager:
    def __init__(self):
        self.circuit_breakers = {}
        self.default_config = CircuitBreakerConfig()
    
    def get_circuit_breaker(self, name: str, config: Optional[CircuitBreakerConfig] = None) -> CircuitBreaker:
        """Get or create a circuit breaker"""
        if name not in self.circuit_breakers:
            breaker_config = config or self.default_config
            self.circuit_breakers[name] = CircuitBreaker(name, breaker_config)
        
        return self.circuit_breakers[name]
    
    def create_circuit_breaker(self, name: str, config: CircuitBreakerConfig) -> CircuitBreaker:
        """Create a new circuit breaker with specific configuration"""
        circuit_breaker = CircuitBreaker(name, config)
        self.circuit_breakers[name] = circuit_breaker
        return circuit_breaker
    
    def get_all_metrics(self) -> Dict[str, Any]:
        """Get metrics for all circuit breakers"""
        return {
            name: breaker.get_metrics()
            for name, breaker in self.circuit_breakers.items()
        }
    
    def reset_circuit_breaker(self, name: str) -> bool:
        """Manually reset a circuit breaker to closed state"""
        if name in self.circuit_breakers:
            breaker = self.circuit_breakers[name]
            breaker._transition_to_closed()
            return True
        return False

# AV Rental Circuit Breaker Configurations
class AVRentalCircuitBreakers:
    @staticmethod
    def get_service_configs() -> Dict[str, CircuitBreakerConfig]:
        """Get circuit breaker configurations for AV rental services"""
        
        return {
            # Critical services - more sensitive to failures
            "inventory-service": CircuitBreakerConfig(
                failure_threshold=3,
                recovery_timeout=30,
                request_timeout=10,
                half_open_max_calls=2,
                minimum_throughput=5,
                error_percentage_threshold=30.0,
                sliding_window_size=50
            ),
            
            "booking-service": CircuitBreakerConfig(
                failure_threshold=5,
                recovery_timeout=60,
                request_timeout=15,
                half_open_max_calls=3,
                minimum_throughput=10,
                error_percentage_threshold=40.0,
                sliding_window_size=100
            ),
            
            # External services - more tolerant of failures
            "payment-gateway": CircuitBreakerConfig(
                failure_threshold=3,
                recovery_timeout=120,
                request_timeout=30,
                half_open_max_calls=1,
                minimum_throughput=5,
                error_percentage_threshold=20.0,
                sliding_window_size=25
            ),
            
            "email-service": CircuitBreakerConfig(
                failure_threshold=10,
                recovery_timeout=300,
                request_timeout=20,
                half_open_max_calls=5,
                minimum_throughput=20,
                error_percentage_threshold=60.0,
                sliding_window_size=200
            ),
            
            # Internal services - balanced configuration
            "pricing-service": CircuitBreakerConfig(
                failure_threshold=5,
                recovery_timeout=60,
                request_timeout=20,
                half_open_max_calls=3,
                minimum_throughput=10,
                error_percentage_threshold=50.0,
                sliding_window_size=100
            ),
            
            "analytics-service": CircuitBreakerConfig(
                failure_threshold=8,
                recovery_timeout=180,
                request_timeout=60,
                half_open_max_calls=5,
                minimum_throughput=15,
                error_percentage_threshold=70.0,
                sliding_window_size=150
            )
        }
    
    @staticmethod
    def setup_circuit_breakers(manager: CircuitBreakerManager) -> Dict[str, CircuitBreaker]:
        """Set up all circuit breakers for AV rental services"""
        
        configs = AVRentalCircuitBreakers.get_service_configs()
        circuit_breakers = {}
        
        for service_name, config in configs.items():
            circuit_breaker = manager.create_circuit_breaker(service_name, config)
            
            # Add state change listener for monitoring
            circuit_breaker.add_state_change_listener(
                lambda name, old_state, new_state: print(
                    f"[CIRCUIT BREAKER] {name}: {old_state.value} -> {new_state.value}"
                )
            )
            
            circuit_breakers[service_name] = circuit_breaker
        
        return circuit_breakers

# Example usage with service calls
class ServiceClient:
    def __init__(self, circuit_breaker_manager: CircuitBreakerManager):
        self.circuit_breaker_manager = circuit_breaker_manager
    
    async def call_inventory_service(self, equipment_id: str) -> Dict[str, Any]:
        """Call inventory service with circuit breaker protection"""
        
        circuit_breaker = self.circuit_breaker_manager.get_circuit_breaker("inventory-service")
        
        async def inventory_call():
            # Mock service call - in real implementation, make HTTP request
            import random
            await asyncio.sleep(0.1)  # Simulate network delay
            
            if random.random() < 0.1:  # 10% failure rate
                raise Exception("Inventory service unavailable")
            
            return {
                "equipment_id": equipment_id,
                "available": True,
                "quantity": 5,
                "location": "Warehouse A"
            }
        
        return await circuit_breaker.call(inventory_call)
    
    async def call_pricing_service(self, equipment_list: List[str], duration: int) -> Dict[str, Any]:
        """Call pricing service with circuit breaker protection"""
        
        circuit_breaker = self.circuit_breaker_manager.get_circuit_breaker("pricing-service")
        
        async def pricing_call():
            # Mock service call
            import random
            await asyncio.sleep(0.2)  # Simulate processing time
            
            if random.random() < 0.05:  # 5% failure rate
                raise Exception("Pricing calculation failed")
            
            base_price = len(equipment_list) * 100 * duration
            return {
                "equipment_list": equipment_list,
                "duration_days": duration,
                "base_price": base_price,
                "total_price": base_price * 1.21,  # Including tax
                "currency": "EUR"
            }
        
        return await circuit_breaker.call(pricing_call)
```

## Summary

This comprehensive implementation provides the Month 19-24 Microservices & Scalability features for the RentGuy AV rental platform:

1. **Service Decomposition & Microservices Architecture**: Complete service registry, load balancing, health monitoring, and deployment management for 12 specialized AV rental microservices.

2. **Event-Driven Architecture**: Full event bus implementation with publish/subscribe patterns, event store, message broker, and AV rental-specific event handlers for equipment, booking, payment, and inventory events.

3. **Auto-scaling Implementation**: Comprehensive auto-scaling service with configurable policies, metric collection, scaling decision algorithms, and execution management specifically tuned for AV rental service patterns.

4. **Circuit Breaker Pattern**: Enterprise-grade circuit breaker implementation with state management, failure detection, recovery mechanisms, and AV rental service-specific configurations for resilience and fault tolerance.

All implementations include enterprise-grade features like monitoring, logging, error handling, and comprehensive APIs specifically designed for AV rental microservices architecture and scalability requirements.
