"""
RentGuy Enterprise - Payment Webhook Routes
===========================================

This module implements FastAPI routes for handling payment webhooks from 
Stripe and Mollie with comprehensive error handling and monitoring.

Author: Manus AI
Date: October 5, 2025
Version: 1.0
"""

import json
import logging
from typing import Dict, Any
from datetime import datetime

from fastapi import APIRouter, Request, HTTPException, Depends, BackgroundTasks
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.logging import get_logger
from app.modules.billing.adapters.stripe_adapter import (
    StripeAdapter, 
    get_stripe_adapter,
    validate_stripe_webhook
)
from app.modules.billing.adapters.mollie_adapter import (
    MollieAdapter,
    get_mollie_adapter, 
    validate_mollie_webhook
)
from app.core.exceptions import PaymentError, WebhookVerificationError

logger = get_logger(__name__)

# Create router for webhook endpoints
webhook_router = APIRouter(prefix="/webhooks", tags=["webhooks"])


@webhook_router.post("/stripe")
async def handle_stripe_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Handle Stripe webhook events
    
    This endpoint receives webhook events from Stripe, verifies the signature,
    and processes the payment status updates asynchronously.
    """
    start_time = datetime.utcnow()
    
    try:
        # Validate webhook signature and parse event data
        event_data = validate_stripe_webhook(request)
        event_type = event_data.get("type")
        event_id = event_data.get("id")
        
        logger.info(f"Received Stripe webhook: {event_type} ({event_id})")
        
        # Get Stripe adapter
        stripe_adapter = get_stripe_adapter(db)
        
        # Process webhook event in background
        background_tasks.add_task(
            process_stripe_webhook_background,
            stripe_adapter,
            event_data,
            start_time
        )
        
        # Return immediate response to Stripe
        return JSONResponse(
            status_code=200,
            content={"status": "received", "event_id": event_id}
        )
        
    except WebhookVerificationError as e:
        logger.error(f"Stripe webhook signature verification failed: {str(e)}")
        raise HTTPException(status_code=400, detail="Invalid signature")
        
    except json.JSONDecodeError:
        logger.error("Invalid JSON in Stripe webhook payload")
        raise HTTPException(status_code=400, detail="Invalid JSON payload")
        
    except Exception as e:
        logger.error(f"Unexpected error processing Stripe webhook: {str(e)}")
        raise HTTPException(status_code=500, detail="Webhook processing error")


@webhook_router.post("/mollie")
async def handle_mollie_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db)
):
    """
    Handle Mollie webhook events
    
    This endpoint receives webhook events from Mollie, validates the payload,
    and processes the payment status updates asynchronously.
    """
    start_time = datetime.utcnow()
    
    try:
        # Validate webhook and parse event data
        event_data = validate_mollie_webhook(request)
        payment_id = event_data.get("id")
        
        logger.info(f"Received Mollie webhook for payment: {payment_id}")
        
        # Get Mollie adapter
        mollie_adapter = get_mollie_adapter(db)
        
        # Process webhook event in background
        background_tasks.add_task(
            process_mollie_webhook_background,
            mollie_adapter,
            event_data,
            start_time
        )
        
        # Return immediate response to Mollie
        return JSONResponse(
            status_code=200,
            content={"status": "received", "payment_id": payment_id}
        )
        
    except json.JSONDecodeError:
        logger.error("Invalid JSON in Mollie webhook payload")
        raise HTTPException(status_code=400, detail="Invalid JSON payload")
        
    except Exception as e:
        logger.error(f"Unexpected error processing Mollie webhook: {str(e)}")
        raise HTTPException(status_code=500, detail="Webhook processing error")


async def process_stripe_webhook_background(
    stripe_adapter: StripeAdapter,
    event_data: Dict[str, Any],
    start_time: datetime
):
    """
    Process Stripe webhook event in background task
    
    Args:
        stripe_adapter: Stripe adapter instance
        event_data: Webhook event data
        start_time: Processing start time for metrics
    """
    event_type = event_data.get("type")
    event_id = event_data.get("id")
    
    try:
        # Process the webhook event
        result = stripe_adapter.handle_webhook_event(event_data)
        
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        
        logger.info(
            f"Stripe webhook {event_id} processed successfully in {processing_time:.2f}s: {result}"
        )
        
    except PaymentError as e:
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        logger.error(f"Payment error processing Stripe webhook {event_id}: {str(e)}")
        
    except Exception as e:
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        logger.error(f"Unexpected error processing Stripe webhook {event_id}: {str(e)}")


async def process_mollie_webhook_background(
    mollie_adapter: MollieAdapter,
    event_data: Dict[str, Any],
    start_time: datetime
):
    """
    Process Mollie webhook event in background task
    
    Args:
        mollie_adapter: Mollie adapter instance
        event_data: Webhook event data
        start_time: Processing start time for metrics
    """
    payment_id = event_data.get("id")
    
    try:
        # Process the webhook event
        result = mollie_adapter.handle_webhook_event(event_data)
        
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        
        logger.info(
            f"Mollie webhook for payment {payment_id} processed successfully in {processing_time:.2f}s: {result}"
        )
        
    except PaymentError as e:
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        logger.error(f"Payment error processing Mollie webhook {payment_id}: {str(e)}")
        
    except Exception as e:
        processing_time = (datetime.utcnow() - start_time).total_seconds()
        logger.error(f"Unexpected error processing Mollie webhook {payment_id}: {str(e)}")


@webhook_router.get("/stripe/health")
async def stripe_webhook_health():
    """Health check endpoint for Stripe webhook"""
    return JSONResponse(
        status_code=200,
        content={
            "status": "healthy",
            "provider": "stripe",
            "timestamp": datetime.utcnow().isoformat()
        }
    )


@webhook_router.get("/mollie/health")
async def mollie_webhook_health():
    """Health check endpoint for Mollie webhook"""
    return JSONResponse(
        status_code=200,
        content={
            "status": "healthy",
            "provider": "mollie",
            "timestamp": datetime.utcnow().isoformat()
        }
    )


@webhook_router.get("/status")
async def webhook_status():
    """
    Get webhook processing status and metrics
    
    Returns summary of webhook processing statistics
    """
    try:
        return JSONResponse(
            status_code=200,
            content={
                "status": "operational",
                "providers": ["stripe", "mollie"],
                "endpoints": {
                    "stripe": "/webhooks/stripe",
                    "mollie": "/webhooks/mollie"
                },
                "health_checks": {
                    "stripe": "/webhooks/stripe/health",
                    "mollie": "/webhooks/mollie/health"
                },
                "timestamp": datetime.utcnow().isoformat()
            }
        )
        
    except Exception as e:
        logger.error(f"Error getting webhook status: {str(e)}")
        raise HTTPException(status_code=500, detail="Status retrieval error")


# Error handlers for webhook-specific errors
@webhook_router.exception_handler(PaymentError)
async def payment_error_handler(request: Request, exc: PaymentError):
    """Handle payment-specific errors"""
    logger.error(f"Payment error in webhook: {str(exc)}")
    return JSONResponse(
        status_code=422,
        content={"error": "payment_error", "detail": str(exc)}
    )


@webhook_router.exception_handler(WebhookVerificationError)
async def webhook_verification_error_handler(request: Request, exc: WebhookVerificationError):
    """Handle webhook verification errors"""
    logger.error(f"Webhook verification error: {str(exc)}")
    return JSONResponse(
        status_code=400,
        content={"error": "verification_failed", "detail": str(exc)}
    )
