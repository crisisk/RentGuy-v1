# Mr. DJ Onboarding Implementation and Customization Plan

This plan details the steps for implementing and customizing the professional onboarding process for Mr. DJ (Bart van de Weijer), focusing on the 'Nieuwe DJ (freelancer)' persona as outlined in the provided `Lyra Superprompt`. The goal is to ensure a seamless, professional, and fully functional onboarding experience, integrated into the consolidated RentGuy platform.

## 1. Review of Existing Onboarding Module

To begin, a thorough review of the extracted `rentguy_analysis/onboarding_v0` directory would be conducted. This involves examining:

*   **Frontend Components:** Specifically, `apps/web/src/OnboardingOverlay.jsx` and `apps/web/src/TipBanner.jsx`, along with other related React components, to understand the current UI/UX of the onboarding flow. This includes analyzing how steps are rendered, user input is captured, and progress is displayed.
*   **Backend Routes:** The `backend/app/modules/onboarding/routes.py` file and associated `usecases.py`, `repo.py`, and `schemas.py` would be inspected to understand the API endpoints for managing onboarding steps, user progress, and data persistence.
*   **Database Migrations:** The `backend/alembic/versions/0007_onboarding.py` migration script would be reviewed to understand the database schema related to onboarding (e.g., tables for steps, user progress, tips).
*   **Configuration:** Any configuration files or environment variables related to onboarding behavior or content would be identified.

## 2. Identifying Customization Points for Mr. DJ

Based on the 'Nieuwe DJ' persona and the general requirements for Mr. DJ, the following customization points would be identified and addressed:

*   **User Account Setup:**
    *   **Initial Admin User:** Ensure the primary admin user for Mr. DJ's instance is set to `admin@sevensa.nl` instead of `rentguy@demo.local`. This would involve updating seed scripts or initial configuration for the specific deployment.
*   **Onboarding Flow Adaptation:**
    *   **Custom Steps/Fields:** If Mr. DJ requires specific information to be collected during onboarding (e.g., specialized AV equipment certifications, preferred event types, specific insurance details), new fields would be added to the relevant frontend forms and corresponding updates made to backend schemas and database models.
    *   **Branding:** Incorporate Mr. DJ's branding elements (logo, color scheme) into the `OnboardingOverlay` and other frontend components to provide a personalized experience.
    *   **Content Customization:** Tailor the text, tips (`TipBanner.jsx`), and instructions within the onboarding flow to resonate with AV freelancers and Mr. DJ's operational context.
*   **Equipment Inventory Integration:**
    *   **Initial Inventory Upload:** Develop or utilize an existing mechanism for Mr. DJ to easily upload his initial AV equipment inventory, potentially through a dedicated step in the onboarding process or an administrative interface.
    *   **Pricing Setup:** Integrate a step for defining default pricing structures or rules for his equipment, aligning with the platform's dynamic pricing capabilities.
*   **Welcome Mail Customization:** Ensure the welcome email (triggered after onboarding completion, as per `F2. Ontvang welcome-mail`) is customized with Mr. DJ's branding and relevant information.

## 3. Simulated Implementation Steps

Given the sandbox environment, the following steps simulate the implementation process:

1.  **Code Modification (Frontend):**
    *   **`OnboardingOverlay.jsx` / `TipBanner.jsx`:** Modify these React components to support dynamic content loading, branding elements (e.g., fetching logo from a configuration endpoint), and rendering any new custom fields required for Mr. DJ.
    *   **New Components:** Create new React components if complex custom steps are needed, integrating them into the existing onboarding wizard structure.
2.  **Code Modification (Backend):**
    *   **`schemas.py`:** Update Pydantic schemas to include any new fields for onboarding data.
    *   **`models.py`:** Modify SQLAlchemy models to reflect changes in the database schema.
    *   **`repo.py` / `usecases.py`:** Adjust repository and use case logic to handle the storage and retrieval of new onboarding data.
    *   **`routes.py`:** Potentially add new API endpoints if the customization requires entirely new data submission flows.
    *   **Email Service:** Update the mailer service to use customized templates for the welcome email, incorporating Mr. DJ's branding and dynamic content.
3.  **Database Migrations:**
    *   Generate new Alembic migration scripts to apply any schema changes to the PostgreSQL database, ensuring backward compatibility where necessary.
4.  **Configuration Management:**
    *   Update environment variables or configuration files (e.g., `.env` files, `config.py`) to reflect Mr. DJ's specific settings, such as the `admin@sevensa.nl` email for initial setup.

## 4. Preparing for UAT and Testing

After implementing the customizations, the following UAT and testing activities would be performed, as specified in the `Lyra Superprompt`:

*   **UI Test (`ui_signup_onboarding.spec.ts`):**
    *   **Adaptation:** Modify the existing Playwright test to reflect any changes in the signup and onboarding UI. This includes updating selectors for new fields, verifying the display of custom branding, and ensuring the 5-step completion flow works as expected.
    *   **Execution:** Run the Playwright test suite to validate the frontend onboarding experience for the 'Nieuwe DJ' persona.
    *   **Validation:** Verify that the progress reaches 100% and that the welcome mail trigger is observed (e.g., via a Mailtrap/SMTP mock dashboard).
*   **API Tests (`test_onboarding_steps.py`, `test_onboarding_progress.py`, `test_onboarding_complete.py`):**
    *   **Adaptation:** Update these Pytest API tests to account for any new API endpoints, changes in request/response schemas, or specific data validation rules introduced for Mr. DJ's customizations.
    *   **Execution:** Run the Pytest API suite to ensure the backend onboarding logic functions correctly, including the seeding of steps, accurate progress tracking, and idempotent completion.
    *   **Validation:** Confirm that the API endpoints return `200 OK` status codes and correct data structures, especially for `user_email=admin@sevensa.nl`.

This systematic approach ensures that Mr. DJ's onboarding experience is not only functional but also tailored to his business needs, providing a strong foundation for his adoption of the RentGuy platform.
