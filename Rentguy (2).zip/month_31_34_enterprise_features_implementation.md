# Month 31-34: Enterprise Features Implementation
## RentGuy AV Rental Platform - Final Enterprise Features

### Overview
This document outlines the implementation of the final enterprise features for the RentGuy AV rental platform, focusing on advanced security, compliance, and governance capabilities that transform the platform into a fully enterprise-ready system.

---

## 1. SSO Integration (AzureAD, Google Workspace)

### Database Models

```python
# backend/app/modules/auth/models/sso_models.py
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class SSOProvider(Base):
    __tablename__ = "sso_providers"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    provider_type = Column(String(50), nullable=False)  # 'azure_ad', 'google_workspace'
    provider_name = Column(String(100), nullable=False)
    client_id = Column(String(255), nullable=False)
    client_secret = Column(Text, nullable=False)  # Encrypted
    tenant_domain = Column(String(255))  # For Azure AD
    workspace_domain = Column(String(255))  # For Google Workspace
    redirect_uri = Column(String(500), nullable=False)
    scopes = Column(JSON, default=list)
    is_active = Column(Boolean, default=True)
    auto_provision = Column(Boolean, default=True)
    default_role = Column(String(50), default='user')
    domain_restriction = Column(JSON, default=list)  # Allowed domains
    group_mapping = Column(JSON, default=dict)  # External groups to internal roles
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SSOSession(Base):
    __tablename__ = "sso_sessions"
    
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, nullable=False)
    provider_id = Column(Integer, nullable=False)
    external_user_id = Column(String(255), nullable=False)
    access_token = Column(Text, nullable=False)  # Encrypted
    refresh_token = Column(Text)  # Encrypted
    id_token = Column(Text)  # Encrypted
    token_expires_at = Column(DateTime)
    session_state = Column(String(255))
    last_activity = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class SSOAuditLog(Base):
    __tablename__ = "sso_audit_logs"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    user_id = Column(Integer)
    provider_id = Column(Integer, nullable=False)
    event_type = Column(String(50), nullable=False)  # 'login', 'logout', 'token_refresh', 'error'
    event_details = Column(JSON)
    ip_address = Column(String(45))
    user_agent = Column(Text)
    success = Column(Boolean, default=True)
    error_message = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
```

### SSO Service Implementation

```python
# backend/app/modules/auth/services/sso_service.py
import asyncio
import jwt
import httpx
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
import secrets
import base64
from urllib.parse import urlencode, parse_qs

class SSOService:
    def __init__(self, db_session, encryption_key: str):
        self.db = db_session
        self.cipher = Fernet(encryption_key.encode())
        self.azure_endpoints = {
            'authorize': 'https://login.microsoftonline.com/{tenant}/oauth2/v2.0/authorize',
            'token': 'https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token',
            'userinfo': 'https://graph.microsoft.com/v1.0/me'
        }
        self.google_endpoints = {
            'authorize': 'https://accounts.google.com/o/oauth2/v2/auth',
            'token': 'https://oauth2.googleapis.com/token',
            'userinfo': 'https://www.googleapis.com/oauth2/v2/userinfo'
        }

    async def create_sso_provider(self, tenant_id: int, provider_config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new SSO provider configuration"""
        try:
            # Encrypt sensitive data
            encrypted_secret = self.cipher.encrypt(provider_config['client_secret'].encode()).decode()
            
            provider = SSOProvider(
                tenant_id=tenant_id,
                provider_type=provider_config['provider_type'],
                provider_name=provider_config['provider_name'],
                client_id=provider_config['client_id'],
                client_secret=encrypted_secret,
                tenant_domain=provider_config.get('tenant_domain'),
                workspace_domain=provider_config.get('workspace_domain'),
                redirect_uri=provider_config['redirect_uri'],
                scopes=provider_config.get('scopes', []),
                auto_provision=provider_config.get('auto_provision', True),
                default_role=provider_config.get('default_role', 'user'),
                domain_restriction=provider_config.get('domain_restriction', []),
                group_mapping=provider_config.get('group_mapping', {})
            )
            
            self.db.add(provider)
            await self.db.commit()
            
            await self._log_sso_event(
                tenant_id, None, provider.id, 'provider_created',
                {'provider_name': provider_config['provider_name']}
            )
            
            return {
                'success': True,
                'provider_id': provider.id,
                'message': 'SSO provider created successfully'
            }
            
        except Exception as e:
            await self.db.rollback()
            return {
                'success': False,
                'error': f'Failed to create SSO provider: {str(e)}'
            }

    async def generate_auth_url(self, provider_id: int, state: str = None) -> Dict[str, Any]:
        """Generate SSO authentication URL"""
        try:
            provider = await self.db.query(SSOProvider).filter(
                SSOProvider.id == provider_id,
                SSOProvider.is_active == True
            ).first()
            
            if not provider:
                return {'success': False, 'error': 'SSO provider not found'}
            
            # Generate state parameter for CSRF protection
            if not state:
                state = secrets.token_urlsafe(32)
            
            if provider.provider_type == 'azure_ad':
                auth_url = self._generate_azure_auth_url(provider, state)
            elif provider.provider_type == 'google_workspace':
                auth_url = self._generate_google_auth_url(provider, state)
            else:
                return {'success': False, 'error': 'Unsupported provider type'}
            
            return {
                'success': True,
                'auth_url': auth_url,
                'state': state,
                'provider_type': provider.provider_type
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to generate auth URL: {str(e)}'
            }

    def _generate_azure_auth_url(self, provider: SSOProvider, state: str) -> str:
        """Generate Azure AD authentication URL"""
        params = {
            'client_id': provider.client_id,
            'response_type': 'code',
            'redirect_uri': provider.redirect_uri,
            'scope': ' '.join(provider.scopes or ['openid', 'profile', 'email']),
            'state': state,
            'response_mode': 'query'
        }
        
        base_url = self.azure_endpoints['authorize'].format(
            tenant=provider.tenant_domain or 'common'
        )
        
        return f"{base_url}?{urlencode(params)}"

    def _generate_google_auth_url(self, provider: SSOProvider, state: str) -> str:
        """Generate Google Workspace authentication URL"""
        params = {
            'client_id': provider.client_id,
            'response_type': 'code',
            'redirect_uri': provider.redirect_uri,
            'scope': ' '.join(provider.scopes or ['openid', 'profile', 'email']),
            'state': state,
            'access_type': 'offline',
            'prompt': 'consent'
        }
        
        if provider.workspace_domain:
            params['hd'] = provider.workspace_domain
        
        return f"{self.google_endpoints['authorize']}?{urlencode(params)}"

    async def handle_callback(self, provider_id: int, code: str, state: str) -> Dict[str, Any]:
        """Handle SSO callback and exchange code for tokens"""
        try:
            provider = await self.db.query(SSOProvider).filter(
                SSOProvider.id == provider_id,
                SSOProvider.is_active == True
            ).first()
            
            if not provider:
                return {'success': False, 'error': 'SSO provider not found'}
            
            # Exchange code for tokens
            if provider.provider_type == 'azure_ad':
                token_result = await self._exchange_azure_code(provider, code)
            elif provider.provider_type == 'google_workspace':
                token_result = await self._exchange_google_code(provider, code)
            else:
                return {'success': False, 'error': 'Unsupported provider type'}
            
            if not token_result['success']:
                await self._log_sso_event(
                    provider.tenant_id, None, provider_id, 'token_exchange_failed',
                    {'error': token_result['error']}
                )
                return token_result
            
            # Get user info
            user_info = await self._get_user_info(provider, token_result['access_token'])
            if not user_info['success']:
                return user_info
            
            # Process user authentication
            auth_result = await self._process_user_authentication(
                provider, token_result, user_info['user_data']
            )
            
            return auth_result
            
        except Exception as e:
            await self._log_sso_event(
                provider.tenant_id if provider else None, None, provider_id, 'callback_error',
                {'error': str(e)}
            )
            return {
                'success': False,
                'error': f'Failed to handle SSO callback: {str(e)}'
            }

    async def _exchange_azure_code(self, provider: SSOProvider, code: str) -> Dict[str, Any]:
        """Exchange Azure AD authorization code for tokens"""
        try:
            client_secret = self.cipher.decrypt(provider.client_secret.encode()).decode()
            
            data = {
                'client_id': provider.client_id,
                'client_secret': client_secret,
                'code': code,
                'grant_type': 'authorization_code',
                'redirect_uri': provider.redirect_uri,
                'scope': ' '.join(provider.scopes or ['openid', 'profile', 'email'])
            }
            
            token_url = self.azure_endpoints['token'].format(
                tenant=provider.tenant_domain or 'common'
            )
            
            async with httpx.AsyncClient() as client:
                response = await client.post(token_url, data=data)
                
            if response.status_code != 200:
                return {
                    'success': False,
                    'error': f'Token exchange failed: {response.text}'
                }
            
            token_data = response.json()
            return {
                'success': True,
                'access_token': token_data['access_token'],
                'refresh_token': token_data.get('refresh_token'),
                'id_token': token_data.get('id_token'),
                'expires_in': token_data.get('expires_in', 3600)
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Azure token exchange failed: {str(e)}'
            }

    async def _exchange_google_code(self, provider: SSOProvider, code: str) -> Dict[str, Any]:
        """Exchange Google authorization code for tokens"""
        try:
            client_secret = self.cipher.decrypt(provider.client_secret.encode()).decode()
            
            data = {
                'client_id': provider.client_id,
                'client_secret': client_secret,
                'code': code,
                'grant_type': 'authorization_code',
                'redirect_uri': provider.redirect_uri
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(self.google_endpoints['token'], data=data)
                
            if response.status_code != 200:
                return {
                    'success': False,
                    'error': f'Token exchange failed: {response.text}'
                }
            
            token_data = response.json()
            return {
                'success': True,
                'access_token': token_data['access_token'],
                'refresh_token': token_data.get('refresh_token'),
                'id_token': token_data.get('id_token'),
                'expires_in': token_data.get('expires_in', 3600)
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Google token exchange failed: {str(e)}'
            }

    async def _get_user_info(self, provider: SSOProvider, access_token: str) -> Dict[str, Any]:
        """Get user information from SSO provider"""
        try:
            headers = {'Authorization': f'Bearer {access_token}'}
            
            if provider.provider_type == 'azure_ad':
                userinfo_url = self.azure_endpoints['userinfo']
            elif provider.provider_type == 'google_workspace':
                userinfo_url = self.google_endpoints['userinfo']
            else:
                return {'success': False, 'error': 'Unsupported provider type'}
            
            async with httpx.AsyncClient() as client:
                response = await client.get(userinfo_url, headers=headers)
                
            if response.status_code != 200:
                return {
                    'success': False,
                    'error': f'Failed to get user info: {response.text}'
                }
            
            user_data = response.json()
            
            # Normalize user data across providers
            normalized_data = self._normalize_user_data(provider.provider_type, user_data)
            
            return {
                'success': True,
                'user_data': normalized_data
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to get user info: {str(e)}'
            }

    def _normalize_user_data(self, provider_type: str, user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize user data across different SSO providers"""
        if provider_type == 'azure_ad':
            return {
                'external_id': user_data.get('id'),
                'email': user_data.get('mail') or user_data.get('userPrincipalName'),
                'first_name': user_data.get('givenName'),
                'last_name': user_data.get('surname'),
                'display_name': user_data.get('displayName'),
                'groups': user_data.get('groups', []),
                'raw_data': user_data
            }
        elif provider_type == 'google_workspace':
            return {
                'external_id': user_data.get('id'),
                'email': user_data.get('email'),
                'first_name': user_data.get('given_name'),
                'last_name': user_data.get('family_name'),
                'display_name': user_data.get('name'),
                'picture': user_data.get('picture'),
                'verified_email': user_data.get('verified_email'),
                'raw_data': user_data
            }
        
        return user_data

    async def _process_user_authentication(self, provider: SSOProvider, token_result: Dict[str, Any], user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Process user authentication and create/update user session"""
        try:
            # Check domain restrictions
            if provider.domain_restriction:
                user_domain = user_data['email'].split('@')[1] if user_data.get('email') else None
                if user_domain not in provider.domain_restriction:
                    await self._log_sso_event(
                        provider.tenant_id, None, provider.id, 'domain_restriction_failed',
                        {'email': user_data.get('email'), 'domain': user_domain}
                    )
                    return {
                        'success': False,
                        'error': 'Domain not allowed for this SSO provider'
                    }
            
            # Find or create user
            user = await self._find_or_create_user(provider, user_data)
            if not user:
                return {
                    'success': False,
                    'error': 'Failed to create or find user'
                }
            
            # Create or update SSO session
            session = await self._create_sso_session(provider, user['id'], token_result, user_data)
            
            await self._log_sso_event(
                provider.tenant_id, user['id'], provider.id, 'login_success',
                {'email': user_data.get('email')}
            )
            
            return {
                'success': True,
                'user': user,
                'session': session,
                'message': 'Authentication successful'
            }
            
        except Exception as e:
            await self._log_sso_event(
                provider.tenant_id, None, provider.id, 'authentication_error',
                {'error': str(e), 'email': user_data.get('email')}
            )
            return {
                'success': False,
                'error': f'Authentication processing failed: {str(e)}'
            }

    async def _find_or_create_user(self, provider: SSOProvider, user_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Find existing user or create new one if auto-provisioning is enabled"""
        try:
            # Implementation would depend on your user management system
            # This is a placeholder for the actual user creation/lookup logic
            
            email = user_data.get('email')
            if not email:
                return None
            
            # Check if user exists
            # user = await self.db.query(User).filter(User.email == email).first()
            
            # If user doesn't exist and auto-provisioning is enabled
            if provider.auto_provision:
                # Create new user
                user_data_normalized = {
                    'email': email,
                    'first_name': user_data.get('first_name'),
                    'last_name': user_data.get('last_name'),
                    'display_name': user_data.get('display_name'),
                    'role': provider.default_role,
                    'tenant_id': provider.tenant_id,
                    'is_sso_user': True,
                    'sso_provider_id': provider.id
                }
                
                # This would be implemented based on your user model
                return user_data_normalized
            
            return None
            
        except Exception as e:
            print(f"Error finding/creating user: {e}")
            return None

    async def _create_sso_session(self, provider: SSOProvider, user_id: int, token_result: Dict[str, Any], user_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create or update SSO session"""
        try:
            # Encrypt tokens
            encrypted_access_token = self.cipher.encrypt(token_result['access_token'].encode()).decode()
            encrypted_refresh_token = None
            encrypted_id_token = None
            
            if token_result.get('refresh_token'):
                encrypted_refresh_token = self.cipher.encrypt(token_result['refresh_token'].encode()).decode()
            
            if token_result.get('id_token'):
                encrypted_id_token = self.cipher.encrypt(token_result['id_token'].encode()).decode()
            
            # Calculate token expiration
            expires_at = datetime.utcnow() + timedelta(seconds=token_result.get('expires_in', 3600))
            
            # Check for existing session
            existing_session = await self.db.query(SSOSession).filter(
                SSOSession.user_id == user_id,
                SSOSession.provider_id == provider.id,
                SSOSession.is_active == True
            ).first()
            
            if existing_session:
                # Update existing session
                existing_session.access_token = encrypted_access_token
                existing_session.refresh_token = encrypted_refresh_token
                existing_session.id_token = encrypted_id_token
                existing_session.token_expires_at = expires_at
                existing_session.last_activity = datetime.utcnow()
                session = existing_session
            else:
                # Create new session
                session = SSOSession(
                    user_id=user_id,
                    provider_id=provider.id,
                    external_user_id=user_data['external_id'],
                    access_token=encrypted_access_token,
                    refresh_token=encrypted_refresh_token,
                    id_token=encrypted_id_token,
                    token_expires_at=expires_at
                )
                self.db.add(session)
            
            await self.db.commit()
            
            return {
                'session_id': session.id,
                'expires_at': expires_at,
                'provider_type': provider.provider_type
            }
            
        except Exception as e:
            await self.db.rollback()
            raise e

    async def refresh_token(self, session_id: int) -> Dict[str, Any]:
        """Refresh SSO access token"""
        try:
            session = await self.db.query(SSOSession).filter(
                SSOSession.id == session_id,
                SSOSession.is_active == True
            ).first()
            
            if not session or not session.refresh_token:
                return {
                    'success': False,
                    'error': 'Session not found or no refresh token available'
                }
            
            provider = await self.db.query(SSOProvider).filter(
                SSOProvider.id == session.provider_id
            ).first()
            
            if not provider:
                return {
                    'success': False,
                    'error': 'SSO provider not found'
                }
            
            # Decrypt refresh token
            refresh_token = self.cipher.decrypt(session.refresh_token.encode()).decode()
            
            # Refresh token based on provider type
            if provider.provider_type == 'azure_ad':
                refresh_result = await self._refresh_azure_token(provider, refresh_token)
            elif provider.provider_type == 'google_workspace':
                refresh_result = await self._refresh_google_token(provider, refresh_token)
            else:
                return {
                    'success': False,
                    'error': 'Unsupported provider type'
                }
            
            if refresh_result['success']:
                # Update session with new tokens
                session.access_token = self.cipher.encrypt(refresh_result['access_token'].encode()).decode()
                if refresh_result.get('refresh_token'):
                    session.refresh_token = self.cipher.encrypt(refresh_result['refresh_token'].encode()).decode()
                session.token_expires_at = datetime.utcnow() + timedelta(seconds=refresh_result.get('expires_in', 3600))
                session.last_activity = datetime.utcnow()
                
                await self.db.commit()
                
                await self._log_sso_event(
                    provider.tenant_id, session.user_id, provider.id, 'token_refresh_success', {}
                )
            
            return refresh_result
            
        except Exception as e:
            await self._log_sso_event(
                provider.tenant_id if provider else None, 
                session.user_id if session else None, 
                session.provider_id if session else None, 
                'token_refresh_error',
                {'error': str(e)}
            )
            return {
                'success': False,
                'error': f'Token refresh failed: {str(e)}'
            }

    async def _refresh_azure_token(self, provider: SSOProvider, refresh_token: str) -> Dict[str, Any]:
        """Refresh Azure AD access token"""
        try:
            client_secret = self.cipher.decrypt(provider.client_secret.encode()).decode()
            
            data = {
                'client_id': provider.client_id,
                'client_secret': client_secret,
                'refresh_token': refresh_token,
                'grant_type': 'refresh_token',
                'scope': ' '.join(provider.scopes or ['openid', 'profile', 'email'])
            }
            
            token_url = self.azure_endpoints['token'].format(
                tenant=provider.tenant_domain or 'common'
            )
            
            async with httpx.AsyncClient() as client:
                response = await client.post(token_url, data=data)
                
            if response.status_code != 200:
                return {
                    'success': False,
                    'error': f'Token refresh failed: {response.text}'
                }
            
            token_data = response.json()
            return {
                'success': True,
                'access_token': token_data['access_token'],
                'refresh_token': token_data.get('refresh_token', refresh_token),
                'expires_in': token_data.get('expires_in', 3600)
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Azure token refresh failed: {str(e)}'
            }

    async def _refresh_google_token(self, provider: SSOProvider, refresh_token: str) -> Dict[str, Any]:
        """Refresh Google access token"""
        try:
            client_secret = self.cipher.decrypt(provider.client_secret.encode()).decode()
            
            data = {
                'client_id': provider.client_id,
                'client_secret': client_secret,
                'refresh_token': refresh_token,
                'grant_type': 'refresh_token'
            }
            
            async with httpx.AsyncClient() as client:
                response = await client.post(self.google_endpoints['token'], data=data)
                
            if response.status_code != 200:
                return {
                    'success': False,
                    'error': f'Token refresh failed: {response.text}'
                }
            
            token_data = response.json()
            return {
                'success': True,
                'access_token': token_data['access_token'],
                'refresh_token': refresh_token,  # Google doesn't always return new refresh token
                'expires_in': token_data.get('expires_in', 3600)
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Google token refresh failed: {str(e)}'
            }

    async def logout_sso_session(self, session_id: int) -> Dict[str, Any]:
        """Logout SSO session"""
        try:
            session = await self.db.query(SSOSession).filter(
                SSOSession.id == session_id,
                SSOSession.is_active == True
            ).first()
            
            if not session:
                return {
                    'success': False,
                    'error': 'Session not found'
                }
            
            provider = await self.db.query(SSOProvider).filter(
                SSOProvider.id == session.provider_id
            ).first()
            
            # Mark session as inactive
            session.is_active = False
            await self.db.commit()
            
            await self._log_sso_event(
                provider.tenant_id if provider else None, 
                session.user_id, 
                session.provider_id, 
                'logout_success', 
                {}
            )
            
            return {
                'success': True,
                'message': 'Session logged out successfully'
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Logout failed: {str(e)}'
            }

    async def get_sso_health_status(self, tenant_id: int) -> Dict[str, Any]:
        """Get SSO health status for a tenant"""
        try:
            providers = await self.db.query(SSOProvider).filter(
                SSOProvider.tenant_id == tenant_id,
                SSOProvider.is_active == True
            ).all()
            
            health_status = {
                'total_providers': len(providers),
                'providers': [],
                'overall_health': 'healthy'
            }
            
            for provider in providers:
                # Check recent login attempts
                recent_logs = await self.db.query(SSOAuditLog).filter(
                    SSOAuditLog.provider_id == provider.id,
                    SSOAuditLog.timestamp >= datetime.utcnow() - timedelta(hours=24)
                ).all()
                
                success_count = len([log for log in recent_logs if log.success])
                total_count = len(recent_logs)
                success_rate = (success_count / total_count * 100) if total_count > 0 else 100
                
                provider_health = {
                    'provider_id': provider.id,
                    'provider_name': provider.provider_name,
                    'provider_type': provider.provider_type,
                    'success_rate_24h': success_rate,
                    'total_attempts_24h': total_count,
                    'status': 'healthy' if success_rate >= 95 else 'degraded' if success_rate >= 80 else 'unhealthy'
                }
                
                health_status['providers'].append(provider_health)
                
                if provider_health['status'] != 'healthy':
                    health_status['overall_health'] = 'degraded'
            
            return {
                'success': True,
                'health_status': health_status
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to get health status: {str(e)}'
            }

    async def _log_sso_event(self, tenant_id: int, user_id: Optional[int], provider_id: int, event_type: str, event_details: Dict[str, Any]):
        """Log SSO events for audit purposes"""
        try:
            log_entry = SSOAuditLog(
                tenant_id=tenant_id,
                user_id=user_id,
                provider_id=provider_id,
                event_type=event_type,
                event_details=event_details,
                success=event_type not in ['login_failed', 'token_exchange_failed', 'domain_restriction_failed', 'authentication_error', 'token_refresh_error']
            )
            
            self.db.add(log_entry)
            await self.db.commit()
            
        except Exception as e:
            print(f"Failed to log SSO event: {e}")
```

### SSO API Routes

```python
# backend/app/modules/auth/routes/sso_routes.py
from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import RedirectResponse
from typing import Dict, Any
import asyncio

router = APIRouter(prefix="/api/v1/sso", tags=["SSO"])

@router.post("/providers")
async def create_sso_provider(
    provider_config: Dict[str, Any],
    sso_service: SSOService = Depends(get_sso_service),
    current_user: Dict = Depends(get_current_admin_user)
):
    """Create a new SSO provider configuration"""
    result = await sso_service.create_sso_provider(
        current_user['tenant_id'], 
        provider_config
    )
    
    if not result['success']:
        raise HTTPException(status_code=400, detail=result['error'])
    
    return result

@router.get("/auth/{provider_id}")
async def initiate_sso_auth(
    provider_id: int,
    request: Request,
    sso_service: SSOService = Depends(get_sso_service)
):
    """Initiate SSO authentication"""
    result = await sso_service.generate_auth_url(provider_id)
    
    if not result['success']:
        raise HTTPException(status_code=400, detail=result['error'])
    
    # Store state in session for validation
    request.session['sso_state'] = result['state']
    request.session['sso_provider_id'] = provider_id
    
    return RedirectResponse(url=result['auth_url'])

@router.get("/callback/{provider_id}")
async def sso_callback(
    provider_id: int,
    code: str,
    state: str,
    request: Request,
    response: Response,
    sso_service: SSOService = Depends(get_sso_service)
):
    """Handle SSO callback"""
    # Validate state parameter
    stored_state = request.session.get('sso_state')
    stored_provider_id = request.session.get('sso_provider_id')
    
    if not stored_state or stored_state != state or stored_provider_id != provider_id:
        raise HTTPException(status_code=400, detail="Invalid state parameter")
    
    # Clear session state
    request.session.pop('sso_state', None)
    request.session.pop('sso_provider_id', None)
    
    result = await sso_service.handle_callback(provider_id, code, state)
    
    if not result['success']:
        raise HTTPException(status_code=400, detail=result['error'])
    
    # Set authentication cookies/session
    # This would depend on your authentication system
    
    return {
        'success': True,
        'user': result['user'],
        'message': result['message']
    }

@router.post("/refresh/{session_id}")
async def refresh_sso_token(
    session_id: int,
    sso_service: SSOService = Depends(get_sso_service),
    current_user: Dict = Depends(get_current_user)
):
    """Refresh SSO access token"""
    result = await sso_service.refresh_token(session_id)
    
    if not result['success']:
        raise HTTPException(status_code=400, detail=result['error'])
    
    return result

@router.post("/logout/{session_id}")
async def logout_sso_session(
    session_id: int,
    sso_service: SSOService = Depends(get_sso_service),
    current_user: Dict = Depends(get_current_user)
):
    """Logout SSO session"""
    result = await sso_service.logout_sso_session(session_id)
    
    if not result['success']:
        raise HTTPException(status_code=400, detail=result['error'])
    
    return result

@router.get("/health")
async def get_sso_health(
    sso_service: SSOService = Depends(get_sso_service),
    current_user: Dict = Depends(get_current_admin_user)
):
    """Get SSO health status"""
    result = await sso_service.get_sso_health_status(current_user['tenant_id'])
    
    if not result['success']:
        raise HTTPException(status_code=500, detail=result['error'])
    
    return result['health_status']
```

---

## 2. Contract Management (DMS Integration)

### Database Models

```python
# backend/app/modules/contracts/models/contract_models.py
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, JSON, Enum, Numeric
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum

Base = declarative_base()

class ContractStatus(enum.Enum):
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    ACTIVE = "active"
    EXPIRED = "expired"
    TERMINATED = "terminated"
    CANCELLED = "cancelled"

class ContractType(enum.Enum):
    RENTAL_AGREEMENT = "rental_agreement"
    SERVICE_CONTRACT = "service_contract"
    MAINTENANCE_AGREEMENT = "maintenance_agreement"
    INSURANCE_POLICY = "insurance_policy"
    VENDOR_AGREEMENT = "vendor_agreement"
    EMPLOYMENT_CONTRACT = "employment_contract"
    NDA = "nda"
    SLA = "sla"

class Contract(Base):
    __tablename__ = "contracts"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    contract_number = Column(String(100), unique=True, nullable=False)
    title = Column(String(255), nullable=False)
    contract_type = Column(Enum(ContractType), nullable=False)
    status = Column(Enum(ContractStatus), default=ContractStatus.DRAFT)
    
    # Parties
    client_id = Column(Integer)  # Reference to client/customer
    client_name = Column(String(255), nullable=False)
    client_email = Column(String(255))
    client_address = Column(Text)
    
    # Contract details
    description = Column(Text)
    terms_and_conditions = Column(Text)
    special_clauses = Column(JSON, default=list)
    
    # Financial terms
    total_value = Column(Numeric(15, 2))
    currency = Column(String(3), default='EUR')
    payment_terms = Column(String(255))
    deposit_amount = Column(Numeric(15, 2))
    
    # Dates
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    renewal_date = Column(DateTime)
    notice_period_days = Column(Integer, default=30)
    
    # Document management
    template_id = Column(Integer)
    document_path = Column(String(500))  # Path to generated document
    document_version = Column(Integer, default=1)
    document_hash = Column(String(64))  # For integrity verification
    
    # Workflow
    created_by = Column(Integer, nullable=False)
    assigned_to = Column(Integer)  # Current assignee for review/approval
    approved_by = Column(Integer)
    approved_at = Column(DateTime)
    
    # Metadata
    tags = Column(JSON, default=list)
    custom_fields = Column(JSON, default=dict)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ContractTemplate(Base):
    __tablename__ = "contract_templates"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    name = Column(String(255), nullable=False)
    contract_type = Column(Enum(ContractType), nullable=False)
    description = Column(Text)
    
    # Template content
    template_content = Column(Text, nullable=False)  # HTML/Markdown template
    template_variables = Column(JSON, default=list)  # List of variables to be replaced
    
    # Configuration
    is_active = Column(Boolean, default=True)
    is_default = Column(Boolean, default=False)
    approval_required = Column(Boolean, default=True)
    auto_renewal = Column(Boolean, default=False)
    
    # Metadata
    version = Column(String(20), default='1.0')
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ContractDocument(Base):
    __tablename__ = "contract_documents"
    
    id = Column(Integer, primary_key=True)
    contract_id = Column(Integer, nullable=False)
    document_name = Column(String(255), nullable=False)
    document_type = Column(String(50), nullable=False)  # 'contract', 'amendment', 'attachment'
    file_path = Column(String(500), nullable=False)
    file_size = Column(Integer)
    mime_type = Column(String(100))
    document_hash = Column(String(64))
    version = Column(Integer, default=1)
    
    # DMS integration
    dms_document_id = Column(String(255))  # External DMS document ID
    dms_metadata = Column(JSON, default=dict)
    
    uploaded_by = Column(Integer, nullable=False)
    uploaded_at = Column(DateTime, default=datetime.utcnow)

class ContractWorkflow(Base):
    __tablename__ = "contract_workflows"
    
    id = Column(Integer, primary_key=True)
    contract_id = Column(Integer, nullable=False)
    step_name = Column(String(100), nullable=False)
    step_order = Column(Integer, nullable=False)
    assigned_to = Column(Integer)
    assigned_role = Column(String(50))  # 'legal', 'manager', 'admin'
    
    status = Column(String(50), default='pending')  # 'pending', 'in_progress', 'completed', 'rejected'
    comments = Column(Text)
    completed_by = Column(Integer)
    completed_at = Column(DateTime)
    
    # Deadlines
    due_date = Column(DateTime)
    reminder_sent = Column(Boolean, default=False)
    
    created_at = Column(DateTime, default=datetime.utcnow)

class ContractAuditLog(Base):
    __tablename__ = "contract_audit_logs"
    
    id = Column(Integer, primary_key=True)
    contract_id = Column(Integer, nullable=False)
    user_id = Column(Integer, nullable=False)
    action = Column(String(100), nullable=False)
    details = Column(JSON)
    old_values = Column(JSON)
    new_values = Column(JSON)
    ip_address = Column(String(45))
    user_agent = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)
```

### Contract Management Service

```python
# backend/app/modules/contracts/services/contract_service.py
import asyncio
import os
import hashlib
import uuid
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from jinja2 import Template
import aiofiles
from weasyprint import HTML, CSS
import json

class ContractManagementService:
    def __init__(self, db_session, file_storage_path: str, dms_config: Dict[str, Any] = None):
        self.db = db_session
        self.storage_path = file_storage_path
        self.dms_config = dms_config or {}
        
        # Ensure storage directories exist
        os.makedirs(f"{self.storage_path}/contracts", exist_ok=True)
        os.makedirs(f"{self.storage_path}/templates", exist_ok=True)

    async def create_contract_template(self, tenant_id: int, template_data: Dict[str, Any], created_by: int) -> Dict[str, Any]:
        """Create a new contract template"""
        try:
            template = ContractTemplate(
                tenant_id=tenant_id,
                name=template_data['name'],
                contract_type=ContractType(template_data['contract_type']),
                description=template_data.get('description'),
                template_content=template_data['template_content'],
                template_variables=template_data.get('template_variables', []),
                is_active=template_data.get('is_active', True),
                is_default=template_data.get('is_default', False),
                approval_required=template_data.get('approval_required', True),
                auto_renewal=template_data.get('auto_renewal', False),
                version=template_data.get('version', '1.0'),
                created_by=created_by
            )
            
            # If this is set as default, unset other defaults for this type
            if template.is_default:
                await self.db.execute(
                    f"UPDATE contract_templates SET is_default = FALSE WHERE tenant_id = {tenant_id} AND contract_type = '{template.contract_type.value}'"
                )
            
            self.db.add(template)
            await self.db.commit()
            
            await self._log_contract_action(
                None, created_by, 'template_created',
                {'template_id': template.id, 'template_name': template.name}
            )
            
            return {
                'success': True,
                'template_id': template.id,
                'message': 'Contract template created successfully'
            }
            
        except Exception as e:
            await self.db.rollback()
            return {
                'success': False,
                'error': f'Failed to create contract template: {str(e)}'
            }

    async def create_contract(self, tenant_id: int, contract_data: Dict[str, Any], created_by: int) -> Dict[str, Any]:
        """Create a new contract"""
        try:
            # Generate contract number
            contract_number = await self._generate_contract_number(tenant_id, contract_data['contract_type'])
            
            contract = Contract(
                tenant_id=tenant_id,
                contract_number=contract_number,
                title=contract_data['title'],
                contract_type=ContractType(contract_data['contract_type']),
                client_id=contract_data.get('client_id'),
                client_name=contract_data['client_name'],
                client_email=contract_data.get('client_email'),
                client_address=contract_data.get('client_address'),
                description=contract_data.get('description'),
                terms_and_conditions=contract_data.get('terms_and_conditions'),
                special_clauses=contract_data.get('special_clauses', []),
                total_value=contract_data.get('total_value'),
                currency=contract_data.get('currency', 'EUR'),
                payment_terms=contract_data.get('payment_terms'),
                deposit_amount=contract_data.get('deposit_amount'),
                start_date=contract_data.get('start_date'),
                end_date=contract_data.get('end_date'),
                renewal_date=contract_data.get('renewal_date'),
                notice_period_days=contract_data.get('notice_period_days', 30),
                template_id=contract_data.get('template_id'),
                created_by=created_by,
                assigned_to=contract_data.get('assigned_to'),
                tags=contract_data.get('tags', []),
                custom_fields=contract_data.get('custom_fields', {})
            )
            
            self.db.add(contract)
            await self.db.commit()
            
            # Create workflow steps if template requires approval
            if contract.template_id:
                await self._create_contract_workflow(contract.id, contract.template_id)
            
            # Generate contract document if template is provided
            if contract.template_id:
                document_result = await self._generate_contract_document(contract.id, contract_data)
                if document_result['success']:
                    contract.document_path = document_result['document_path']
                    contract.document_hash = document_result['document_hash']
                    await self.db.commit()
            
            await self._log_contract_action(
                contract.id, created_by, 'contract_created',
                {'contract_number': contract_number, 'title': contract.title}
            )
            
            return {
                'success': True,
                'contract_id': contract.id,
                'contract_number': contract_number,
                'message': 'Contract created successfully'
            }
            
        except Exception as e:
            await self.db.rollback()
            return {
                'success': False,
                'error': f'Failed to create contract: {str(e)}'
            }

    async def _generate_contract_number(self, tenant_id: int, contract_type: str) -> str:
        """Generate unique contract number"""
        try:
            # Get current year and month
            now = datetime.utcnow()
            year = now.strftime('%Y')
            month = now.strftime('%m')
            
            # Get contract type prefix
            type_prefixes = {
                'rental_agreement': 'RA',
                'service_contract': 'SC',
                'maintenance_agreement': 'MA',
                'insurance_policy': 'IP',
                'vendor_agreement': 'VA',
                'employment_contract': 'EC',
                'nda': 'NDA',
                'sla': 'SLA'
            }
            
            prefix = type_prefixes.get(contract_type, 'CON')
            
            # Get next sequence number for this tenant, type, and month
            count = await self.db.execute(
                f"""
                SELECT COUNT(*) FROM contracts 
                WHERE tenant_id = {tenant_id} 
                AND contract_type = '{contract_type}' 
                AND DATE_FORMAT(created_at, '%Y-%m') = '{year}-{month}'
                """
            ).scalar()
            
            sequence = str(count + 1).zfill(4)
            
            return f"{prefix}-{year}{month}-{sequence}"
            
        except Exception as e:
            # Fallback to UUID-based number
            return f"CON-{uuid.uuid4().hex[:8].upper()}"

    async def _generate_contract_document(self, contract_id: int, contract_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate contract document from template"""
        try:
            contract = await self.db.query(Contract).filter(Contract.id == contract_id).first()
            if not contract or not contract.template_id:
                return {'success': False, 'error': 'Contract or template not found'}
            
            template = await self.db.query(ContractTemplate).filter(
                ContractTemplate.id == contract.template_id
            ).first()
            
            if not template:
                return {'success': False, 'error': 'Template not found'}
            
            # Prepare template variables
            template_vars = {
                'contract': {
                    'number': contract.contract_number,
                    'title': contract.title,
                    'type': contract.contract_type.value,
                    'description': contract.description,
                    'terms_and_conditions': contract.terms_and_conditions,
                    'special_clauses': contract.special_clauses,
                    'total_value': contract.total_value,
                    'currency': contract.currency,
                    'payment_terms': contract.payment_terms,
                    'deposit_amount': contract.deposit_amount,
                    'start_date': contract.start_date.strftime('%Y-%m-%d') if contract.start_date else None,
                    'end_date': contract.end_date.strftime('%Y-%m-%d') if contract.end_date else None,
                    'renewal_date': contract.renewal_date.strftime('%Y-%m-%d') if contract.renewal_date else None,
                    'notice_period_days': contract.notice_period_days
                },
                'client': {
                    'name': contract.client_name,
                    'email': contract.client_email,
                    'address': contract.client_address
                },
                'company': contract_data.get('company_info', {}),
                'custom_fields': contract.custom_fields,
                'generated_date': datetime.utcnow().strftime('%Y-%m-%d'),
                'generated_time': datetime.utcnow().strftime('%H:%M:%S')
            }
            
            # Render template
            jinja_template = Template(template.template_content)
            rendered_html = jinja_template.render(**template_vars)
            
            # Generate PDF
            document_filename = f"{contract.contract_number}_{contract.document_version}.pdf"
            document_path = f"{self.storage_path}/contracts/{document_filename}"
            
            HTML(string=rendered_html).write_pdf(document_path)
            
            # Calculate document hash
            document_hash = await self._calculate_file_hash(document_path)
            
            # Store document record
            document = ContractDocument(
                contract_id=contract_id,
                document_name=document_filename,
                document_type='contract',
                file_path=document_path,
                file_size=os.path.getsize(document_path),
                mime_type='application/pdf',
                document_hash=document_hash,
                version=contract.document_version,
                uploaded_by=contract.created_by
            )
            
            self.db.add(document)
            await self.db.commit()
            
            # Integrate with DMS if configured
            if self.dms_config.get('enabled'):
                dms_result = await self._upload_to_dms(document_path, document_filename, contract_id)
                if dms_result['success']:
                    document.dms_document_id = dms_result['document_id']
                    document.dms_metadata = dms_result['metadata']
                    await self.db.commit()
            
            return {
                'success': True,
                'document_path': document_path,
                'document_hash': document_hash,
                'document_id': document.id
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to generate contract document: {str(e)}'
            }

    async def _calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA-256 hash of file"""
        hash_sha256 = hashlib.sha256()
        async with aiofiles.open(file_path, 'rb') as f:
            async for chunk in f:
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()

    async def _upload_to_dms(self, file_path: str, filename: str, contract_id: int) -> Dict[str, Any]:
        """Upload document to Document Management System"""
        try:
            # This is a placeholder for DMS integration
            # Implementation would depend on the specific DMS system (SharePoint, Alfresco, etc.)
            
            # Mock DMS upload
            dms_document_id = f"DMS_{uuid.uuid4().hex[:12].upper()}"
            
            metadata = {
                'contract_id': contract_id,
                'filename': filename,
                'upload_date': datetime.utcnow().isoformat(),
                'file_size': os.path.getsize(file_path),
                'content_type': 'application/pdf'
            }
            
            return {
                'success': True,
                'document_id': dms_document_id,
                'metadata': metadata
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'DMS upload failed: {str(e)}'
            }

    async def _create_contract_workflow(self, contract_id: int, template_id: int):
        """Create workflow steps for contract approval"""
        try:
            template = await self.db.query(ContractTemplate).filter(
                ContractTemplate.id == template_id
            ).first()
            
            if not template or not template.approval_required:
                return
            
            # Default workflow steps for AV rental contracts
            workflow_steps = [
                {'step_name': 'Legal Review', 'assigned_role': 'legal', 'step_order': 1},
                {'step_name': 'Manager Approval', 'assigned_role': 'manager', 'step_order': 2},
                {'step_name': 'Final Approval', 'assigned_role': 'admin', 'step_order': 3}
            ]
            
            for step in workflow_steps:
                workflow = ContractWorkflow(
                    contract_id=contract_id,
                    step_name=step['step_name'],
                    step_order=step['step_order'],
                    assigned_role=step['assigned_role'],
                    due_date=datetime.utcnow() + timedelta(days=3)  # 3 days per step
                )
                self.db.add(workflow)
            
            await self.db.commit()
            
        except Exception as e:
            print(f"Failed to create workflow: {e}")

    async def update_contract_status(self, contract_id: int, new_status: str, user_id: int, comments: str = None) -> Dict[str, Any]:
        """Update contract status"""
        try:
            contract = await self.db.query(Contract).filter(Contract.id == contract_id).first()
            if not contract:
                return {'success': False, 'error': 'Contract not found'}
            
            old_status = contract.status
            contract.status = ContractStatus(new_status)
            
            # Handle status-specific logic
            if new_status == 'approved':
                contract.approved_by = user_id
                contract.approved_at = datetime.utcnow()
            elif new_status == 'active':
                if not contract.start_date:
                    contract.start_date = datetime.utcnow()
            
            await self.db.commit()
            
            await self._log_contract_action(
                contract_id, user_id, 'status_changed',
                {
                    'old_status': old_status.value,
                    'new_status': new_status,
                    'comments': comments
                }
            )
            
            return {
                'success': True,
                'message': f'Contract status updated to {new_status}'
            }
            
        except Exception as e:
            await self.db.rollback()
            return {
                'success': False,
                'error': f'Failed to update contract status: {str(e)}'
            }

    async def get_contract_analytics(self, tenant_id: int, date_range: Dict[str, Any] = None) -> Dict[str, Any]:
        """Get contract analytics for AV rental business"""
        try:
            # Date range filter
            date_filter = ""
            if date_range:
                start_date = date_range.get('start_date')
                end_date = date_range.get('end_date')
                if start_date and end_date:
                    date_filter = f"AND created_at BETWEEN '{start_date}' AND '{end_date}'"
            
            # Contract status distribution
            status_query = f"""
                SELECT status, COUNT(*) as count 
                FROM contracts 
                WHERE tenant_id = {tenant_id} {date_filter}
                GROUP BY status
            """
            status_results = await self.db.execute(status_query).fetchall()
            
            # Contract type distribution
            type_query = f"""
                SELECT contract_type, COUNT(*) as count 
                FROM contracts 
                WHERE tenant_id = {tenant_id} {date_filter}
                GROUP BY contract_type
            """
            type_results = await self.db.execute(type_query).fetchall()
            
            # Financial metrics
            financial_query = f"""
                SELECT 
                    SUM(total_value) as total_contract_value,
                    AVG(total_value) as average_contract_value,
                    COUNT(*) as total_contracts
                FROM contracts 
                WHERE tenant_id = {tenant_id} 
                AND total_value IS NOT NULL 
                {date_filter}
            """
            financial_results = await self.db.execute(financial_query).fetchone()
            
            # Contract lifecycle metrics
            lifecycle_query = f"""
                SELECT 
                    AVG(DATEDIFF(approved_at, created_at)) as avg_approval_time_days,
                    COUNT(CASE WHEN status = 'active' THEN 1 END) as active_contracts,
                    COUNT(CASE WHEN end_date < NOW() THEN 1 END) as expired_contracts
                FROM contracts 
                WHERE tenant_id = {tenant_id} {date_filter}
            """
            lifecycle_results = await self.db.execute(lifecycle_query).fetchone()
            
            # Monthly contract creation trend
            trend_query = f"""
                SELECT 
                    DATE_FORMAT(created_at, '%Y-%m') as month,
                    COUNT(*) as contracts_created
                FROM contracts 
                WHERE tenant_id = {tenant_id} {date_filter}
                GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                ORDER BY month DESC
                LIMIT 12
            """
            trend_results = await self.db.execute(trend_query).fetchall()
            
            return {
                'success': True,
                'analytics': {
                    'status_distribution': [
                        {'status': row[0], 'count': row[1]} 
                        for row in status_results
                    ],
                    'type_distribution': [
                        {'type': row[0], 'count': row[1]} 
                        for row in type_results
                    ],
                    'financial_metrics': {
                        'total_contract_value': float(financial_results[0] or 0),
                        'average_contract_value': float(financial_results[1] or 0),
                        'total_contracts': financial_results[2] or 0
                    },
                    'lifecycle_metrics': {
                        'avg_approval_time_days': float(lifecycle_results[0] or 0),
                        'active_contracts': lifecycle_results[1] or 0,
                        'expired_contracts': lifecycle_results[2] or 0
                    },
                    'creation_trend': [
                        {'month': row[0], 'count': row[1]} 
                        for row in trend_results
                    ]
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to get contract analytics: {str(e)}'
            }

    async def get_contract_health_status(self, tenant_id: int) -> Dict[str, Any]:
        """Get contract management system health status"""
        try:
            # System health checks
            health_checks = {
                'database_connection': True,
                'file_storage_accessible': os.path.exists(self.storage_path),
                'dms_integration': self.dms_config.get('enabled', False)
            }
            
            # Contract metrics
            total_contracts = await self.db.query(Contract).filter(
                Contract.tenant_id == tenant_id
            ).count()
            
            active_contracts = await self.db.query(Contract).filter(
                Contract.tenant_id == tenant_id,
                Contract.status == ContractStatus.ACTIVE
            ).count()
            
            pending_approvals = await self.db.query(Contract).filter(
                Contract.tenant_id == tenant_id,
                Contract.status.in_([ContractStatus.PENDING_REVIEW, ContractStatus.UNDER_REVIEW])
            ).count()
            
            # Expiring contracts (next 30 days)
            expiring_soon = await self.db.query(Contract).filter(
                Contract.tenant_id == tenant_id,
                Contract.status == ContractStatus.ACTIVE,
                Contract.end_date <= datetime.utcnow() + timedelta(days=30)
            ).count()
            
            # Overall health score
            health_score = 100
            if pending_approvals > 10:
                health_score -= 20
            if expiring_soon > 5:
                health_score -= 15
            if not health_checks['file_storage_accessible']:
                health_score -= 30
            
            health_status = 'healthy' if health_score >= 80 else 'degraded' if health_score >= 60 else 'unhealthy'
            
            return {
                'success': True,
                'health_status': {
                    'overall_health': health_status,
                    'health_score': health_score,
                    'system_checks': health_checks,
                    'metrics': {
                        'total_contracts': total_contracts,
                        'active_contracts': active_contracts,
                        'pending_approvals': pending_approvals,
                        'expiring_soon': expiring_soon
                    },
                    'alerts': [
                        f"{pending_approvals} contracts pending approval" if pending_approvals > 0 else None,
                        f"{expiring_soon} contracts expiring within 30 days" if expiring_soon > 0 else None,
                        "File storage not accessible" if not health_checks['file_storage_accessible'] else None
                    ]
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to get health status: {str(e)}'
            }

    async def _log_contract_action(self, contract_id: Optional[int], user_id: int, action: str, details: Dict[str, Any]):
        """Log contract actions for audit purposes"""
        try:
            log_entry = ContractAuditLog(
                contract_id=contract_id,
                user_id=user_id,
                action=action,
                details=details
            )
            
            self.db.add(log_entry)
            await self.db.commit()
            
        except Exception as e:
            print(f"Failed to log contract action: {e}")
```

---

## 3. SLA/Compliance Dashboards

### Database Models

```python
# backend/app/modules/compliance/models/sla_models.py
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, JSON, Enum, Numeric
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum

Base = declarative_base()

class SLAType(enum.Enum):
    AVAILABILITY = "availability"
    RESPONSE_TIME = "response_time"
    RESOLUTION_TIME = "resolution_time"
    EQUIPMENT_UPTIME = "equipment_uptime"
    DELIVERY_TIME = "delivery_time"
    CUSTOMER_SATISFACTION = "customer_satisfaction"

class ComplianceFramework(enum.Enum):
    GDPR = "gdpr"
    ISO27001 = "iso27001"
    SOC2 = "soc2"
    HIPAA = "hipaa"
    PCI_DSS = "pci_dss"
    CUSTOM = "custom"

class SLAMetric(Base):
    __tablename__ = "sla_metrics"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    name = Column(String(255), nullable=False)
    sla_type = Column(Enum(SLAType), nullable=False)
    description = Column(Text)
    
    # Targets
    target_value = Column(Numeric(10, 4), nullable=False)
    target_unit = Column(String(50), nullable=False)  # 'percentage', 'seconds', 'minutes', 'hours'
    threshold_warning = Column(Numeric(10, 4))  # Warning threshold
    threshold_critical = Column(Numeric(10, 4))  # Critical threshold
    
    # Measurement
    measurement_frequency = Column(String(50), default='hourly')  # 'realtime', 'hourly', 'daily'
    measurement_window = Column(Integer, default=24)  # Hours for rolling window
    
    # Configuration
    is_active = Column(Boolean, default=True)
    auto_alert = Column(Boolean, default=True)
    escalation_rules = Column(JSON, default=list)
    
    # Metadata
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SLAMeasurement(Base):
    __tablename__ = "sla_measurements"
    
    id = Column(Integer, primary_key=True)
    sla_metric_id = Column(Integer, nullable=False)
    measured_value = Column(Numeric(10, 4), nullable=False)
    target_value = Column(Numeric(10, 4), nullable=False)
    compliance_percentage = Column(Numeric(5, 2))  # Calculated compliance %
    
    # Status
    status = Column(String(20), default='compliant')  # 'compliant', 'warning', 'breach'
    breach_duration = Column(Integer, default=0)  # Minutes in breach
    
    # Context
    measurement_period_start = Column(DateTime, nullable=False)
    measurement_period_end = Column(DateTime, nullable=False)
    sample_count = Column(Integer, default=1)
    raw_data = Column(JSON)  # Raw measurement data
    
    # Timestamps
    measured_at = Column(DateTime, default=datetime.utcnow)

class ComplianceRequirement(Base):
    __tablename__ = "compliance_requirements"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    framework = Column(Enum(ComplianceFramework), nullable=False)
    requirement_id = Column(String(100), nullable=False)  # e.g., 'GDPR-Art-32'
    title = Column(String(255), nullable=False)
    description = Column(Text)
    
    # Implementation
    implementation_status = Column(String(50), default='not_started')  # 'not_started', 'in_progress', 'implemented', 'verified'
    implementation_details = Column(Text)
    evidence_documents = Column(JSON, default=list)
    
    # Assessment
    last_assessment_date = Column(DateTime)
    next_assessment_due = Column(DateTime)
    assessment_frequency = Column(Integer, default=365)  # Days
    compliance_score = Column(Numeric(3, 2))  # 0.00 to 1.00
    
    # Responsibility
    assigned_to = Column(Integer)
    responsible_team = Column(String(100))
    
    # Metadata
    priority = Column(String(20), default='medium')  # 'low', 'medium', 'high', 'critical'
    tags = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ComplianceAudit(Base):
    __tablename__ = "compliance_audits"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    audit_name = Column(String(255), nullable=False)
    framework = Column(Enum(ComplianceFramework), nullable=False)
    audit_type = Column(String(50), nullable=False)  # 'internal', 'external', 'self_assessment'
    
    # Audit details
    auditor_name = Column(String(255))
    audit_firm = Column(String(255))
    audit_scope = Column(Text)
    
    # Schedule
    planned_start_date = Column(DateTime)
    planned_end_date = Column(DateTime)
    actual_start_date = Column(DateTime)
    actual_end_date = Column(DateTime)
    
    # Results
    overall_score = Column(Numeric(3, 2))  # 0.00 to 1.00
    findings_count = Column(Integer, default=0)
    critical_findings = Column(Integer, default=0)
    high_findings = Column(Integer, default=0)
    medium_findings = Column(Integer, default=0)
    low_findings = Column(Integer, default=0)
    
    # Status
    status = Column(String(50), default='planned')  # 'planned', 'in_progress', 'completed', 'cancelled'
    report_path = Column(String(500))
    
    # Metadata
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class SLAAlert(Base):
    __tablename__ = "sla_alerts"
    
    id = Column(Integer, primary_key=True)
    sla_metric_id = Column(Integer, nullable=False)
    alert_type = Column(String(50), nullable=False)  # 'warning', 'breach', 'recovery'
    severity = Column(String(20), default='medium')  # 'low', 'medium', 'high', 'critical'
    
    # Alert details
    message = Column(Text, nullable=False)
    current_value = Column(Numeric(10, 4))
    target_value = Column(Numeric(10, 4))
    breach_duration = Column(Integer, default=0)  # Minutes
    
    # Status
    status = Column(String(20), default='active')  # 'active', 'acknowledged', 'resolved'
    acknowledged_by = Column(Integer)
    acknowledged_at = Column(DateTime)
    resolved_at = Column(DateTime)
    
    # Escalation
    escalation_level = Column(Integer, default=0)
    escalated_to = Column(JSON, default=list)
    
    # Timestamps
    triggered_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

### SLA/Compliance Service

```python
# backend/app/modules/compliance/services/sla_compliance_service.py
import asyncio
import json
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import statistics
from dataclasses import dataclass

@dataclass
class SLATarget:
    name: str
    target_value: float
    current_value: float
    compliance_percentage: float
    status: str
    trend: str

class SLAComplianceService:
    def __init__(self, db_session, monitoring_service=None):
        self.db = db_session
        self.monitoring = monitoring_service
        
        # AV Rental specific SLA targets
        self.default_sla_targets = {
            'equipment_availability': {'target': 99.5, 'unit': 'percentage'},
            'booking_response_time': {'target': 2.0, 'unit': 'seconds'},
            'delivery_time_compliance': {'target': 95.0, 'unit': 'percentage'},
            'equipment_setup_time': {'target': 30.0, 'unit': 'minutes'},
            'customer_satisfaction': {'target': 4.5, 'unit': 'rating'},
            'incident_resolution_time': {'target': 4.0, 'unit': 'hours'}
        }

    async def create_sla_metric(self, tenant_id: int, metric_data: Dict[str, Any], created_by: int) -> Dict[str, Any]:
        """Create a new SLA metric"""
        try:
            metric = SLAMetric(
                tenant_id=tenant_id,
                name=metric_data['name'],
                sla_type=SLAType(metric_data['sla_type']),
                description=metric_data.get('description'),
                target_value=metric_data['target_value'],
                target_unit=metric_data['target_unit'],
                threshold_warning=metric_data.get('threshold_warning'),
                threshold_critical=metric_data.get('threshold_critical'),
                measurement_frequency=metric_data.get('measurement_frequency', 'hourly'),
                measurement_window=metric_data.get('measurement_window', 24),
                is_active=metric_data.get('is_active', True),
                auto_alert=metric_data.get('auto_alert', True),
                escalation_rules=metric_data.get('escalation_rules', []),
                created_by=created_by
            )
            
            self.db.add(metric)
            await self.db.commit()
            
            return {
                'success': True,
                'metric_id': metric.id,
                'message': 'SLA metric created successfully'
            }
            
        except Exception as e:
            await self.db.rollback()
            return {
                'success': False,
                'error': f'Failed to create SLA metric: {str(e)}'
            }

    async def record_sla_measurement(self, metric_id: int, measured_value: float, measurement_context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Record an SLA measurement"""
        try:
            metric = await self.db.query(SLAMetric).filter(
                SLAMetric.id == metric_id,
                SLAMetric.is_active == True
            ).first()
            
            if not metric:
                return {'success': False, 'error': 'SLA metric not found'}
            
            # Calculate compliance percentage
            if metric.sla_type in [SLAType.AVAILABILITY, SLAType.CUSTOMER_SATISFACTION]:
                # Higher is better
                compliance_percentage = min(100.0, (measured_value / metric.target_value) * 100)
            else:
                # Lower is better (response time, resolution time)
                compliance_percentage = min(100.0, (metric.target_value / measured_value) * 100)
            
            # Determine status
            status = 'compliant'
            if metric.threshold_critical and compliance_percentage < metric.threshold_critical:
                status = 'breach'
            elif metric.threshold_warning and compliance_percentage < metric.threshold_warning:
                status = 'warning'
            
            # Create measurement record
            measurement = SLAMeasurement(
                sla_metric_id=metric_id,
                measured_value=measured_value,
                target_value=metric.target_value,
                compliance_percentage=compliance_percentage,
                status=status,
                measurement_period_start=measurement_context.get('period_start', datetime.utcnow() - timedelta(hours=1)),
                measurement_period_end=measurement_context.get('period_end', datetime.utcnow()),
                sample_count=measurement_context.get('sample_count', 1),
                raw_data=measurement_context.get('raw_data', {})
            )
            
            self.db.add(measurement)
            await self.db.commit()
            
            # Generate alerts if needed
            if status != 'compliant' and metric.auto_alert:
                await self._generate_sla_alert(metric, measurement)
            
            return {
                'success': True,
                'measurement_id': measurement.id,
                'compliance_percentage': compliance_percentage,
                'status': status
            }
            
        except Exception as e:
            await self.db.rollback()
            return {
                'success': False,
                'error': f'Failed to record SLA measurement: {str(e)}'
            }

    async def get_sla_dashboard(self, tenant_id: int, time_range: Dict[str, Any] = None) -> Dict[str, Any]:
        """Get comprehensive SLA dashboard data"""
        try:
            # Default to last 24 hours if no time range specified
            if not time_range:
                end_time = datetime.utcnow()
                start_time = end_time - timedelta(hours=24)
            else:
                start_time = datetime.fromisoformat(time_range['start_time'])
                end_time = datetime.fromisoformat(time_range['end_time'])
            
            # Get all active SLA metrics for tenant
            metrics = await self.db.query(SLAMetric).filter(
                SLAMetric.tenant_id == tenant_id,
                SLAMetric.is_active == True
            ).all()
            
            dashboard_data = {
                'overview': {
                    'total_metrics': len(metrics),
                    'compliant_metrics': 0,
                    'warning_metrics': 0,
                    'breach_metrics': 0,
                    'overall_compliance': 0.0
                },
                'metrics': [],
                'alerts': [],
                'trends': {},
                'av_rental_specific': {}
            }
            
            total_compliance = 0.0
            
            for metric in metrics:
                # Get latest measurement
                latest_measurement = await self.db.query(SLAMeasurement).filter(
                    SLAMeasurement.sla_metric_id == metric.id,
                    SLAMeasurement.measured_at >= start_time,
                    SLAMeasurement.measured_at <= end_time
                ).order_by(SLAMeasurement.measured_at.desc()).first()
                
                if not latest_measurement:
                    continue
                
                # Get trend data (last 7 days)
                trend_data = await self._get_metric_trend(metric.id, days=7)
                
                metric_data = {
                    'id': metric.id,
                    'name': metric.name,
                    'type': metric.sla_type.value,
                    'target_value': float(metric.target_value),
                    'target_unit': metric.target_unit,
                    'current_value': float(latest_measurement.measured_value),
                    'compliance_percentage': float(latest_measurement.compliance_percentage),
                    'status': latest_measurement.status,
                    'trend': trend_data['trend'],
                    'last_updated': latest_measurement.measured_at.isoformat()
                }
                
                dashboard_data['metrics'].append(metric_data)
                total_compliance += latest_measurement.compliance_percentage
                
                # Count status
                if latest_measurement.status == 'compliant':
                    dashboard_data['overview']['compliant_metrics'] += 1
                elif latest_measurement.status == 'warning':
                    dashboard_data['overview']['warning_metrics'] += 1
                else:
                    dashboard_data['overview']['breach_metrics'] += 1
            
            # Calculate overall compliance
            if metrics:
                dashboard_data['overview']['overall_compliance'] = total_compliance / len(metrics)
            
            # Get active alerts
            active_alerts = await self.db.query(SLAAlert).filter(
                SLAAlert.status == 'active',
                SLAAlert.triggered_at >= start_time
            ).order_by(SLAAlert.triggered_at.desc()).limit(10).all()
            
            dashboard_data['alerts'] = [
                {
                    'id': alert.id,
                    'metric_id': alert.sla_metric_id,
                    'type': alert.alert_type,
                    'severity': alert.severity,
                    'message': alert.message,
                    'triggered_at': alert.triggered_at.isoformat()
                }
                for alert in active_alerts
            ]
            
            # AV Rental specific metrics
            dashboard_data['av_rental_specific'] = await self._get_av_rental_metrics(tenant_id, start_time, end_time)
            
            return {
                'success': True,
                'dashboard': dashboard_data
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to get SLA dashboard: {str(e)}'
            }

    async def _get_av_rental_metrics(self, tenant_id: int, start_time: datetime, end_time: datetime) -> Dict[str, Any]:
        """Get AV rental specific SLA metrics"""
        try:
            # Equipment availability
            equipment_uptime = await self._calculate_equipment_availability(tenant_id, start_time, end_time)
            
            # Delivery performance
            delivery_performance = await self._calculate_delivery_performance(tenant_id, start_time, end_time)
            
            # Customer satisfaction
            customer_satisfaction = await self._calculate_customer_satisfaction(tenant_id, start_time, end_time)
            
            # Incident response
            incident_response = await self._calculate_incident_response(tenant_id, start_time, end_time)
            
            return {
                'equipment_availability': equipment_uptime,
                'delivery_performance': delivery_performance,
                'customer_satisfaction': customer_satisfaction,
                'incident_response': incident_response
            }
            
        except Exception as e:
            return {
                'error': f'Failed to get AV rental metrics: {str(e)}'
            }

    async def _calculate_equipment_availability(self, tenant_id: int, start_time: datetime, end_time: datetime) -> Dict[str, Any]:
        """Calculate equipment availability metrics"""
        try:
            # Mock calculation - in real implementation, this would query equipment status logs
            total_equipment_hours = 1000  # Total possible equipment hours
            downtime_hours = 5  # Hours of downtime
            availability_percentage = ((total_equipment_hours - downtime_hours) / total_equipment_hours) * 100
            
            return {
                'availability_percentage': availability_percentage,
                'target': 99.5,
                'status': 'compliant' if availability_percentage >= 99.5 else 'warning',
                'downtime_hours': downtime_hours,
                'total_equipment': 50,
                'equipment_with_issues': 2
            }
            
        except Exception as e:
            return {'error': str(e)}

    async def _calculate_delivery_performance(self, tenant_id: int, start_time: datetime, end_time: datetime) -> Dict[str, Any]:
        """Calculate delivery performance metrics"""
        try:
            # Mock calculation - in real implementation, this would query delivery records
            total_deliveries = 100
            on_time_deliveries = 95
            performance_percentage = (on_time_deliveries / total_deliveries) * 100
            
            return {
                'on_time_percentage': performance_percentage,
                'target': 95.0,
                'status': 'compliant' if performance_percentage >= 95.0 else 'warning',
                'total_deliveries': total_deliveries,
                'on_time_deliveries': on_time_deliveries,
                'average_delay_minutes': 15
            }
            
        except Exception as e:
            return {'error': str(e)}

    async def _calculate_customer_satisfaction(self, tenant_id: int, start_time: datetime, end_time: datetime) -> Dict[str, Any]:
        """Calculate customer satisfaction metrics"""
        try:
            # Mock calculation - in real implementation, this would query customer feedback
            total_ratings = 50
            average_rating = 4.6
            ratings_above_4 = 45
            
            return {
                'average_rating': average_rating,
                'target': 4.5,
                'status': 'compliant' if average_rating >= 4.5 else 'warning',
                'total_ratings': total_ratings,
                'ratings_above_4': ratings_above_4,
                'satisfaction_percentage': (ratings_above_4 / total_ratings) * 100
            }
            
        except Exception as e:
            return {'error': str(e)}

    async def _calculate_incident_response(self, tenant_id: int, start_time: datetime, end_time: datetime) -> Dict[str, Any]:
        """Calculate incident response metrics"""
        try:
            # Mock calculation - in real implementation, this would query incident records
            total_incidents = 10
            incidents_resolved_on_time = 8
            average_resolution_hours = 3.5
            
            return {
                'average_resolution_hours': average_resolution_hours,
                'target': 4.0,
                'status': 'compliant' if average_resolution_hours <= 4.0 else 'warning',
                'total_incidents': total_incidents,
                'resolved_on_time': incidents_resolved_on_time,
                'resolution_rate': (incidents_resolved_on_time / total_incidents) * 100
            }
            
        except Exception as e:
            return {'error': str(e)}

    async def get_compliance_dashboard(self, tenant_id: int) -> Dict[str, Any]:
        """Get compliance dashboard data"""
        try:
            # Get all compliance requirements
            requirements = await self.db.query(ComplianceRequirement).filter(
                ComplianceRequirement.tenant_id == tenant_id
            ).all()
            
            # Group by framework
            frameworks = {}
            for req in requirements:
                framework = req.framework.value
                if framework not in frameworks:
                    frameworks[framework] = {
                        'total_requirements': 0,
                        'implemented': 0,
                        'in_progress': 0,
                        'not_started': 0,
                        'compliance_score': 0.0,
                        'requirements': []
                    }
                
                frameworks[framework]['total_requirements'] += 1
                frameworks[framework][req.implementation_status] += 1
                
                if req.compliance_score:
                    frameworks[framework]['compliance_score'] += float(req.compliance_score)
                
                frameworks[framework]['requirements'].append({
                    'id': req.id,
                    'requirement_id': req.requirement_id,
                    'title': req.title,
                    'status': req.implementation_status,
                    'score': float(req.compliance_score) if req.compliance_score else 0.0,
                    'next_assessment': req.next_assessment_due.isoformat() if req.next_assessment_due else None
                })
            
            # Calculate average compliance scores
            for framework in frameworks.values():
                if framework['total_requirements'] > 0:
                    framework['compliance_score'] = framework['compliance_score'] / framework['total_requirements']
            
            # Get recent audits
            recent_audits = await self.db.query(ComplianceAudit).filter(
                ComplianceAudit.tenant_id == tenant_id
            ).order_by(ComplianceAudit.created_at.desc()).limit(5).all()
            
            audit_data = [
                {
                    'id': audit.id,
                    'name': audit.audit_name,
                    'framework': audit.framework.value,
                    'type': audit.audit_type,
                    'status': audit.status,
                    'overall_score': float(audit.overall_score) if audit.overall_score else None,
                    'findings_count': audit.findings_count,
                    'planned_date': audit.planned_start_date.isoformat() if audit.planned_start_date else None
                }
                for audit in recent_audits
            ]
            
            # Calculate overall compliance health
            total_score = sum(f['compliance_score'] for f in frameworks.values())
            overall_compliance = total_score / len(frameworks) if frameworks else 0.0
            
            return {
                'success': True,
                'compliance_dashboard': {
                    'overall_compliance': overall_compliance,
                    'frameworks': frameworks,
                    'recent_audits': audit_data,
                    'summary': {
                        'total_frameworks': len(frameworks),
                        'total_requirements': sum(f['total_requirements'] for f in frameworks.values()),
                        'implemented_requirements': sum(f['implemented'] for f in frameworks.values()),
                        'pending_assessments': len([req for reqs in frameworks.values() for req in reqs['requirements'] if req['next_assessment']])
                    }
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to get compliance dashboard: {str(e)}'
            }

    async def _generate_sla_alert(self, metric: SLAMetric, measurement: SLAMeasurement):
        """Generate SLA alert for breach or warning"""
        try:
            alert_type = measurement.status
            severity = 'high' if measurement.status == 'breach' else 'medium'
            
            message = f"SLA {alert_type.upper()}: {metric.name} is at {measurement.compliance_percentage:.1f}% compliance (target: {metric.target_value}{metric.target_unit})"
            
            alert = SLAAlert(
                sla_metric_id=metric.id,
                alert_type=alert_type,
                severity=severity,
                message=message,
                current_value=measurement.measured_value,
                target_value=measurement.target_value
            )
            
            self.db.add(alert)
            await self.db.commit()
            
            # Handle escalation if configured
            if metric.escalation_rules:
                await self._handle_alert_escalation(alert, metric.escalation_rules)
            
        except Exception as e:
            print(f"Failed to generate SLA alert: {e}")

    async def _handle_alert_escalation(self, alert: SLAAlert, escalation_rules: List[Dict[str, Any]]):
        """Handle alert escalation based on rules"""
        try:
            for rule in escalation_rules:
                if alert.severity in rule.get('severities', []):
                    # This would integrate with notification system
                    # For now, just log the escalation
                    print(f"Escalating alert {alert.id} to {rule.get('recipients', [])}")
            
        except Exception as e:
            print(f"Failed to handle alert escalation: {e}")

    async def _get_metric_trend(self, metric_id: int, days: int = 7) -> Dict[str, Any]:
        """Get trend data for a metric"""
        try:
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=days)
            
            measurements = await self.db.query(SLAMeasurement).filter(
                SLAMeasurement.sla_metric_id == metric_id,
                SLAMeasurement.measured_at >= start_date,
                SLAMeasurement.measured_at <= end_date
            ).order_by(SLAMeasurement.measured_at.asc()).all()
            
            if len(measurements) < 2:
                return {'trend': 'stable', 'change': 0.0}
            
            # Calculate trend
            values = [float(m.compliance_percentage) for m in measurements]
            recent_avg = statistics.mean(values[-3:]) if len(values) >= 3 else values[-1]
            older_avg = statistics.mean(values[:3]) if len(values) >= 3 else values[0]
            
            change = recent_avg - older_avg
            
            if change > 2:
                trend = 'improving'
            elif change < -2:
                trend = 'declining'
            else:
                trend = 'stable'
            
            return {
                'trend': trend,
                'change': change,
                'data_points': len(measurements)
            }
            
        except Exception as e:
            return {'trend': 'unknown', 'change': 0.0, 'error': str(e)}

    async def get_sla_health_status(self, tenant_id: int) -> Dict[str, Any]:
        """Get SLA system health status"""
        try:
            # Get metrics summary
            total_metrics = await self.db.query(SLAMetric).filter(
                SLAMetric.tenant_id == tenant_id,
                SLAMetric.is_active == True
            ).count()
            
            # Get recent measurements
            recent_measurements = await self.db.query(SLAMeasurement).filter(
                SLAMeasurement.measured_at >= datetime.utcnow() - timedelta(hours=24)
            ).all()
            
            compliant_count = len([m for m in recent_measurements if m.status == 'compliant'])
            warning_count = len([m for m in recent_measurements if m.status == 'warning'])
            breach_count = len([m for m in recent_measurements if m.status == 'breach'])
            
            # Get active alerts
            active_alerts = await self.db.query(SLAAlert).filter(
                SLAAlert.status == 'active'
            ).count()
            
            # Calculate health score
            total_measurements = len(recent_measurements)
            if total_measurements > 0:
                compliance_rate = (compliant_count / total_measurements) * 100
            else:
                compliance_rate = 100
            
            health_score = max(0, compliance_rate - (active_alerts * 5))  # Reduce score for active alerts
            
            health_status = 'healthy' if health_score >= 90 else 'degraded' if health_score >= 70 else 'unhealthy'
            
            return {
                'success': True,
                'health_status': {
                    'overall_health': health_status,
                    'health_score': health_score,
                    'metrics': {
                        'total_sla_metrics': total_metrics,
                        'measurements_24h': total_measurements,
                        'compliant_measurements': compliant_count,
                        'warning_measurements': warning_count,
                        'breach_measurements': breach_count,
                        'active_alerts': active_alerts
                    },
                    'compliance_rate': compliance_rate
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to get SLA health status: {str(e)}'
            }
```

---

## 4. Full Audit Log and Exports

### Database Models

```python
# backend/app/modules/audit/models/audit_models.py
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, JSON, Enum
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
import enum

Base = declarative_base()

class AuditEventType(enum.Enum):
    USER_LOGIN = "user_login"
    USER_LOGOUT = "user_logout"
    USER_CREATED = "user_created"
    USER_UPDATED = "user_updated"
    USER_DELETED = "user_deleted"
    EQUIPMENT_CREATED = "equipment_created"
    EQUIPMENT_UPDATED = "equipment_updated"
    EQUIPMENT_DELETED = "equipment_deleted"
    BOOKING_CREATED = "booking_created"
    BOOKING_UPDATED = "booking_updated"
    BOOKING_CANCELLED = "booking_cancelled"
    PAYMENT_PROCESSED = "payment_processed"
    PAYMENT_FAILED = "payment_failed"
    CONTRACT_CREATED = "contract_created"
    CONTRACT_SIGNED = "contract_signed"
    DATA_EXPORT = "data_export"
    DATA_IMPORT = "data_import"
    SYSTEM_CONFIG_CHANGED = "system_config_changed"
    SECURITY_EVENT = "security_event"
    COMPLIANCE_CHECK = "compliance_check"

class AuditSeverity(enum.Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    
    # Event details
    event_type = Column(Enum(AuditEventType), nullable=False)
    event_category = Column(String(50), nullable=False)  # 'authentication', 'data_access', 'system', 'business'
    severity = Column(Enum(AuditSeverity), default=AuditSeverity.MEDIUM)
    
    # Actor information
    user_id = Column(Integer)
    user_email = Column(String(255))
    user_role = Column(String(50))
    session_id = Column(String(255))
    
    # Target information
    resource_type = Column(String(100))  # 'user', 'equipment', 'booking', 'contract'
    resource_id = Column(String(100))
    resource_name = Column(String(255))
    
    # Event details
    action = Column(String(100), nullable=False)
    description = Column(Text)
    old_values = Column(JSON)  # Previous state
    new_values = Column(JSON)  # New state
    metadata = Column(JSON)    # Additional context
    
    # Request context
    ip_address = Column(String(45))
    user_agent = Column(Text)
    request_id = Column(String(100))
    api_endpoint = Column(String(255))
    http_method = Column(String(10))
    
    # Result
    success = Column(Boolean, default=True)
    error_message = Column(Text)
    response_code = Column(Integer)
    
    # Compliance
    retention_period_days = Column(Integer, default=2555)  # 7 years default
    is_sensitive = Column(Boolean, default=False)
    compliance_tags = Column(JSON, default=list)
    
    # Timestamps
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class AuditExport(Base):
    __tablename__ = "audit_exports"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    
    # Export details
    export_name = Column(String(255), nullable=False)
    export_type = Column(String(50), nullable=False)  # 'full', 'filtered', 'compliance'
    file_format = Column(String(20), nullable=False)  # 'json', 'csv', 'xml', 'pdf'
    
    # Filters
    date_range_start = Column(DateTime)
    date_range_end = Column(DateTime)
    event_types = Column(JSON, default=list)
    user_ids = Column(JSON, default=list)
    resource_types = Column(JSON, default=list)
    severity_levels = Column(JSON, default=list)
    
    # Export results
    total_records = Column(Integer, default=0)
    file_path = Column(String(500))
    file_size = Column(Integer)
    file_hash = Column(String(64))
    
    # Status
    status = Column(String(50), default='pending')  # 'pending', 'processing', 'completed', 'failed'
    progress_percentage = Column(Integer, default=0)
    error_message = Column(Text)
    
    # Metadata
    requested_by = Column(Integer, nullable=False)
    purpose = Column(String(255))  # Reason for export
    compliance_framework = Column(String(50))  # GDPR, SOX, etc.
    
    # Timestamps
    requested_at = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    expires_at = Column(DateTime)  # When export file expires

class AuditRetentionPolicy(Base):
    __tablename__ = "audit_retention_policies"
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, nullable=False)
    
    # Policy details
    policy_name = Column(String(255), nullable=False)
    event_types = Column(JSON, default=list)
    resource_types = Column(JSON, default=list)
    severity_levels = Column(JSON, default=list)
    
    # Retention settings
    retention_period_days = Column(Integer, nullable=False)
    archive_after_days = Column(Integer)
    auto_delete = Column(Boolean, default=False)
    
    # Compliance
    compliance_framework = Column(String(50))
    legal_hold = Column(Boolean, default=False)
    
    # Status
    is_active = Column(Boolean, default=True)
    last_applied = Column(DateTime)
    
    # Metadata
    created_by = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

### Audit Service Implementation

```python
# backend/app/modules/audit/services/audit_service.py
import asyncio
import json
import csv
import hashlib
import os
import uuid
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import aiofiles
from xml.etree.ElementTree import Element, SubElement, tostring
from xml.dom import minidom

class AuditService:
    def __init__(self, db_session, storage_path: str):
        self.db = db_session
        self.storage_path = storage_path
        
        # Ensure export directory exists
        os.makedirs(f"{self.storage_path}/audit_exports", exist_ok=True)

    async def log_event(self, tenant_id: int, event_data: Dict[str, Any]) -> Dict[str, Any]:
        """Log an audit event"""
        try:
            audit_log = AuditLog(
                tenant_id=tenant_id,
                event_type=AuditEventType(event_data['event_type']),
                event_category=event_data['event_category'],
                severity=AuditSeverity(event_data.get('severity', 'medium')),
                user_id=event_data.get('user_id'),
                user_email=event_data.get('user_email'),
                user_role=event_data.get('user_role'),
                session_id=event_data.get('session_id'),
                resource_type=event_data.get('resource_type'),
                resource_id=event_data.get('resource_id'),
                resource_name=event_data.get('resource_name'),
                action=event_data['action'],
                description=event_data.get('description'),
                old_values=event_data.get('old_values'),
                new_values=event_data.get('new_values'),
                metadata=event_data.get('metadata', {}),
                ip_address=event_data.get('ip_address'),
                user_agent=event_data.get('user_agent'),
                request_id=event_data.get('request_id'),
                api_endpoint=event_data.get('api_endpoint'),
                http_method=event_data.get('http_method'),
                success=event_data.get('success', True),
                error_message=event_data.get('error_message'),
                response_code=event_data.get('response_code'),
                retention_period_days=event_data.get('retention_period_days', 2555),
                is_sensitive=event_data.get('is_sensitive', False),
                compliance_tags=event_data.get('compliance_tags', [])
            )
            
            self.db.add(audit_log)
            await self.db.commit()
            
            return {
                'success': True,
                'audit_id': audit_log.id,
                'message': 'Audit event logged successfully'
            }
            
        except Exception as e:
            await self.db.rollback()
            return {
                'success': False,
                'error': f'Failed to log audit event: {str(e)}'
            }

    async def search_audit_logs(self, tenant_id: int, search_criteria: Dict[str, Any]) -> Dict[str, Any]:
        """Search audit logs with filters"""
        try:
            query = self.db.query(AuditLog).filter(AuditLog.tenant_id == tenant_id)
            
            # Apply filters
            if search_criteria.get('start_date'):
                query = query.filter(AuditLog.timestamp >= datetime.fromisoformat(search_criteria['start_date']))
            
            if search_criteria.get('end_date'):
                query = query.filter(AuditLog.timestamp <= datetime.fromisoformat(search_criteria['end_date']))
            
            if search_criteria.get('event_types'):
                query = query.filter(AuditLog.event_type.in_(search_criteria['event_types']))
            
            if search_criteria.get('user_ids'):
                query = query.filter(AuditLog.user_id.in_(search_criteria['user_ids']))
            
            if search_criteria.get('resource_types'):
                query = query.filter(AuditLog.resource_type.in_(search_criteria['resource_types']))
            
            if search_criteria.get('severity_levels'):
                query = query.filter(AuditLog.severity.in_(search_criteria['severity_levels']))
            
            if search_criteria.get('success') is not None:
                query = query.filter(AuditLog.success == search_criteria['success'])
            
            if search_criteria.get('search_text'):
                search_text = f"%{search_criteria['search_text']}%"
                query = query.filter(
                    AuditLog.description.like(search_text) |
                    AuditLog.action.like(search_text) |
                    AuditLog.resource_name.like(search_text)
                )
            
            # Pagination
            page = search_criteria.get('page', 1)
            page_size = search_criteria.get('page_size', 50)
            offset = (page - 1) * page_size
            
            total_count = query.count()
            logs = query.order_by(AuditLog.timestamp.desc()).offset(offset).limit(page_size).all()
            
            # Format results
            results = []
            for log in logs:
                results.append({
                    'id': log.id,
                    'timestamp': log.timestamp.isoformat(),
                    'event_type': log.event_type.value,
                    'event_category': log.event_category,
                    'severity': log.severity.value,
                    'user_email': log.user_email,
                    'user_role': log.user_role,
                    'resource_type': log.resource_type,
                    'resource_id': log.resource_id,
                    'resource_name': log.resource_name,
                    'action': log.action,
                    'description': log.description,
                    'success': log.success,
                    'ip_address': log.ip_address,
                    'metadata': log.metadata
                })
            
            return {
                'success': True,
                'results': results,
                'pagination': {
                    'total_count': total_count,
                    'page': page,
                    'page_size': page_size,
                    'total_pages': (total_count + page_size - 1) // page_size
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Failed to search audit logs: {str(e)}'
            }

    async def create_audit_export(self, tenant_id: int, export_config: Dict[str, Any], requested_by: int) -> Dict[str, Any]:
        """Create an audit log export"""
        try:
            export_name = export_config.get('export_name', f"audit_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}")
            
            audit_export = AuditExport(
                tenant_id=tenant_id,
                export_name=export_name,
                export_type=export_config.get('export_type', 'filtered'),
                file_format=export_config.get('file_format', 'json'),
                date_range_start=datetime.fromisoformat(export_config['date_range_start']) if export_config.get('date_range_start') else None,
                date_range_end=datetime.fromisoformat(export_config['date_range_end']) if export_config.get('date_range_end') else None,
                event_types=export_config.get('event_types', []),
                user_ids=export_config.get('user_ids', []),
                resource_types=export_config.get('resource_types', []),
                severity_levels=export_config.get('severity_levels', []),
                requested_by=requested_by,
                purpose=export_config.get('purpose'),
                compliance_framework=export_config.get('compliance_framework'),
                expires_at=datetime.utcnow() + timedelta(days=export_config.get('retention_days', 30))
            )
            
            self.db.add(audit_export)
            await self.db.commit()
            
            # Start export process asynchronously
            asyncio.create_task(self._process_audit_export(audit_export.id))
            
            return {
                'success': True,
                'export_id': audit_export.id,
                'message': 'Audit export created and processing started'
            }
            
        except Exception as e:
            await self.db.rollback()
            return {
                'success': False,
                'error': f'Failed to create audit export: {str(e)}'
            }

    async def _process_audit_export(self, export_id: int):
        """Process audit export in background"""
        try:
            export = await self.db.query(AuditExport).filter(AuditExport.id == export_id).first()
            if not export:
                return
            
            # Update status
            export.status = 'processing'
            export.started_at = datetime.utcnow()
            await self.db.commit()
            
            # Build query based on filters
            query = self.db.query(AuditLog).filter(AuditLog.tenant_id == export.tenant_id)
            
            if export.date_range_start:
                query = query.filter(AuditLog.timestamp >= export.date_range_start)
            
            if export.date_range_end:
                query = query.filter(AuditLog.timestamp <= export.date_range_end)
            
            if export.event_types:
                query = query.filter(AuditLog.event_type.in_(export.event_types))
            
            if export.user_ids:
                query = query.filter(AuditLog.user_id.in_(export.user_ids))
            
            if export.resource_types:
                query = query.filter(AuditLog.resource_type.in_(export.resource_types))
            
            if export.severity_levels:
                query = query.filter(AuditLog.severity.in_(export.severity_levels))
            
            # Get total count
            total_records = query.count()
            export.total_records = total_records
            await self.db.commit()
            
            # Generate filename
            filename = f"{export.export_name}_{export.id}.{export.file_format}"
            file_path = f"{self.storage_path}/audit_exports/{filename}"
            
            # Export data based on format
            if export.file_format == 'json':
                await self._export_to_json(query, file_path, export)
            elif export.file_format == 'csv':
                await self._export_to_csv(query, file_path, export)
            elif export.file_format == 'xml':
                await self._export_to_xml(query, file_path, export)
            else:
                raise ValueError(f"Unsupported export format: {export.file_format}")
            
            # Calculate file hash and size
            file_hash = await self._calculate_file_hash(file_path)
            file_size = os.path.getsize(file_path)
            
            # Update export record
            export.status = 'completed'
            export.file_path = file_path
            export.file_size = file_size
            export.file_hash = file_hash
            export.completed_at = datetime.utcnow()
            export.progress_percentage = 100
            
            await self.db.commit()
            
            # Log the export event
            await self.log_event(export.tenant_id, {
                'event_type': 'data_export',
                'event_category': 'data_access',
                'severity': 'medium',
                'user_id': export.requested_by,
                'action': 'audit_export_completed',
                'description': f'Audit export completed: {export.export_name}',
                'metadata': {
                    'export_id': export.id,
                    'total_records': total_records,
                    'file_format': export.file_format,
                    'file_size': file_size
                }
            })
            
        except Exception as e:
            # Update export with error
            export.status = 'failed'
            export.error_message = str(e)
            await self.db.commit()
            
            print(f"Audit export failed: {e}")

    async def _export_to_json(self, query, file_path: str, export: AuditExport):
        """Export audit logs to JSON format"""
        logs = query.order_by(AuditLog.timestamp.desc()).all()
        
        export_data = {
            'export_metadata': {
                'export_id': export.id,
                'export_name': export.export_name,
                'tenant_id': export.tenant_id,
                'generated_at': datetime.utcnow().isoformat(),
                'total_records': len(logs),
                'date_range': {
                    'start': export.date_range_start.isoformat() if export.date_range_start else None,
                    'end': export.date_range_end.isoformat() if export.date_range_end else None
                },
                'filters': {
                    'event_types': export.event_types,
                    'user_ids': export.user_ids,
                    'resource_types': export.resource_types,
                    'severity_levels': export.severity_levels
                }
            },
            'audit_logs': []
        }
        
        for i, log in enumerate(logs):
            export_data['audit_logs'].append({
                'id': log.id,
                'timestamp': log.timestamp.isoformat(),
                'event_type': log.event_type.value,
                'event_category': log.event_category,
                'severity': log.severity.value,
                'user_id': log.user_id,
                'user_email': log.user_email,
                'user_role': log.user_role,
                'session_id': log.session_id,
                'resource_type': log.resource_type,
                'resource_id': log.resource_id,
                'resource_name': log.resource_name,
                'action': log.action,
                'description': log.description,
                'old_values': log.old_values,
                'new_values': log.new_values,
                'metadata': log.metadata,
                'ip_address': log.ip_address,
                'user_agent': log.user_agent,
                'request_id': log.request_id,
                'api_endpoint': log.api_endpoint,
                'http_method': log.http_method,
                'success': log.success,
                'error_message': log.error_message,
                'response_code': log.response_code,
                'compliance_tags': log.compliance_tags
            })
            
            # Update progress
            if i % 100 == 0:
                progress = int((i / len(logs)) * 100)
                export.progress_percentage = progress
                await self.db.commit()
        
        async with aiofiles.open(file_path, 'w') as f:
            await f.write(json.dumps(export_data, indent=2, default=str))

    async def _export_to_csv(self, query, file_path: str, export: AuditExport):
        """Export audit logs to CSV format"""
        logs = query.order_by(AuditLog.timestamp.desc()).all()
        
        fieldnames = [
            'id', 'timestamp', 'event_type', 'event_category', 'severity',
            'user_id', 'user_email', 'user_role', 'session_id',
            'resource_type', 'resource_id', 'resource_name',
            'action', 'description', 'ip_address', 'user_agent',
            'request_id', 'api_endpoint', 'http_method',
            'success', 'error_message', 'response_code'
        ]
        
        with open(file_path, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            
            for i, log in enumerate(logs):
                writer.writerow({
                    'id': log.id,
                    'timestamp': log.timestamp.isoformat(),
                    'event_type': log.event_type.value,
                    'event_category': log.event_category,
                    'severity': log.severity.value,
                    'user_id': log.user_id,
                    'user_email': log.user_email,
                    'user_role': log.user_role,
                    'session_id': log.session_id,
                    'resource_type': log.resource_type,
                    'resource_id': log.resource_id,
                    'resource_name': log.resource_name,
                    'action': log.action,
                    'description': log.description,
                    'ip_address': log.ip_address,
                    'user_agent': log.user_agent,
                    'request_id': log.request_id,
                    'api_endpoint': log.api_endpoint,
                    'http_method': log.http_method,
                    'success': log.success,
                    'error_message': log.error_message,
                    'response_code': log.response_code
                })
                
                # Update progress
                if i % 100 == 0:
                    progress = int((i / len(logs)) * 100)
                    export.progress_percentage = progress
                    await self.db.commit()

    async def _export_to_xml(self, query, file_path: str, export: AuditExport):
        """Export audit logs to XML format"""
        logs = query.order_by(AuditLog.timestamp.desc()).all()
        
        root = Element('audit_export')
        
        # Metadata
        metadata = SubElement(root, 'metadata')
        SubElement(metadata, 'export_id').text = str(export.id)
        SubElement(metadata, 'export_name').text = export.export_name
        SubElement(metadata, 'tenant_id').text = str(export.tenant_id)
        SubElement(metadata, 'generated_at').text = datetime.utcnow().isoformat()
        SubElement(metadata, 'total_records').text = str(len(logs))
        
        # Audit logs
        logs_element = SubElement(root, 'audit_logs')
        
        for i, log in enumerate(logs):
            log_element = SubElement(logs_element, 'audit_log')
            log_element.set('id', str(log.id))
            
            SubElement(log_element, 'timestamp').text = log.timestamp.isoformat()
            SubElement(log_element, 'event_type').text = log.event_type.value
            SubElement(log_element, 'event_category').text = log.event_category
            SubElement(log_element, 'severity').text = log.severity.value
            SubElement(log_element, 'user_id').text = str(log.user_id) if log.user_id else ''
            SubElement(log_element, 'user_email').text = log.user_email or ''
            SubElement(log_element, 'user_role').text = log.user_role or ''
            SubElement(log_element, 'resource_type').text = log.resource_type or ''
            SubElement(log_element, 'resource_id').text = log.resource_id or ''
            SubElement(log_element, 'resource_name').text = log.resource_name or ''
            SubElement(log_element, 'action').text = log.action
            SubElement(log_element, 'description').text = log.description or ''
            SubElement(log_element, 'ip_address').text = log.ip_address or ''
            SubElement(log_element, 'success').text = str(log.success)
            
            # Update progress
            if i % 100 == 0:
                progress = int((i / len(logs)) * 100)
                export.progress_percentage = progress
                await self.db.commit()
        
        # Pretty print XML
        rough_string = tostring(root, 'utf-8')
        reparsed = minidom.parseString(rough_string)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(reparsed.toprettyxml(indent="  "))

    async def _calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA-256 hash of exported file"""
        hash_sha256 = hashlib.sha256()
        async with aiofiles.open(file_path, 'rb') as f:
            async for chunk in f:
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()

    async def get_audit_analytics(self, tenant_id: int, date_range: Dict[str, Any] = None) -> Dict[str, Any]:
        """Get audit analytics for AV rental business"""
        try:
            # Date range filter
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=30)
            
            if date_range:
                if date_range.get('start_date'):
                    start_date = datetime.fromisoformat(date_range['start_date'])
                if date_range.get('end_date'):
                    end_date = datetime.fromisoformat(date_range['end_date'])
            
            # Event type distribution
            event_type_query = f"""
                SELECT event_type, COUNT(*) as count 
                FROM audit_logs 
                WHERE tenant_id = {tenant_id} 
                AND timestamp BETWEEN '{start_date}' AND '{end_date}'
                GROUP BY event_type
                ORDER BY count DESC
            """
            event_type_results = await self.db.execute(event_type_query).fetchall()
            
            # User activity
            user_activity_query = f"""
                SELECT user_email, COUNT(*) as activity_count
                FROM audit_logs 
                WHERE tenant_id = {tenant_id} 
                AND timestamp BETWEEN '{start_date}' AND '{end_date}'
                AND user_email IS NOT NULL
                GROUP BY user_email
                ORDER BY activity
