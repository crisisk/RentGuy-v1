import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from 'path'
import { visualizer } from 'rollup-plugin-visualizer'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    // Bundle analyzer for production builds
    process.env.ANALYZE && visualizer({
      filename: 'dist/stats.html',
      open: true,
      gzipSize: true,
      brotliSize: true,
    })
  ].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  build: {
    // Performance optimizations
    target: 'es2015',
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
      },
    },
    rollupOptions: {
      output: {
        // Code splitting strategy
        manualChunks: {
          // Vendor chunks
          'react-vendor': ['react', 'react-dom'],
          'ui-vendor': ['@radix-ui/react-dialog', '@radix-ui/react-select'],
          'icons-vendor': ['lucide-react'],
          
          // Feature chunks - using relative paths
          'onboarding-core': [
            './src/components/OnboardingWizard',
            './src/components/ImprovedOnboardingWizard'
          ],
          'equipment-catalog': [
            './src/components/ImprovedEquipmentCatalogStep'
          ],
          'pricing-setup': [
            './src/components/ImprovedPricingSetupStep'
          ]
        },
      },
    },
    // Chunk size warnings
    chunkSizeWarningLimit: 1000,
  },
  server: {
    // Development server optimizations
    hmr: {
      overlay: false,
    },
  },
  // Asset optimization
  assetsInclude: ['**/*.woff2', '**/*.woff'],
  
  // Performance budgets
  define: {
    __PERFORMANCE_BUDGET__: JSON.stringify({
      maxBundleSize: 1000000, // 1MB
      maxChunkSize: 500000,   // 500KB
    })
  }
})
