
import openai

OPENAI_API_KEY = "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"

try:
    client = openai.OpenAI(api_key=OPENAI_API_KEY, base_url="https://api.openai.com/v1/")
    models = client.models.list()
    print("Successfully connected to OpenAI API.")
    print(f"Found {len(models.data)} models.")
except Exception as e:
    print(f"Failed to connect to OpenAI API: {e}")

