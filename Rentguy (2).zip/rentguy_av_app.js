import React, { useState, useEffect } from 'react';
import './App.css';

// Main App Component
function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [equipment, setEquipment] = useState([]);
  const [packages, setPackages] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [analytics, setAnalytics] = useState({});
  const [loading, setLoading] = useState(true);

  const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

  // Fetch data from API
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Fetch equipment
        const equipmentResponse = await fetch(`${API_BASE_URL}/api/v1/equipment`);
        const equipmentData = await equipmentResponse.json();
        setEquipment(equipmentData);

        // Fetch packages
        const packagesResponse = await fetch(`${API_BASE_URL}/api/v1/packages`);
        const packagesData = await packagesResponse.json();
        setPackages(packagesData);

        // Fetch bookings
        const bookingsResponse = await fetch(`${API_BASE_URL}/api/v1/bookings`);
        const bookingsData = await bookingsResponse.json();
        setBookings(bookingsData);

        // Fetch analytics
        const analyticsResponse = await fetch(`${API_BASE_URL}/api/v1/analytics/dashboard`);
        const analyticsData = await analyticsResponse.json();
        setAnalytics(analyticsData);

        setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, [API_BASE_URL]);

  // Dashboard Component
  const Dashboard = () => (
    <div className="dashboard">
      <h2>RentGuy AV Rental Dashboard</h2>
      <div className="stats-grid">
        <div className="stat-card">
          <h3>Total Equipment</h3>
          <p className="stat-number">{analytics.total_equipment || 0}</p>
        </div>
        <div className="stat-card">
          <h3>Available Equipment</h3>
          <p className="stat-number">{analytics.available_equipment || 0}</p>
        </div>
        <div className="stat-card">
          <h3>Total Bookings</h3>
          <p className="stat-number">{analytics.total_bookings || 0}</p>
        </div>
        <div className="stat-card">
          <h3>Total Revenue</h3>
          <p className="stat-number">${analytics.total_revenue || 0}</p>
        </div>
      </div>
      
      <div className="popular-packages">
        <h3>Popular Packages</h3>
        {analytics.popular_packages && analytics.popular_packages.map((pkg, index) => (
          <div key={index} className="package-stat">
            <span>{pkg.name}</span>
            <span>{pkg.bookings} bookings</span>
          </div>
        ))}
      </div>
    </div>
  );

  // Equipment Component
  const Equipment = () => (
    <div className="equipment">
      <h2>Equipment Catalog</h2>
      <div className="equipment-grid">
        {equipment.map(item => (
          <div key={item.id} className="equipment-card">
            <h3>{item.name}</h3>
            <p className="category">{item.category}</p>
            <p className="description">{item.description}</p>
            <p className="rate">${item.daily_rate}/day</p>
            <p className={`status ${item.availability_status.toLowerCase()}`}>
              {item.availability_status}
            </p>
            <p className="location">Location: {item.location}</p>
          </div>
        ))}
      </div>
    </div>
  );

  // Packages Component
  const Packages = () => (
    <div className="packages">
      <h2>AV Packages</h2>
      <div className="packages-grid">
        {packages.map(pkg => (
          <div key={pkg.id} className="package-card">
            <h3>{pkg.name}</h3>
            <p className="tier">{pkg.tier} Tier</p>
            <p className="description">{pkg.description}</p>
            <p className="rate">${pkg.total_rate}/day</p>
            <p className="equipment-count">
              {pkg.equipment_ids.length} items included
            </p>
          </div>
        ))}
      </div>
    </div>
  );

  // Bookings Component
  const Bookings = () => (
    <div className="bookings">
      <h2>Current Bookings</h2>
      <div className="bookings-table">
        <table>
          <thead>
            <tr>
              <th>Customer</th>
              <th>Event Date</th>
              <th>Location</th>
              <th>Total Cost</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map(booking => (
              <tr key={booking.id}>
                <td>{booking.customer_name}</td>
                <td>{booking.event_date}</td>
                <td>{booking.event_location}</td>
                <td>${booking.total_cost}</td>
                <td className={`status ${booking.status.toLowerCase()}`}>
                  {booking.status}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="loading">
        <h2>Loading RentGuy AV Rental Platform...</h2>
      </div>
    );
  }

  return (
    <div className="App">
      <header className="app-header">
        <h1>RentGuy AV Rental Platform</h1>
        <nav className="nav-tabs">
          <button 
            className={activeTab === 'dashboard' ? 'active' : ''}
            onClick={() => setActiveTab('dashboard')}
          >
            Dashboard
          </button>
          <button 
            className={activeTab === 'equipment' ? 'active' : ''}
            onClick={() => setActiveTab('equipment')}
          >
            Equipment
          </button>
          <button 
            className={activeTab === 'packages' ? 'active' : ''}
            onClick={() => setActiveTab('packages')}
          >
            Packages
          </button>
          <button 
            className={activeTab === 'bookings' ? 'active' : ''}
            onClick={() => setActiveTab('bookings')}
          >
            Bookings
          </button>
        </nav>
      </header>

      <main className="app-main">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'equipment' && <Equipment />}
        {activeTab === 'packages' && <Packages />}
        {activeTab === 'bookings' && <Bookings />}
      </main>

      <footer className="app-footer">
        <p>&copy; 2024 RentGuy AV Rental Platform. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;
