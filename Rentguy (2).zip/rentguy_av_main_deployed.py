"""
RentGuy AV Rental Platform - Main Application
FastAPI backend for comprehensive AV equipment rental management
"""

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import uvicorn
import os
from datetime import datetime, date
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="RentGuy AV Rental Platform",
    description="Comprehensive AV equipment rental management system",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models
class HealthResponse(BaseModel):
    status: str
    timestamp: datetime
    version: str
    services: Dict[str, str]

class Equipment(BaseModel):
    id: int
    name: str
    category: str
    description: str
    daily_rate: float
    availability_status: str
    location: str

class Package(BaseModel):
    id: int
    name: str
    description: str
    equipment_ids: List[int]
    total_rate: float
    tier: str  # Silver, Gold, Diamond, Platinum

class Booking(BaseModel):
    id: int
    customer_name: str
    customer_email: str
    event_date: date
    event_location: str
    package_id: int
    equipment_ids: List[int]
    total_cost: float
    status: str

class Customer(BaseModel):
    id: int
    name: str
    email: str
    phone: str
    company: Optional[str] = None
    customer_type: str  # Corporate, Wedding Planner, Individual

# Mock data for demonstration
mock_equipment = [
    Equipment(id=1, name="Professional Projector 4K", category="Projection", 
              description="High-resolution 4K projector for presentations", 
              daily_rate=150.0, availability_status="Available", location="Warehouse A"),
    Equipment(id=2, name="Wireless Microphone System", category="Audio", 
              description="Professional wireless microphone with receiver", 
              daily_rate=75.0, availability_status="Available", location="Warehouse A"),
    Equipment(id=3, name="LED Stage Lighting Kit", category="Lighting", 
              description="Complete LED lighting setup for events", 
              daily_rate=200.0, availability_status="Rented", location="On Site"),
    Equipment(id=4, name="Sound Mixing Console", category="Audio", 
              description="32-channel digital mixing console", 
              daily_rate=300.0, availability_status="Available", location="Warehouse B"),
]

mock_packages = [
    Package(id=1, name="Silver Package", description="Basic AV setup for small events", 
            equipment_ids=[1, 2], total_rate=200.0, tier="Silver"),
    Package(id=2, name="Gold Package", description="Enhanced AV setup for medium events", 
            equipment_ids=[1, 2, 4], total_rate=450.0, tier="Gold"),
    Package(id=3, name="Diamond Package", description="Premium AV setup for large events", 
            equipment_ids=[1, 2, 3, 4], total_rate=600.0, tier="Diamond"),
]

mock_bookings = [
    Booking(id=1, customer_name="John Smith", customer_email="john@example.com",
            event_date=date(2024, 11, 15), event_location="Conference Center A",
            package_id=2, equipment_ids=[1, 2, 4], total_cost=450.0, status="Confirmed"),
    Booking(id=2, customer_name="Sarah Johnson", customer_email="sarah@weddingplanner.com",
            event_date=date(2024, 11, 20), event_location="Grand Hotel Ballroom",
            package_id=3, equipment_ids=[1, 2, 3, 4], total_cost=600.0, status="Pending"),
]

mock_customers = [
    Customer(id=1, name="John Smith", email="john@example.com", phone="+1-555-0123", 
             company="Tech Corp", customer_type="Corporate"),
    Customer(id=2, name="Sarah Johnson", email="sarah@weddingplanner.com", phone="+1-555-0456", 
             company="Elegant Events", customer_type="Wedding Planner"),
    Customer(id=3, name="Mike Wilson", email="mike@example.com", phone="+1-555-0789", 
             customer_type="Individual"),
]

# Health check endpoint
@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint for monitoring and load balancer"""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now(),
        version="1.0.0",
        services={
            "database": "connected",
            "redis": "connected",
            "api": "running"
        }
    )

# Equipment endpoints
@app.get("/api/v1/equipment", response_model=List[Equipment])
async def get_equipment():
    """Get all available equipment"""
    return mock_equipment

@app.get("/api/v1/equipment/{equipment_id}", response_model=Equipment)
async def get_equipment_by_id(equipment_id: int):
    """Get specific equipment by ID"""
    equipment = next((eq for eq in mock_equipment if eq.id == equipment_id), None)
    if not equipment:
        raise HTTPException(status_code=404, detail="Equipment not found")
    return equipment

@app.get("/api/v1/equipment/category/{category}")
async def get_equipment_by_category(category: str):
    """Get equipment by category"""
    filtered_equipment = [eq for eq in mock_equipment if eq.category.lower() == category.lower()]
    return filtered_equipment

# Package endpoints
@app.get("/api/v1/packages", response_model=List[Package])
async def get_packages():
    """Get all available packages"""
    return mock_packages

@app.get("/api/v1/packages/{package_id}", response_model=Package)
async def get_package_by_id(package_id: int):
    """Get specific package by ID"""
    package = next((pkg for pkg in mock_packages if pkg.id == package_id), None)
    if not package:
        raise HTTPException(status_code=404, detail="Package not found")
    return package

# Booking endpoints
@app.get("/api/v1/bookings", response_model=List[Booking])
async def get_bookings():
    """Get all bookings"""
    return mock_bookings

@app.get("/api/v1/bookings/{booking_id}", response_model=Booking)
async def get_booking_by_id(booking_id: int):
    """Get specific booking by ID"""
    booking = next((bk for bk in mock_bookings if bk.id == booking_id), None)
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    return booking

@app.post("/api/v1/bookings", response_model=Booking)
async def create_booking(booking_data: dict):
    """Create a new booking"""
    # In a real implementation, this would save to database
    new_booking = Booking(
        id=len(mock_bookings) + 1,
        customer_name=booking_data.get("customer_name"),
        customer_email=booking_data.get("customer_email"),
        event_date=datetime.strptime(booking_data.get("event_date"), "%Y-%m-%d").date(),
        event_location=booking_data.get("event_location"),
        package_id=booking_data.get("package_id"),
        equipment_ids=booking_data.get("equipment_ids", []),
        total_cost=booking_data.get("total_cost"),
        status="Pending"
    )
    mock_bookings.append(new_booking)
    return new_booking

# Customer endpoints
@app.get("/api/v1/customers", response_model=List[Customer])
async def get_customers():
    """Get all customers"""
    return mock_customers

@app.get("/api/v1/customers/{customer_id}", response_model=Customer)
async def get_customer_by_id(customer_id: int):
    """Get specific customer by ID"""
    customer = next((cust for cust in mock_customers if cust.id == customer_id), None)
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    return customer

# Analytics endpoints
@app.get("/api/v1/analytics/dashboard")
async def get_dashboard_analytics():
    """Get dashboard analytics data"""
    return {
        "total_equipment": len(mock_equipment),
        "available_equipment": len([eq for eq in mock_equipment if eq.availability_status == "Available"]),
        "total_bookings": len(mock_bookings),
        "confirmed_bookings": len([bk for bk in mock_bookings if bk.status == "Confirmed"]),
        "total_revenue": sum(bk.total_cost for bk in mock_bookings if bk.status == "Confirmed"),
        "equipment_utilization": 75.5,  # Mock percentage
        "popular_packages": [
            {"name": "Gold Package", "bookings": 15},
            {"name": "Silver Package", "bookings": 12},
            {"name": "Diamond Package", "bookings": 8}
        ]
    }

# Inventory endpoints
@app.get("/api/v1/inventory/status")
async def get_inventory_status():
    """Get real-time inventory status"""
    return {
        "total_items": len(mock_equipment),
        "available": len([eq for eq in mock_equipment if eq.availability_status == "Available"]),
        "rented": len([eq for eq in mock_equipment if eq.availability_status == "Rented"]),
        "maintenance": len([eq for eq in mock_equipment if eq.availability_status == "Maintenance"]),
        "last_updated": datetime.now().isoformat()
    }

# Crew management endpoints
@app.get("/api/v1/crew/assignments")
async def get_crew_assignments():
    """Get crew assignments for upcoming events"""
    return {
        "assignments": [
            {
                "crew_member": "Emily Johnson",
                "role": "AV Technician",
                "event": "Tech Corp Conference",
                "date": "2024-11-15",
                "location": "Conference Center A",
                "status": "Assigned"
            },
            {
                "crew_member": "David Smith",
                "role": "Freelance Crew",
                "event": "Wedding Reception",
                "date": "2024-11-20",
                "location": "Grand Hotel Ballroom",
                "status": "Confirmed"
            }
        ]
    }

# Route optimization endpoints
@app.get("/api/v1/logistics/routes")
async def get_delivery_routes():
    """Get optimized delivery routes"""
    return {
        "routes": [
            {
                "route_id": "R001",
                "driver": "Mike Wilson",
                "vehicle": "Van-001",
                "stops": [
                    {"location": "Conference Center A", "time": "09:00", "type": "Delivery"},
                    {"location": "Grand Hotel Ballroom", "time": "11:30", "type": "Setup"},
                    {"location": "Warehouse A", "time": "15:00", "type": "Return"}
                ],
                "total_distance": "45.2 km",
                "estimated_duration": "6 hours"
            }
        ]
    }

# Error handlers
@app.exception_handler(404)
async def not_found_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"detail": "Resource not found"}
    )

@app.exception_handler(500)
async def internal_error_handler(request, exc):
    logger.error(f"Internal server error: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"}
    )

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "message": "RentGuy AV Rental Platform API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health"
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        workers=1
    )
